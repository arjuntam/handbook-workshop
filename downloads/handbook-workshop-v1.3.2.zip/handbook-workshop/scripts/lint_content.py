#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""内容层 lint：构建前检查 content.py 的块选型、字段与素材引用。

用法：
  python3 lint_content.py <项目目录>            # 人或 Agent 看的中文报告
  python3 lint_content.py <项目目录> --json     # 机器可读
  python3 lint_content.py <项目目录> --strict   # 有提醒也返回非 0

检查分三级：
  [错误] 构建会出问题（块类型不存在、字段缺失、图片找不到、xref 断链）
  [提醒] 版式选错（违反 content-model.md 的选块规则，会返工）
  [提示] 可优化（未使用素材、目录名过长等）

只读，不修改任何文件。规则来源：references/content-model.md 与 SKILL.md 的设计硬约束。
"""
import argparse
import json
import re
import sys
from pathlib import Path

# 支持的块类型与必填字段（字段=必填，可选字段在渲染时都有 get 兜底）
REQUIRED = {
    "resources": ["items"],
    "china_map": ["cities"],
    "table": ["rows"],
    "lede": ["v"], "text": ["v"], "html": ["v"], "h3": ["v"], "quote": ["v"],
    "callout": ["v"], "warn": ["v"], "note": ["v"], "divider": [],
    "img": ["src"], "imgs": ["items"],
    "grid": ["items"], "pick": ["items"], "tabs": ["items"], "compare": ["items"],
    "roster": ["items"], "runsheet": ["items"], "steps": ["items"], "stats": ["items"],
    "total": ["items"], "metro": ["items"],
    "chat": ["bubbles"], "faq": ["items"], "scriptlib": ["data"], "moments": [],
}

NEEDS_ITEMS = {"imgs", "grid", "pick", "tabs", "compare", "roster", "runsheet",
               "steps", "stats", "total", "metro", "faq"}

IMAGE_KEYS = {
    "img": ["src"], "imgs": ["src"], "grid": ["img", "icon"], "pick": ["img", "icon"],
    "resources": ["cover"],
    "tabs": ["img"], "chat": ["avatar", "img"], "moments": ["avatar", "imgs", "comments"],
}


class Report:
    def __init__(self):
        self.rows = []

    def add(self, level, where, msg):
        self.rows.append({"level": level, "where": where, "msg": msg})

    def count(self, level):
        return sum(1 for r in self.rows if r["level"] == level)

    def dump(self, as_json=False):
        if as_json:
            print(json.dumps({
                "errors": self.count("错误"), "warns": self.count("提醒"),
                "hints": self.count("提示"), "items": self.rows,
            }, ensure_ascii=False, indent=2))
            return
        if not self.rows:
            print("内容层检查通过：没有错误，也没有版式提醒。")
            return
        order = ["错误", "提醒", "提示"]
        mark = {"错误": "✗", "提醒": "!", "提示": "·"}
        for lv in order:
            group = [r for r in self.rows if r["level"] == lv]
            if not group:
                continue
            print(f"\n[{lv}] {len(group)} 条")
            for r in group:
                print(f"  {mark[lv]} {r['where']}：{r['msg']}")
        print(f"\n合计：错误 {self.count('错误')} / 提醒 {self.count('提醒')} / 提示 {self.count('提示')}")


def load_content(proj):
    """导入项目 content.py，返回 (HERO, SECTIONS, ATTACHMENTS, XREF)。"""
    import importlib.util
    cf = proj / "content.py"
    if not cf.exists():
        raise SystemExit(f"找不到 {cf}")
    spec = importlib.util.spec_from_file_location("hb_content_lint", cf)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return (getattr(mod, "HERO", {}), getattr(mod, "SECTIONS", []),
            getattr(mod, "ATTACHMENTS", []), getattr(mod, "XREF", {}))


def walk_blocks(blocks, where):
    """展开 tabs 内嵌块，逐个产出 (block, 位置描述)。"""
    for i, b in enumerate(blocks or []):
        if not isinstance(b, dict):
            yield b, f"{where}.blocks[{i}]"
            continue
        yield b, f"{where}.blocks[{i}]"
        for j, it in enumerate(b.get("items") or []):
            if isinstance(it, dict) and isinstance(it.get("block"), dict):
                yield it["block"], f"{where}.blocks[{i}].items[{j}].block"


def collect_images(block):
    """返回块里引用到的图片文件名列表。"""
    t = block.get("t")
    keys = IMAGE_KEYS.get(t, [])
    out = []
    if "src" in keys and block.get("src"):
        out.append(block["src"])
    for it in block.get("items") or []:
        if not isinstance(it, dict):
            continue
        for k in ("img", "icon", "src", "cover"):
            if k in keys and it.get(k):
                out.append(it[k])
    for m in block.get("bubbles") or []:
        for k in ("avatar", "img"):
            if k in keys and m.get(k):
                out.append(m[k])
    if block.get("avatar") and "avatar" in keys:
        out.append(block["avatar"])
    if "imgs" in keys:
        out.extend(block.get("imgs") or [])
    for c in block.get("comments") or []:
        if isinstance(c, dict) and c.get("img"):
            out.append(c["img"])
    return out


def lint(proj, report):
    hero, sections, attachments, xref = load_content(proj)
    assets = proj / "assets"
    asset_names = {f.name for f in assets.iterdir() if f.is_file() and f.suffix.lower() in {".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".bmp", ".emf", ".wmf", ".tif", ".tiff"}} if assets.exists() else set()
    used_images = set()

    # ── 封面 ──
    if not hero.get("title"):
        report.add("错误", "HERO", "缺 title，封面无主标题")
    if not hero.get("desc"):
        report.add("提示", "HERO", "缺 desc，封面显得空")

    # ── 章节骨架 ──
    if not sections:
        report.add("错误", "SECTIONS", "为空，没有可翻页内容")
        return report
    ids = [s.get("id") for s in sections]
    dup = {i for i in ids if ids.count(i) > 1}
    if dup:
        report.add("错误", "SECTIONS", f"id 重复：{', '.join(sorted(dup))}；锚点与 xref 会串位")
    for s in sections:
        sid = s.get("id") or "(缺 id)"
        if not s.get("id"):
            report.add("错误", "某个 section", "缺 id")
        elif not re.fullmatch(r"[a-z0-9][a-z0-9-]*", s["id"]):
            report.add("提示", sid, "id 建议用英文小写 + 短横线，避免锚点转义")
        if not s.get("title"):
            report.add("错误", sid, "缺 title，正文页无大标题")
        if not s.get("blocks"):
            report.add("错误", sid, "blocks 为空，这一页会是白屏")
        if not s.get("nav"):
            report.add("错误", sid, "缺 nav，左侧目录无条目")
        elif len(s["nav"]) > 12:
            report.add("提醒", sid, f"nav「{s['nav']}」{len(s['nav'])} 字，目录容易折行，建议 ≤12 字")
        if not s.get("kicker"):
            report.add("提示", sid, "缺 kicker，标题上方小标签为空")
        if not s.get("group"):
            report.add("提示", sid, "缺 group，目录无法折叠分组")
        n_blocks = len(s.get("blocks") or [])
        if n_blocks > 5:
            report.add("提醒", sid, f"一页 {n_blocks} 个块，纵向过长；按「一个 h3 一页」拆开")

    # ── 块级检查 ──
    for s in sections:
        sid = s.get("id", "?")
        for b, where in walk_blocks(s.get("blocks"), sid):
            if not isinstance(b, dict):
                report.add("错误", where, "块不是 dict")
                continue
            t = b.get("t")
            if t not in REQUIRED:
                report.add("错误", where, f"未知块类型 t={t!r}；支持：{', '.join(sorted(REQUIRED))}")
                continue
            for k in REQUIRED[t]:
                if not b.get(k):
                    report.add("错误", where, f"{t} 缺必填字段 {k}")
            if t in NEEDS_ITEMS and not b.get("items"):
                report.add("错误", where, f"{t} 的 items 为空，渲染出来是空壳")
            for name in collect_images(b):
                used_images.add(name)
                if name not in asset_names:
                    report.add("错误", where, f"图片 {name} 不在 assets/ 里，页面会出破图")

            # 类型专属校验
            if t == "imgs" and b.get("layout", "grid") not in ("grid", "filmstrip", "focus", "coverflow"):
                report.add("错误", where, "imgs.layout 只能为 grid/filmstrip/focus（coverflow 旧值转焦点大图）")
            if t == "china_map":
                from china_map import validate
                try: validate(b)
                except ValueError as e: report.add("错误", where, str(e))
            if t == "resources":
                from portal_layout import safe_href
                for i,item in enumerate(b.get("items", [])):
                    if not item.get("title"):
                        report.add("错误", where, f"resources items[{i}] 缺 title")
                    for action in item.get("actions", []):
                        if not action.get("label"):
                            report.add("错误", where, "资料操作缺按钮名称")
                        if action.get("kind") != "pending":
                            try: safe_href(action.get("href", ""))
                            except ValueError as e: report.add("错误", where, str(e))
            if t == "table":
                rows = b.get("rows", [])
                widths = {len(r) for r in rows if isinstance(r, list)}
                if len(widths) != 1 or any(not isinstance(r, list) for r in rows):
                    report.add("错误", where, "table rows 必须为等宽二维数组")
                if b.get("head") and widths and len(b["head"]) not in widths:
                    report.add("错误", where, "table head 列数与 rows 不一致")
            if t == "stats":
                for i, it in enumerate(b.get("items") or []):
                    num = str(it.get("num", ""))
                    if not re.fullmatch(r"\d+(\.\d+)?", num):
                        report.add("错误", where, f"stats items[{i}].num={num!r} 不是数字，滚动动画会失效")
            if t == "compare":
                for i, it in enumerate(b.get("items") or []):
                    if not it.get("left") or not it.get("right"):
                        report.add("错误", where, f"compare items[{i}] 缺 left 或 right，对照缺一边")
            if t == "chat":
                for i, m in enumerate(b.get("bubbles") or []):
                    if m.get("role") not in ("sales", "client"):
                        report.add("提醒", where, f"chat bubbles[{i}].role={m.get('role')!r}，应为 sales / client")
                    if not m.get("text"):
                        report.add("错误", where, f"chat bubbles[{i}] 缺 text")
            if t == "faq":
                for i, it in enumerate(b.get("items") or []):
                    if not it.get("q"):
                        report.add("错误", where, f"faq items[{i}] 缺 q")
                    if not it.get("answer"):
                        report.add("提醒", where, f"faq items[{i}] 缺 answer，复制按钮没有可复制内容")
            if t == "scriptlib":
                for gi, g in enumerate(b.get("data") or []):
                    if not g.get("group"):
                        report.add("错误", where, f"scriptlib data[{gi}] 缺 group")
                    for row in g.get("blocks") or []:
                        if row.get("type") not in ("h", "say", "p"):
                            report.add("提醒", where, f"scriptlib data[{gi}] 行 type={row.get('type')!r}，只会当普通段落渲染")
                        if not row.get("text"):
                            report.add("错误", where, f"scriptlib data[{gi}] 有空文本行")
            if t == "moments" and not b.get("name"):
                report.add("提醒", where, "moments 缺 name，仿真朋友圈没有昵称")

            # ── 版式选型（content-model.md 的规则表） ──
            items = b.get("items") or []
            if t == "grid":
                cols = int(b.get("cols", 2) or 2)
                if not 1 <= cols <= 4:
                    report.add("错误", where, f"grid cols={cols} 超出 1–4")
                if len(items) > cols * 2:
                    report.add("提醒", where, f"grid 有 {len(items)} 项 / {cols} 列，纵向会拖长；≥{cols*2+1} 项建议 cut() 横切或 roster 表格")
                if len(items) >= 6 and all(it.get("title") and not it.get("body") and not it.get("img") for it in items):
                    report.add("提醒", where, f"grid {len(items)} 项同构短标题，改用 roster 表格更紧凑")
                for i, it in enumerate(items):
                    if not it.get("title") and not it.get("num"):
                        report.add("提醒", where, f"grid items[{i}] 既无 title 也无 num，卡片没有重点")
            if t == "pick" and not 1 <= len(items) <= 4:
                report.add("提醒", where, f"pick 有 {len(items)} 个选项，单选建议 2–4 个")
            if t == "tabs":
                if len(items) == 1:
                    report.add("提醒", where, "tabs 只有 1 个标签，等于多一次点击；直接放内嵌块")
                if len(items) > 6:
                    report.add("提醒", where, f"tabs 有 {len(items)} 个标签，标签栏会挤；拆成两页")
                for i, it in enumerate(items):
                    if not it.get("tab") and not it.get("title"):
                        report.add("错误", where, f"tabs items[{i}] 缺 tab，标签按钮没有文字")
                    inner = it.get("block")
                    if isinstance(inner, dict) and inner.get("t") == "scriptlib" and not inner.get("flat"):
                        report.add("提醒", where, f"tabs items[{i}] 内 scriptlib 未设 flat，标签里再套折叠＝两次点击")
            if t == "metro":
                for i, it in enumerate(items):
                    num = str(it.get("num", ""))
                    if len(num) > 3:
                        report.add("提醒", where, f"metro items[{i}].num={num!r} 过长，40px 圆圈会溢出；阶段名放 title")
                if b.get("navigate"):
                    report.add("提醒", where, "metro 开了 navigate，点站会直接跳章节，容易被当成 bug")
                default = int(b.get("default", 0) or 0)
                if default >= len(items):
                    report.add("错误", where, "metro default 超出 items 范围")
            if t == "roster":
                if len(items) < 4:
                    report.add("提醒", where, f"roster 只有 {len(items)} 行，少于 4 行用 grid 卡片更轻")
                head_n = len(b.get("head") or ["#", "事项", "执行", "负责", "时间"])
                if head_n > 5:
                    report.add("提示", where, f"roster head {head_n} 列，表格固定 5 列（# / 事项 / 执行 / 负责 / 时间），超出的表头不会渲染")
            if t == "runsheet" and len(items) < 5:
                report.add("提醒", where, f"runsheet 只有 {len(items)} 个节点，短流程用 steps 更直观")
            if t == "stats":
                cols = int(b.get("cols", 4) or 4)
                if len(items) > 5:
                    report.add("提醒", where, f"stats 有 {len(items)} 张数字卡，一屏最多 5 张")
                elif cols < len(items):
                    report.add("提示", where, f"stats cols={cols} 小于 {len(items)} 张卡，会换行")
            if t in ("text", "lede") and len(str(b.get("v", ""))) > 220:
                report.add("提醒", where, f"{t} 有 {len(str(b.get('v','')))} 字，单段过长；拆段或改 callout")
            if t == "quote" and b.get("reveal") and not b.get("label"):
                report.add("提示", where, "quote reveal 缺 label，折叠条上只有按钮没提示")

    # ── 交叉引用 ──
    id_set = set(ids)
    for src, targets in (xref or {}).items():
        if src not in id_set:
            report.add("错误", "XREF", f"源章节 {src} 不存在")
        for tg in targets or []:
            if tg not in id_set:
                report.add("错误", f"XREF[{src}]", f"指向不存在的章节 {tg}")
            elif tg == src:
                report.add("提醒", f"XREF[{src}]", "指向自己，chip 点了没反应")

    # ── 附件 ──
    for i, a in enumerate(attachments or []):
        kind = a.get("kind", "local")
        if kind not in ("local", "netdisk", "link", "pending"):
            report.add("错误", f"ATTACHMENTS[{i}]", f"kind={kind!r} 不支持，应为 local/netdisk/link/pending")
        if kind == "pending" and a.get("path"):
            report.add("提示", f"ATTACHMENTS[{i}]", "标了 pending 但填了 path，页面仍显示「链接待补」")
        if kind == "local":
            p = Path(a.get("path", ""))
            full = p if p.is_absolute() else proj / p
            if not full.exists():
                report.add("错误", f"ATTACHMENTS[{i}]", f"本地附件不存在：{a.get('path')}")

    # ── 未使用素材 ──
    if asset_names:
        unused = sorted(asset_names - used_images - {"logo.png", "logo-white.png", "cover-wave.png"})
        if unused:
            preview = "、".join(unused[:6]) + ("…" if len(unused) > 6 else "")
            report.add("提示", "assets/", f"{len(unused)} 个图片未被引用（会打进产物）：{preview}")

    return report


def main():
    ap = argparse.ArgumentParser(description="content.py 内容层 lint")
    ap.add_argument("project", help="手册项目目录（含 content.py 与 assets/）")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    ap.add_argument("--strict", action="store_true", help="有提醒也返回非 0")
    args = ap.parse_args()
    proj = Path(args.project).expanduser().resolve()
    rep = lint(proj, Report())
    rep.dump(args.json)
    if rep.count("错误"):
        sys.exit(1)
    if args.strict and rep.count("提醒"):
        sys.exit(2)


if __name__ == "__main__":
    main()
