"""L19 中国城市分布地图：沿用提供的底图，城市数据独立配置。"""
import html,json,math
from pathlib import Path
from itertools import count
_IDS=count(1)
ASSETS=Path(__file__).resolve().parent.parent/'assets'/'maps'

def validate(block):
    cities=block.get('cities',[])
    if not isinstance(cities,list) or not cities:raise ValueError('china_map.cities 必须是非空列表')
    names=set()
    for city in cities:
        if not isinstance(city,dict) or not all(city.get(k) for k in ('name','province','region')):raise ValueError('地图城市须包含 name / province / region')
        if city['name'] in names:raise ValueError('地图城市名称不可重复')
        names.add(city['name'])
        x,y=city.get('lng'),city.get('lat')
        if isinstance(x,bool) or isinstance(y,bool) or not isinstance(x,(int,float)) or not isinstance(y,(int,float)) or not (73<=x<=136 and 17.2<=y<=54.6):raise ValueError('地图经纬度缺失或超出底图范围，不自动猜测城市坐标')
    return cities

def render(block):
    cities=validate(block);base=json.loads((ASSETS/'china-base.json').read_text());uid='china-map-'+str(next(_IDS));esc=lambda s:html.escape(str(s),quote=True)
    regions=list(dict.fromkeys(x['region'] for x in cities));province_names={x['province'] for x in cities}
    land=''.join('<path class="cm-land'+(' is-covered' if any(x['name'].startswith(n) for n in province_names) else '')+'" d="'+x['d']+'"/>' for x in base['provinces'])
    def xy(lon,lat):
        merc=lambda y:math.log(math.tan(math.pi/4+math.radians(y)/2))*180/math.pi
        return (lon-73)*660/63,(merc(54.6)-merc(lat))*660/63
    dots=[];buttons=[]
    for i,city in enumerate(cities):
        x,y=xy(city['lng'],city['lat']);label=esc(city['name']);region=esc(city['region']);detail=esc(city.get('detail',''))
        dots.append(f'<g class="cm-point" data-city="{i}" data-region="{region}" tabindex="0" role="button" aria-label="选择{label}" aria-pressed="false"><title>{label}</title><circle class="cm-halo" cx="{x:.1f}" cy="{y:.1f}" r="8"/><circle class="cm-dot" cx="{x:.1f}" cy="{y:.1f}" r="3.5"/><text class="cm-label" x="{x:.1f}" y="{y-9:.1f}">{label}</text></g>')
        buttons.append(f'<button type="button" class="cm-city" data-city="{i}" data-region="{region}" data-detail="{detail}" aria-pressed="false">{label}</button>')
    filters='<button type="button" data-region-filter="" aria-pressed="true">全部</button>'+''.join(f'<button type="button" data-region-filter="{esc(r)}" aria-pressed="false">{esc(r)}</button>' for r in regions)
    note=esc(block.get('note','点位用于分布示意，请以对应资料的数据日期与口径为准。'))
    return f'''<div class="china-map-component" id="{uid}" role="group" aria-label="{esc(block.get('title','中国城市分布'))}">
<div class="cm-heading"><span><b class="cm-total">{len(cities)}</b> 个城市点位</span><span class="cm-data-note">{note}</span></div>
<div class="cm-filters" role="group" aria-label="按区域筛选城市">{filters}</div>
<div class="cm-layout"><div class="cm-maparea"><div class="cm-mapframe" tabindex="0" role="group" aria-label="城市地图：方向键平移，加减键缩放，Home 复位"><svg class="cm-map" viewBox="0 0 660 503" role="group" aria-label="中国城市分布，含南海诸岛插图">{land}{base['inset_svg']}<g class="cm-points">{''.join(dots)}</g></svg></div>
<div class="cm-tools"><span>拖动平移 · Ctrl/⌘ + 滚轮缩放</span><div><button type="button" data-map-action="out" aria-label="缩小地图">−</button><output class="cm-zoom">100%</output><button type="button" data-map-action="in" aria-label="放大地图">+</button><button type="button" data-map-action="reset">复位</button></div></div></div>
<div class="cm-listpanel"><p class="cm-selection" role="status" aria-live="polite">悬停或选择城市，查看点位说明。</p><div class="cm-cities" role="group" aria-label="城市列表">{''.join(buttons)}</div><p class="cm-filter-count">全部 · {len(cities)} 个点位</p></div></div>
<p class="cm-source">底图沿用城市合伙人资料现有素材 · 原资料标注 GS(2022)4309号 · 含南海诸岛插图</p></div>'''

CSS=r'''
.china-map-component{border:1px solid var(--border);border-radius:1rem;background:var(--surface);padding:1.25rem;min-inline-size:0;margin-block:1.5rem}
.cm-heading{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.75rem;align-items:baseline;color:var(--brand)}
.cm-total{font-size:2rem;font-weight:500;margin-inline-end:.375rem}.cm-data-note{color:var(--muted);font-size:.8125rem;max-inline-size:36rem}
.cm-layout{display:flex;flex-wrap:wrap;gap:1.25rem}.cm-maparea{flex:2 1 24rem;min-inline-size:0}.cm-listpanel{flex:1 1 13rem;min-inline-size:0}
.cm-mapframe{overflow:hidden;background:#fff;border:1px solid var(--border);border-radius:.75rem;cursor:grab;touch-action:none}.cm-mapframe.is-dragging{cursor:grabbing}
.cm-map{display:block;inline-size:100%;aspect-ratio:660/503;overflow:hidden;user-select:none}
.cm-land{fill:#F0F3F7;stroke:#B8C5D3;stroke-width:.65;stroke-linejoin:round}.cm-land.is-covered{fill:var(--accent-soft);stroke:var(--accent)}
.cm-inset-bg{fill:#fff;stroke:#B8C5D3;stroke-width:.7}.cm-inset-line{fill:none;stroke:#8799AC;stroke-width:.8}.cm-inset-land{fill:#EEF2F6;stroke:#9CABB9;stroke-width:.5}.cm-inset-t{font-size:6.5px;fill:#526579;text-anchor:middle}
.cm-point{cursor:pointer;outline:none}.cm-halo{fill:var(--accent);opacity:.15}.cm-dot{fill:var(--accent);stroke:#fff;stroke-width:1.6;vector-effect:non-scaling-stroke}
.cm-label{font-family:MiSans,sans-serif;font-size:10px;font-weight:430;fill:var(--brand);text-anchor:middle;paint-order:stroke;stroke:#fff;stroke-width:3;stroke-linejoin:round;opacity:0;pointer-events:none}
.cm-point:hover .cm-label,.cm-point:focus-visible .cm-label,.cm-point[aria-pressed=true] .cm-label{opacity:1}
.cm-point:focus-visible .cm-halo,.cm-point[aria-pressed=true] .cm-halo{opacity:.35;stroke:var(--accent);stroke-width:1;vector-effect:non-scaling-stroke}
.cm-point.is-filtered{display:none}
.cm-filters,.cm-tools,.cm-tools>div{display:flex;align-items:center;flex-wrap:wrap;gap:.5rem}.cm-filters{margin-block:1rem}.cm-filters button,.cm-city,.cm-tools button{font:inherit;font-size:.8125rem;font-weight:330;padding:.5rem .75rem;border:1px solid var(--border);border-radius:.5rem;background:var(--surface);color:var(--brand);cursor:pointer;min-block-size:2.5rem}
.cm-filters button[aria-pressed=true],.cm-city[aria-pressed=true]{background:var(--accent-soft);border-color:var(--accent);font-weight:430;box-shadow:inset 3px 0 0 var(--accent)}
.cm-cities{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,5rem),1fr));gap:.375rem;max-block-size:20rem;overflow:auto;padding:.25rem}.cm-city[hidden]{display:none}
.cm-selection{font-size:.9375rem;line-height:1.7;color:var(--brand);margin:0 0 1rem;min-block-size:4rem}.cm-filter-count,.cm-source{font-size:.75rem;color:var(--muted);line-height:1.7;margin-block:.75rem 0}
.cm-tools{justify-content:space-between;margin-block-start:.75rem}.cm-tools>span{font-size:.75rem;color:var(--muted)}.cm-zoom{font-size:.8125rem;color:var(--muted);min-inline-size:3rem;text-align:center}
'''

JS=r'''
(function(){document.querySelectorAll('.china-map-component').forEach(root=>{
 const frame=root.querySelector('.cm-mapframe'),svg=root.querySelector('svg'),points=[...root.querySelectorAll('.cm-point')],cities=[...root.querySelectorAll('.cm-city')],filters=[...root.querySelectorAll('[data-region-filter]')];
 const info=root.querySelector('.cm-selection'),status=root.querySelector('.cm-filter-count'),zoom=root.querySelector('.cm-zoom');
 let scale=1,x=0,y=0,drag=null,suppress=0;
 function paint(){const w=660/scale,h=503/scale;x=Math.max(0,Math.min(660-w,x));y=Math.max(0,Math.min(503-h,y));svg.setAttribute('viewBox',[x,y,w,h].join(' '));zoom.textContent=Math.round(scale*100)+'%';root.querySelector('[data-map-action=out]').disabled=scale===1;root.querySelector('[data-map-action=in]').disabled=scale===4;}
 function zoomAt(f,cx=.5,cy=.5){const px=x+cx*660/scale,py=y+cy*503/scale;scale=Math.max(1,Math.min(4,scale*f));x=px-cx*660/scale;y=py-cy*503/scale;paint();}
 function pick(i){points.forEach((p,k)=>p.setAttribute('aria-pressed',String(k===i)));cities.forEach((c,k)=>c.setAttribute('aria-pressed',String(k===i)));const c=cities[i];info.textContent=c.textContent+' · '+c.dataset.region+(c.dataset.detail?' — '+c.dataset.detail:'');}
 points.forEach((p,i)=>{p.addEventListener('click',e=>{if(Date.now()<suppress)return;e.stopPropagation();pick(i)});p.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();pick(i)}})});
 cities.forEach((c,i)=>c.addEventListener('click',()=>{pick(i);if(scale>1){const dot=points[i].querySelector('.cm-dot');x=Number(dot.getAttribute('cx'))-330/scale;y=Number(dot.getAttribute('cy'))-251.5/scale;paint();}}));
 filters.forEach(b=>b.addEventListener('click',()=>{const region=b.dataset.regionFilter;filters.forEach(f=>f.setAttribute('aria-pressed',String(f===b)));let n=0;cities.forEach((c,i)=>{const on=!region||c.dataset.region===region;c.hidden=!on;points[i].classList.toggle('is-filtered',!on);points[i].setAttribute('tabindex',on?'0':'-1');if(on)n++;});info.textContent='悬停或选择城市，查看点位说明。';points.forEach(p=>p.setAttribute('aria-pressed','false'));cities.forEach(c=>c.setAttribute('aria-pressed','false'));status.textContent=(region||'全部')+' · '+n+' 个点位';}));
 root.querySelectorAll('[data-map-action]').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.mapAction==='reset'){scale=1;x=0;y=0;paint();}else zoomAt(b.dataset.mapAction==='in'?1.4:1/1.4);}));
 frame.addEventListener('wheel',e=>{if(!e.ctrlKey&&!e.metaKey)return;e.preventDefault();const r=frame.getBoundingClientRect();zoomAt(Math.exp(-e.deltaY*.002),(e.clientX-r.left)/r.width,(e.clientY-r.top)/r.height);},{passive:false});
 frame.addEventListener('pointerdown',e=>{if(e.button!==0)return;drag={id:e.pointerId,startX:e.clientX,startY:e.clientY,x,y,moved:false};});
 frame.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.startX,dy=e.clientY-drag.startY;if(Math.hypot(dx,dy)>5){drag.moved=true;frame.setPointerCapture(e.pointerId);frame.classList.add('is-dragging');}if(drag.moved){const r=frame.getBoundingClientRect();x=drag.x-dx*660/(r.width*scale);y=drag.y-dy*503/(r.height*scale);paint();}});
 function end(){if(!drag)return;const d=drag;drag=null;if(frame.hasPointerCapture(d.id))frame.releasePointerCapture(d.id);frame.classList.remove('is-dragging');if(d.moved)suppress=Date.now()+300;}
 frame.addEventListener('pointerup',end);frame.addEventListener('pointercancel',end);frame.addEventListener('lostpointercapture',end);
 frame.addEventListener('keydown',e=>{let handled=true;if(e.key==='+'||e.key==='=')zoomAt(1.4);else if(e.key==='-')zoomAt(1/1.4);else if(e.key==='Home'){scale=1;x=0;y=0;paint();}else if(e.key.startsWith('Arrow')){const step=35/scale;if(e.key==='ArrowLeft')x-=step;else if(e.key==='ArrowRight')x+=step;else if(e.key==='ArrowUp')y-=step;else if(e.key==='ArrowDown')y+=step;paint();}else handled=false;if(handled){e.preventDefault();e.stopPropagation();}});paint();
});})();
'''
