"""无封面素材时的默认流体感封面。CSS 合成动画，不声称物理流体模拟。"""
MARKUP = '''<div class="cover-fluid" aria-hidden="true"><div class="flow-field flow-one"></div><div class="flow-field flow-two"></div><div class="flow-field flow-three"></div><div class="flow-sweep"></div></div>
<button type="button" class="cover-motion-toggle">暂停动态</button>'''
CSS = r'''
/* Fluid cover baseline · restrained blue, neutral ink, slow atmospheric motion. */
:root{--flow-paper:#f7fbff;--flow-one:#bddcf5;--flow-two:#d7e8fa;--flow-three:#e3f0f6;
 --flow-wash:rgba(255,255,255,.8);--flow-clear:rgba(255,255,255,0);--cover-ink:#142536;
 --cover-muted:#526579;--flow-ease:cubic-bezier(.45,0,.55,1)}
.cover.cover-fluid-mode{isolation:isolate;background:var(--flow-paper);overflow:auto;padding:5rem 2rem}
.cover-fluid-mode::before{display:none}
.cover-fluid{position:fixed;inset:0;z-index:-1;overflow:clip;pointer-events:none;background:var(--flow-paper)}
.flow-field{position:absolute;inline-size:100vmax;block-size:90vmax;pointer-events:none;opacity:.72}
.flow-one{inset-block-start:-58vmax;inset-inline-start:-24vmax;
 background:radial-gradient(ellipse at 50% 50%,var(--flow-one) 0%,var(--flow-clear) 65%);transform:rotate(-18deg)}
.flow-two{inset-block-end:-48vmax;inset-inline-end:-36vmax;
 background:radial-gradient(ellipse at 50% 50%,var(--flow-two) 0%,var(--flow-clear) 64%);transform:rotate(24deg)}
.flow-three{inset-block-start:-8vmax;inset-inline-end:-70vmax;
 background:radial-gradient(ellipse at 45% 50%,var(--flow-three) 0%,var(--flow-clear) 64%)}
.flow-sweep{position:absolute;inset:-35%;background:linear-gradient(118deg,var(--flow-clear) 34%,var(--flow-wash) 48%,var(--flow-clear) 61%);transform:translateX(-14%) rotate(-8deg)}
.cover-fluid-mode .cover-inner{background:transparent;border:0;border-radius:0;backdrop-filter:none;box-shadow:none;
 max-inline-size:62rem;padding:0;text-align:center;position:relative;margin:auto}
.cover-fluid-mode .cover-logo{block-size:var(--logo-cover-height,48px);inline-size:auto;max-inline-size:18rem;margin:0 auto 2.75rem;object-fit:contain}
.cover-fluid-mode .cover-brand-text{font-size:1rem;letter-spacing:.04em;margin-block-end:2.5rem}
.cover-fluid-mode .cover-kicker{font-size:.8125rem;letter-spacing:.12em;font-weight:400;color:var(--accent);margin-block-end:1.5rem}
.cover-fluid-mode .cover-kicker::before,.cover-fluid-mode .cover-kicker::after{display:none}
.cover-fluid-mode h1{font-size:clamp(2.6rem,2rem + 2.5vw,4.5rem);font-weight:var(--cover-title-weight,500);color:var(--cover-ink);line-height:1.17;letter-spacing:-.025em;
 max-inline-size:19ch;margin:0 auto 1.75rem;overflow-wrap:anywhere;text-wrap:balance}
.cover-fluid-mode p{font-weight:var(--cover-description-weight,330);font-size:1.125rem;line-height:1.85;color:var(--cover-muted);max-inline-size:40rem;margin:0 auto 1.5rem}
.cover-fluid-mode .cover-meta{font-size:.8125rem;color:var(--cover-muted);letter-spacing:.025em;margin-block-end:2.25rem}
.cover-fluid-mode .cover-start{background:var(--cover-ink);box-shadow:none;border-radius:.875rem;font-size:1rem;padding:.875rem 1.75rem;min-block-size:3.25rem}
.cover-fluid-mode .cover-start:active{transform:scale(.985)}
.cover-motion-toggle{position:fixed;inset-block-start:1.25rem;inset-inline-end:1.5rem;border:1px solid var(--border);border-radius:99px;
 background:var(--surface);color:var(--muted);font:inherit;font-size:.8125rem;padding:.5rem .875rem;cursor:pointer;z-index:2}
@media(hover:hover) and (pointer:fine){.cover-fluid-mode .cover-start:hover{background:var(--accent);transform:translateY(-1px)}}
@media(prefers-reduced-motion:no-preference){
 .flow-one{animation:flowDriftOne 24s var(--flow-ease) infinite alternate}
 .flow-two{animation:flowDriftTwo 29s var(--flow-ease) infinite alternate}
 .flow-three{animation:flowDriftThree 32s var(--flow-ease) infinite alternate}
 .flow-sweep{animation:flowSweep 26s var(--flow-ease) infinite alternate}
}
.cover-fluid-mode.flow-paused .cover-fluid>*{animation-play-state:paused}
@keyframes flowDriftOne{from{transform:translate3d(-5%,-2%,0) rotate(-18deg) scale(1)}to{transform:translate3d(18%,16%,0) rotate(12deg) scale(1.14)}}
@keyframes flowDriftTwo{from{transform:translate3d(6%,0,0) rotate(24deg) scale(1)}to{transform:translate3d(-22%,-14%,0) rotate(-8deg) scale(1.12)}}
@keyframes flowDriftThree{from{transform:translate3d(4%,-6%,0)}to{transform:translate3d(-28%,15%,0)}}
@keyframes flowSweep{from{transform:translateX(-14%) rotate(-8deg)}to{transform:translateX(18%) rotate(8deg)}}
@media(prefers-reduced-motion:reduce){.cover-motion-toggle{display:none}}
@media(max-width:600px){.cover.cover-fluid-mode{padding:5rem 1.5rem 3rem}.cover-fluid-mode .cover-logo{block-size:2.5rem;max-inline-size:14rem;margin-block-end:2rem}.cover-fluid-mode p{font-size:1rem}.cover-motion-toggle{inset-inline-end:1rem;inset-block-start:1rem}}
'''
JS = r'''
(function(){
 const cover=document.querySelector('.cover-fluid-mode'),button=cover?.querySelector('.cover-motion-toggle');
 if(!cover||!button)return;
 let paused=false;
 function sync(){cover.classList.toggle('flow-paused',paused||document.hidden);button.textContent=paused?'开启动效':'暂停动态';}
 button.addEventListener('click',()=>{paused=!paused;sync();});
 document.addEventListener('visibilitychange',sync);sync();
})();
'''

SKIN_CSS = r'''
/* Shared skin for existing handbook HTML; all content structure remains editable upstream. */
body{background:var(--bg);color:var(--text)}
.cover.cover-plain-mode{background:var(--bg)}
.brand-logo{block-size:var(--logo-header-height,28px);inline-size:auto;max-inline-size:11rem;object-fit:contain}
.cover-logo{block-size:var(--logo-cover-height,48px);inline-size:auto;max-inline-size:18rem;object-fit:contain}
.card,.pick-card,.tabset,.cmp-card,.rt,.rs{border-color:var(--border)}
.card,.pick-card{background:var(--surface)}
.card-title,.tab-title,.cmp-head h4{color:var(--brand)}
.card-body,.body-text,.sl-p,.cmp-side p,.rs-n{color:var(--text)}
.nav-link,.sec-sub,.card-sub,.topbar-title{color:var(--muted)}
.nav-link:hover,.nav-link.target-current,.cmp-side,.tab-head{background:var(--accent-soft)}
.tab-head{color:var(--brand)}
.tab-head.on{background:var(--accent);border-color:var(--accent);color:white}
.callout-blue{background:var(--accent-soft);border-color:var(--border);color:var(--brand)}
.stat-card{background:linear-gradient(150deg,var(--surface),var(--accent-soft))}
.pagerbar{background:var(--bg)}.pagerbar::before{background:linear-gradient(180deg,transparent,var(--bg))}
.pick-card.on{background:var(--selected-bg);border-color:var(--selected-border);box-shadow:var(--selected-shadow)}
.pick-card.on .card-title{color:var(--selected-text)}
:where(a,button,summary,input,[tabindex]):focus-visible{outline:3px solid var(--focus);outline-offset:3px}
.cover[data-surface=dark]{--cover-ink:#fff;--cover-muted:#dce5ef;--flow-paper:#102237;--flow-one:#254d72;--flow-two:#23516c;--flow-three:#343d65;--flow-wash:rgba(100,150,200,.10)}
.cover[data-surface=dark] .cover-inner{background:#102237;color:#fff}
.cover.cover-fluid-mode[data-surface=dark] .cover-inner{background:transparent}
.cover[data-surface=dark] .cover-kicker{color:#a6d5ff}
.cover[data-surface=dark] .cover-start{background:#fff;color:#142536}
.topbar[data-surface=dark]{background:#102237;color:#fff}
.topbar[data-surface=dark] .topbar-title{color:#dce5ef}
'''
