#!/usr/bin/env python3
"""核对对象去向和原文保留；不以映射覆盖率冒充内容准确率。读取 JSON，不执行提取内容。"""
import hashlib
import argparse
import json
import re
from collections import Counter
from pathlib import Path

VISIBLE = {'v','text','title','nav','group','kicker','subtitle','desc','body','sub','q','answer','principle',
           'label','note','num','suffix','name','time','who','own','left','right','cap','caption','tag','tab',
           'head','rows','data','blocks','items','copy','bubbles','sep'}


def strings(value):
    if isinstance(value,str):
        yield value
    elif isinstance(value,list):
        for v in value: yield from strings(v)
    elif isinstance(value,dict):
        for k,v in value.items():
            if k in VISIBLE: yield from strings(v)


def norm(v):
    return re.sub(r'\s+', '', v)


def audit(project):
    project = Path(project)
    doc = json.loads((project/'source.json').read_text(encoding='utf-8'))
    plan = json.loads((project/'content.json').read_text(encoding='utf-8'))
    objects = {it['id']:it for p in doc['pages'] for it in p['items']}
    issues, refs = [], {}
    def add(level, ref, message): issues.append(dict(level=level, ref=ref, message=message))
    if plan.get('source_sha256') != doc['source_sha256']:
        add('error', 'source', '原稿指纹不一致')
    def walk(v):
        if isinstance(v,dict):
            for ref in v.get('source_refs',[]):
                if ref not in objects:
                    add('error',ref,'引用不存在的来源对象')
                # Section-level refs apply to heading fields only, not unrelated descendant blocks.
                text = {k:x for k,x in v.items() if k not in ('blocks','items')} if 'id' in v else v
                refs.setdefault(ref,[]).append(text)
            for k,x in v.items():
                if k != 'source_refs': walk(x)
        elif isinstance(v,list):
            for x in v: walk(x)
    walk(plan.get('sections',[]))
    exclusions = {r['ref']:r for r in plan.get('exclusions',[])}
    reviews = {r['ref']:r for r in plan.get('reviews',[])}
    transforms = {r['ref']:r for r in plan.get('transformations',[])}
    for r in [*exclusions.values(), *reviews.values(), *transforms.values()]:
        if r['ref'] not in objects: add('error',r['ref'],'处理清单引用不存在的对象')
        if not r.get('reason','').strip(): add('error',r['ref'],'缺处理原因')
    counts = Counter()
    for ref,it in objects.items():
        if ref in refs:
            counts['mapped'] += 1
            vs = refs[ref]
            original = it.get('text','')
            if it['kind'] in ('text','notes') and norm(original) not in norm(''.join(s for v in vs for s in strings(v))):
                # Rewritten text must have a separate review record. It remains a warning.
                if ref in transforms:
                    add('warning',ref,'原文已改写，需依据 transformation 原因逐项复核；脚本不能证明语义等价')
                else:
                    add('error',ref,'映射存在但原文不完整或改写未说明')
            elif it['kind'] == 'table':
                expected = Counter(norm(c) for row in it['data'] for c in row if norm(c))
                rendered = Counter(norm(c) for v in vs if v.get('t')=='table' for row in v.get('rows',[]) for c in row if norm(c))
                rendered.update(norm(c) for v in vs if v.get('t')=='table' for c in v.get('head',[]) if norm(c))
                if expected-rendered:
                    if ref in transforms: add('warning',ref,'表格已重组，原表单元格需逐项复核')
                    else: add('error',ref,'表格映射存在但有单元格内容缺失；重组需说明 transformation')
            elif it['kind'] == 'image':
                def filenames(v):
                    if isinstance(v,dict):
                        for k,x in v.items():
                            if k in ('src','img','icon','avatar','cover') and isinstance(x,str): yield x
                            elif k=='imgs' and isinstance(x,list): yield from x
                            elif k not in ('source_refs',): yield from filenames(x)
                    elif isinstance(v,list):
                        for x in v: yield from filenames(x)
                names = [n for v in vs for n in filenames(v)]
                if it['file'] not in names: add('error',ref,'原图片未被实际引用；替换图请明确记录并保留原图供复核')
                asset=project/'assets'/it['file']
                if not asset.is_file(): add('error',ref,'图片素材不存在')
                elif it.get('sha256') and hashlib.sha256(asset.read_bytes()).hexdigest()!=it['sha256']:
                    add('error',ref,'图片素材指纹改变；请核对原图，不把错图当作保留成功')
            if it['kind'] in ('unsupported','image-error'):
                add('warning',ref,'未知对象虽有映射，仍需确认视觉关系与内容')
        elif ref in exclusions:
            counts['excluded'] += 1
        elif ref in reviews:
            counts['pending'] += 1
            add('warning',ref,'待处理：'+reviews[ref].get('reason',''))
        else:
            counts['missing'] += 1
            add('error',ref,'来源对象没有正文去向，也没有明确排除/待处理记录')
        for issue in it.get('issues',[]):
            if ref not in exclusions:
                add('warning',ref,issue)
    for note in doc.get('limitations',[]):
        add('warning','source',note)
    # A review item is pending regardless of whether an editor later maps its object.
    for ref,r in reviews.items():
        if ref in refs: add('warning',ref,'已映射但仍在 reviews；复核后移除该条')
    return dict(schema_version='1.0', objects=len(objects), counts=dict(counts),
                errors=sum(i['level']=='error' for i in issues), warnings=sum(i['level']=='warning' for i in issues),
                status='blocked' if any(i['level']=='error' for i in issues) else 'review-required', issues=issues,
                boundary='只核对提取清单、原文和素材引用，不证明原稿已被完整提取或重组正确。')


def write_source_map(project):
    project=Path(project)
    doc=json.loads((project/'source.json').read_text(encoding='utf-8'))
    plan=json.loads((project/'content.json').read_text(encoding='utf-8'))
    refs={}
    def walk(v,sid):
        if isinstance(v,dict):
            for ref in v.get('source_refs',[]): refs.setdefault(ref,set()).add(sid)
            for k,x in v.items():
                if k!='source_refs': walk(x,sid)
        elif isinstance(v,list):
            for x in v: walk(x,sid)
    for sec in plan['sections']: walk(sec,sec['id'])
    rows=['对象ID\t原稿页\t类型\t目标章节']
    for page in doc['pages']:
        for it in page['items']:
            rows.append(f'{it["id"]}\t{page["page"]}\t{it["kind"]}\t{",".join(sorted(refs.get(it["id"],[]))) or "待处理"}')
    (project/'来源映射.tsv').write_text('\n'.join(rows),encoding='utf-8-sig')


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('project')
    ap.add_argument('--strict', action='store_true')
    args=ap.parse_args()
    result=audit(args.project)
    print(json.dumps(result,ensure_ascii=False,indent=2))
    raise SystemExit(1 if result['errors'] else (2 if args.strict and result['warnings'] else 0))

if __name__=='__main__': main()
