"""Author-only, color-aware expression comparison. Hover never commits a choice."""
from html import escape

CHOICES={
 'professional':dict(name='简约阅读',summary='清楚、克制，方便连续阅读与快速回查。',uses='操作手册、制度规范、知识资料',detail='让内容成为重点。标题、正文和图片各有清楚的位置，卡片与表格保持规整，适合经常打开、需要仔细阅读的资料。',features=['图片与文字分区，信息图完整展示','卡片并列、层次清楚，装饰较少','正文节奏稳定，适合长文和日常查阅']),
 'brand':dict(name='品牌展陈',summary='更有主视觉和展示感，适合讲解与呈现。',uses='培训开场、会议介绍、案例展示',detail='在同一套左右结构中强化第一眼的吸引力。使用更醒目的标题、主色光感和卡片主次；氛围照片可渐变融入背景，保留正文、表格的阅读能力。',features=['大标题、照片渐变融合，强化开场','行动卡一主两辅，重要信息更突出','轻入场与局部光感，可暂停并减少动态'])
}


def thumbnail(key,prefix):
    """A schematic of the same scene, using live project colors, not a tinted photograph."""
    e=escape;uid='v2-'+prefix+'-'+key
    start=f'<svg class="v2-expression-art" viewBox="0 0 640 360" role="img" aria-label="{e(CHOICES[key]["name"])}版式示意：同一份会议开场与三项行动"><defs><linearGradient id="{uid}-fade"><stop offset="0" stop-color="var(--surface)"/><stop offset=".45" stop-color="var(--surface)" stop-opacity=".97"/><stop offset="1" stop-color="var(--surface)" stop-opacity="0"/></linearGradient><linearGradient id="{uid}-bottom" x2="0" y2="1"><stop offset="0" stop-color="var(--surface)" stop-opacity="0"/><stop offset="1" stop-color="var(--surface)"/></linearGradient><clipPath id="{uid}-clip"><rect width="640" height="360" rx="10"/></clipPath></defs><g clip-path="url(#{uid}-clip)"><rect width="640" height="360" fill="var(--surface)"/><rect width="640" height="24" fill="var(--bg)"/><rect x="12" y="9" width="37" height="6" rx="2" fill="var(--accent)"/><rect x="0" y="24" width="66" height="336" fill="var(--bg)"/><rect x="8" y="53" width="48" height="15" rx="3" fill="var(--accent-soft)"/><path d="M15 59h30M15 89h30M15 113h30M15 137h30M15 161h30" stroke="var(--muted)" stroke-width="3" opacity=".6"/>'
    if key=='professional':
        body=f'<rect x="88" y="44" width="530" height="208" rx="8" fill="var(--surface)" stroke="var(--border)"/><image href="assets/v2-examples/conference.jpg" x="358" y="62" width="242" height="166" preserveAspectRatio="xMidYMid slice"/><text x="108" y="78" fill="var(--accent)" font-size="12">联合启动会</text><text x="108" y="117" fill="var(--brand)" font-size="28" font-weight="650">从共识到行动</text><text x="108" y="155" fill="var(--text)" font-size="13">讲清价值，明确各自行动。</text><text x="108" y="179" fill="var(--muted)" font-size="12">保留完整说明，方便日后回查。</text>'
        for i,title in enumerate(('讲清价值','明确分工','安排跟进')):
            x=88+i*181
            body+=f'<rect x="{x}" y="270" width="168" height="72" rx="7" fill="var(--surface)" stroke="var(--border)"/><text x="{x+14}" y="300" font-size="15" fill="var(--brand)" font-weight="600">{title}</text><path d="M{x+14} 318h126" stroke="var(--border)" stroke-width="4"/>'
    else:
        body=f'<rect x="66" y="24" width="574" height="336" fill="var(--accent-soft)"/><image href="assets/v2-examples/conference.jpg" x="260" y="24" width="380" height="230" preserveAspectRatio="xMidYMid slice"/><rect x="66" y="24" width="574" height="240" fill="url(#{uid}-fade)"/><rect x="66" y="186" width="574" height="84" fill="url(#{uid}-bottom)"/><text x="94" y="65" fill="var(--accent)" font-size="12">联合启动会</text><text x="94" y="119" fill="var(--brand)" font-size="38" font-weight="750">从共识</text><text x="94" y="166" fill="var(--accent)" font-size="38" font-weight="750">到行动</text><text x="96" y="200" fill="var(--text)" font-size="12">讲清价值，明确各自行动。</text><rect x="88" y="246" width="254" height="96" rx="9" fill="var(--accent)"/><text x="104" y="281" fill="#ffffff" font-size="23" font-weight="700">01</text><text x="104" y="318" fill="#ffffff" font-size="17" font-weight="600">讲清价值</text><rect x="355" y="246" width="263" height="42" rx="8" fill="var(--surface)"/><text x="373" y="273" fill="var(--brand)" font-size="15" font-weight="600">02　明确分工</text><rect x="355" y="300" width="263" height="42" rx="8" fill="var(--surface)"/><text x="373" y="327" fill="var(--brand)" font-size="15" font-weight="600">03　安排跟进</text>'
    return start+body+'</g></svg>'


def markup():
    cards=[]
    for key,item in CHOICES.items():
        title='v2-expression-name-'+key;summary='v2-expression-summary-'+key;preview='v2-expression-preview-'+key
        cards.append(f'<article class="v2-expression-choice"><button type="button" class="v2-expression-pick" data-expression="{key}" interestfor="{preview}" aria-pressed="{str(key=="professional").lower()}" aria-labelledby="{title}" aria-describedby="{summary} {preview}" style="anchor-name:--v2-expression-{key}"><span class="v2-expression-thumb">'+thumbnail(key,'thumb')+f'</span><span class="v2-expression-heading"><span id="{title}">{item["name"]}</span><span class="v2-expression-state"><span class="v2-is-selected">已选用</span><span class="v2-not-selected">点击选用</span></span></span><span class="v2-expression-summary" id="{summary}">{item["summary"]}</span><span class="v2-expression-uses">适合：{item["uses"]}</span><span class="v2-expression-hint">鼠标停留查看版式细节与说明</span></button><div id="{preview}" class="v2-expression-preview" popover="hint" role="tooltip" style="position-anchor:--v2-expression-{key}">'+thumbnail(key,'detail')+f'<div class="v2-expression-detail"><h4>{item["name"]}</h4><p>{item["detail"]}</p><ul>'+''.join('<li>'+escape(x)+'</li>' for x in item['features'])+f'</ul><p class="v2-expression-detail-note">版式示意随当前配色变化；仅预览，点击卡片才会应用。</p></div></div><a class="v2-expression-example" href="视觉表达-{item["name"]}.html" target="_blank" rel="noopener">查看{item["name"]}完整示例</a></article>')
    return '<p class="v2-expression-help">配色决定色系，主题风格决定版式、图片融合与动效。下面是同一份内容的两种表达，点击任一张应用到整本。</p><div class="v2-expression-grid" role="group" aria-label="选择主题风格">'+''.join(cards)+'</div><p id="v2-expression-current" class="v2-expression-current" role="status">当前主题风格：简约阅读</p>'


def steps():
    return '<nav class="v2-style-steps" aria-label="样式方案设置步骤"><ol><li><button type="button" data-style-step="v2-palette-heading"><span>1</span>选配色</button></li><li><button type="button" data-style-step="v2-theme-title"><span>2</span>选主题风格</button></li><li><button type="button" data-style-step="design-export-title"><span>3</span>保存方案</button></li></ol><p id="v2-selection-summary">颜色与主题风格可以分别选择</p></nav>'


CSS=r'''
.v2-style-steps{padding:1rem 1.25rem;border-radius:1rem;background:var(--accent-soft);margin-block:0 1.5rem;color:var(--brand)}
.v2-style-steps ol{display:flex;flex-wrap:wrap;gap:.5rem 1.5rem;list-style:none;padding:0;margin:0}.v2-style-steps button{display:inline-flex;align-items:center;gap:.5rem;min-block-size:2.75rem;border:0;padding:.25rem 0;background:transparent;color:var(--brand);font:inherit;font-weight:600;cursor:pointer}.v2-style-steps button span{display:grid;place-items:center;inline-size:1.65rem;block-size:1.65rem;border-radius:50%;background:var(--surface);font-size:.8125rem}.v2-style-steps p{font-size:.875rem;color:var(--muted);margin:.5rem 0 0}
#v2-theme-title,#v2-palette-heading,#design-export-title{scroll-margin-block-start:calc(var(--header-height,3.75rem) + 1rem)}
.v2-authoring .v2-expression-help{font-size:1rem;line-height:1.75;color:var(--muted);margin-block:.5rem 1.25rem}
.v2-expression-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.25rem;align-items:stretch}
.v2-expression-choice{min-inline-size:0;display:flex;flex-direction:column;gap:.4rem}
.v2-expression-pick{appearance:none;display:flex;flex-direction:column;align-items:stretch;gap:0;flex:1;inline-size:100%;min-inline-size:0;text-align:start;font:inherit;color:var(--text);background:var(--surface);border:1px solid var(--border);border-radius:1rem;padding:.625rem;cursor:pointer;--interest-delay-start:0.3s;interest-delay-start:var(--interest-delay-start);--interest-delay-end:.15s;interest-delay-end:var(--interest-delay-end)}
.v2-expression-grid:has([interestfor]:is(:interest-source,.interest-source)) [interestfor]{--interest-delay-start:0s}
.v2-expression-pick[aria-pressed=true]{border-color:var(--accent);box-shadow:0 0 0 2px var(--accent)}
.v2-expression-thumb{display:block;background:var(--bg);padding:.4rem;border-radius:.625rem;pointer-events:none}
.v2-expression-art{display:block;inline-size:100%;block-size:auto;aspect-ratio:16/9;max-block-size:none;border:0;border-radius:.5rem;font-family:var(--sans);pointer-events:none}
.v2-expression-heading{display:flex;align-items:center;flex-wrap:wrap;gap:.5rem;justify-content:space-between;font-size:1.125rem;font-weight:650;color:var(--brand);margin:1rem .625rem .5rem}
.v2-expression-state{font-size:.75rem;font-weight:500;padding:.2rem .5rem;border-radius:1rem;background:var(--bg);color:var(--muted)}
.v2-expression-pick[aria-pressed=true] .v2-expression-state{background:var(--accent-soft);color:var(--brand2)}
.v2-is-selected,.v2-expression-pick[aria-pressed=true] .v2-not-selected{display:none}.v2-expression-pick[aria-pressed=true] .v2-is-selected{display:inline}
.v2-expression-summary,.v2-expression-uses,.v2-expression-hint{display:block;margin-inline:.625rem;font-size:.9375rem;line-height:1.7}.v2-expression-uses{color:var(--muted);font-size:.8125rem;margin-block:.375rem .75rem}.v2-expression-hint{color:var(--brand2);font-size:.75rem;margin-block:auto .5rem}
.v2-expression-example{align-self:flex-start;display:inline-flex;align-items:center;min-block-size:2.75rem;font-size:.875rem;color:var(--brand2);text-underline-offset:.25em;padding-inline:.25rem}
.v2-authoring .v2-expression-current{font-size:.875rem;color:var(--muted);margin-block:1rem .5rem}
.v2-expression-pick:focus-visible,.v2-style-steps button:focus-visible,.v2-expression-example:focus-visible{outline:3px solid var(--focus);outline-offset:5px}
@media(hover:hover) and (pointer:fine){.v2-expression-pick:hover{border-color:var(--accent);background:var(--brand-paper,var(--surface))}.v2-expression-example:hover{text-decoration-thickness:2px}}
.v2-expression-preview[popover]{display:none;inline-size:min(34rem,calc(100dvw - 2rem));max-block-size:calc(100dvh - var(--header-height,3.75rem) - 7rem);overflow:auto;overscroll-behavior:contain;box-sizing:border-box;padding:.75rem;border:1px solid var(--border);border-radius:1.125rem;background:var(--surface);color:var(--text);box-shadow:0 1.25rem 4rem #1024332b;font-family:var(--sans);font-size:1rem;line-height:1.65;z-index:100}
.v2-expression-preview[popover]:is(:popover-open,.\:popover-open){display:block}
.v2-expression-detail{padding:.75rem .5rem .25rem}.v2-expression-detail h4{font-size:1.25rem;color:var(--brand);margin:0 0 .5rem}.v2-expression-detail p{margin:.5rem 0}.v2-expression-detail ul{padding-inline-start:1.3rem;font-size:.9375rem}.v2-expression-detail li{margin-block:.375rem}.v2-expression-detail-note{font-size:.8125rem;color:var(--muted)}
@supports(position-area:top){.v2-expression-preview[popover]{position-area:right;position-try-fallbacks:flip-inline,flip-block,flip-block flip-inline;inset:auto;margin:0 0 .625rem}}
@supports not(position-area:top){.v2-expression-preview[popover]{position:fixed;inset:auto 1rem 6rem auto;margin:0}}
@media(prefers-reduced-motion:no-preference){.v2-expression-pick{transition:border-color 160ms ease,background-color 160ms ease,box-shadow 160ms ease}.v2-expression-preview[popover]{transition:opacity 150ms ease-out,display 150ms,overlay 150ms;transition-behavior:allow-discrete}@starting-style{.v2-expression-preview[popover]:is(:popover-open,.\:popover-open){opacity:0}}}
@media(max-width:1000px){.v2-expression-grid{gap:.875rem}.v2-expression-heading{font-size:1rem}.v2-expression-summary{font-size:.875rem}}
@container(max-width:33rem){.v2-expression-grid{grid-template-columns:1fr}}
@media(forced-colors:active){.v2-expression-pick[aria-pressed=true]{outline:2px solid Highlight;outline-offset:2px}.v2-expression-preview[popover]{border:2px solid CanvasText}.v2-expression-state{border:1px solid ButtonText}}
'''


JS=r'''
(()=>{
 const editor=document.getElementById('v2-theme-editor');if(!editor)return;
 const opened=hint=>CSS.supports('selector(:popover-open)')?hint.matches(':popover-open'):hint.classList.contains(':popover-open');
 const names={professional:'简约阅读',brand:'品牌展陈'};
 function sync(){const expression=document.documentElement.dataset.expression||'professional',name=names[expression]||names.professional,summary=document.getElementById('v2-selection-summary'),current=document.getElementById('v2-expression-current');if(summary)summary.textContent='当前方案：'+designNames[currentPalette]+' · '+name+' · '+(currentShell==='dark'?'深色外框':'浅色外框');if(current)current.textContent='当前主题风格：'+name+'。已应用到整本预览，最后下载样式配置即可复用。';}
 const fit=hint=>{hint.style.translate='';const rect=hint.getBoundingClientRect(),header=document.querySelector('body>.topbar')?.getBoundingClientRect().bottom||60,delta=Math.max(header+8-rect.top,Math.min(0,innerHeight-88-rect.bottom));hint.style.translate='0 '+delta+'px';};
 editor.querySelectorAll('[popover]').forEach(hint=>hint.addEventListener('toggle',event=>{if(event.newState==='open')requestAnimationFrame(()=>{if(opened(hint))fit(hint);});}));
 addEventListener('resize',()=>editor.querySelectorAll('[popover]').forEach(hint=>{if(opened(hint))fit(hint);}));
 editor.addEventListener('beforetoggle',event=>{if(event.newState==='open'&&event.target.matches('.v2-expression-preview'))editor.querySelectorAll('[popover]').forEach(hint=>{if(hint!==event.target&&opened(hint))hint.hidePopover();});},true);
 document.addEventListener('keydown',event=>{if(event.key!=='Escape')return;const hints=[...editor.querySelectorAll('[popover]')].filter(opened);if(hints.length){event.preventDefault();hints.forEach(hint=>hint.hidePopover());}});

 window.HWExpressionPicker={sync};sync();
 // Describe supplemental previews before any interaction; never change selection on interest.
 editor.querySelectorAll('button[interestfor]').forEach(button=>button.addEventListener('click',()=>{const hint=document.getElementById(button.getAttribute('interestfor'));if(hint&&opened(hint))hint.hidePopover();sync();}));
 document.querySelectorAll('[data-style-step]').forEach(button=>button.addEventListener('click',()=>{const target=document.getElementById(button.dataset.styleStep);if(!target)return;target.setAttribute('tabindex','-1');target.scrollIntoView({block:'start',behavior:'instant'});target.focus({preventScroll:true});}));
 const load=src=>new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=src;script.onload=resolve;script.onerror=reject;document.head.append(script);});
 // Classic local bundles also work when an offline library is opened via file://.
 (async()=>{if(!Object.hasOwn(HTMLElement.prototype,'popover'))await load('assets/vendor/popover-polyfill.min.js');if(!('interestForElement' in HTMLButtonElement.prototype))await load('assets/vendor/interestfor.min.js');})().catch(()=>{editor.dataset.previewFallback='true';});
 addEventListener('hb:sectionchange',()=>editor.querySelectorAll('[popover]').forEach(hint=>{if(opened(hint))hint.hidePopover();}));
})();
'''
