"""汇总与明细共享稳定标识；仅渲染内容，不计算业务转化率或保存读者数据。"""
from html import escape
from itertools import count
import math

_ids = count(1)


def numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def validate(block):
    columns = block.get('columns')
    items = block.get('items')
    if not isinstance(columns, list) or not columns:
        raise ValueError('detail_table.columns 需要非空字段列表')
    keys = []
    for column in columns:
        if not isinstance(column, dict):
            raise ValueError('汇总字段必须为对象')
        key = column.get('key')
        if not isinstance(key, str) or not key or not column.get('label'):
            raise ValueError('汇总字段需要 key 与 label')
        if 'max' in column and (not numeric(column['max']) or column['max'] <= 0):
            raise ValueError('条形比例 max 必须是正数')
        keys.append(key)
    if len(keys) != len(set(keys)):
        raise ValueError('汇总字段 key 重复')
    if not isinstance(items, list):
        raise ValueError('detail_table.items 必须为列表，可为空')
    identifiers = []
    for item in items:
        if not isinstance(item, dict):
            raise ValueError('每个汇总项目必须为对象')
        if not isinstance(item.get('id'), str) or not item['id'] or not item.get('title'):
            raise ValueError('每个汇总对象需要稳定的 id 与 title')
        identifiers.append(item['id'])
        values = item.get('values')
        if not isinstance(values, dict) or set(values) - set(keys):
            raise ValueError('values 必须为已声明字段的键值对象')
        if not isinstance(item.get('blocks', []), list):
            raise ValueError('详情 blocks 必须为列表')
        for column in columns:
            value = values.get(column['key'])
            if value is not None and not isinstance(value, str) and not numeric(value):
                raise ValueError('汇总值只能为有限数字、文字或 null')
            if 'max' in column and value is not None:
                if not numeric(value) or value < 0 or value > column['max']:
                    raise ValueError('条形值需要在 0 与本列 max 之间；缺失用 null')
    if len(identifiers) != len(set(identifiers)):
        raise ValueError('汇总对象 id 重复')
    if block.get('default') is not None and block['default'] not in identifiers:
        raise ValueError('detail_table.default 指向不存在的对象')


def validate_matrix(block):
    head = block.get('head', [])
    rows = block.get('rows', [])
    if not isinstance(head, list) or len(head) < 2 or not isinstance(rows, list) or not rows or any(not isinstance(r, list) or len(r) != len(head) for r in rows):
        raise ValueError('关系矩阵需要完整表头和等宽行，第一列为对象名称')
    if any(not str(r[0]).strip() for r in rows):
        raise ValueError('关系矩阵不能缺少行标题')
    if not block.get('legend'):
        raise ValueError('关系矩阵需要 legend 说明单元格含义')
    if 'symbols' in block:
        symbols = block['symbols']
        if not isinstance(symbols, dict) or not symbols or any(
                not isinstance(label, str) or not label.strip() or not isinstance(mark, str) or not 1 <= len(mark.strip()) <= 4
                for label, mark in symbols.items()):
            raise ValueError('symbols 需要“原文字义:短符号”的非空映射')
        if len(set(symbols.values())) != len(symbols):
            raise ValueError('同一矩阵中的不同含义不能共用一个符号')


def render_matrix(block):
    validate_matrix(block)
    e = lambda v: escape(str(v), quote=True).replace('\n', '<br>')
    head = ''.join('<th scope="col">' + e(x) + '</th>' for x in block['head'])
    symbols = block.get('symbols', {})
    def cell(value):
        if str(value) in symbols:
            return '<span class="hw-matrix-symbol" aria-hidden="true">' + e(symbols[str(value)]) + '</span><span class="sr-only">' + e(value) + '</span>'
        return e(value)
    rows = ''.join('<tr><th scope="row">' + e(row[0]) + '</th>' + ''.join(
        '<td>' + cell(x) + '</td>' for x in row[1:]) + '</tr>' for row in block['rows'])
    symbol_legend = ('<ul class="hw-matrix-legend" role="list">' + ''.join(
        '<li><span class="hw-matrix-symbol" aria-hidden="true">' + e(mark) + '</span><span>' + e(label) + '</span></li>'
        for label, mark in symbols.items()) + '</ul>') if symbols else ''
    caption = e(block.get('caption', '关系矩阵'))
    return ('<div class="hw-matrix">' + symbol_legend + '<p class="hw-data-note">' + e(block['legend']) + '</p>'
            '<div class="data-table-scroll" tabindex="0" role="region" aria-label="' + caption + '">'
            '<table class="data-table hw-matrix-table"><caption>' + caption + '</caption><thead><tr>' + head +
            '</tr></thead><tbody>' + rows + '</tbody></table></div></div>')


def render(block, render_children):
    validate(block)
    e = lambda v: escape(str(v), quote=True).replace('\n', '<br>')
    title = e(block.get('title', '汇总与详情'))
    if not block['items']:
        return '<div class="hw-detail-empty"><p class="body-text">' + title + '：暂无可查看的对象。</p></div>'
    uid = 'hw-data-' + str(next(_ids))
    default = block.get('default') or block['items'][0]['id']
    columns = block['columns']
    headers = '<th scope="col">' + e(block.get('object_label', '对象')) + '</th>' + ''.join(
        '<th scope="col">' + e(c['label']) + ('<small>单位：' + e(c['unit']) + '</small>' if c.get('unit') else '') +
        ('<small>条形上限：' + e(c['max']) + '</small>' if 'max' in c else '') + '</th>' for c in columns)
    rows, panels = [], []
    for index, item in enumerate(block['items']):
        key, name = escape(item['id'], quote=True), e(item['title'])
        panel_id = uid + '-panel-' + str(index)
        button_id = uid + '-button-' + str(index)
        current = item['id'] == default
        cells = []
        for column in columns:
            value = item['values'].get(column['key'])
            if value is None or value == '':
                cell = '<span class="hw-value-missing">未提供</span>'
            else:
                cell = '<span class="hw-data-value">' + e(value) + '</span>'
                if 'max' in column:
                    ratio = format(value / column['max'] * 100, '.6g')
                    cell = '<span class="hw-data-bar" aria-hidden="true"><i style="--hw-value:' + ratio + '%"></i></span>' + cell
            cells.append('<td><div class="hw-data-cell">' + cell + '</div></td>')
        rows.append('<tr data-detail-row="' + key + '"><th scope="row"><button type="button" id="' + button_id +
                    '" class="hw-data-choice" data-detail-key="' + key + '" aria-controls="' + panel_id +
                    '" aria-pressed="' + str(current).lower() + '">' + name +
                    '<span class="hw-data-choice-hint" aria-hidden="true"><span class="hw-choice-off">查看详情 →</span>'
                    '<span class="hw-choice-on">当前查看</span></span></button></th>' + ''.join(cells) + '</tr>')
        body = render_children(item.get('blocks', [])) or '<p class="body-text">该对象暂未提供详情。</p>'
        panels.append('<article class="hw-detail-panel" id="' + panel_id + '" data-detail-panel="' + key +
                      '" aria-labelledby="' + panel_id + '-title"><h3 tabindex="-1" id="' + panel_id + '-title">' +
                      name + '</h3>' + body + '</article>')
    return ('<div class="hw-detail-table" data-default-key="' + escape(default, quote=True) + '">'
            '<p class="hw-data-note">选择对象名称，在下方查看对应详情。选择仅在当前页面生效。</p>'
            '<div class="data-table-scroll" tabindex="0" role="region" aria-label="' + title + '">'
            '<table class="data-table hw-summary-table"><caption>' + title + '</caption><thead><tr>' + headers +
            '</tr></thead><tbody>' + ''.join(rows) + '</tbody></table></div>'
            '<p class="hw-detail-feedback" role="status" aria-atomic="true"></p>'
            '<button type="button" class="hw-detail-jump" hidden>查看当前详情 ↓</button>' + ''.join(panels) + '</div>')


CSS = r'''
.hw-detail-table,.hw-matrix{min-inline-size:0;margin-block:1rem 1.5rem}
.hw-data-note,.hw-detail-feedback{font-size:var(--fs-note);line-height:1.7;color:var(--muted);margin-block:0 .75rem}
.hw-detail-table .data-table{font-size:var(--fs-text)}
.hw-detail-table .data-table small{display:block;font-size:var(--fs-note);font-weight:var(--weight-body,400);color:var(--muted);line-height:1.5}
.hw-summary-table tbody th,.hw-matrix-table tbody th{position:sticky;inset-inline-start:0;z-index:1;background:var(--surface);font-weight:var(--weight-title,500)}
.hw-summary-table thead,.hw-matrix-table thead{z-index:2}
.hw-summary-table tbody th{min-inline-size:12rem;max-inline-size:22rem;padding:.5rem .75rem}
.hw-data-choice{font:inherit;text-align:start;border:0;background:transparent;color:var(--brand);cursor:pointer;padding:.5rem;inline-size:100%;min-block-size:2.75rem;overflow-wrap:anywhere;border-radius:.5rem;font-weight:var(--weight-title,500)}
.hw-data-choice-hint{display:block;font-size:var(--fs-note);font-weight:var(--weight-body,400);color:var(--accent);margin-block-start:.25rem}
.hw-data-choice .hw-choice-on,.hw-data-choice[aria-pressed=true] .hw-choice-off{display:none}
.hw-data-choice[aria-pressed=true] .hw-choice-on{display:inline}
.hw-summary-table tr:has(.hw-data-choice[aria-pressed=true])>*{background:var(--selected-bg);border-block-end-color:var(--selected-border)}
.hw-data-choice[aria-pressed=true]{box-shadow:inset 3px 0 var(--selected-border)}
.hw-data-choice:hover{background:var(--accent-soft)}
.hw-data-choice:focus-visible,.hw-detail-jump:focus-visible,.hw-detail-panel h3:focus-visible,.hw-detail-table .data-table-scroll:focus-visible,.hw-matrix .data-table-scroll:focus-visible{outline:3px solid var(--focus);outline-offset:2px}
.hw-data-cell{display:flex;align-items:center;gap:.75rem;min-inline-size:6rem}
.hw-data-value{font-variant-numeric:tabular-nums;overflow-wrap:anywhere}.hw-value-missing{font-size:var(--fs-note);color:var(--muted)}
.hw-data-bar{display:block;flex:1;min-inline-size:3rem;background:var(--accent-soft);block-size:.5rem;border-radius:1rem}
.hw-data-bar i{display:block;inline-size:var(--hw-value);block-size:100%;background:var(--accent);border-radius:inherit}
.hw-detail-panel{border:1px solid var(--border);border-radius:var(--r-card);background:var(--surface);padding:1.25rem;margin-block-start:1rem;min-inline-size:0}
.hw-detail-panel[hidden]{display:none!important}
.hw-detail-panel>h3{font-size:var(--fs-h3,var(--fs-cardtitle));line-height:1.5;color:var(--brand);font-weight:var(--weight-title,500);margin:0 0 1rem;overflow-wrap:anywhere;scroll-margin-block-start:6rem}
.hw-detail-panel>:last-child{margin-block-end:0}
.hw-detail-jump{font:inherit;font-size:var(--fs-note);color:var(--accent);background:var(--surface);border:1px solid var(--border);padding:.5rem .75rem;border-radius:var(--r-ctl);cursor:pointer}
.hw-detail-jump[hidden]{display:none}
.hw-matrix-table{font-size:var(--fs-text)}
.hw-matrix-table tbody td{text-align:center}
.hw-matrix-symbol{display:inline-block;font-size:1.375em;line-height:1;font-weight:var(--weight-title,500);color:var(--accent);font-family:var(--sans);min-inline-size:1.25em;text-align:center}
.hw-matrix-legend{list-style:none;display:flex;flex-wrap:wrap;gap:.75rem 1.5rem;margin:0 0 .75rem;padding:0;font-size:var(--fs-note);color:var(--muted)}
.hw-matrix-legend li{display:flex;align-items:center;gap:.375rem}
@media(forced-colors:active){.hw-data-choice[aria-pressed=true]{outline:2px solid Highlight}.hw-data-bar{border:1px solid CanvasText}.hw-data-bar i{background:Highlight;forced-color-adjust:none}}
'''

JS = r'''
(()=>{
 document.querySelectorAll('.hw-detail-table').forEach(root=>{
  const choices=[...root.querySelectorAll('.hw-data-choice')].filter(x=>x.closest('.hw-detail-table')===root);
  const panels=[...root.querySelectorAll('.hw-detail-panel')].filter(x=>x.closest('.hw-detail-table')===root);
  const status=root.querySelector(':scope > .hw-detail-feedback'),jump=root.querySelector(':scope > .hw-detail-jump');
  function select(key,announce=false){
   const button=choices.find(x=>x.dataset.detailKey===key),panel=panels.find(x=>x.dataset.detailPanel===key);
   if(!button||!panel)return;
   choices.forEach(x=>x.setAttribute('aria-pressed',String(x===button)));
   panels.forEach(x=>x.hidden=x!==panel);
   root.dataset.currentKey=key;
   if(announce)status.textContent='当前查看：'+panel.querySelector('h3').textContent+'。详情位于汇总表下方。';
  }
  choices.forEach(button=>button.addEventListener('click',()=>select(button.dataset.detailKey,true)));
  select(root.dataset.defaultKey);
  jump.hidden=false;
  jump.addEventListener('click',()=>{
   const current=panels.find(x=>x.dataset.detailPanel===root.dataset.currentKey);
   if(current)current.querySelector('h3').focus();
  });
 });
})();
'''
