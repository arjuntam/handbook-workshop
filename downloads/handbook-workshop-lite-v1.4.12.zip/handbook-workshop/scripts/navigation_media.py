"""L21 导航变体与 L26 录音；显式绑定，不按标题猜目标。"""
from html import escape
from itertools import count
import json
import re
from pathlib import PurePosixPath
from urllib.parse import urlsplit, unquote

TYPES = {'chapter_cover', 'back_link', 'section_jump', 'audio'}
_ids = count(1)


def children(block):
    if block.get('t') == 'solution':
        yield from block.get('blocks', [])
    if block.get('t') in ('tabs', 'icon_folds', 'number_folds', 'detail_table'):
        for item in block.get('items', []):
            if 'blocks' in item:
                yield from item['blocks']
            elif item.get('block'):
                yield item['block']


def walk(blocks):
    for block in blocks:
        yield block
        yield from walk(children(block))


def key(value):
    return isinstance(value, str) and bool(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*', value))


def media_source(value):
    if not value:
        return ''
    if not isinstance(value, str):
        raise ValueError('audio.src 必须为资源路径或 HTTPS 地址')
    url = urlsplit(value)
    if url.scheme:
        if url.scheme != 'https' or not url.netloc:
            raise ValueError('外部录音仅支持 HTTPS 地址')
        return value
    path = PurePosixPath(unquote(url.path))
    if not url.path or url.netloc or path.is_absolute() or '..' in path.parts or '\\' in value:
        raise ValueError('录音路径必须位于项目资源中')
    return value if value.startswith('assets/') else 'assets/' + value


def validate(block, section_ids=None):
    kind = block['t']
    if kind == 'back_link':
        if not block.get('label') or not block.get('target'):
            raise ValueError('back_link 需要 label 与 target')
        targets = [block['target']]
    elif kind in ('chapter_cover', 'section_jump'):
        items = block.get('items')
        if not isinstance(items, list) or not items:
            raise ValueError(kind + '.items 需要非空列表')
        if any(not isinstance(x, dict) or not x.get('title') or not x.get('target') for x in items):
            raise ValueError(kind + ' 每项需要 title 与 target')
        targets = [x['target'] for x in items]
        if kind == 'chapter_cover':
            if not re.fullmatch('[A-Z]', block.get('letter', 'A')):
                raise ValueError('章节扉页 letter 只接受单个 A–Z')
            if len(items) < 2:
                raise ValueError('只有一个章节时使用普通章节入口')
            targets.append(block.get('cta_target') or items[0]['target'])
    elif kind == 'audio':
        tracks = block.get('tracks')
        if not isinstance(tracks, list) or not 1 <= len(tracks) <= 5:
            raise ValueError('audio.tracks 需要 1–5 段短录音')
        keys = []
        for track in tracks:
            if not isinstance(track, dict) or not key(track.get('key')) or not track.get('title'):
                raise ValueError('录音需要稳定 key 与 title')
            keys.append(track['key'])
            media_source(track.get('src', ''))
        if len(keys) != len(set(keys)):
            raise ValueError('录音 key 重复')
        if block.get('default') and block['default'] not in keys:
            raise ValueError('录音 default 不存在')
        if block.get('tabset') and not key(block['tabset']):
            raise ValueError('录音 tabset 必须为稳定标识')
        return
    else:
        return
    if kind != 'section_jump' and section_ids is not None and any(x not in section_ids for x in targets):
        raise ValueError('章节目标不存在')


def validate_sections(sections):
    ids = {s['id'] for s in sections}
    for section in sections:
        blocks = list(walk(section['blocks']))
        anchors, tabsets = {}, {}
        for block in blocks:
            if block.get('t') in TYPES:
                validate(block, ids)
            if block.get('t') == 'h3' and 'id' in block:
                name = block['id']
                if not key(name) or name in anchors:
                    raise ValueError('同节小标题锚点无效或重复：' + str(name))
                anchors[name] = block
            if block.get('t') == 'tabs':
                for item in block.get('items', []):
                    if 'blocks' in item and not isinstance(item['blocks'], list):
                        raise ValueError('tabs.items.blocks 必须为列表')
                if block.get('key'):
                    name = block['key']
                    keys = [x.get('key') for x in block['items']]
                    if not key(name) or name in tabsets or not all(key(k) for k in keys) or len(set(keys)) != len(keys):
                        raise ValueError('绑定用 tabs.key 与标签 key 必须有效且不重复')
                    tabsets[name] = set(keys)
        for block in blocks:
            if block.get('t') == 'section_jump' and any(x['target'] not in anchors for x in block['items']):
                raise ValueError('分区条目标必须是当前章节内具有 id 的 h3')
            if block.get('t') == 'audio' and block.get('tabset'):
                if tabsets.get(block['tabset']) != {x['key'] for x in block['tracks']}:
                    raise ValueError('录音与同节标签必须按稳定 key 完整对应')


def render(block):
    validate(block)
    e = lambda v: escape(str(v), quote=True)
    text = lambda v: e(v).replace('\n', '<br>')
    kind = block['t']
    if kind == 'chapter_cover':
        cards = ''.join('<button type="button" class="hw-cover-card" data-goto="' + e(x['target']) +
                        '"><span class="hw-cover-num">' + text(x.get('num', str(i + 1).zfill(2))) +
                        '</span><span><span class="hw-cover-title">' + text(x['title']) +
                        '</span><span class="hw-cover-desc">' + text(x.get('body', '')) + '</span></span></button>'
                        for i, x in enumerate(block['items']))
        return ('<nav class="hw-chapter-cover" aria-label="' + e(block.get('title', '本章阅读入口')) +
                '"><span class="hw-cover-letter" aria-hidden="true">' + e(block.get('letter', 'A')) +
                '</span><p class="hw-cover-kicker">' + text(block.get('kicker', '本章阅读顺序')) +
                '</p><div class="hw-cover-grid">' + cards + '</div><div class="hw-cover-action"><p>' +
                text(block.get('hint', '按顺序阅读，也可直接选择需要的章节。')) +
                '</p><button type="button" data-goto="' + e(block.get('cta_target') or block['items'][0]['target']) +
                '">' + text(block.get('cta_label', '开始阅读第一节')) + ' <span aria-hidden="true">→</span></button></div></nav>')
    if kind == 'back_link':
        return ('<nav class="hw-back-link" aria-label="返回上层"><button type="button" class="xref-chip" data-goto="' +
                e(block['target']) + '"><span aria-hidden="true">←</span>' + text(block['label']) + '</button></nav>')
    if kind == 'section_jump':
        return ('<nav class="hw-section-jump" aria-label="' + e(block.get('title', '本节分区')) + '"><span>' +
                text(block.get('title', '本节分区')) + '</span>' + ''.join(
                    '<button type="button" data-scroll="' + e(x['target']) + '">' + text(x['title']) + '</button>'
                    for x in block['items']) + '</nav>')
    if kind == 'audio':
        uid = 'hw-audio-' + str(next(_ids))
        tracks = [{**x, 'src': media_source(x.get('src', ''))} for x in block['tracks']]
        first = next((x for x in tracks if x['key'] == block.get('default')), tracks[0])
        options = ''.join('<option value="' + e(x['key']) + '"' + (' selected' if x is first else '') + '>' + text(x['title']) + '</option>' for x in tracks)
        transcripts = ''.join('<p class="hw-audio-transcript" data-transcript-key="' + e(x['key']) + '"' +
                              ('' if x is first else ' hidden') + '>' + text(x.get('transcript', '')) + '</p>' for x in tracks)
        return ('<div class="hw-audio" data-tracks="' + e(json.dumps(tracks, ensure_ascii=False)) +
                '" data-tabset="' + e(block.get('tabset', '')) + '" data-default="' + e(first['key']) +
                '" role="group" aria-label="' + e(block.get('title', '录音播放')) + '"><div class="hw-audio-head">' +
                '<span class="hw-audio-badge">' + text(block.get('badge', '配套录音')) + '</span><b class="hw-audio-title">' +
                text(first['title']) + '</b><span class="hw-audio-note" role="status" aria-atomic="true">按播放键收听</span></div>' +
                '<label class="hw-audio-picker" for="' + uid + '-track">选择录音<select id="' + uid + '-track">' + options + '</select></label>' +
                '<div class="hw-audio-bar" hidden><button type="button" class="hw-audio-play" aria-label="播放录音">' +
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path class="hw-audio-play-icon" d="m8 5 11 7-11 7z"/>' +
                '<path class="hw-audio-pause-icon" d="M6 5h4v14H6zm8 0h4v14h-4z"/></svg></button>' +
                '<label class="sr-only" for="' + uid + '-seek">录音播放进度</label><input id="' + uid +
                '-seek" class="hw-audio-seek" type="range" min="0" max="100" step="0.1" value="0" disabled>' +
                '<span class="hw-audio-time">00:00 / --:--</span><button type="button" class="hw-audio-rate" aria-label="播放速度 1 倍">1×</button></div>' +
                '<audio controls preload="none"' +
                ' aria-label="' + e(block.get('title', '配套录音')) + '"></audio>' + transcripts + '</div>')
    raise ValueError('未知导航/录音块')


CSS = r'''
.hw-chapter-cover{position:relative;isolation:isolate;container:hw-cover/inline-size;margin-block:1.25rem;padding:1.75rem;border:1px solid var(--border);border-radius:var(--r-card);background:linear-gradient(135deg,var(--surface),var(--accent-soft));min-inline-size:0}
.hw-cover-letter{position:absolute;inset-block-start:.25rem;inset-inline-end:1.25rem;font-size:7rem;line-height:1;font-weight:var(--weight-title,700);color:var(--accent);opacity:.09;pointer-events:none;user-select:none;z-index:-1}
.hw-cover-kicker{font-size:var(--fs-note);color:var(--accent);font-weight:var(--weight-title,500);letter-spacing:.1em;margin:0 0 1rem}
.hw-cover-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.875rem;min-inline-size:0}
.hw-cover-card{display:flex;gap:.875rem;align-items:start;border:1px solid var(--border);border-radius:var(--r-ctl);padding:1rem;background:var(--surface);color:var(--text);text-align:start;font:inherit;cursor:pointer;min-inline-size:0}
.hw-cover-card>span:last-child{min-inline-size:0}.hw-cover-card:hover{border-color:var(--accent);box-shadow:var(--shadow)}
.hw-cover-num{flex:none;font-size:var(--fs-note);padding:.25rem .5rem;border-radius:.5rem;background:var(--accent-soft);color:var(--accent);font-weight:var(--weight-title,500)}
.hw-cover-title{display:block;font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);line-height:1.5;overflow-wrap:anywhere}
.hw-cover-desc{display:block;font-size:var(--fs-note);line-height:1.75;color:var(--muted);margin-block-start:.375rem;overflow-wrap:anywhere}
.hw-cover-action{display:flex;align-items:center;justify-content:space-between;gap:1rem;flex-wrap:wrap;margin-block-start:1.25rem}
.hw-cover-action p{margin:0;font-size:var(--fs-note);line-height:1.7;color:var(--muted);flex:1 1 15rem}
.hw-cover-action button{font:inherit;font-size:var(--fs-note);font-weight:var(--weight-title,500);border:0;border-radius:var(--r-ctl);background:var(--brand);color:var(--surface);padding:.75rem 1rem;min-block-size:2.75rem;cursor:pointer}
@container hw-cover (inline-size < 32rem){.hw-cover-grid{grid-template-columns:1fr}}
.hw-back-link{margin-block-start:1.75rem;padding-block-start:1rem;border-block-start:1px dashed var(--border)}
.hw-back-link .xref-chip{gap:.5rem}
.hw-section-jump{display:flex;align-items:center;flex-wrap:wrap;gap:.5rem;padding:.875rem 1rem;border-radius:var(--r-ctl);background:var(--accent-soft);margin-block:1rem}
.hw-section-jump>span{color:var(--brand);font-size:var(--fs-note);font-weight:var(--weight-title,500);margin-inline-end:.5rem}
.hw-section-jump button{font:inherit;font-size:var(--fs-note);padding:.5rem .875rem;border:1px solid var(--border);border-radius:999px;background:var(--surface);color:var(--brand);cursor:pointer;min-block-size:2.75rem}
.hw-section-jump button:hover{border-color:var(--accent)}.hw-anchor{scroll-margin-block:6rem 8rem}
.hw-cover-card:focus-visible,.hw-cover-action button:focus-visible,.hw-section-jump button:focus-visible,.hw-anchor:focus-visible{outline:3px solid var(--focus);outline-offset:3px}
.hw-audio{container:hw-audio/inline-size;min-inline-size:0;padding:1rem 1.25rem;margin-block:1rem;border:1px solid var(--border);border-radius:var(--r-card);background:var(--surface);color:var(--text)}
.hw-audio-head{display:flex;align-items:center;flex-wrap:wrap;gap:.625rem;margin-block-end:.75rem}
.hw-audio-badge{font-size:var(--fs-note);padding:.25rem .625rem;border-radius:999px;background:var(--accent-soft);color:var(--brand)}
.hw-audio-title{font-size:var(--fs-text);font-weight:var(--weight-title,500);overflow-wrap:anywhere}.hw-audio-note{font-size:var(--fs-note);line-height:1.7;color:var(--muted);margin-inline-start:auto}
.hw-audio[data-state=empty] .hw-audio-note,.hw-audio[data-state=error] .hw-audio-note{font-weight:var(--weight-title,500);text-decoration:underline}
.hw-audio-picker{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem;font-size:var(--fs-note);margin-block:.75rem}.hw-audio-picker select{font:inherit;max-inline-size:100%;background:var(--surface);color:var(--text);border:1px solid var(--border);padding:.5rem;border-radius:.5rem}
.hw-audio-bar{display:grid;grid-template-columns:auto minmax(4rem,1fr) auto auto;align-items:center;gap:.875rem;min-inline-size:0}
.hw-audio-bar[hidden],.hw-audio-picker[hidden]{display:none!important}
.hw-audio-play{inline-size:2.75rem;block-size:2.75rem;border:0;border-radius:50%;background:var(--brand);color:var(--surface);display:grid;place-items:center;cursor:pointer;flex:none}
.hw-audio-play svg{inline-size:1.125rem;block-size:1.125rem;fill:currentColor}.hw-audio-pause-icon,.hw-audio[data-state=playing] .hw-audio-play-icon{display:none}.hw-audio[data-state=playing] .hw-audio-pause-icon{display:block}
.hw-audio-seek{appearance:none;-webkit-appearance:none;inline-size:100%;min-inline-size:0;block-size:.5rem;border-radius:999px;background:linear-gradient(to right,var(--brand) var(--p,0%),var(--border) var(--p,0%));cursor:pointer;margin:0}
.hw-audio-seek::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;inline-size:1rem;block-size:1rem;border-radius:50%;background:var(--surface);border:2px solid var(--brand)}
.hw-audio-seek::-moz-range-thumb{inline-size:1rem;block-size:1rem;border-radius:50%;background:var(--surface);border:2px solid var(--brand)}
.hw-audio-time{font-size:var(--fs-note);font-variant-numeric:tabular-nums;white-space:nowrap;color:var(--muted)}
.hw-audio-rate{font:inherit;font-size:var(--fs-note);padding:.5rem .625rem;border:1px solid var(--border);border-radius:.5rem;color:var(--text);background:var(--surface);cursor:pointer;min-block-size:2.75rem}
.hw-audio :disabled{opacity:.45;cursor:not-allowed}.hw-audio :is(button,input,select):focus-visible{outline:3px solid var(--focus);outline-offset:4px}
.hw-audio.is-enhanced audio{display:none}.hw-audio audio{max-inline-size:100%}.hw-audio-transcript{font-size:var(--fs-note);line-height:1.75;color:var(--muted);margin:.875rem 0 0}.hw-audio-transcript:empty{display:none}
@container hw-audio (inline-size < 30rem){.hw-audio-bar{grid-template-columns:auto minmax(4rem,1fr) auto}.hw-audio-time{grid-column:2;grid-row:2}.hw-audio-rate{grid-column:3;grid-row:1 / 3}.hw-audio-note{margin-inline-start:0}}
@media(forced-colors:active){.hw-audio-seek{appearance:auto;-webkit-appearance:auto}.hw-cover-card{border-color:ButtonText}}
'''

JS = r'''
(()=>{
 document.addEventListener('click',e=>{
  const button=e.target.closest('.hw-section-jump [data-scroll]');if(!button)return;
  const section=button.closest('.section');
  const target=[...section.querySelectorAll('[data-hw-anchor]')].find(x=>x.dataset.hwAnchor===button.dataset.scroll);
  if(!target)return;
  target.focus({preventScroll:true});
  const offset=(document.querySelector('body > .topbar')?.getBoundingClientRect().height||60)+24;
  window.scrollTo({top:scrollY+target.getBoundingClientRect().top-offset,behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});
 });
 const players=[];
 document.querySelectorAll('.hw-audio').forEach(root=>{
  const audio=root.querySelector('audio'),play=root.querySelector('.hw-audio-play'),seek=root.querySelector('.hw-audio-seek');
  const rate=root.querySelector('.hw-audio-rate'),note=root.querySelector('.hw-audio-note'),time=root.querySelector('.hw-audio-time');
  const picker=root.querySelector('.hw-audio-picker'),select=picker.querySelector('select'),title=root.querySelector('.hw-audio-title');
  const tracks=JSON.parse(root.dataset.tracks),rates=[1,1.25,1.5,2];let current=null,rateIndex=0,generation=0;
  const section=root.closest('.section');
  const host=root.dataset.tabset?[...section.querySelectorAll('.tabset')].find(x=>x.dataset.tabsKey===root.dataset.tabset):null;
  players.push({root,audio,host});
  const fmt=n=>Number.isFinite(n)?String(Math.floor(n/60)).padStart(2,'0')+':'+String(Math.floor(n%60)).padStart(2,'0'):'--:--';
  function state(value,message){root.dataset.state=value;play.setAttribute('aria-label',value==='playing'?'暂停录音':'播放录音');if(message!==undefined)note.textContent=message;}
  function paint(){
   const duration=audio.duration,position=audio.currentTime||0,p=Number.isFinite(duration)&&duration>0?position/duration*100:0;
   seek.value=String(p);seek.style.setProperty('--p',p+'%');seek.disabled=!Number.isFinite(duration)||duration<=0||root.dataset.state==='error';
   seek.setAttribute('aria-valuetext',fmt(position)+'，共 '+fmt(duration));time.textContent=fmt(position)+' / '+fmt(duration);
  }
  function load(key){
   const track=tracks.find(x=>x.key===key);if(!track||current?.key===key)return;
   generation++;audio.pause();current=track;title.textContent=track.title;select.value=key;rateIndex=0;rate.textContent='1×';rate.setAttribute('aria-label','播放速度 1 倍');audio.playbackRate=1;
   root.querySelectorAll('[data-transcript-key]').forEach(x=>x.hidden=x.dataset.transcriptKey!==key);
   play.disabled=!track.src;rate.disabled=!track.src;seek.disabled=true;seek.value='0';seek.style.setProperty('--p','0%');time.textContent='00:00 / --:--';
   if(track.src){audio.removeAttribute('src');state('ready','按播放键收听');}
   else{audio.removeAttribute('src');state('empty','这段录音待补充');}
   audio.load();
  }
  play.addEventListener('click',async()=>{
   if(!current?.src)return;
   if(!audio.paused){audio.pause();return;}
   const token=generation;if(!audio.hasAttribute('src')){audio.src=current.src;audio.load();}audio.playbackRate=rates[rateIndex];state('loading','正在加载录音');
   try{await audio.play();}
   catch(error){if(token!==generation||!current?.src)return;if(error.name==='AbortError'&&audio.paused){state('paused','已暂停');return;}state('error',error.name==='NotAllowedError'?'播放未获允许，请再次点击':'录音加载失败，请检查文件或地址');play.disabled=false;seek.disabled=true;}
  });
  audio.addEventListener('play',()=>{players.forEach(p=>{if(p.audio!==audio)p.audio.pause();});state('playing','播放中');});
  audio.addEventListener('pause',()=>{if(current?.src&&['playing','loading'].includes(root.dataset.state))state('paused','已暂停');});
  audio.addEventListener('ended',()=>state('paused','播放结束，可重新播放'));
  audio.addEventListener('error',()=>{if(!current?.src||!audio.hasAttribute('src'))return;state('error','录音加载失败，请检查文件或地址');seek.disabled=true;});
  audio.addEventListener('loadedmetadata',paint);audio.addEventListener('timeupdate',paint);
  seek.addEventListener('input',()=>{if(Number.isFinite(audio.duration)){audio.currentTime=Number(seek.value)/100*audio.duration;paint();}});
  rate.addEventListener('click',()=>{rateIndex=(rateIndex+1)%rates.length;audio.playbackRate=rates[rateIndex];rate.textContent=rates[rateIndex]+'×';rate.setAttribute('aria-label','播放速度 '+rates[rateIndex]+' 倍');});
  select.addEventListener('change',()=>load(select.value));
  if(host){picker.hidden=true;host.addEventListener('hb:tabchange',e=>{if(e.target===host)load(e.detail.key);});}
  root.classList.add('is-enhanced');root.querySelector('.hw-audio-bar').hidden=false;
  load(host?.querySelector('.tab-head.on')?.dataset.tabKey||root.dataset.default);
 });
 function pauseHidden(){players.forEach(p=>{if(!p.root.getClientRects().length||p.host&&!p.host.getClientRects().length)p.audio.pause();});}
 document.addEventListener('hb:tabchange',pauseHidden);
 document.addEventListener('toggle',pauseHidden,true);
 document.getElementById('home-btn')?.addEventListener('click',()=>players.forEach(p=>p.audio.pause()));
 const visibility=new MutationObserver(pauseHidden),watched=new Set();
 players.forEach(p=>{for(let parent=p.root.parentElement;parent;parent=parent.parentElement){if(!watched.has(parent)){visibility.observe(parent,{attributes:true,attributeFilter:['hidden','class']});watched.add(parent);}}});
 window.addEventListener('pagehide',()=>players.forEach(p=>p.audio.pause()));
 window.addEventListener('hb:sectionchange',pauseHidden);
 document.addEventListener('visibilitychange',()=>{if(document.hidden)players.forEach(p=>p.audio.pause());});
})();
'''
