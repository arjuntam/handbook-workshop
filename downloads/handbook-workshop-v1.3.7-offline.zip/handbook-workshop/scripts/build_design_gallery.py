#!/usr/bin/env python3
"""构建可点击的视觉与交互样式预览；不读取或发布外部项目。"""
import argparse
import json
import shutil
import re
from pathlib import Path
from handbook_core import build_html, render_header, render_blocks, render_credit, resolve_config, CSS, APPLE_BASE_CSS, JS
import cover_design
import desktop_gate
import gallery_layouts
import portal_layout
import typography_rules
import china_map
from style_catalog import CATALOG, BASE, RECIPES, GALLERY_VARIANTS
from design_tokens import PALETTES, TYPE_SCALES, tokens, LEGACY_PALETTES

SKILL = Path(__file__).resolve().parent.parent


def build(out, atlas=None, skill_download_href=None, offline_download_href=None):
    from prepare_resources import font_source, copy_font, copy_resource, copy_resources
    font = font_source()
    out.mkdir(parents=True, exist_ok=True)
    version=json.loads((SKILL/'assets'/'base-style.json').read_text())['design_version']
    skill_download_href=skill_download_href or 'downloads/handbook-workshop-v'+version+'.zip'
    (out/'assets').mkdir(exist_ok=True)
    copy_resources(SKILL/'assets'/'maps',out/'assets'/'maps')
    copy_resources(SKILL/'assets'/'fonts',out/'assets'/'fonts')
    copy_font(out/'assets'/'fonts'/'MiSans-VF.ttf',font)
    copy_resource(SKILL/'assets'/'brand'/'daikin-color.png',out/'assets'/'logo.png')
    copy_resource(SKILL/'assets'/'brand'/'daikin-white.png',out/'assets'/'logo-white.png')
    # Original block atlas is retained; new entry adds the design decisions above it.
    legacy = Path(atlas) if atlas else SKILL/'assets'/'gallery-source'
    if out.resolve() != legacy.resolve():
        copy_resources(legacy/'assets',out/'assets')
    original = (legacy/'index.html').read_text(encoding='utf-8')
    original = re.sub(r'<script>.*?</script>',lambda m:'<script>'+desktop_gate.JS+JS+'</script>',original,count=1,flags=re.S)
    # Use revised typography and selected-state CSS in retained examples.
    first_style = re.search(r'<style>(.*?)</style>', original, re.S)
    if first_style:
        from build_gallery import GALLERY_CSS
        original = original[:first_style.start()]+'<style>'+CSS+APPLE_BASE_CSS+GALLERY_CSS+'</style>'+original[first_style.end():]
    for entry in CATALOG:
        t=entry['type']
        if t=='table': continue
        title=entry['id']+' · '+entry['name']
        original=re.sub(r'(<h2 id="h-blk-'+t+r'">).*?(</h2>)',lambda m:m[1]+title+m[2],original,count=1)
        original=re.sub(r'(<a[^>]*href="#blk-'+t+r'"[^>]*>.*?</span>).*?(</a>)',lambda m:m[1]+title+m[2],original,count=1)
        specs='<div class="callout callout-blue"><span class="callout-label">固定样式定义</span><div class="callout-body">'+''.join('<p><b>'+key+'：</b>'+entry[field]+'</p>' for key,field in [('适用','scope'),('不适用','avoid'),('交互','interaction'),('状态','states'),('配色','colors')])+'</div></div>'
        pattern=r'(<section class="section" id="blk-'+t+r'".*?<div class="section-head">.*?</div>)'
        original=re.sub(pattern,lambda m:m[1]+specs,original,count=1,flags=re.S)
    original=original.replace('</body>','<script>document.querySelectorAll(".pick-grid").forEach(g=>{g.addEventListener("change",()=>g.querySelectorAll(".pick-card").forEach(c=>c.classList.toggle("on",!!c.querySelector("input:checked"))))});</script></body>')
    original=re.sub(r'<header class="topbar"[^>]*>.*?</header>',render_header('网页手册 · 内容块图鉴',config={'home_href':'index.html'}),original,count=1,flags=re.S)
    original=re.sub(r'<div class="cover-brand-text">.*?</div>','<img class="cover-logo" src="assets/logo.png" alt="大金 DAIKIN">',original,count=1,flags=re.S)
    original=original.replace('<div class="cover" id="cover">','<div class="cover cover-fluid-mode" id="cover" data-surface="light">'+cover_design.MARKUP,1)
    overrides=':root{'+''.join(k+':'+v+';' for k,v in tokens({}).items())+'}'
    original=original.replace('</head>','<style>'+cover_design.SKIN_CSS+cover_design.CSS+overrides+'</style></head>',1)
    original=original.replace('</body>','<script>'+cover_design.JS+'</script></body>',1)
    def native_pick(m):
        classes,checked,index,body=m.groups()
        body=re.sub(r'<h4([^>]*)>(.*?)</h4>',r'<span\1>\2</span>',body,flags=re.S)
        body=re.sub(r'<p([^>]*)>(.*?)</p>',r'<span\1>\2</span>',body,flags=re.S)
        return '<label class="'+classes+'" data-pick="'+index+'"><input class="pick-control" type="radio" name="atlas-pick"'+(' checked' if checked=='true' else '')+'>'+body+'</label>'
    original=re.sub(r'<article class="(pick-card[^"]*)" tabindex="0" role="radio" aria-checked="(true|false)" data-pick="([^"]*)">(.*?)</article>',native_pick,original,flags=re.S)
    original=original.replace('</body>','<script>document.querySelectorAll(".pick-grid").forEach((g,i)=>g.querySelectorAll("input[type=radio]").forEach(x=>x.name="atlas-pick-"+i));</script></body>')
    # Regenerate the moments sample with current icons, sizing and feedback elements.
    from build_gallery import FALLBACK
    moment_block=FALLBACK['moments'][0]
    moment_html=render_blocks([moment_block],{})
    moment_section='<section class="section" id="blk-moments" aria-labelledby="h-blk-moments"><div class="section-head"><h2 id="h-blk-moments">L15 · 朋友圈范例</h2><p class="sec-sub">爱心点赞、评论气泡、状态与轻动效</p></div><p class="body-text">仅本页演示，操作不会向任何社交平台发送。</p>'+moment_html+'</section>'
    original=re.sub(r'<section class="section" id="blk-moments".*?</section>',moment_section,original,count=1,flags=re.S)
    original=original.replace('</body>','<script>'+gallery_layouts.JS+'</script></body>')
    original=original.replace('</head>','<meta name="font-credit" content="本作品使用 MiSans 字体"></head>',1)
    original=typography_rules.decorate_document(original)
    original=original.replace('<h2 id="h-blk-imgs">L17 · 多图画廊</h2>','<h2 id="h-blk-imgs">L17-A · 网格图册</h2><p><a href="index.html#gallery-focus">查看 L17-B 横向胶片与 L17-C 焦点大图画廊 →</a></p>')
    (out/'blocks.html').write_text('<!doctype html><meta charset="utf-8"><title>打开统一样式库</title><script>location.replace("index.html"+location.hash)</script>',encoding='utf-8')
    (out/'样式目录.json').write_text(json.dumps(dict(navigation=['使用说明','基础规范','配色与字号','内容样式','转换与验收'],max_navigation_depth=2,base=BASE,components=CATALOG,pages=RECIPES,gallery_variants=GALLERY_VARIANTS),ensure_ascii=False,indent=2),encoding='utf-8')
    def sec(sid,title,group,blocks):
        return dict(id=sid,nav=title,group=group,title=title,kicker='视觉与交互 · v1.3.7',blocks=blocks)
    def txt(s): return dict(t='text',v=s)
    def call(s): return dict(t='callout',label='使用规则',v=s)
    palette_ui = '<div class="palette-grid">'+''.join(
        f'<button class="palette-option" type="button" data-palette="{key}" aria-pressed="{str(key=="air-blue").lower()}">'
        f'<span class="palette-swatches" aria-hidden="true"><i style="background:{p["brand"]}"></i><i style="background:{p["accent"]}"></i><i style="background:{p["soft"]}"></i></span>'
        f'<b>{p["name"]}</b><small>{key}</small></button>' for key,p in PALETTES.items())+'</div>'
    mode_ui = '<div class="preview-toolbar shell-options" role="group" aria-label="外框深浅"><button type="button" data-shell-mode="light" aria-pressed="true">浅色外框</button><button type="button" data-shell-mode="dark" aria-pressed="false">深色外框</button></div><p class="body-text">每个色系都支持两种外框。深色仅用于顶栏和侧栏，正文保持白色。</p>'
    toolbar = '<div class="preview-toolbar"><button type="button" data-type="standard" aria-pressed="true">日常阅读字号</button><button type="button" data-type="presentation" aria-pressed="false">演示大字</button><button type="button" id="download-design">下载当前样式配置</button></div><p id="design-status" role="status">当前：清透蓝 · 日常阅读字号</p>'
    sections = [
        sec('start','先定义整本风格','先选风格',[
            dict(t='lede',v='品牌页头、标题和交互规则固定下来；后续主要调整内容和选用版式。'),
            dict(t='pick',cols=3,default=-1,label='选择基准层级',items=[dict(title='品牌层',body='固定 logo 位置、留白与大小，保留原始比例。'),dict(title='内容层',body='封面、章节、卡片标题各用一个字号层级。'),dict(title='状态层',body='可选卡片、标签切换和复制操作有明确反馈。')]),
            call('原 PPT 的文字、数据和必要图片继续使用。整页坐标、零散字号和每页背景色不自动继承。'),
            txt('大金 logo 固定使用用户提供的原色与白色版本：浅底原色、深底白色。十个色系及深浅模式仍是候选样式，不代表官方品牌色规范。')]),
        sec('palette','配色与深浅模式','先选风格',[
            txt('先选色系，再切换浅色或深色外框。主题色沿用同一色系，正文保持白色；logo 随顶栏明暗切换原色或白色。'),
            dict(t='html',v=mode_ui+palette_ui+toolbar+'<label class="date-option"><input type="checkbox" id="show-update-date" checked> 显示更新日期（默认开启）</label>'),
            dict(t='pick',label='主题下的卡片选中演示',cols=3,default=0,items=[dict(title='当前选中',body='边框、柔底和左侧竖线同时提示选中。'),dict(title='点击选择我',body='可用鼠标、触屏或键盘切换。'),dict(title='第三个选项',body='同组始终只选中一个。')]),
            call('配色统一定义主色、强调色、页面底色、文字色、边界色和选中态，不只换一个蓝色。')]),
        sec('brand','logo 使用定义','基础样式',[
            dict(t='lede',v='每本手册只有一套品牌标识规则。'),
            dict(t='table',caption='logo 位置与限制',head=['位置','默认尺寸','显示方式','素材缺失时'],rows=[['顶栏左侧','高 28px；最大宽 176px','等比完整显示，不拉伸、不裁切','固定使用配套 logo'],['封面中央','高 48px；最大宽 288px','独立留白，不与主标题抢层级','固定使用配套 logo'],['深色背景','固定使用提供的白色 logo','保持完整原图与比例','不自动反相或重绘']]),
            call('logo 已固定为用户提供的两份透明 PNG。浅色底用原色 logo，深色底用白色 logo；不重绘、不反相、不从 PPT 截图裁取。'),
            dict(t='html',v='<div class=logo-plates><figure><img src=assets/logo.png alt=浅底原色logo><figcaption>浅色底 · 原色 logo</figcaption></figure><figure class=dark-plate><img src=assets/logo-white.png alt=深底白色logo><figcaption>深色底 · 白色 logo</figcaption></figure></div>')]),
        sec('type','标题与正文层级','基础样式',[
            dict(t='lede',v='封面主标题 / 章节标题 / 卡片标题 / 正文，各有固定角色。'),
            dict(t='h3',v='二级说明标题 · 21px'),
            dict(t='grid',cols=2,items=[dict(title='卡片标题 · 19px',body='正文默认 17px；辅助说明使用 13px。长标题允许换行。'),dict(title='不要随 PPT 改字号',body='同一级标题整本一致，字多时拆分内容，不无限缩小字体。')]),
            dict(t='html',v='<div class="preview-toolbar"><button type="button" data-type="standard" aria-pressed="true">日常阅读字号</button><button type="button" data-type="presentation" aria-pressed="false">演示大字</button></div>'),
            txt('字号随系统和浏览器放大。上面的像素数是默认字号下的参考值，大字模式和无障碍缩放会增大。')]),
        sec('states','L02 单选高亮卡','交互规范',[
            txt('请点击前两张卡片体验选中高亮。第三张不可选；键盘 Tab 进入后，可用方向键切换、空格选择。'),
            dict(t='pick',label='选中与禁用状态演示',cols=3,default=-1,items=[dict(title='方案 A',body='点击后：柔底、主题边框、竖线和外描边。'),dict(title='方案 B',body='换选后，上一张恢复默认状态。'),dict(title='暂不可选',body='禁用时变淡，点击和键盘均不会选中。',disabled=True)]),
            dict(t='table',caption='交互状态约定',head=['状态','视觉反馈','行为'],rows=[['默认','中性底色和边界','可操作性用文字说明'],['悬停','轻微抬升与边界提示','鼠标移开恢复'],['键盘焦点','清晰外描边','不等同于选中'],['已选中','柔底 + 强边界 + 竖线','同组保留一个选择'],['禁用','降低明度 + 禁用鼠标样式','不能选中'],['动作结果','可读的成功或失败提示','复制不静默失败']]),
            call('普通展示卡片不自动获得“已选择”含义；确实要选方案时才用单选卡。选中只在当前页面内生效，没有提交或跨设备同步。')]),
        sec('tabs-demo','L03 场景切换卡','交互规范',[
            dict(t='tabs',items=[dict(tab='首次沟通',block=dict(t='scriptlib',flat=True,data=[dict(group='首次沟通',blocks=[dict(type='say',text='您好，这里是示意话术。请根据真实业务资料填写内容。')])])),dict(tab='现场确认',block=dict(t='callout',label='确认要点',v='确认时间、地点和联系人。此处仅为交互样例。')),dict(tab='会后记录',block=txt('记录实际发生的事项，不补写未发生的结果。'))]),
            call('标签切换保留位置和选中反馈。复制有成功或失败提示；不把每张卡都变成需要点击才能阅读。')]),
        sec('recipes','P01–P08 页面组合','转换规则',[
            dict(t='table',caption='按名称选择页面组合与内容样式',head=['信息形状','首选内容块','不要自动做的事'],rows=[['同列数据、分工或明细','L05 通用数据表 / L06 人员分工表','把任意表格压进固定五列'],['少量同层级短要点','L01 并列要点卡','给长段落强行排三列'],['双方一一对应','L04 双栏对照','凭两列位置猜对照关系'],['明确时间顺序','L10 时间流程单 / L09 步骤流程','仅凭编号补出时间关系'],['多个可选方案','L02 单选高亮卡','把展示内容伪装成选择操作'],['多个相互独立场景','tabs','把需要同时比较的数据藏进标签'],['复杂结构或关系图','原图 + 待核对项','猜连线含义或只抽文字']]),
            call('先识别内容关系，再选页面组合，再套已选风格。文本长短和行数只是提醒，最终以实际渲染结果为准。')]),
        sec('table-demo','L05 通用数据表','内容样式',[
            txt('不属于“事项 / 执行 / 负责 / 时间”的表格，使用通用表格。窄屏在表格区域滚动，不删除或截断列。'),
            dict(t='table',caption='七列表格样例（模拟内容）',head=['编号','对象','动作','时间','口径','来源','状态'],rows=[['01','示例 A','核对资料','会前','模拟字段','模拟原稿','待核对'],['02','示例 B','记录问题','会后','模拟字段','模拟原稿','已记录']]),
            txt('若原表有跨行跨列表头，平铺只能作为初稿，需对照原页确认关系。')]),
        sec('workflow','首版怎么生成和验收','转换规则',[
            dict(t='steps',items=[dict(title='选定视觉配置',body='确认 logo、配色、字号模式和必要交互；整本复用。'),dict(title='清点并映射内容',body='给原稿对象保留来源 ID；识别原文、图片、表格和待核对项。'),dict(title='按关系重组初稿',body='优先用固定组合，保留事实和来源；未知关系不猜。'),dict(title='集中检查并交付',body='检查文字遗漏、破图、窄屏和大字；按规则批量修正同类问题。')]),
            call('脚本直出的是保守初稿。按读者任务重组仍需内容判断；自动检查通过不等于业务、视觉与真实设备验收通过。'),
            dict(t='html',v='<p><a class="atlas-link" href="#catalog">在统一目录选择内容样式 →</a></p>')]),
    ]
    photo_names=['p26-img005.jpg','p26-img006.jpg','p26-img007.jpg']
    photos=[dict(src=n,cap=c) for n,c in zip(photo_names,['认筹现场 · 活动全景','认筹现场 · 宣讲环节','认筹现场 · 互动环节'])]
    for variant in GALLERY_VARIANTS:
        layout=variant['layout']
        block=dict(t='imgs',layout=layout,title=variant['name'],items=photos,cols=3,default=1 if layout=='focus' else 0)
        code=json.dumps(block,ensure_ascii=False,indent=2)
        sections.append(sec('gallery-'+layout,variant['id']+' '+variant['name'],'多图样式',[
            txt('适用：'+variant['scope']),block,txt('交互：'+variant['interaction']),
            dict(t='html',v='<details class="g-code"><summary>查看配置示例</summary><pre tabindex="0" aria-label="图片样式配置">'+__import__('html').escape(code)+'</pre></details>'),
            call('图片完整显示，不裁掉信息；同组有限顺序，不自动播放。减少动态时关闭平滑滚动。')]))
    quote_text='以店为阵地、以平台为背书，以机制为驱动，把前端异业搭建为可持续获客的增长渠道。'
    sections.append(sec('phrase-wrap','T08 词组与数字换行','文字规范',[
        txt('词库和内容标记保护固定词组；短句做均衡排布。窄屏放不下整组时允许拆开，避免撑出正文。'),
        dict(t='quote',v=quote_text,keep_phrases=['以店为阵地','以平台为背书','以机制为驱动','增长渠道']),
        txt('城市合伙人使用同一份资料中心。参考周期 30 天，活动场地 180 ㎡。数字与单位保持同组。'),
        call('这是固定词库 + Agent 内容标记，浏览器没有通用业务语义理解；原文中的明确段落换行仍保留。')]))
    sections.append(sec('moments-live','L15 朋友圈图标与动效','交互规范',[
        txt('点击爱心可点赞与取消；点击气泡展开评论；发送后只添加到本页示例。'),moment_block,
        call('减少动态时保留图标、已赞和评论状态，不飞出爱心、不弹跳。中文输入法正在组词时回车不误发送。')]))
    illustration_dir=Path('/Users/apple/WorkBuddy/大金AI赋能/城市合伙人资料中心/illus')
    bundled=SKILL/'assets'/'portal-covers'
    bundled.mkdir(exist_ok=True)
    for name in ['partner.svg','flow.svg','template.svg']:
        src=bundled/name
        if not src.exists() and (illustration_dir/name).exists():shutil.copy2(illustration_dir/name,src)
        if src.exists():shutil.copy2(src,out/'assets'/name)
    portal=dict(title='城市合伙人 · 资料中心',kicker='大金新零售 · 城市合伙人项目',desc='一份讲清价值、一份教落地执行、一份给可复用版式。',steps=[dict(title='总部招商讲价值',desc='让门店看懂项目、愿意入局'),dict(title='门店启动教执行',desc='让团队照着话术和流程落地'),dict(title='现场会用模板',desc='换掉门店信息就能开一场')],resources=[
        dict(title='招商宣讲手册',tag='面向业务团队与经销商',cover='partner.svg',desc='讲清项目价值与合作方式。此入口展示统一封面卡片样式。',bullets=['明确资料对象','按用途选择手册'],actions=[dict(label='查看手册示例',href='示例招商手册.html',kind='read')]),
        dict(title='启动会执行手册',tag='面向门店执行人员',cover='flow.svg',desc='把准备、执行与复盘组织为可查阅的动作清单。',bullets=['场景与步骤对应','配套资料入口一致'],actions=[dict(label='查看手册示例',href='示例执行手册.html',kind='read')]),
        dict(title='现场会模板与清单',tag='配套模板与附件',cover='template.svg',desc='同一张卡片可有多个明确动作，不将整卡导航与内部按钮嵌套。',bullets=['按钮底部对齐','区分阅读、下载和外链'],actions=[dict(label='下载示例替换清单',href='assets/示例字段清单.txt',kind='download'),dict(label='查看入口配置',href='project-portal.json',kind='read')]),
    ],footer='本作品使用 MiSans 字体 · 本页为样式示例，未上线')
    (out/'assets'/'示例字段清单.txt').write_text('示例替换字段：项目名称、手册名称、适用对象、资料说明、封面图、阅读链接、下载路径。',encoding='utf-8')
    (out/'project-portal.json').write_text(json.dumps(portal,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'project-portal.html').write_text(portal_layout.build_page(portal),encoding='utf-8')
    for fname,title in [('示例招商手册.html','城市合伙人 · 招商宣讲手册'),('示例执行手册.html','城市合伙人 · 启动会执行手册')]:
        demo=build_html(title,'样式示例',dict(title=title,desc='本页用于验证资料中心到子手册的完整入口。'),[dict(id='demo',nav='示例说明',title='这是子手册样式示例',blocks=[txt('真实交付时，把这里替换成对应手册内容。')])],config=dict(home_href='project-portal.html'))
        (out/fname).write_text(demo,encoding='utf-8')
    sections.append(sec('project-portal-demo','P09 项目资料中心','资料入口',[
        txt('同一项目有多本手册、模板或附件时，使用统一项目标题、资料关系说明与 L18 资料封面入口卡。'),
        dict(t='resources',items=portal['resources']),
        dict(t='html',v='<p><a class="atlas-link" href="project-portal.html">打开完整资料中心样例 →</a></p>'),
        call('封面比例、标题层级、动作按钮位置固定；不存在的文件应标记待补，不能伪装成可下载。')]))
    header_demos=[]
    for slug,title in [('header-sales','城市合伙人 · 招商宣讲手册'),('header-execution','城市合伙人 · 启动会执行手册')]:
        header=render_header(title,config={'home_href':''})
        header_page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>'+CSS+APPLE_BASE_CSS+':root{'+''.join(k+':'+v+';' for k,v in tokens({}).items())+'}.topbar{position:static}</style></head><body class="viewing">'+header+'</body></html>'
        (out/(slug+'.html')).write_text(header_page,encoding='utf-8')
        header_demos.append('<p>'+title+'</p><div class="header-demo-row" inert>'+header.replace('id="home-btn"','')+'</div>')
    sections.insert(2,sec('shared-header','B01 标准品牌页头','固定样式目录',[
        txt('B01 标准品牌页头：左边永远是同一份 logo，大小和留白一致；右侧只换“资料系列 · 手册名”。下面是同一组件生成的两种标题，仅作页头外观对照。'),
        dict(t='html',v=''.join(header_demos)),
        call('禁止在品牌区写“大金空调”或“大金空调·城市合伙人”来代替 logo。没有“每本手册再设计一遍页头”的步骤。')]))
    catalog_links = '<div class="catalog-list">'+''.join('<a class="catalog-row" href="'+('#table-demo' if x['type']=='table' else '#project-portal-demo' if x['type']=='resources' else '#china-map' if x['type']=='china_map' else '#blk-'+x['type'])+'"><b>'+x['id']+' '+x['name']+'</b><span>'+x['scope']+'</span></a>' for x in CATALOG)+'</div>'
    sections.insert(1,sec('catalog','样式名称与选型','固定样式目录',[
        txt('以后直接报编号与名称，例如“把这页换成 L04 双栏对照”。配色沿用同一项目基准，不逐页重选。'),
        dict(t='html',v=catalog_links),
        dict(t='html',v='<p><a class="atlas-link" href="样式命名与规则.md">查看完整命名、交互与适用规则</a></p>')]))
    map_cities=json.loads((SKILL/'assets'/'maps'/'example-cities.json').read_text())
    map_block=dict(t='china_map',title='城市合伙人 · 城市分布示例',cities=map_cities,note='原资料点位快照，仅作样式示例，不代表实时覆盖数。')
    map_code=__import__('html').escape(json.dumps(dict(t='china_map',title='中国城市分布',cities=map_cities[:2]),ensure_ascii=False,indent=2))
    sections.append(sec('china-map','L19 中国城市分布地图','内容样式',[
        txt('适用：已确认的城市覆盖、区域布局与项目分布。底图、南海诸岛插图与经纬度点位沿用城市合伙人项目。'),map_block,
        txt('交互：悬停看城市名，点选后保留高亮与说明；右侧按区域汇总城市与省份，不堆叠城市按钮。缩放与复位收于图内，悬停或聚焦时显示；支持拖动平移、方向键平移和加减键缩放。'),
        dict(t='html',v='<details class="g-code"><summary>查看城市数据配置示例</summary><pre tabindex="0">'+map_code+'</pre></details>'),
        call('替换 cities 数组即可复用。城市名、省份、区域、经纬度和说明均由明确资料提供；不自动猜坐标，不把示例点位数量写成最新业务成绩。')]))
    from build_gallery import META
    by_type={x['type']:x for x in CATALOG}
    for sid,body in re.findall(r'<section class="section" id="([^"]+)"[^>]*>(.*?)</section>',original,re.S):
        if not sid.startswith('blk-'):continue
        t=sid[4:]
        if t not in by_type:continue
        entry=by_type[t]
        body=re.sub(r'^<div class="section-head">.*?</div>','',body,count=1,flags=re.S)
        body=body.replace('href="index.html#','href="#')
        if t=='metro':
            # The atlas demonstrates local stages, not links into a different project.
            body=re.sub(r'<button[^>]*class="xref-chip metro-goto".*?</button>','',body,flags=re.S)
            body=re.sub(r' data-goto="[^"]*"','',body)
            body=body.replace('data-nav="1"','data-nav="0"')

        sections.append(sec(sid,entry['id']+' '+entry['name'],'内容块 · '+META.get(t,('','其他'))[1],[dict(t='html',v=body)]))
    # One taxonomy, at most two levels. Variants belong beside other content styles.
    by_id={x['id']:x for x in sections}
    alias={'blk-pick':'states','blk-tabs':'tabs-demo','blk-moments':'moments-live','blk-imgs':'gallery-grid'}
    for old,new in [('blk-pick','states'),('blk-tabs','tabs-demo')]:
        if old in by_id:
            by_id[new]['blocks'] += [dict(t='h3',v='完整样例与代码'),*by_id[old]['blocks']]
    usage=sec('usage','使用说明','__bare__',[
        dict(t='lede',v='先确定整本风格，再按内容关系选择样式。以后修改主要围绕内容和样式编号。'),
        dict(t='steps',items=[
            dict(title='先看基础规范',body='logo、MiSans、页头与文字层级固定。同一项目的不同手册共用一份配置。'),
            dict(title='选一套配色与字号',body='在“配色与字号”中试用；预览会同步到所有内容样式。正式使用时下载配置，作为项目共用基准。'),
            dict(title='从内容样式里直接选型',body='文字、卡片、数据、流程、话术、图片和多图变体都在“内容样式”的第二级；点击具体编号即可查看适用范围、交互和样例。'),
            dict(title='用编号提出内容调整',body='例如“这一组照片改用 L17-C 焦点大图画廊”“这页改用 L04 双栏对照”。换版式沿用项目配色和品牌规则。'),
            dict(title='转换后集中核对',body='对照原文检查事实、数据、图片与关系，再检查选中、复制、切图和放大；自动检查通过不代替业务与视觉确认。')]),
        dict(t='html',v='<p class="preview-toolbar"><a class="atlas-link" href="#palette">配色与字号 →</a><a class="atlas-link" href="#catalog">内容样式 →</a><a class="atlas-link" href="#workflow">转换与验收 →</a></p>'),
        call('本库固定电脑端使用，手机与平板不开放正文。样例中的资料和互动用于演示；朋友圈点赞与评论仅在本页生效。原稿提供内容，不默认继承其零散版式与配色。')])
    if offline_download_href:
        download_card='<div class="skill-download-card"><strong>选择技能包 · V'+version+'</strong><p>网页版共享包小于 5 MiB，适合上传到 WorkBuddy；首次构建需联网准备完整 MiSans 字体。离线使用请选择已含全部资源的完整包。</p><a class="skill-download" href="'+__import__('html').escape(skill_download_href,quote=True)+'" download="handbook-workshop-v'+version+'.zip">下载网页版共享包 <span aria-hidden="true">↓</span></a> <a class="offline-skill-download" href="'+__import__('html').escape(offline_download_href,quote=True)+'" download="handbook-workshop-v'+version+'-offline.zip">下载完整离线包 <span aria-hidden="true">↓</span></a></div>'
    else:
        download_card='<div class="skill-download-card"><strong>获取技能包 · V'+version+'</strong><p>包含转换规则、样式引擎和品牌素材。可按使用环境选择网页版共享包或完整离线包。</p><a class="skill-download" href="'+__import__('html').escape(skill_download_href,quote=True)+'" download="handbook-workshop-v'+version+'.zip">下载技能包 V'+version+' <span aria-hidden="true">↓</span></a></div>'
    usage['blocks'].insert(1,dict(t='html',v=download_card))
    usage['blocks'].append(txt('读者页面默认仅显示资料更新日期，方便核对资料新旧，不添加版本号或设计者。仅调整样式时沿用原有日期；日期显示开关可在“配色与字号”设置并随配置导出。'))
    usage['blocks'].append(dict(t='html',v='<aside class="library-about" aria-labelledby="library-about-title"><h3 id="library-about-title">关于本样式库</h3><dl><div><dt>样式库版本</dt><dd>V'+__import__('html').escape(version)+'</dd></div><div><dt>设计者</dt><dd>吖君</dd></div></dl></aside>'))
    usage['blocks'].append(dict(t='html',v=render_credit(resolve_config())))
    ordered=[usage]
    for sid in ['start','shared-header','brand','type','phrase-wrap']:
        x=by_id[sid];x['group']='基础规范';ordered.append(x)
    by_id['palette']['group']='配色与字号';ordered.append(by_id['palette'])
    by_id['catalog']['group']='内容样式';by_id['catalog']['nav']='样式选型总览';ordered.append(by_id['catalog'])
    for entry in CATALOG:
        kind=entry['type']
        if kind=='imgs':sids=['gallery-grid','gallery-filmstrip','gallery-focus']
        elif kind=='table':sids=['table-demo']
        elif kind=='resources':sids=['project-portal-demo']
        elif kind=='china_map':sids=['china-map']
        else:sids=[alias.get('blk-'+kind,'blk-'+kind)]
        for sid in sids:
            if sid not in by_id:continue
            x=by_id[sid];x['group']='内容样式'
            if kind=='resources':x['nav']='L18 资料封面入口卡'
            ordered.append(x)
    for sid in ['recipes','workflow']:
        by_id[sid]['group']='转换与验收';ordered.append(by_id[sid])
    sections=ordered
    cfg=dict(skill_download_href=skill_download_href,palette='air-blue',type_scale='standard',home_href='',brand='大金 DAIKIN',brand_logo='assets/logo.png',cover_image='',mobile_block=True)
    html=build_html('网页手册 · 视觉与交互样式库','先定义风格，再转换内容',dict(title='网页手册\n视觉与交互样式库',desc='MiSans · 统一页头 · 十个色系 × 深浅模式 · 内容选型',kicker='首版质量改进 · 2026.11',meta='演示内容与示意配色'),sections,config=cfg)
    for old,new in alias.items():
        html=html.replace('href="#'+old+'"','href="#'+new+'"').replace('data-goto="'+old+'"','data-goto="'+new+'"')
    palettes={k:{mode:tokens(dict(palette=k,shell_mode=mode)) for mode in ('light','dark')} for k in PALETTES}
    extra_css='''<style>
.skill-download-card a.offline-skill-download{background:var(--surface);color:var(--brand);border:1px solid var(--border)}
.library-about{border-block-start:1px solid var(--border);margin-block:1.5rem 0;padding-block-start:1.25rem}
.library-about h3{font-size:1rem;font-weight:500;color:var(--brand);margin:0 0 .875rem;padding:0;border:0}
.library-about dl{display:flex;flex-wrap:wrap;gap:1rem 3rem;margin:0}
.library-about dt{font-size:.75rem;line-height:1.5;color:var(--muted);margin-block-end:.25rem}
.library-about dd{font-size:1rem;font-weight:430;line-height:1.5;color:var(--brand);margin:0}
.header-demo-row{border:1px solid var(--border);border-radius:.75rem;overflow:clip}.header-demo-row .topbar{position:static!important;padding-inline:1rem}.header-demo{display:block;inline-size:100%;block-size:5rem;border:1px solid var(--border);border-radius:.75rem;background:white}
.catalog-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,18rem),1fr));gap:.5rem}.catalog-row{display:block;padding:.875rem;border:1px solid var(--border);border-radius:.75rem;color:var(--brand);text-decoration:none}.catalog-row span{display:block;font-size:.8125rem;color:var(--muted);margin-block-start:.25rem}.catalog-row:hover{background:var(--accent-soft)}
.logo-plates{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,15rem),1fr));gap:1rem}.logo-plates figure{padding:2rem;background:#f4f7fb;margin:0;border-radius:1rem}.logo-plates figure.dark-plate{background:#102237;color:white}.logo-plates img{inline-size:100%;block-size:auto;border:0;cursor:default}.logo-plates figcaption{margin-block-start:1rem}
.date-option{display:flex;align-items:center;gap:.5rem;color:var(--muted);font-size:.875rem;margin-block:1rem}.date-option input{accent-color:var(--accent)}
.palette-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,12rem),1fr));gap:1rem;margin-block:1.5rem}
.palette-option{appearance:none;text-align:start;font:inherit;border:1px solid var(--border);background:#fff;border-radius:1rem;padding:1rem;cursor:pointer;min-inline-size:0}
.palette-option b,.palette-option small{display:block;margin-block-start:.5rem}.palette-option small{font-size:.8125rem;color:var(--muted)}
.palette-option[aria-pressed=true]{outline:2px solid var(--accent);outline-offset:2px;background:var(--accent-soft)}
.palette-swatches{display:flex;gap:.25rem}.palette-swatches i{display:block;inline-size:2rem;block-size:2rem;border-radius:.5rem;border:1px solid #ddd}
.preview-toolbar{display:flex;flex-wrap:wrap;gap:.5rem;margin-block:1rem}.preview-toolbar button,.atlas-link{border:1px solid var(--border);border-radius:.75rem;padding:.625rem .875rem;background:white;color:var(--brand);font:inherit;cursor:pointer;text-decoration:none}
.preview-toolbar button[aria-pressed=true]{border-color:var(--accent);background:var(--accent-soft)}
#design-status{color:var(--muted);font-size:.875rem}.cover-brand-text{font-weight:800;letter-spacing:.08em;color:var(--brand);margin-block-end:1.5rem}
</style>'''
    extra_js='''<script>
const designPalettes=__PALETTES__, designTypes=__TYPES__, designNames=__NAMES__;
let currentPalette='air-blue',currentType='standard',currentShell='light',showUpdateDate=true;
const legacyPalettes=__LEGACY__;
function applyDesign(){
 document.documentElement.dataset.shell=currentShell;
 document.querySelectorAll('.credit-date').forEach(el=>el.hidden=!showUpdateDate);
 document.getElementById('show-update-date').checked=showUpdateDate;
 document.querySelectorAll('.topbar').forEach(el=>el.setAttribute('data-surface',currentShell));
 document.querySelectorAll('.topbar .brand-logo').forEach(el=>el.src=currentShell==='dark'?'assets/logo-white.png':'assets/logo.png');
 Object.entries({...designPalettes[currentPalette][currentShell],...designTypes[currentType]}).forEach(([k,v])=>document.documentElement.style.setProperty(k,v));
 document.querySelectorAll('[data-palette]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.palette===currentPalette)));
 document.querySelectorAll('[data-shell-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.shellMode===currentShell)));
 document.querySelectorAll('[data-type]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.type===currentType)));
 try{localStorage.setItem('handbook-preview-v12',JSON.stringify({palette:currentPalette,type:currentType,shell_mode:currentShell,show_update_date:showUpdateDate}));}catch(e){}
 document.getElementById('design-status').textContent='当前：'+designNames[currentPalette]+' · '+(currentShell==='dark'?'深色外框':'浅色外框')+' · '+(currentType==='standard'?'日常阅读字号':'演示大字');
}
try{const saved=JSON.parse(localStorage.getItem('handbook-preview-v12')||'null');if(saved){if(legacyPalettes[saved.palette]){currentPalette=legacyPalettes[saved.palette];currentShell='dark';}else if(designPalettes[saved.palette])currentPalette=saved.palette;if(['light','dark'].includes(saved.shell_mode))currentShell=saved.shell_mode;}if(saved&&designTypes[saved.type])currentType=saved.type;if(saved&&typeof saved.show_update_date==='boolean')showUpdateDate=saved.show_update_date;}catch(e){}
applyDesign();
document.getElementById('show-update-date').addEventListener('change',e=>{showUpdateDate=e.target.checked;applyDesign();});
document.querySelectorAll('[data-shell-mode]').forEach(b=>b.addEventListener('click',()=>{currentShell=b.dataset.shellMode;applyDesign();}));
document.querySelectorAll('[data-palette]').forEach(b=>b.addEventListener('click',()=>{currentPalette=b.dataset.palette;applyDesign();}));
document.querySelectorAll('[data-type]').forEach(b=>b.addEventListener('click',()=>{currentType=b.dataset.type;applyDesign();}));
document.getElementById('download-design').addEventListener('click',()=>{
 const cfg={design_version:'1.3.7',show_update_date:showUpdateDate,palette:currentPalette,shell_mode:currentShell,type_scale:currentType,logo_header_height:28,logo_cover_height:48,cover_mode:'auto',cover_surface:'light',header_surface:currentShell,home_href:'',mobile_block:true,theme:{}};
 const url=URL.createObjectURL(new Blob([JSON.stringify(cfg,null,2)],{type:'application/json'}));
 const a=document.createElement('a');a.href=url;a.download='project-style.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
});
</script>'''.replace('__LEGACY__',json.dumps(LEGACY_PALETTES)).replace('__PALETTES__',json.dumps(palettes)).replace('__TYPES__',json.dumps(TYPE_SCALES)).replace('__NAMES__',json.dumps({k:p['name'] for k,p in PALETTES.items()},ensure_ascii=False))
    html=html.replace('</head>','<style>'+GALLERY_CSS+'</style>'+extra_css+'</head>').replace('</body>',extra_js+'</body>')
    html=html.replace('</head>','<meta name="font-credit" content="本作品使用 MiSans 字体"></head>',1)
    (out/'index.html').write_text(html,encoding='utf-8')
    (out/'配色与字号.json').write_text(json.dumps(dict(palettes=PALETTES,shell_modes=["light","dark"],type_scales=TYPE_SCALES),ensure_ascii=False,indent=2),encoding='utf-8')
    lines=['# 固定样式命名与使用规则','', '同一资料中心使用一份基准：logo、页头、字体层级、间距和交互规范保持一致。十个色系各有浅色/深色外框，用于项目级选型，不用于同本手册逐页变色。','']
    for x in BASE:
        lines += [f'## {x["id"]} {x["name"]}', '', '适用：'+x['scope'], '', '交互：'+x['interaction'], '', '配色：'+x['colors'], '']
    for x in CATALOG:
        lines += [f'## {x["id"]} {x["name"]}', '', f'实现类型：`{x["type"]}`', '', '适用：'+x['scope'], '', '不适用：'+x['avoid'], '', '交互：'+x['interaction'], '', '状态：'+x['states'], '', '配色：'+x['colors'], '']
    for x in GALLERY_VARIANTS:
        lines += [f'## {x["id"]} {x["name"]}', '', '适用：'+x['scope'], '', '不适用：'+x['avoid'], '', '交互：'+x['interaction'], '', '配色：继承项目统一配色。', '']
    lines += ['## 页面组合', '']+[x['id']+' '+x['name']+'：'+' + '.join(x['blocks']) for x in RECIPES]
    (out/'样式命名与规则.md').write_text('\n'.join(lines),encoding='utf-8')
    (out/'说明.md').write_text('# 网页手册视觉与交互样式库\n\n打开 index.html。先读使用说明，再看基础规范和配色与字号；文本、卡片、数据、流程、话术和多图变体全部归入内容样式的第二级，菜单最多两层。色系与深浅模式只在项目级选型时使用，无需跳转第二套页面。\n\n配色页可以下载当前配置，保存为项目共用的 project-style.json。保留现有 title/subtitle；logo 已固定为配套两版，按背景明暗自动使用，重新构建即可。选择状态仅为当前页面演示。\n\n本地可直接打开；未上线。候选配色不代表官方品牌色规范；logo 使用用户提供的两份正式素材。\n',encoding='utf-8')
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',required=True)
    ap.add_argument('--atlas',help='可选：build_gallery.py 新采样目录')
    ap.add_argument('--skill-download-href',help='技能包下载地址，默认使用 downloads/ 下的本地版本文件')
    args=ap.parse_args()
    print(build(Path(args.out).resolve(), args.atlas, args.skill_download_href))
