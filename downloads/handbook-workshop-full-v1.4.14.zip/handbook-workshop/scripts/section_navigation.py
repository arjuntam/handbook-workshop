"""L21-C: compact sticky local navigation, independent of media playback."""

CSS = r'''
.hw-section-jump{display:flex;align-items:center;gap:.75rem;padding:.5rem .75rem;border:1px solid var(--border);border-radius:var(--r-ctl);background:var(--surface);margin-block:1rem;min-inline-size:0}
.hw-section-jump.is-primary{position:sticky;top:var(--hw-section-top,60px);z-index:30}
.hw-section-jump.is-stuck{box-shadow:0 4px 12px #0000000d}
.hw-section-jump>span{flex:none;color:var(--muted);font-size:var(--fs-note);font-weight:var(--weight-title,500);white-space:nowrap}
.hw-section-jump-links{display:flex;align-items:center;gap:.375rem;min-inline-size:0;overflow-x:auto;overscroll-behavior-inline:contain;scrollbar-width:thin;padding:6px}
.hw-section-jump button{flex:none;white-space:nowrap;font:inherit;font-size:var(--fs-note);line-height:1.5;padding:.375rem .75rem;border:1px solid transparent;border-radius:999px;background:transparent;color:var(--text);cursor:pointer;min-block-size:2.75rem}
.hw-section-jump button:hover{background:var(--accent-soft)}
.hw-section-jump button[aria-current=location]{background:var(--accent-soft);color:var(--accent);border-color:var(--accent);font-weight:var(--weight-title,600)}
.hw-anchor{scroll-margin-block-start:var(--hw-anchor-offset,8rem);scroll-margin-block-end:8rem}
@media print{.hw-section-jump.is-primary{position:static;box-shadow:none}.hw-section-jump-links{flex-wrap:wrap;overflow:visible}}
'''

JS = r'''
/* hw-section-navigation:start v1 */
(()=>{
 const groups=[...document.querySelectorAll('.hw-section-jump')].map(nav=>{
  const section=nav.closest('.section');if(!section)return null;
  let links=nav.querySelector('.hw-section-jump-links');
  if(!links){links=document.createElement('div');links.className='hw-section-jump-links';[...nav.querySelectorAll('button[data-scroll]')].forEach(b=>links.append(b));nav.append(links);}
  const buttons=[...links.querySelectorAll('button[data-scroll]')];
  const targets=buttons.map(b=>[...section.querySelectorAll('[data-hw-anchor]')].find(t=>t.dataset.hwAnchor===b.dataset.scroll));
  buttons.forEach((b,i)=>{if(targets[i]?.id)b.setAttribute('aria-controls',targets[i].id);});
  return {nav,section,links,buttons,targets,current:null};
 }).filter(Boolean);
 if(!groups.length)return;
 const visible=x=>!!x?.getClientRects().length;
 const header=document.querySelector('body > .topbar');let pending=false;
 function reveal(g,b){
  const r=b.getBoundingClientRect(),box=g.links.getBoundingClientRect();
  if(r.left<box.left)g.links.scrollLeft-=box.left-r.left+4;
  else if(r.right>box.right)g.links.scrollLeft+=r.right-box.right+4;
 }
 function mark(g,index){
  const button=g.buttons[index]||null;if(g.current===button)return;g.current=button;
  g.buttons.forEach(b=>{if(b===button)b.setAttribute('aria-current','location');else b.removeAttribute('aria-current');});
  if(button)reveal(g,button);
 }
 function update(){
  pending=false;const top=visible(header)?Math.max(0,header.getBoundingClientRect().bottom):0,seen=new Set();
  groups.forEach(g=>{
   const shown=visible(g.nav),primary=shown&&!seen.has(g.section);if(primary)seen.add(g.section);
   g.nav.classList.toggle('is-primary',primary);
   if(!shown){mark(g,-1);return;}
   const value=top+'px';if(g.nav.style.getPropertyValue('--hw-section-top')!==value)g.nav.style.setProperty('--hw-section-top',value);
   const rect=g.nav.getBoundingClientRect();g.nav.classList.toggle('is-stuck',primary&&Math.abs(rect.top-top)<2);
   const sticky=primary?g.nav:groups.find(x=>x.section===g.section&&x.nav.classList.contains('is-primary'))?.nav;
   const offset=top+(sticky?.getBoundingClientRect().height||0)+24,margin=offset+'px';
   if(primary&&g.section.style.getPropertyValue('--hw-anchor-offset')!==margin)g.section.style.setProperty('--hw-anchor-offset',margin);
   const entries=g.targets.map((target,index)=>({target,index})).filter(x=>visible(x.target)).sort((a,b)=>a.target.getBoundingClientRect().top-b.target.getBoundingClientRect().top);
   let current=entries[0]?.index??-1;
   for(const x of entries){if(x.target.getBoundingClientRect().top<=offset+4)current=x.index;}
   if(scrollY+innerHeight>=document.documentElement.scrollHeight-2&&entries.length)current=entries.at(-1).index;
   mark(g,current);
  });
 }
 function schedule(){if(!pending){pending=true;requestAnimationFrame(update);}}
 document.addEventListener('click',e=>{
  const button=e.target.closest('.hw-section-jump [data-scroll]');if(!button)return;
  const g=groups.find(x=>x.nav.contains(button)),target=g?.targets[g.buttons.indexOf(button)];if(!visible(target))return;
  update();
  const primary=groups.find(x=>x.section===g.section&&x.nav.classList.contains('is-primary'));
  const offset=(visible(header)?Math.max(0,header.getBoundingClientRect().bottom):0)+(primary?.nav.getBoundingClientRect().height||0)+24;
  target.focus({preventScroll:true});
  window.scrollTo({top:scrollY+target.getBoundingClientRect().top-offset,behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});
  schedule();
 });
 addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);addEventListener('hb:sectionchange',schedule);
 document.addEventListener('toggle',schedule,true);
 const observer=new ResizeObserver(schedule);if(header)observer.observe(header);
 new Set(groups.map(g=>g.section)).forEach(s=>observer.observe(s));groups.forEach(g=>observer.observe(g.nav));
 document.fonts?.ready.then(schedule);update();
})();
/* hw-section-navigation:end */
'''
