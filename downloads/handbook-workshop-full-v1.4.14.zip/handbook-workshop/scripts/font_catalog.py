"""项目级字体选型与官方完整字库元数据；不做字形裁剪。"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT = 'misans'

# Optical weights differ between families; role values travel with the selected font.
ROLE_WEIGHTS = {
    'source-han-sans': dict(body=450, note=400, medium=550, title=650,
                           subheading=600, card=600, navigation=600,
                           table=600, emphasis=600, metric=700),
    'source-han-serif': dict(body=450, note=450, medium=600, title=700,
                            subheading=650, card=650, navigation=600,
                            table=650, emphasis=650, metric=700),
}


def catalog(root=None):
    return json.loads((Path(root or ROOT)/'assets/font-catalog.json').read_text(encoding='utf-8'))


def spec(key=DEFAULT, root=None):
    fonts = catalog(root)
    if key not in fonts:
        raise ValueError('未知字体选项：' + str(key))
    return fonts[key]


def tokens(key=DEFAULT):
    face = spec(key)
    serif = key == 'source-han-serif'
    result = {'--sans': '"' + face['family'] + '",' + ('serif' if serif else 'sans-serif'),
              '--weight-body': '330', '--weight-title': '500', '--weight-medium': '430'}
    result.update({'--weight-'+role:str(weight) for role,weight in ROLE_WEIGHTS.get(key,{}).items()})
    return result


def faces_css():
    return ''.join('@font-face{font-family:"'+f['family']+'";src:url("assets/fonts/'+f['file']+'") format("'+f['format']+'");font-weight:'+f['weight']+';font-style:normal;font-display:swap}' for f in catalog().values())


def preview_data():
    return {k:dict(name=f['name'],family=f['family'],tokens=tokens(k)) for k,f in catalog().items()}
