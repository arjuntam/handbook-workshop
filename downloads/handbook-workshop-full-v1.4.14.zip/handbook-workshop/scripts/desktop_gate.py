"""固定电脑端访问策略：不提供单本关闭开关，不放行 iPad。"""
JS=r'''
(function(){
 const ua=navigator.userAgent||'';
 const ipad=/iPad/i.test(ua)||(/Macintosh/.test(ua)&&navigator.maxTouchPoints>0);
 const mobile=ipad||/Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini|Mobile/i.test(ua);
 const narrow=innerWidth<900;
 if(!mobile&&!narrow)return;
 document.documentElement.classList.add('mobile-blocked');document.body.classList.add('mobile-blocked');
 if(document.querySelector('.mobile-block'))return;
 const screen=document.createElement('div');screen.className='mobile-block';screen.setAttribute('role','alertdialog');screen.setAttribute('aria-modal','true');
 const card=document.createElement('div');card.className='mb-card';
 const heading=document.createElement('h2');heading.textContent=mobile?'请使用电脑打开':'请扩大电脑浏览器窗口';
 const p=document.createElement('p');p.textContent=mobile?'本资料仅支持电脑端。手机和平板不开放正文与交互。':'请使用至少 900px 宽的电脑浏览器窗口查看。';
 card.append(heading,p);screen.append(card);document.body.append(screen);
})();
'''
