"""生成全文搜索的虚构验收内容；输出至已有样式库旁以复用 assets。"""
from pathlib import Path
import argparse
from handbook_core import build_html
sections=[]
def add(id,title,blocks):sections.append(dict(id=id,nav=title,title=title,group='搜索验证',blocks=blocks))
add('body','正文与表格',[dict(t='text',v='排序试词出现在正文。跨段甲在这里。'),dict(t='text',v='跨段乙在另一段。MiXeDCase 样例。'),dict(t='table',head=['项目','资料'],rows=[['甲项目','表格独有词']]),dict(t='html',v='<p>连<span>续短</span>语测试。</p><p>&lt;img src=x onerror=alert(1)&gt;</p>'),dict(t='html',v='<svg viewBox="0 0 200 60" role="img"><text x="10" y="30">矢量独有词</text></svg>'),dict(t='stats',items=[dict(num='98765',label='测试数量')])])
add('rank','排序试词标题',[dict(t='text',v='优先打开标题命中的页面。')])
add('hidden','折叠与切换',[dict(t='faq',items=[dict(q='折叠提问',answer='折叠独有词与可复制回答。')]),dict(t='tabs',items=[dict(tab='常规',body='常规内容'),dict(tab='备用',block=dict(t='faq',items=[dict(q='备用提问',answer='嵌套独有词')]))]),dict(t='metro',items=[dict(title='起点',body='一般内容'),dict(title='终点',body='阶段独有词')])])
add('detail','详情联动',[dict(t='detail_table',title='验收表',columns=[dict(key='n',label='份数',max=10)],items=[dict(id='one',title='默认对象',values=dict(n=1),blocks=[dict(t='text',v='默认说明')]),dict(id='two',title='未选中对象',values=dict(n=2),blocks=[dict(t='text',v='详情独有词')])])])
add('control','交互保留',[dict(t='faq',items=[dict(q='复制动作',answer='复制验收词')])])
html=build_html('搜索验证 · 手册','搜索验证',dict(title='验收',desc=''),sections,config=dict(home_href='',cover_mode='plain'))
if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',required=True);a=ap.parse_args()
    path=Path(a.out);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(html,encoding='utf-8');print(path)
