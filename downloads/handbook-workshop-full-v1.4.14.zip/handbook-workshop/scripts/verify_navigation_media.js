const fs=require('fs'),path=require('path'),{pathToFileURL}=require('url');
const {launchBrowser}=require('./browser_runtime');
const [site,out]=process.argv.slice(2);if(!out)throw Error('Usage: node verify_navigation_media.js index.html output');fs.mkdirSync(out,{recursive:true});
(async()=>{
 const browser=await launchBrowser(),checks=[],errors=[],mediaRequests=[];
 const ck=(name,ok,detail)=>{checks.push({name,ok,detail});if(!ok)throw Error(name+' '+JSON.stringify(detail||''));};
 try{
  const p=await browser.newPage({viewport:{width:1440,height:1050},reducedMotion:'reduce'});p.on('pageerror',e=>errors.push(String(e)));p.on('request',r=>{if(/\.wav(?:$|\?)/.test(r.url()))mediaRequests.push(r.url())});
  await p.goto(pathToFileURL(path.resolve(site)).href+'#blk-chapter_cover',{waitUntil:'domcontentloaded'});
  async function visit(id){await p.evaluate(id=>location.hash=id,id);await p.locator('#'+id+'.active').waitFor();}
  ck('新分类与总数',await p.locator('#catalog').textContent().then(t=>t.includes('45')&&t.includes('6')));
  ck('页面加载不预取全部音频',mediaRequests.length===0,mediaRequests);
  await p.locator('.hw-cover-card').first().focus();await p.keyboard.press('Enter');ck('整卡键盘跳章与目录同步',await p.locator('#blk-section_jump.active').count()===1&&await p.locator('.nav-link[aria-current=true]').getAttribute('href')==='#blk-section_jump');
  await p.locator('#blk-section_jump .hw-section-jump button').nth(2).click();const anchor=p.locator('#blk-section_jump [data-hw-anchor="deliver"]');
  ck('节内跳读聚焦且避让页头',await anchor.evaluate(x=>document.activeElement===x&&x.getBoundingClientRect().top>=60&&x.getBoundingClientRect().bottom<innerHeight-80));
  await p.locator('#blk-section_jump .hw-back-link button').click();ck('返回明确上层',await p.locator('#blk-chapter_cover.active').count()===1);
  await p.locator('.hw-cover-action button').click();ck('扉页主入口可用',await p.locator('#blk-section_jump.active').count()===1);
  await visit('blk-back_link');await p.locator('#blk-back_link button[data-goto]').click();ck('独立回跳条可用',await p.locator('#blk-chapter_cover.active').count()===1);
  await visit('blk-audio');const players=p.locator('#blk-audio .hw-audio'),first=players.nth(0),second=players.nth(1),audio=first.locator('audio');
  ck('同页播放器独立且未自动播放',await players.count()===2&&await audio.evaluate(a=>a.paused)&&await first.getAttribute('data-state')==='ready');
  ck('同页播放器控件 ID 不冲突',await p.locator('#blk-audio [id]').evaluateAll(xs=>new Set(xs.map(x=>x.id)).size===xs.length));
  ck('一个标签可以组合多个块',await p.locator('#blk-audio .tab-panel.on .rs').count()===1&&await p.locator('#blk-audio .tab-panel.on .body-text').count()===2&&await p.locator('#blk-audio .tab-panel.on .card-num').count()===0);
  await first.locator('.hw-audio-play').click();await p.waitForFunction(()=>{const a=document.querySelector('#blk-audio .hw-audio audio');return !a.paused&&a.currentTime>.1});
  ck('真实音频资源已解码并播放',await audio.evaluate(a=>a.duration>=7.9&&a.duration<=8.1)&&await first.getAttribute('data-state')==='playing');
  await first.locator('.hw-audio-seek').evaluate(x=>{x.value='50';x.dispatchEvent(new Event('input',{bubbles:true}))});ck('拖动调整实际进度',await audio.evaluate(a=>a.currentTime>=3.9&&a.currentTime<5));
  await first.locator('.hw-audio-rate').click();ck('倍速调整实际音频',await audio.evaluate(a=>a.playbackRate===1.25));
  await first.locator('.hw-audio-play').click();await p.waitForFunction(()=>document.querySelector('#blk-audio .hw-audio').dataset.state==='paused');ck('暂停按钮与实际状态一致',await audio.evaluate(a=>a.paused)&&await first.getAttribute('data-state')==='paused');
  const tabs=p.locator('#blk-audio .tab-head');await tabs.nth(1).focus();await p.keyboard.press('Enter');
  ck('标签换源并显示待补',await first.getAttribute('data-state')==='empty'&&await first.locator('.hw-audio-play').isDisabled()&&await audio.getAttribute('src')===null);
  await tabs.nth(0).evaluate(x=>x.textContent='改名后的场景');await tabs.nth(0).click();ck('改标签名仍按 key 对应',await first.getAttribute('data-state')==='ready'&&(await first.locator('.hw-audio-title').textContent()).includes('合成提示音'));
  await first.locator('.hw-audio-play').click();await p.waitForTimeout(150);await second.locator('.hw-audio-play').click();await p.waitForTimeout(150);
  ck('播放另一条时暂停前一条',await audio.evaluate(a=>a.paused)&&await second.locator('audio').evaluate(a=>!a.paused));
  await second.locator('select').selectOption('second');ck('独立选择器换源并停止旧录音',await second.locator('audio').evaluate(a=>a.paused&&!a.hasAttribute('src')));
  await second.locator('.hw-audio-play').click();await p.waitForTimeout(150);await visit('blk-back_link');ck('离开章节暂停播放',await second.locator('audio').evaluate(a=>a.paused));
  await visit('blk-audio');await second.locator('.hw-audio-play').click();await p.waitForTimeout(150);await p.locator('body > .topbar #home-btn').click();ck('返回封面暂停播放',await second.locator('audio').evaluate(a=>a.paused));
  await visit('blk-audio');await second.locator('audio').evaluate(a=>{a.src='assets/media-examples/missing-test.wav';a.load()});await second.locator('.hw-audio-play').click();await p.waitForFunction(()=>document.querySelectorAll('#blk-audio .hw-audio')[1].dataset.state==='error');
  ck('失败有提示且不伪装播放',await second.locator('.hw-audio-note').textContent().then(t=>t.includes('失败'))&&await second.locator('.hw-audio-seek').isDisabled());
  await second.locator('select').selectOption('first');ck('错误后可换回有效源',await second.getAttribute('data-state')==='ready');
  const search=p.locator('.search-box input').first();await search.fill('本场景的录音尚未提供');await p.waitForTimeout(230);await p.locator('.search-result').first().click();await p.waitForTimeout(100);
  ck('全文搜索可打开未选中录音说明',await first.getAttribute('data-state')==='empty'&&await first.locator('[data-transcript-key=pending]').isVisible());
  for(const width of [1440,1024])for(const font of ['misans','source-han-sans','source-han-serif'])for(const factor of [1,1.5]){
   const mode=[width,font,factor].join('-');await p.setViewportSize({width,height:1050});await visit('palette');await p.locator('#palette [data-font="'+font+'"]').click();await p.locator('#palette [data-type="'+(factor===1?'standard':'presentation')+'"]').click();await p.locator('#type-size-slider').evaluate((x,f)=>{x.value=String(f*100);x.dispatchEvent(new Event('input',{bubbles:true}))},factor);
   await p.locator('#palette [data-shell-mode="'+(factor===1?'light':'dark')+'"]').click();await p.evaluate(()=>document.fonts.ready);
   for(const id of ['blk-chapter_cover','blk-back_link','blk-section_jump','blk-audio','gallery-filmstrip']){
    await visit(id);const shape=await p.locator('#'+id).evaluate(s=>({overflow:document.documentElement.scrollWidth>innerWidth+2,clipped:[...s.querySelectorAll('button,p,h3,figcaption')].filter(x=>x.getClientRects().length&&!x.closest('.sr-only')&&/hidden|clip/.test(getComputedStyle(x).overflowY)&&x.scrollHeight>x.clientHeight+2).length}));ck('排版无横溢或裁字 '+mode+' '+id,!shape.overflow&&!shape.clipped,shape);
    if(width===1440&&font==='misans'&&factor===1){await p.locator('#'+id+' img').evaluateAll(xs=>Promise.all(xs.map(x=>x.decode().catch(()=>{}))));await p.evaluate(()=>window.scrollTo(0,0));await p.screenshot({path:path.join(out,id+'.png'),fullPage:true});}
   }
   await visit('blk-audio');ck('日期范围保持单行 '+mode,await p.locator('#blk-audio .rs-t').evaluateAll(xs=>xs.every(x=>getComputedStyle(x).whiteSpace==='nowrap'&&x.scrollWidth<=x.clientWidth+2)));
   await visit('gallery-filmstrip');const portrait=p.locator('#gallery-filmstrip .g-portrait');await portrait.locator('img').first().evaluate(im=>im.decode());await portrait.locator('.g-marker').nth(2).click();await p.waitForTimeout(180);ck('竖图胶片可切换到最后一张 '+mode,await portrait.locator('.g-count').textContent()==='3 / 3');
   ck('竖图保持自然比例 '+mode,await portrait.locator('img').first().evaluate(im=>{const r=im.getBoundingClientRect();return Math.abs(r.width/r.height-.75)<.03}));
  }
  ck('无页面脚本错误',errors.length===0,errors);
 }finally{await browser.close();fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({checks:checks.length,failures:checks.filter(x=>!x.ok).length,errors,results:checks},null,2));}
 console.log('Navigation/media checks passed: '+checks.length);
})().catch(e=>{console.error(e);process.exitCode=1});
