const fs=require('fs'),path=require('path'),{pathToFileURL}=require('url');
const {launchBrowser}=require('./browser_runtime');
const [site,out]=process.argv.slice(2);if(!out)throw Error('Usage: node verify_section_navigation.js index.html output');
fs.mkdirSync(out,{recursive:true});
(async()=>{
 const browser=await launchBrowser(),results=[],errors=[];
 const ck=(name,ok,detail)=>{results.push({name,ok,detail});if(!ok)throw Error(name+' '+JSON.stringify(detail));};
 try{
  const p=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce'});p.on('pageerror',e=>errors.push(String(e)));
  await p.goto(pathToFileURL(path.resolve(site)).href+'#blk-section_jump',{waitUntil:'domcontentloaded'});
  async function visit(id){await p.evaluate(id=>location.hash=id,id);await p.locator('#'+id+'.active').waitFor();await p.waitForTimeout(60);}
  // Simulate genuinely long sections without changing the library's editorial content.
  await p.locator('#blk-section_jump [data-hw-anchor]').evaluateAll(xs=>xs.forEach(x=>{
   const content=document.createElement('div');content.className='long-fixture';content.style.minHeight='1100px';
   for(let i=0;i<12;i++){const para=document.createElement('p');para.textContent='长章节验收：保留完整正文，随时从分区入口跳读。';content.append(para);}x.after(content);
  }));
  for(const width of [1440,1024])for(const font of ['misans','source-han-sans','source-han-serif'])for(const scale of [1,1.5]){
   const mode=[width,font,scale].join('-');await p.setViewportSize({width,height:1000});await visit('palette');
   await p.locator('#palette [data-font="'+font+'"]').click();await p.locator('#palette [data-type="'+(scale===1?'standard':'presentation')+'"]').click();
   await p.locator('#type-size-slider').evaluate((x,s)=>{x.value=String(s*100);x.dispatchEvent(new Event('input',{bubbles:true}))},scale);await p.evaluate(()=>document.fonts.ready);
   await visit('blk-section_jump');const nav=p.locator('#blk-section_jump .hw-section-jump');
   for(const key of ['prepare','check','deliver']){
    await nav.locator('[data-scroll='+key+']').focus();await p.keyboard.press('Enter');await p.waitForTimeout(80);
    const state=await p.locator('#blk-section_jump').evaluate((s,key)=>{
     const n=s.querySelector('.hw-section-jump'),t=s.querySelector('[data-hw-anchor='+key+']');
     return {header:document.querySelector('body > .topbar').getBoundingClientRect().bottom,nav:n.getBoundingClientRect().toJSON(),target:t.getBoundingClientRect().toJSON(),focus:document.activeElement===t,current:n.querySelector('[aria-current=location]')?.dataset.scroll,overflow:document.documentElement.scrollWidth>innerWidth+2};
    },key);
    ck('定位与吸顶 '+mode+' '+key,state.focus&&state.current===key&&Math.abs(state.nav.top-state.header)<2&&state.target.top>=state.nav.bottom+20&&!state.overflow,state);
   }
   await p.locator('#blk-section_jump [data-hw-anchor=check]').evaluate(t=>window.scrollTo(0,scrollY+t.getBoundingClientRect().top+400));await p.waitForTimeout(80);
   ck('手动阅读同步高亮 '+mode,await nav.locator('[aria-current=location]').getAttribute('data-scroll')==='check');
   ck('紧凑单行 '+mode,await nav.evaluate(n=>{const bs=[...n.querySelectorAll('button')];return new Set(bs.map(b=>Math.round(b.getBoundingClientRect().top))).size===1&&n.getBoundingClientRect().height<innerHeight*.12}));
   if(width===1440&&font==='misans'&&scale===1)await p.screenshot({path:path.join(out,'sticky-reading.png')});
  }
  await p.setViewportSize({width:1024,height:1000});await p.locator('#blk-section_jump .hw-section-jump button').evaluateAll(xs=>xs.forEach((b,i)=>b.textContent='较长分区名称用于验证横向滚动 '+i));
  await p.evaluate(()=>dispatchEvent(new Event('resize')));await p.waitForTimeout(80);
  const nav=p.locator('#blk-section_jump .hw-section-jump');
  ck('长标题局部滚动而非页面溢出',await nav.evaluate(n=>{const box=n.querySelector('.hw-section-jump-links');return box.scrollWidth>box.clientWidth&&document.documentElement.scrollWidth<=innerWidth+2}));
  await nav.locator('button').last().focus();await p.keyboard.press('Enter');await p.waitForTimeout(80);
  ck('横向末项键盘可达且露出',await nav.locator('button').last().evaluate(b=>{const r=b.getBoundingClientRect(),box=b.parentElement.getBoundingClientRect();return b.getAttribute('aria-current')==='location'&&r.left>=box.left-1&&r.right<=box.right+1}));
  await p.evaluate(()=>scrollTo(0,document.documentElement.scrollHeight));await p.waitForTimeout(80);
  ck('页面底部高亮最后分区',await nav.locator('[aria-current=location]').getAttribute('data-scroll')==='deliver');
  await visit('blk-audio');ck('换节后旧分区条退出',!(await nav.isVisible())&&await p.locator('.hw-section-jump.is-primary').count()===0);
  ck('无脚本异常',errors.length===0,errors);
 }finally{await browser.close();fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({checks:results.length,failures:results.filter(x=>!x.ok).length,errors,results},null,2));}
 console.log('Section navigation checks passed: '+results.length);
})().catch(e=>{console.error(e);process.exitCode=1});
