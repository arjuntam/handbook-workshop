#!/usr/bin/env python3
"""从 portal.json 构建同项目多资料入口页。源和输出目录都由用户指定。"""
import argparse,json
from pathlib import Path
from handbook_core import ensure_brand_assets,prepare_assets
from portal_layout import build_page

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--content',required=True);ap.add_argument('--out',required=True)
    args=ap.parse_args();source=Path(args.content).resolve();out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
    data=json.loads(source.read_text(encoding='utf-8'));cfg=data.get('config',{})
    shared=source.parent/'project-style.json'
    if shared.exists():cfg['project_style_file']=str(shared)
    ensure_brand_assets(out,cfg);A=prepare_assets(source.parent/'assets',out)
    html=build_page(data,A,cfg)
    (out/'index.html').write_text(html,encoding='utf-8');print(out/'index.html')

if __name__=='__main__':main()
