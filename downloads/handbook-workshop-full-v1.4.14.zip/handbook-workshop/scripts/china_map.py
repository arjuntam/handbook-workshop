"""L19 中国城市分布地图：沿用提供的底图，城市数据独立配置。"""
import html,json,math
from pathlib import Path
from itertools import count
_IDS=count(1)
ASSETS=Path(__file__).resolve().parent.parent/'assets'/'maps'

def validate(block):
    cities=block.get('cities',[])
    if not isinstance(cities,list) or not cities:raise ValueError('china_map.cities 必须是非空列表')
    names=set()
    for city in cities:
        if not isinstance(city,dict) or not all(city.get(k) for k in ('name','province','region')):raise ValueError('地图城市须包含 name / province / region')
        if city['name'] in names:raise ValueError('地图城市名称不可重复')
        names.add(city['name'])
        x,y=city.get('lng'),city.get('lat')
        if isinstance(x,bool) or isinstance(y,bool) or not isinstance(x,(int,float)) or not isinstance(y,(int,float)) or not (73<=x<=136 and 17.2<=y<=54.6):raise ValueError('地图经纬度缺失或超出底图范围，不自动猜测城市坐标')
    return cities

def render(block):
    cities=validate(block);base=json.loads((ASSETS/'china-base.json').read_text());uid='china-map-'+str(next(_IDS));esc=lambda s:html.escape(str(s),quote=True)
    regions=list(dict.fromkeys(x['region'] for x in cities));province_names={x['province'] for x in cities}
    land=''.join('<path class="cm-land'+(' is-covered' if any(x['name'].startswith(n) for n in province_names) else '')+'" d="'+x['d']+'"/>' for x in base['provinces'])
    def xy(lon,lat):
        merc=lambda y:math.log(math.tan(math.pi/4+math.radians(y)/2))*180/math.pi
        return (lon-73)*660/63,(merc(54.6)-merc(lat))*660/63
    dots=[];labels=[]
    for i,city in enumerate(cities):
        x,y=xy(city['lng'],city['lat']);label=esc(city['name']);region=esc(city['region']);detail=esc(city.get('detail',''))
        dots.append(f'<g class="cm-point" data-city="{i}" data-region="{region}" tabindex="0" role="button" aria-label="选择{label}" aria-pressed="false"><title>{label}</title><circle class="cm-halo" cx="{x:.1f}" cy="{y:.1f}" r="8"/><circle class="cm-dot" cx="{x:.1f}" cy="{y:.1f}" r="3.5"/><text class="cm-label" x="{x:.1f}" y="{y-9:.1f}">{label}</text></g>')
        labels.append(f'<span class="cm-city" data-city="{i}" data-region="{region}" data-detail="{detail}">{label}</span>')
    zones=[]
    for ri,region in enumerate(regions):
        entries=[(i,c) for i,c in enumerate(cities) if c['region']==region]
        provinces={}
        for _,city in entries:provinces[city['province']]=provinces.get(city['province'],0)+1
        counts=' · '.join(esc(n)+' '+str(v) for n,v in provinces.items())
        names='<span class="cm-city-separator" aria-hidden="true"> · </span>'.join(labels[i] for i,_ in entries)
        zones.append(f'<section class="cm-zone" style="--zone-color:var({"--brand" if ri%2==0 else "--accent"})"><h4><i aria-hidden="true"></i>{esc(region)} {len(entries)} 座</h4><p class="cm-provinces">{counts}</p><p class="cm-city-names">{names}</p></section>')
    note=esc(block.get('note','点位用于分布示意，请以对应资料的数据日期与口径为准。'))
    return f'''<div class="china-map-component" id="{uid}" role="group" aria-label="{esc(block.get('title','中国城市分布'))}">
<div class="cm-heading"><span><b class="cm-total">{len(cities)}</b> 个城市点位</span><span class="cm-data-note">{note}</span></div>
<div class="cm-layout"><div class="cm-maparea"><div class="cm-mapframe" tabindex="0" role="group" aria-label="城市地图：方向键平移，加减键缩放，Home 复位"><svg class="cm-map" viewBox="0 0 660 503" role="group" aria-label="中国城市分布，含南海诸岛插图"><defs><radialGradient id="{uid}-halo"><stop offset="0" stop-color="var(--map-dot,var(--accent))" stop-opacity=".36"/><stop offset=".55" stop-color="var(--map-dot,var(--accent))" stop-opacity=".15"/><stop offset="1" stop-color="var(--map-dot,var(--accent))" stop-opacity="0"/></radialGradient></defs>{land}{base['inset_svg']}<g class="cm-points" style="--cm-halo:url(#{uid}-halo)">{''.join(dots)}</g></svg>
<span class="cm-hint">Ctrl/⌘ + 滚轮缩放 · 拖动平移</span><div class="cm-tools" role="group" aria-label="地图缩放"><button type="button" data-map-action="out" aria-label="缩小地图">−</button><output class="cm-zoom sr-only" aria-live="polite">100%</output><button type="button" data-map-action="in" aria-label="放大地图">+</button><button type="button" data-map-action="reset">复位</button></div></div></div>
<div class="cm-listpanel">{''.join(zones)}<p class="cm-selection" role="status" aria-live="polite"></p></div></div>
<p class="cm-source"><span>底图沿用城市合伙人资料现有素材 · 原资料标注 GS(2022)4309号 · 含南海诸岛插图</span><span class="cm-version">L19 城市分布</span></p></div>'''

CSS=r'''
.china-map-component{border:1px solid var(--border);border-radius:1rem;background:linear-gradient(180deg,var(--flow-paper),var(--bg));padding:1rem 1.125rem .75rem;min-inline-size:0;margin-block:1.5rem}
.cm-heading{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.75rem;align-items:baseline;color:var(--brand)}
.cm-total{font-size:1.75rem;font-weight:500;margin-inline-end:.375rem}.cm-heading>span:first-child{font-size:.8125rem}.cm-data-note{color:var(--muted);font-size:.71875rem;max-inline-size:36rem}
.cm-layout{display:flex;flex-wrap:wrap;gap:.875rem;align-items:flex-start}.cm-maparea{flex:1 1 62%;min-inline-size:0}.cm-listpanel{flex:1 1 30%;min-inline-size:0;display:grid;gap:.5625rem;padding-block-start:.25rem}
.cm-mapframe{position:relative;overflow:clip;background:#fff;border-radius:.625rem;cursor:grab;touch-action:none}.cm-mapframe.is-dragging{cursor:grabbing}
.cm-map{display:block;inline-size:100%;aspect-ratio:660/503;overflow:hidden;user-select:none}
.cm-land{fill:var(--map-land-fill,#E6EDF6);stroke:#C0D0E2;stroke-width:.75;stroke-linejoin:round}.cm-land.is-covered{fill:var(--map-covered-fill,#9CC8EF);stroke:var(--map-covered-stroke,#4F95D4);stroke-width:1.05}
.cm-inset-bg{fill:#FBFDFF;stroke:#E6EEF7;stroke-width:.7}.cm-inset-line{fill:none;stroke:#A9C1D8;stroke-width:.8}.cm-inset-land{fill:#E8F1FA;stroke:#BCD3EA;stroke-width:.5}.cm-inset-t{font-size:6.5px;fill:#657D94;text-anchor:middle}
.cm-point{cursor:pointer;outline:none}.cm-halo{fill:var(--cm-halo);opacity:1}.cm-dot{fill:var(--map-dot,var(--accent));stroke:#fff;stroke-width:1.9;vector-effect:non-scaling-stroke}
.cm-label{font-family:MiSans,sans-serif;font-size:10px;font-weight:430;fill:var(--brand);text-anchor:middle;paint-order:stroke;stroke:#fff;stroke-width:3;stroke-linejoin:round;opacity:0;pointer-events:none}
.cm-map.is-zoomed .cm-label,.cm-point:hover .cm-label,.cm-point:focus-visible .cm-label,.cm-point[aria-pressed=true] .cm-label{opacity:1}
.cm-point:focus-visible .cm-dot,.cm-point[aria-pressed=true] .cm-dot{stroke-width:3}
.cm-point:focus-visible .cm-halo,.cm-point[aria-pressed=true] .cm-halo{stroke:var(--accent);stroke-width:1;vector-effect:non-scaling-stroke}
.cm-zone{background:var(--surface);border:1px solid var(--border);border-radius:.5625rem;padding:.5rem .625rem}
.cm-zone h4{display:flex;align-items:center;gap:.375rem;font-size:.875rem!important;font-weight:500!important;line-height:1.5;color:var(--brand);margin:0}
.cm-zone h4 i{inline-size:.375rem;block-size:.375rem;flex:none;border-radius:50%;background:var(--zone-color)}
.cm-zone .cm-provinces{font-size:.71875rem;line-height:1.5;color:var(--muted);margin:.1875rem 0 0}
.cm-zone .cm-city-names{font-size:.8125rem;line-height:1.65;color:var(--muted);margin:.25rem 0 0}
.cm-city{display:inline;white-space:nowrap}.cm-city.is-selected{color:var(--accent);font-weight:500;text-decoration:underline;text-underline-offset:.2em}
.cm-selection{font-size:.75rem;line-height:1.6;color:var(--muted);margin:0}.cm-selection:empty{display:none}
.cm-source{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:.5rem;font-size:.6875rem;color:var(--muted);line-height:1.6;margin:.5rem 0 0}
.cm-version{font-size:.65625rem;padding:.125rem .5rem;border:1px solid var(--border);border-radius:99px;white-space:nowrap}
.cm-tools{position:absolute;inset-inline-end:.5rem;inset-block-end:.5rem;display:flex;align-items:center;gap:.3125rem;opacity:0;transition:opacity .15s;z-index:2}
.cm-mapframe:hover .cm-tools,.cm-mapframe:focus-within .cm-tools{opacity:1}
.cm-tools button{font:inherit;font-size:.875rem;font-weight:430;min-inline-size:1.75rem;min-block-size:1.75rem;padding:.125rem .4375rem;border:1px solid var(--border);border-radius:.4375rem;background:var(--surface);color:var(--brand);cursor:pointer;box-shadow:0 2px 6px rgba(16,42,71,.08)}
.cm-tools button:disabled{opacity:.4;cursor:default}.cm-tools button[data-map-action=reset]{font-size:.71875rem}
.cm-hint{position:absolute;inset-inline-end:.5rem;inset-block-start:.5rem;background:rgba(255,255,255,.88);font-size:.6875rem;color:var(--muted);padding:.125rem .4375rem;border-radius:.3125rem;pointer-events:none}
@media(prefers-reduced-motion:reduce){.cm-tools{transition:none}}
@media(forced-colors:active){.cm-city.is-selected{color:Highlight}.cm-tools button{border-color:ButtonText}}
'''

JS=r'''
(function(){document.querySelectorAll('.china-map-component').forEach(root=>{
 const frame=root.querySelector('.cm-mapframe'),svg=root.querySelector('svg'),points=[...root.querySelectorAll('.cm-point')],cities=[...root.querySelectorAll('.cm-city')].sort((a,b)=>Number(a.dataset.city)-Number(b.dataset.city));
 const info=root.querySelector('.cm-selection'),zoom=root.querySelector('.cm-zoom');
 let scale=1,x=0,y=0,drag=null,suppress=0;
 function paint(){const w=660/scale,h=503/scale;x=Math.max(0,Math.min(660-w,x));y=Math.max(0,Math.min(503-h,y));svg.setAttribute('viewBox',[x,y,w,h].join(' '));zoom.textContent=Math.round(scale*100)+'%';root.querySelector('[data-map-action=out]').disabled=scale===1;root.querySelector('[data-map-action=in]').disabled=scale===4;const u=w/(frame.clientWidth||660);svg.classList.toggle('is-zoomed',scale>=1.55);points.forEach(p=>{p.querySelector('.cm-dot').setAttribute('r',4*u);p.querySelector('.cm-halo').setAttribute('r',9*u);p.querySelector('.cm-label').style.fontSize=10.5*u+'px'});placeLabels(u);}
 function placeLabels(u){const placed=[],fs=10.5*u;points.slice().sort((a,b)=>+a.querySelector('.cm-dot').getAttribute('cy')-b.querySelector('.cm-dot').getAttribute('cy')).forEach(p=>{const dot=p.querySelector('.cm-dot'),label=p.querySelector('.cm-label'),cx=+dot.getAttribute('cx'),cy=+dot.getAttribute('cy'),w=label.getBBox().width||label.textContent.length*fs,h=fs*1.2;let best=null;for(const dy of [-fs,fs*1.65,-fs*2.2,fs*2.8,-fs*3.5])for(const dx of [0,-w*.65,w*.65,-w*1.2,w*1.2]){const box={l:cx+dx-w/2,r:cx+dx+w/2,t:cy+dy-h,b:cy+dy+fs*.2};const overlap=placed.reduce((n,b)=>n+Math.max(0,Math.min(b.r,box.r)-Math.max(b.l,box.l)+u)*Math.max(0,Math.min(b.b,box.b)-Math.max(b.t,box.t)+u),0);const score=overlap*100+Math.abs(dy)+Math.abs(dx)*.6;if(!best||score<best.score)best={box,score,dx,dy};}label.setAttribute('x',cx+(scale>=1.55?best.dx:0));label.setAttribute('y',cy+(scale>=1.55?best.dy:-fs));placed.push(best.box);});}
 function zoomAt(f,cx=.5,cy=.5){const px=x+cx*660/scale,py=y+cy*503/scale;scale=Math.max(1,Math.min(4,scale*f));x=px-cx*660/scale;y=py-cy*503/scale;paint();}
 function pick(i){points.forEach((p,k)=>p.setAttribute('aria-pressed',String(k===i)));cities.forEach((c,k)=>c.classList.toggle('is-selected',k===i));const c=cities[i];info.textContent=c.textContent+' · '+c.dataset.region+(c.dataset.detail?' — '+c.dataset.detail:'');}
 points.forEach((p,i)=>{p.addEventListener('click',e=>{if(Date.now()<suppress)return;e.stopPropagation();pick(i)});p.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();pick(i)}})});
 root.querySelectorAll('[data-map-action]').forEach(b=>b.addEventListener('click',()=>{if(b.dataset.mapAction==='reset'){scale=1;x=0;y=0;paint();}else zoomAt(b.dataset.mapAction==='in'?1.4:1/1.4);}));
 frame.addEventListener('wheel',e=>{if(!e.ctrlKey&&!e.metaKey)return;e.preventDefault();const r=frame.getBoundingClientRect();zoomAt(Math.exp(-e.deltaY*.002),(e.clientX-r.left)/r.width,(e.clientY-r.top)/r.height);},{passive:false});
 frame.addEventListener('pointerdown',e=>{if(e.button!==0)return;drag={id:e.pointerId,startX:e.clientX,startY:e.clientY,x,y,moved:false};});
 frame.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-drag.startX,dy=e.clientY-drag.startY;if(Math.hypot(dx,dy)>5){drag.moved=true;frame.setPointerCapture(e.pointerId);frame.classList.add('is-dragging');}if(drag.moved){const r=frame.getBoundingClientRect();x=drag.x-dx*660/(r.width*scale);y=drag.y-dy*503/(r.height*scale);paint();}});
 function end(){if(!drag)return;const d=drag;drag=null;if(frame.hasPointerCapture(d.id))frame.releasePointerCapture(d.id);frame.classList.remove('is-dragging');if(d.moved)suppress=Date.now()+300;}
 frame.addEventListener('pointerup',end);frame.addEventListener('pointercancel',end);frame.addEventListener('lostpointercapture',end);
 frame.addEventListener('keydown',e=>{let handled=true;if(e.key==='+'||e.key==='=')zoomAt(1.4);else if(e.key==='-')zoomAt(1/1.4);else if(e.key==='Home'){scale=1;x=0;y=0;paint();}else if(e.key.startsWith('Arrow')){const step=35/scale;if(e.key==='ArrowLeft')x-=step;else if(e.key==='ArrowRight')x+=step;else if(e.key==='ArrowUp')y-=step;else if(e.key==='ArrowDown')y+=step;paint();}else handled=false;if(handled){e.preventDefault();e.stopPropagation();}});new ResizeObserver(paint).observe(frame);document.fonts.ready.then(paint);paint();
});})();
'''
