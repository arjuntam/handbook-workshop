#!/usr/bin/env python3
"""给已有 UTF-8 HTML 追加 B04，复制到新目录；不重排、不执行旧页、不覆盖原件。"""
import argparse
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import shutil
import tempfile
from share_card import SHARE_KEYS, social_meta, share_thumb_tag, validate


class Page(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.text=text;self.offsets=[0]
        for line in text.splitlines(keepends=True):self.offsets.append(self.offsets[-1]+len(line))
        self.heads=[];self.head_ends=[];self.bodies=[];self.removals=[];self.in_head=False
        self.title_parts=[];self.in_title=False;self.desc=''
        self.feed(text)
    def at(self):
        line,col=self.getpos();return self.offsets[line-1]+col
    def handle_starttag(self,tag,attrs):
        a=dict(attrs);start=self.at();end=start+len(self.get_starttag_text())
        if tag=='head':self.heads.append(end);self.in_head=True
        if tag=='body':self.bodies.append(end)
        if tag=='title' and self.in_head:self.in_title=True
        if tag=='meta' and self.in_head:
            name=a.get('name','').lower();prop=a.get('property','').lower()
            if name=='description':self.desc=a.get('content','')
            managed=(a.get('data-handbook-share')=='B04' or
                     prop in ('og:type','og:title','og:description','og:url','og:image') or prop.startswith('og:image:') or
                     name in ('twitter:card','twitter:title','twitter:description','twitter:image','twitter:image:alt'))
            if managed:self.removals.append((start,end))
        if tag=='link' and self.in_head and 'image_src' in a.get('rel','').lower().split():self.removals.append((start,end))
        if tag=='img' and 'share-thumb' in a.get('class','').split():self.removals.append((start,end))
    handle_startendtag=handle_starttag
    def handle_endtag(self,tag):
        if tag=='head':self.head_ends.append(self.at());self.in_head=False
        if tag=='title':self.in_title=False
    def handle_data(self,data):
        if self.in_title:self.title_parts.append(data)


def patch_html(text, cfg):
    validate(cfg)
    page=Page(text)
    if len(page.heads)!=1 or len(page.head_ends)!=1 or len(page.bodies)!=1 or not page.heads[0]<page.head_ends[0]<page.bodies[0]:
        raise ValueError('需要一份包含单一 head/body 的完整静态 HTML；框架模板或残片应回源工程添加')
    meta=social_meta(cfg,''.join(page.title_parts),page.desc);thumb=share_thumb_tag(cfg)
    changes=[(s,e,'') for s,e in page.removals]
    changes += [(page.head_ends[0],page.head_ends[0],meta),(page.bodies[0],page.bodies[0],thumb)]
    for start,end,value in sorted(changes,reverse=True):text=text[:start]+value+text[end:]
    return text


def apply(src, out, cfg):
    src=Path(src).resolve();out=Path(out).resolve()
    if out.exists():raise FileExistsError('输出目录已存在，请另用一个新版目录')
    if out==src.parent or src.parent in out.parents:raise ValueError('输出目录须位于源项目之外，避免递归复制')
    updated=patch_html(src.read_bytes().decode('utf-8'),cfg)
    # Do not silently copy outside project boundaries through links.
    for base,dirs,files in os.walk(src.parent,followlinks=False):
        dirs[:]=[d for d in dirs if d not in ('.git','__pycache__')]
        if any((Path(base)/n).is_symlink() for n in dirs+files):
            raise ValueError('源项目含符号链接，请先提供携带实际资源的发布目录')
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.b04-',dir=out.parent) as td:
        snapshot=Path(td)/'page'
        shutil.copytree(src.parent,snapshot,ignore=shutil.ignore_patterns('.git','__pycache__','.DS_Store'))
        for d in [snapshot,*[p for p in snapshot.rglob('*') if p.is_dir()]]:d.chmod(d.stat().st_mode|0o700)
        target=snapshot/src.name;target.chmod(target.stat().st_mode|0o600)
        target.write_bytes(updated.encode('utf-8'))
        (snapshot/'share-card.json').write_text(json.dumps({k:cfg[k] for k in SHARE_KEYS if k in cfg},ensure_ascii=False,indent=2),encoding='utf-8')
        snapshot.rename(out)
    return out/src.name


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--src',required=True,help='已有页面的 HTML 文件')
    ap.add_argument('--config',required=True,help='分享配置 JSON；不作为通用视觉配置导出')
    ap.add_argument('--out',required=True,help='位于源项目外的全新输出目录')
    a=ap.parse_args()
    cfg=json.loads(Path(a.config).read_text(encoding='utf-8'))
    if not isinstance(cfg,dict):ap.error('分享配置须为 JSON 对象')
    print('已另存 B04 页面：'+str(apply(a.src,a.out,cfg)))
    print('发布新目录后再验图片可访问性；微信效果未验证，需真机确认。源工程重建后请再次应用此配置。')
