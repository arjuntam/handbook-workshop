#!/usr/bin/env python3
"""提取 docx 为结构化 JSON，按段落保留顺序与样式层级。

用法：
  python3 extract_docx.py --src <docx所在目录或若干docx> --out <输出目录> [--name scripts.json]

小标题识别同时依赖 Word 样式名与内容特征正则；不同领域的正则可在 HEURISTICS 中增补。
"""
import zipfile, re, os, json, argparse
from pathlib import Path

# 内容特征小标题识别规则（可按需增补）
HEURISTICS = [
    r'^【.{1,20}】$', r'^话题[一二三四五六七八九十\d]+', r'^异议\s*\d',
    r'^0?\d[\s、.．]', r'^[一二三四五六七八九十]+[、.]', r'^话术\s*\d+\s*[:：]?$',
]
HEADING_LITERALS = ("标准话术：", "【话术案例】", "应答原则：")


def is_heading(text, style):
    s = (style or "").lower()
    if "heading" in s or "标题" in s:
        return True
    for pat in HEURISTICS:
        lim = 40 if pat.startswith('^[一二') else 30 if pat.startswith('^0?\\d') else 10**9
        if re.match(pat, text) and len(text) < lim:
            return True
    if text in HEADING_LITERALS or text.startswith("应答原则"):
        return True
    return False


def extract(files, out_dir, name="scripts.json"):
    OUT = Path(out_dir)
    if not OUT.exists():
        OUT.mkdir(parents=True, exist_ok=True)
    result = {}
    for path in files:
        path = Path(path)
        z = zipfile.ZipFile(str(path))
        x = z.read('word/document.xml').decode('utf-8', errors='ignore')
        paras = re.findall(r'<w:p[ >].*?</w:p>', x, re.S)
        lines = []
        for p in paras:
            sm = re.search(r'<w:pStyle w:val="([^"]+)"', p)
            style = sm.group(1) if sm else ""
            ts = re.findall(r'<w:t[^>]*>(.*?)</w:t>', p, re.S)
            t = ''.join(ts).strip()
            if not t:
                continue
            lines.append({"t": t, "h": is_heading(t, style), "style": style})
        m = re.match(r'(\d+)', path.name)
        key = m.group(1) if m else str(len(result) + 1)
        result[key] = {"file": path.name, "lines": lines}
        print(f"{path.name}: {len(lines)}段")
    target = OUT / name
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"输出 {target}")


def main():
    ap = argparse.ArgumentParser(description="提取 docx 段落结构为 JSON")
    ap.add_argument("--src", required=True, nargs="+", help="docx 文件，或包含 docx 的目录")
    ap.add_argument("--out", required=True, help="输出目录")
    ap.add_argument("--name", default="scripts.json", help="输出文件名，默认 scripts.json")
    args = ap.parse_args()
    files = []
    for s in args.src:
        p = Path(s)
        if p.is_dir():
            files.extend(sorted(p.glob("*.docx")))
        elif p.is_file():
            files.append(p)
        else:
            print(f"路径不存在，跳过：{p}")
    if not files:
        print("未找到 docx 文件"); return
    extract(files, args.out, args.name)


if __name__ == "__main__":
    main()
