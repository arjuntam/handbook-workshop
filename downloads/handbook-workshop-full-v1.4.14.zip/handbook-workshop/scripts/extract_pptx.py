#!/usr/bin/env python3
"""PPTX -> 可追溯清单。坐标仅辅助排序，不声称重现视觉阅读顺序。"""
import argparse
import hashlib
import json
from pathlib import Path
from pptx import Presentation


def box(sh):
    return [float(sh.left or 0), float(sh.top or 0), float(sh.width or 0), float(sh.height or 0)]


def iter_shapes(shapes, transform=(1, 1, 0, 0), prefix=''):
    """按 OOXML chOff/chExt 变换组合坐标；旋转/翻转只记录，留待视觉核对。"""
    sx, sy, tx, ty = transform
    for sh in shapes:
        sid = f'{prefix}{sh.shape_id}'
        x, y, w, h = box(sh)
        bounds = [x * sx + tx, y * sy + ty, w * sx, h * sy]
        if sh.shape_type == 6:
            xf = sh._element.grpSpPr.xfrm
            cx, cy = float(xf.chOff.x), float(xf.chOff.y)
            cw, ch = float(xf.chExt.cx), float(xf.chExt.cy)
            ax, ay = w / cw if cw else 1, h / ch if ch else 1
            yield from iter_shapes(sh.shapes, (sx*ax, sy*ay, tx+sx*(x-cx*ax), ty+sy*(y-cy*ay)), sid+'-')
        else:
            yield sh, sid, [round(v/360000, 4) for v in bounds]


def process(src_path, out_dir, tag):
    src_path, out_dir = Path(src_path), Path(out_dir)
    if Path(tag).name != tag or tag in ('.', '..'):
        raise ValueError('tag 只能是文件名')
    out_dir.mkdir(parents=True, exist_ok=True)
    if (out_dir/(tag+'.json')).exists():
        raise FileExistsError('提取结果已存在，请用新的输出目录或 tag，保留原版本')
    prs = Presentation(str(src_path))
    assets = out_dir/(tag+'-assets')
    assets.mkdir(exist_ok=True)
    pages = []
    for pi, slide in enumerate(prs.slides, 1):
        items = []
        for sh, sid, bounds in iter_shapes(slide.shapes):
            rec = dict(id=f'p{pi:03d}-s{sid}', page=pi, shape_id=sh.shape_id, name=sh.name,
                       type=str(sh.shape_type), kind='unsupported', x=bounds[0], y=bounds[1],
                       w=bounds[2], h=bounds[3], rotation=float(sh.rotation), issues=[])
            if '-' in sid or sh.rotation:
                rec['issues'].append('组合/旋转对象：坐标为辅助包围盒，视觉顺序需核对')
            if sh.shape_type == 13:
                try:
                    blob, ext = sh.image.blob, sh.image.ext
                    fn = f'p{pi:03d}-s{sid}.{ext}'
                    (assets/fn).write_bytes(blob)
                    rec.update(kind='image', file=fn, bytes=len(blob), sha256=hashlib.sha256(blob).hexdigest(),
                               crop=[sh.crop_left, sh.crop_top, sh.crop_right, sh.crop_bottom])
                    rec['issues'].append('图片内文字未 OCR；原图与 PPT 裁切后的显示可能不同，需核对')
                    if ext.lower() not in ('png','jpg','jpeg','gif','webp','svg'):
                        rec['issues'].append('浏览器可能不支持此图片格式：需转为 PNG 或提供整页参考图')
                except Exception as e:
                    rec.update(kind='image-error', err=str(e))
            elif getattr(sh, 'has_table', False):
                rec.update(kind='table', data=[[c.text for c in row.cells] for row in sh.table.rows])
                if any(c.is_merge_origin or c.is_spanned for row in sh.table.rows for c in row.cells):
                    rec['issues'].append('合并表格已平铺；表头与分组关系需要对照原页确认')
            elif getattr(sh, 'has_text_frame', False) and sh.text.strip():
                rec.update(kind='text', text=sh.text, is_title=sh == slide.shapes.title,
                           paragraphs=[dict(text=p.text, level=p.level,
                            sizes=[round(r.font.size.pt, 1) for r in p.runs if r.font.size])
                            for p in sh.text_frame.paragraphs])
            else:
                rec['issues'].append('未解释的形状/图表/连线/嵌入对象；可能含关系或重要信息，不能自动当装饰删除')
            items.append(rec)
        items.sort(key=lambda r: (r['y'], r['x'], r['id']))
        if slide.has_notes_slide:
            note = slide.notes_slide.notes_text_frame.text
            if note.strip():
                items.append(dict(id=f'p{pi:03d}-notes', page=pi, kind='notes', text=note,
                                  name='演讲者备注', issues=['备注可能含讲解信息，需判断是否并入正文']))
        pages.append(dict(page=pi, layout=slide.slide_layout.name, items=items))
    doc = dict(schema_version='2.0', name=src_path.name, source_sha256=hashlib.sha256(src_path.read_bytes()).hexdigest(),
               size=[round(prs.slide_width/360000, 4), round(prs.slide_height/360000, 4)],
               assets_dir=assets.name, pages=pages,
               limitations=['未提取母版/版式继承内容、页背景、动画语义、超链接与嵌入文件；整页视觉核对仍必需',
                            '无 OCR/图表解释/自动业务重组；坐标排序不是确认后的阅读顺序'])
    target = out_dir/(tag+'.json')
    target.write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding='utf-8')
    lines = [f'# {src_path.name}', '', *['> '+s for s in doc['limitations']]]
    for page in pages:
        lines += ['', f'## 第 {page["page"]} 页']
        for it in page['items']:
            value = it.get('text') or it.get('file') or json.dumps(it.get('data', []), ensure_ascii=False)
            lines += [f'\n### {it["id"]} · {it["kind"]} · {it["name"]}', value]
            lines += ['- 待核对：'+issue for issue in it.get('issues', [])]
    (out_dir/(tag+'.md')).write_text('\n'.join(lines), encoding='utf-8')
    print(f'提取 {len(pages)} 页 / {sum(len(p["items"]) for p in pages)} 个对象：{target}')
    return target


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--src', required=True)
    ap.add_argument('--out', required=True)
    ap.add_argument('--tags', nargs='*')
    args = ap.parse_args()
    src = Path(args.src)
    jobs = []
    if args.tags:
        for v in args.tags:
            tag, name = v.split(':', 1)
            jobs.append(((src if src.is_dir() else src.parent)/name, tag))
    else:
        jobs = [(p, p.stem) for p in ([src] if src.is_file() else sorted(src.glob('*.pptx')))]
    if not jobs:
        ap.error('未找到 PPTX 文件')
    for p, tag in jobs:
        process(p, args.out, tag)

if __name__ == '__main__':
    main()
