// Verify real generated gallery behavior; no publishing or package changes.
const fs=require('fs'),path=require('path'),{pathToFileURL}=require('url');
const {launchBrowser}=require('./browser_runtime');
const site=process.argv[2],out=process.argv[3];
if(!site||!out)throw Error('用法：node verify_structured.js 样式库/index.html 检查目录 [独立项目/index.html]');
fs.mkdirSync(out,{recursive:true});
(async()=>{
 const browser=await launchBrowser(),checks=[],errors=[];
 function ck(name,ok,detail){checks.push({name,ok,detail});if(!ok)throw Error(name+' '+JSON.stringify(detail||''));}
 async function visit(page,id){await page.evaluate(id=>location.hash=id,id);await page.locator('#'+id+'.active').waitFor();}
 async function alignment(grid){return grid.evaluate(g=>{
  const rows=new Map();for(const card of g.children){const r=card.getBoundingClientRect(),top=Math.round(r.top);if(!rows.has(top))rows.set(top,[]);rows.get(top).push(r.height);}
  return [...rows.values()].every(heights=>Math.max(...heights)-Math.min(...heights)<2);
 });}
 try{
  const page=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce'});
  page.on('pageerror',e=>errors.push(String(e)));
  await page.goto(pathToFileURL(path.resolve(site)).href+'#palette');
  const modes=[['compact',1],['standard',1],['presentation',1],['standard',1.5]];
  for(const font of ['misans','source-han-sans','source-han-serif'])for(const width of [1440,1024])for(const [preset,factor] of modes){
   const mode=[font,width,preset,factor].join('-');
   await page.setViewportSize({width,height:1000});await visit(page,'palette');
   await page.locator('#palette button[data-font="'+font+'"]').click();await page.locator('#palette button[data-type="'+preset+'"]').click();
   if(factor!==1)await page.locator('#type-size-slider').evaluate((x,f)=>{x.value=String(f*100);x.dispatchEvent(new Event('input',{bubbles:true}));},factor);
   await page.evaluate(()=>document.fonts.ready);
   await visit(page,'blk-number_folds');
   for(const selector of ['.hw-fold-stages','.hw-fold-grid.hw-fold-fields']){
    const grid=page.locator('#blk-number_folds '+selector).first();
    await grid.locator('details').evaluateAll(cards=>{
     cards.forEach((x,i)=>x.open=i<2);
     // Exercise uneven real content lengths, not just matching demo sentences.
     const title=cards[1]?.querySelector('.hw-fold-title');
     if(title&&!title.dataset.original){title.dataset.original=title.textContent;title.textContent+='：针对长标题与不同说明长度的核对';}
     const value=cards[1]?.querySelector('dd');
     if(value&&!value.dataset.original){value.dataset.original=value.textContent;value.textContent+=' 保留原始材料中的条件、责任与执行说明。'.repeat(8);}
    });
    ck('同排边界对齐 '+mode+' '+selector,await alignment(grid));
    const second=grid.locator('summary').nth(1);await second.focus();await page.keyboard.press('Enter');
    ck('键盘收起且独立 '+mode+' '+selector,await grid.locator('details[open]').count()===1);
    await page.keyboard.press('Space');ck('键盘展开且独立 '+mode+' '+selector,await grid.locator('details[open]').count()===2);
    ck('展开后仍对齐 '+mode+' '+selector,await alignment(grid));
   }
   for(const id of ['blk-number_folds','blk-detail_table','table-demo']){
    await visit(page,id);
    const m=await page.locator('#'+id).evaluate(section=>({
     rootOverflow:document.documentElement.scrollWidth>innerWidth+2,
     clipped:[...section.querySelectorAll('summary,dt,dd,p,h3,td,th')].filter(x=>x.getClientRects().length&&/hidden|clip/.test(getComputedStyle(x).overflowY)&&x.scrollHeight>x.clientHeight+2).length
    }));ck('正文无横溢或裁字 '+mode+' '+id,!m.rootOverflow&&!m.clipped,m);
   }
   if(width===1440&&preset==='standard'&&factor===1){
    await visit(page,'blk-number_folds');
    const chrome=await page.addStyleTag({content:'.topbar,.pagerbar,.dl-dock{visibility:hidden!important}'});
    for(const [selector,name] of [['.hw-fold-stages','阶段展开'],['.hw-fold-grid.hw-fold-fields','字段说明']])await page.locator('#blk-number_folds '+selector).first().screenshot({path:path.join(out,font+'-'+name+'.png')});
    await chrome.evaluate(x=>x.remove());
   }
  }
  await visit(page,'palette');await page.locator('#palette button[data-font="misans"]').click();await page.locator('#palette button[data-type="standard"]').click();await page.setViewportSize({width:1440,height:1050});
  await visit(page,'blk-detail_table');const root=page.locator('#blk-detail_table .hw-detail-table');
  ck('默认对象正确',await root.getAttribute('data-current-key')==='north');
  const choices=root.locator('.hw-data-choice');await choices.nth(1).focus();await page.keyboard.press('Enter');
  ck('名称按钮键盘联动',await root.getAttribute('data-current-key')==='south');
  ck('只展示当前明细',await root.locator('.hw-detail-panel:visible').count()===1&&(await root.locator('.hw-detail-panel:visible h3').first().textContent()).includes('南区'));
  const row=root.locator('tr[data-detail-row="south"]');ck('零值与缺失分开',await row.locator('.hw-value-missing').count()===1&&(await row.textContent()).includes('0'));
  await root.locator('.hw-detail-panel:visible img').evaluate(im=>im.decode());
  ck('对应图片同步',(await root.locator('.hw-detail-panel:visible figcaption').textContent()).includes('南区'));
  await root.locator('tbody').evaluate(t=>t.prepend(t.lastElementChild));
  const west=root.locator('[data-detail-key="west"]');await west.click();
  ck('改变行顺序仍按标识关联',await root.getAttribute('data-current-key')==='west'&&(await root.locator('.hw-detail-panel:visible').textContent()).includes('暂未提供详情'));
  await page.keyboard.press('ArrowRight');ck('方向键不抢占翻页',await page.locator('#blk-detail_table.active').count()===1);
  await root.locator('[data-detail-key="south"]').click();await root.locator('.hw-detail-jump').click();
  ck('明确入口可跳到当前详情',await root.locator('.hw-detail-panel:visible h3').first().evaluate(x=>x===document.activeElement));
  await page.screenshot({path:path.join(out,'汇总详情联动.png'),fullPage:true});
  await visit(page,'table-demo');
  const chrome=await page.addStyleTag({content:'.topbar,.pagerbar,.dl-dock{visibility:hidden!important}'});
  await page.locator('.hw-matrix').screenshot({path:path.join(out,'关系矩阵.png')});await chrome.evaluate(x=>x.remove());
  ck('矩阵保留行列标题',await page.locator('.hw-matrix th[scope="row"]').count()===4&&await page.locator('.hw-matrix th[scope="col"]').count()===5);
  ck('符号保留图例和文字含义',await page.locator('.hw-matrix-legend li').count()===3&&await page.locator('.hw-matrix td .sr-only').count()===16);
  await visit(page,'catalog');const totals=await page.locator('.catalog-summary strong').allTextContents();
  ck('分类总数与款式总数同步',totals.join(',')==='45,6',totals);
  // Old sidebar and pager remain active; old links still resolve.
  for(const id of ['navigation','pagination','tabs-demo','blk-number_folds','recipes']){await visit(page,id);ck('原入口仍可访问 '+id,await page.locator('.section.active').count()===1);}
  if(process.argv[4]){
   const sample=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce'});sample.on('pageerror',e=>errors.push(String(e)));
   await sample.goto(pathToFileURL(path.resolve(process.argv[4])).href+'#details');
   const roots=sample.locator('.hw-detail-table');ck('独立手册同时渲染两个组件',await roots.count()===2);
   await roots.nth(0).locator('[data-detail-key="south"]').click();await roots.nth(1).locator('[data-detail-key="practice"]').click();
   ck('不同组件各自保持选择',await roots.nth(0).getAttribute('data-current-key')==='south'&&await roots.nth(1).getAttribute('data-current-key')==='practice');
   ck('文字列与详情可复用',(await roots.nth(1).locator('.hw-detail-panel:visible').textContent()).includes('练习材料'));
   ck('空列表诚实显示',(await sample.locator('.hw-detail-empty').textContent()).includes('暂无可查看的对象'));
   ck('资料日期沿用原值',(await sample.locator('body').textContent()).includes('2026-10-10'));
   await sample.close();
  }
  await page.setViewportSize({width:390,height:844});await page.reload();ck('手机仍按既定规则拦截',await page.locator('html.mobile-blocked').count()===1);
  ck('无运行错误',errors.length===0,errors);await page.close();
 }finally{await browser.close();fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({checks:checks.length,failures:checks.filter(x=>!x.ok).length,errors,results:checks,boundary:'本机浏览器与模拟资料检查；不等于业务数据、WorkBuddy 导入或真实设备验收。'},null,2));}
 console.log('Structured UI checks passed: '+checks.length);
})().catch(e=>{console.error(e);process.exitCode=1});
