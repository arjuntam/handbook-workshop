"""结构化内容回归：稳定关联、缺失/零、拒绝错配、嵌套校验与旧格式兼容。"""
import copy
import json
from pathlib import Path
import unittest

import content_extensions
import data_views
from handbook_core import render_blocks
from lint_content import walk_blocks, collect_images
from audit_sources import strings


class StructuredInformationTests(unittest.TestCase):
    def setUp(self):
        self.examples = json.loads((Path(__file__).resolve().parent.parent / 'assets/structured-examples.json').read_text())

    def test_all_examples_validate_and_render(self):
        for name, block in self.examples.items():
            with self.subTest(name=name):
                content_extensions.validate_tree([block], set(), [])
                self.assertTrue(render_blocks([block], {}))

    def test_duplicates_cannot_link_to_wrong_detail(self):
        block = self.examples['detail_table']
        block['items'][1]['id'] = block['items'][0]['id']
        with self.assertRaises(ValueError):
            data_views.validate(block)

    def test_duplicate_or_unknown_columns_are_rejected(self):
        for mode in ('duplicate', 'unknown'):
            block = copy.deepcopy(self.examples['detail_table'])
            if mode == 'duplicate':
                block['columns'].append(block['columns'][0])
            else:
                block['items'][0]['values']['typo'] = 3
            with self.assertRaises(ValueError):
                data_views.validate(block)

    def test_missing_default_is_rejected(self):
        block = self.examples['detail_table']
        block['default'] = 'not-an-object'
        with self.assertRaises(ValueError):
            data_views.validate(block)

    def test_zero_and_missing_are_not_interchangeable(self):
        block = self.examples['detail_table']
        block.pop('default')
        block['items'] = [block['items'][1]]
        html = render_blocks([block], {})
        self.assertIn('hw-data-value">0</span>', html)
        self.assertIn('hw-value:0%', html)
        self.assertEqual(html.count('hw-value-missing">未提供'), 1)

    def test_invalid_bar_values_stop_build(self):
        for value in (-1, 11, True, float('nan'), float('inf'), '3'):
            with self.subTest(value=value):
                block = copy.deepcopy(self.examples['detail_table'])
                block['items'][0]['values']['source'] = value
                with self.assertRaises(ValueError):
                    data_views.validate(block)

    def test_empty_list_and_missing_detail_have_honest_states(self):
        block = self.examples['detail_table']
        self.assertIn('暂未提供详情', render_blocks([block], {}))
        block['items'] = []
        block.pop('default')
        html = render_blocks([block], {})
        self.assertIn('暂无可查看的对象', html)
        self.assertNotIn('<button', html)

    def test_text_columns_and_independent_instances(self):
        html = render_blocks([self.examples['training'], self.examples['training']], {})
        import re
        ids = re.findall(r'\bid="([^"]+)"', html)
        self.assertEqual(len(ids), len(set(ids)))
        self.assertIn('实操', html)

    def test_nested_images_and_navigation_are_checked(self):
        block = self.examples['detail_table']
        images = [name for child, _ in walk_blocks([block], 'sample') for name in collect_images(child)]
        self.assertIn('profile-example.svg', images)
        block['items'][0]['blocks'].append(dict(t='chapter_nav', items=[dict(title='错误目标', target='missing')]))
        with self.assertRaises(ValueError):
            content_extensions.validate_tree([block], set(), [])

    def test_source_text_in_new_fields_is_preserved(self):
        self.assertIn('阶段摘要', list(strings(dict(summary='阶段摘要'))))
        self.assertIn('42', list(strings(dict(values={'people': 42}))))

    def test_stage_goal_and_field_rows_are_required(self):
        for name, key in [('stages', 'summary'), ('fields', 'rows')]:
            block = self.examples[name]
            del block['items'][0][key]
            with self.assertRaises(ValueError):
                content_extensions.validate_tree([block], set(), [])

    def test_matrix_has_row_headers_and_explains_unknown(self):
        block = self.examples['matrix']
        html = render_blocks([block], {})
        self.assertEqual(html.count('scope="row"'), len(block['rows']))
        self.assertIn('待确认', html)
        del block['legend']
        with self.assertRaises(ValueError):
            render_blocks([block], {})

    def test_input_text_cannot_inject_markup(self):
        block = self.examples['fields']
        block['items'][0]['rows'][0]['body'] = '<img src=x onerror=alert(1)>'
        html = render_blocks([block], {})
        self.assertNotIn('<img src=x', html)
        self.assertIn('&lt;img', html)

    def test_matrix_symbols_keep_their_text_meaning(self):
        block = self.examples['matrix']
        html = render_blocks([block], {})
        self.assertIn('hw-matrix-symbol', html)
        self.assertIn('sr-only">参与', html)
        self.assertIn('sr-only">待确认', html)
        self.assertIn('hw-matrix-legend', html)
        block['symbols']['待确认'] = block['symbols']['参与']
        with self.assertRaises(ValueError):
            render_blocks([block], {})

    def test_legacy_fold_and_table_still_render(self):
        html = render_blocks([dict(t='number_folds', items=[dict(title='旧格式', body='普通正文', open=True)]),
                              dict(t='table', head=['名称', '说明'], rows=[['旧表', '保留内容']])], {})
        self.assertIn('hw-number-folds"', html)
        self.assertNotIn('hw-fold-fields', html)
        self.assertIn('普通正文', html)
        self.assertIn('保留内容', html)


if __name__ == '__main__':
    unittest.main()
