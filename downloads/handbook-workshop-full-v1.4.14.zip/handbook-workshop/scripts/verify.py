#!/usr/bin/env python3
"""用无头浏览器验证生成的手册：封面/正文切换、按钮、交叉引用、图片、JS 错误。

用法：
  python3 verify.py --site <index.html路径> [--edge 浏览器可执行文件]

依赖：playwright（Python 版，pip install playwright）或改用仓库自带 node 版。
本脚本用 Python playwright；若未安装，会给出明确提示。
"""
import argparse, sys
from pathlib import Path


def main():
    ap = argparse.ArgumentParser(description="浏览器验证手册")
    ap.add_argument("--site", required=True, help="index.html 绝对路径")
    ap.add_argument("--edge", default="", help="Edge/Chrome 可执行文件路径，留空用 playwright 自带 chromium")
    args = ap.parse_args()

    site = Path(args.site).resolve()
    if not site.exists():
        print(f"文件不存在：{site}"); sys.exit(1)

    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("缺少 playwright，请先运行：pip install playwright && playwright install chromium")
        sys.exit(2)

    launch = {}
    if args.edge:
        launch["executable_path"] = args.edge

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, **launch)
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        errs = []
        page.on("pageerror", lambda e: errs.append(str(e)))
        page.goto(site.as_uri() + "?t=verify", wait_until="load")
        page.wait_for_timeout(400)

        cover = page.evaluate("""() => ({
          coverVisible: getComputedStyle(document.getElementById('cover')).display !== 'none',
          layoutHidden: getComputedStyle(document.querySelector('.layout')).display === 'none',
          hasStart: !!document.getElementById('cover-start'),
          homeBtns: document.querySelectorAll('.topbar .home-btn').length,
          sections: document.querySelectorAll('.section[id]').length
        })""")
        print("封面态:", cover)

        page.click("#cover-start")
        page.wait_for_timeout(300)
        after = page.evaluate("""() => ({
          viewing: document.body.classList.contains('viewing'),
          coverHidden: getComputedStyle(document.getElementById('cover')).display === 'none',
          activeSections: document.querySelectorAll('.section.active').length,
          pos: document.getElementById('pager-pos').textContent.trim()
        })""")
        print("进入正文:", after)

        # 交叉引用
        xref = "n/a"
        chip = page.query_selector(".section.active .xref-chip")
        if chip:
            before = page.eval_on_selector(".section.active h2", "el => el.textContent")
            target = chip.get_attribute("data-goto")
            chip.click(); page.wait_for_timeout(300)
            now = page.eval_on_selector(".section.active h2", "el => el.textContent")
            xref = "OK" if before != now and now else "FAIL"
            print(f"交叉引用({target}):", xref)

        # 图片加载
        imgs = page.evaluate("""() => {
          const a=[...document.querySelectorAll('.section img')];
          return {total:a.length, broken:a.filter(i=>!i.complete||i.naturalWidth===0).length};
        }""")
        print("图片:", imgs)
        print("JS 错误:", len(errs), errs[:2])

        ok = (cover["coverVisible"] and cover["hasStart"]
              and after["viewing"] and after["coverHidden"]
              and after["activeSections"] == 1
              and imgs["broken"] == 0 and len(errs) == 0
              and (xref == "n/a" or xref == "OK"))
        print("结论:", "通过" if ok else "未通过")
        browser.close()
        sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
