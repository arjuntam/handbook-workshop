// Optional browser verification; generation does not depend on this module.
const fs = require('fs');
const path = require('path');

function loadPlaywright() {
  const candidates = process.env.PW_MODULE ? [process.env.PW_MODULE] : ['playwright', 'playwright-core'];
  for (const candidate of candidates) {
    try {
      const target = candidate.startsWith('.') ? path.resolve(candidate) : candidate;
      const loaded = require(require.resolve(target, { paths: [process.cwd(), __dirname] }));
      if (loaded.chromium && typeof loaded.chromium.launch === 'function') return loaded;
    } catch {}
  }
  throw new Error('缺少可用的 Playwright。请在当前项目准备 playwright 或 playwright-core，或用 PW_MODULE 指定已安装模块。浏览器验收为可选工具，生成手册本身不依赖它；此脚本不会自动安装或下载依赖。');
}

async function launchBrowser(options = {}) {
  const { chromium } = loadPlaywright();
  const executable = process.env.BROWSER_PATH || process.env.EDGE;
  if (executable) {
    if (!fs.existsSync(executable)) throw new Error('指定的浏览器文件不存在，请检查 BROWSER_PATH / EDGE。');
    return chromium.launch({ headless: true, ...options, executablePath: executable });
  }
  if (process.env.BROWSER_CHANNEL) {
    return chromium.launch({ headless: true, ...options, channel: process.env.BROWSER_CHANNEL });
  }
  // Prefer bundled Chromium, then installed standard browser channels.
  for (const channel of [null, 'chrome', 'msedge']) {
    try {
      return await chromium.launch({ headless: true, ...options, ...(channel ? { channel } : {}) });
    } catch {}
  }
  throw new Error('未找到可启动的浏览器。请准备 Playwright 的 Chromium，或用 BROWSER_CHANNEL / BROWSER_PATH 指定当前电脑可用的浏览器；兼容旧 EDGE 配置。不自动下载浏览器。');
}

module.exports = { loadPlaywright, launchBrowser };
