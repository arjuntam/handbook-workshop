#!/usr/bin/env python3
"""从 v2 提取清单生成保守初稿；或从已整理的 plan.json 生成手册。只写新目录。"""
import argparse
import json
import shutil
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

SCRIPT = Path(__file__).resolve().parent


def split_text(text, limit=200):
    # 保留文字，不用省略号截断；优先按段落/句号拆分。
    parts, current = [], ''
    import re
    for token in re.findall(r'.*?(?:[。！？\n]|$)', text):
        if not token:
            continue
        if current and len(current)+len(token) > limit:
            parts.append(current)
            current = ''
        while len(token) > limit:
            if current:
                parts.append(current)
                current = ''
            parts.append(token[:limit])
            token = token[limit:]
        current += token
    if current.strip():
        parts.append(current)
    return parts or [text]


def default_plan(doc, name):
    sections, reviews = [], []
    for page in doc['pages']:
        items = page['items']
        title_obj = next((i for i in items if i.get('is_title') and len(i.get('text','')) <= 70), None)
        title = title_obj['text'] if title_obj else f'原稿第 {page["page"]} 页'
        blocks = []
        for it in items:
            ref, kind = it['id'], it['kind']
            if it == title_obj:
                continue
            if kind == 'text':
                blocks += [dict(t='text', v=s, source_refs=[ref]) for s in split_text(it['text'])]
            elif kind == 'table':
                rows = it['data']
                for j in range(0, len(rows), 8):
                    blocks.append(dict(t='table', caption=f'原第 {page["page"]} 页 · 表格'+(f'（续 {j//8+1}）' if j else ''),
                                       rows=rows[j:j+8], source_refs=[ref]))
            elif kind == 'image':
                blocks.append(dict(t='img', src=it['file'], cap=f'原第 {page["page"]} 页 · 原图（可放大）', source_refs=[ref]))
            else:
                reviews.append(dict(ref=ref, reason='需对照原页解释或确认用途；尚未进入读者正文', status='pending'))
        # Conservative density budget: images/tables own their pages. No fixed-height cropping.
        chunks, chunk, weight = [], [], 0
        for b in blocks:
            cost = 900 if b['t'] in ('img', 'table') else len(b.get('v', ''))
            if chunk and (weight+cost > 700 or len(chunk) >= 4):
                chunks.append(chunk)
                chunk, weight = [], 0
            chunk.append(b)
            weight += cost
        if chunk:
            chunks.append(chunk)
        if not chunks:
            chunks = [[dict(t='callout', label='待核对', tone='amber', v='此页尚未形成可阅读正文，请对照原始资料核对。')]]
        for j, chunk in enumerate(chunks, 1):
            sections.append(dict(id=f'p{page["page"]:03d}-{j}', title=title+(f' · {j}/{len(chunks)}' if len(chunks)>1 else ''),
                                 nav=(title.replace('\n',' ')[:10]+(f'·{j}' if len(chunks)>1 else '')),
                                 group=f'原稿第 {page["page"]} 页', kicker='初稿 · 待内容校对',
                                 source_refs=[title_obj['id']] if title_obj else [], blocks=chunk))
    return dict(schema_version='1.0', route='conservative', source_sha256=doc['source_sha256'],
                config=dict(title=name, subtitle='由原始资料整理的工作初稿', home_href='', brand_logo='', cover_image='',
                            mobile_block=True, palette='air-blue', type_scale='standard', logo_header_height=28, logo_cover_height=48, style_preset='apple', theme={}),
                hero=dict(title=name, desc='先核对信息与结构，再打磨表达。', kicker='工作初稿', meta=''),
                sections=sections, attachments=[], xref={}, reviews=reviews, exclusions=[], transformations=[])


CONTENT_LOADER = '''import json
from pathlib import Path
D = json.loads((Path(__file__).parent / "content.json").read_text(encoding="utf-8"))
HERO, SECTIONS = D["hero"], D["sections"]
ATTACHMENTS, XREF = D.get("attachments", []), D.get("xref", {})
SEARCH_PLACEHOLDER = "搜索章节 / 关键词"
'''
BUILD = '''import json
import sys
from pathlib import Path
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "runtime"))
from handbook_core import build_html, prepare_assets, ensure_brand_assets
from lint_content import lint, Report
from audit_sources import audit, write_source_map
D = json.loads((HERE / "content.json").read_text(encoding="utf-8"))
rep = lint(HERE, Report())
rep.dump()
if rep.count("错误"):
    raise SystemExit("内容检查失败，未覆盖 index.html")
a = audit(HERE)
write_source_map(HERE)
(HERE / "检查报告.json").write_text(json.dumps(a, ensure_ascii=False, indent=2), encoding="utf-8")
if a["errors"]:
    raise SystemExit("来源核对失败，未覆盖 index.html；见检查报告.json")
cfg = dict(D["config"])
shared = HERE.parent / "project-style.json"
cfg["project_style_file"] = str(shared if shared.is_file() else HERE / "project-style.json")
for key in ("brand_logo", "cover_image"):
    if cfg.get(key):
        p = Path(cfg[key])
        cfg[key] = str(p if p.is_absolute() else HERE / p)
ensure_brand_assets(HERE, cfg)
A = prepare_assets(HERE / "assets", HERE)
html = build_html(cfg["title"], cfg.get("subtitle", ""), D["hero"], D["sections"],
                  D.get("attachments", []), A, xref=D.get("xref", {}), config=cfg)
(HERE / "index.html").write_text(html, encoding="utf-8")
print(f"已生成 {len(D['sections'])} 节；{a['warnings']} 项待核对。浏览器与目视验收仍需进行。")
'''


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source', required=True, help='extract_pptx v2 JSON')
    ap.add_argument('--out', required=True, help='不存在或为空的目录')
    ap.add_argument('--name', default='网页手册初稿')
    ap.add_argument('--plan', help='已有 plan JSON；使用其中 sections/blocks，不重写内容')
    args = ap.parse_args()
    source, out = Path(args.source).resolve(), Path(args.out).resolve()
    doc = json.loads(source.read_text(encoding='utf-8'))
    if doc.get('schema_version') != '2.0':
        ap.error('请先用新版 extract_pptx.py 重提，旧清单缺稳定来源 id')
    if out.exists() and any(out.iterdir()):
        ap.error('输出目录不为空；请新建版本，避免覆盖已有修改')
    plan = json.loads(Path(args.plan).read_text(encoding='utf-8')) if args.plan else default_plan(doc,args.name)
    if plan.get('source_sha256') != doc['source_sha256']:
        ap.error('方案与原稿指纹不一致')
    assets = source.parent/doc['assets_dir']
    if not assets.is_dir():
        ap.error('提取素材目录不存在')
    from prepare_resources import font_source, copy_font, copy_resources, copy_resource
    profile_path = out.parent/'project-style.json'
    profile = json.loads((profile_path if profile_path.exists() else SCRIPT.parent/'assets'/'base-style.json').read_text())
    font_key = profile.get('font_family', 'misans')
    font = font_source(font_family=font_key)
    out.mkdir(parents=True, exist_ok=True)
    (out/'runtime').mkdir()
    for fn in ('handbook_core.py', 'share_card.py', 'design_tokens.py', 'cover_design.py', 'desktop_gate.py', 'gallery_layouts.py', 'portal_layout.py', 'typography_rules.py', 'china_map.py', 'content_extensions.py', 'data_views.py', 'full_text_search.py', 'navigation_media.py', 'section_navigation.py', 'font_catalog.py', 'prepare_resources.py', 'lint_content.py', 'audit_sources.py'):
        shutil.copy2(SCRIPT/fn, out/'runtime'/fn)
        (out/'runtime'/fn).chmod(0o644)
    copy_resources(assets, out/'assets')
    copy_resources(SCRIPT.parent/'assets'/'brand', out/'assets'/'brand')
    for notice in (SCRIPT.parent/'assets'/'fonts').iterdir():
        if notice.suffix not in ('.txt','.md'):continue
        copy_resource(notice,out/'assets'/'fonts'/notice.name)
    shutil.copy2(SCRIPT.parent/'assets'/'font-catalog.json',out/'assets'/'font-catalog.json')
    copy_font(out/'assets'/'fonts'/font.name,font)
    copy_resources(SCRIPT.parent/'assets'/'maps', out/'assets'/'maps')
    shutil.copy2(SCRIPT.parent/'assets'/'base-style.json', out/'assets'/'base-style.json')
    shared_style = out.parent/'project-style.json'
    if not shared_style.exists():
        shutil.copy2(SCRIPT.parent/'assets'/'base-style.json', shared_style)
        shared_style.chmod(0o644)
    shutil.copy2(shared_style, out/'project-style.json')
    (out/'project-style.json').chmod(0o644)
    # Pin the material date once. A later style-only rebuild must not make old
    # material look newly updated just because the build runs on another day.
    if not plan.setdefault('config',{}).get('updated_at'):
        shared_profile=json.loads(shared_style.read_text(encoding='utf-8'))
        plan['config']['updated_at']=shared_profile.get('updated_at') or datetime.now(ZoneInfo('Asia/Shanghai')).date().isoformat()
    (out/'source.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'content.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'content.py').write_text(CONTENT_LOADER,encoding='utf-8')
    (out/'build.py').write_text(BUILD,encoding='utf-8')
    # Keep a source/object/section table outside reader HTML.
    rows = ['对象ID\t原稿页\t类型\t目标章节']
    refs = {}
    def walk(v, sid):
        if isinstance(v,dict):
            for ref in v.get('source_refs',[]):
                refs.setdefault(ref,set()).add(sid)
            for k,x in v.items():
                if k != 'source_refs': walk(x,sid)
        elif isinstance(v,list):
            for x in v: walk(x,sid)
    for sec in plan['sections']: walk(sec,sec['id'])
    for page in doc['pages']:
        for it in page['items']:
            rows.append(f'{it["id"]}\t{page["page"]}\t{it["kind"]}\t{",".join(sorted(refs.get(it["id"],[]))) or "待处理"}')
    (out/'来源映射.tsv').write_text('\n'.join(rows),encoding='utf-8-sig')
    print(f'初稿项目：{out}\n下一步：python3 "{out / "build.py"}"')

if __name__ == '__main__':
    main()
