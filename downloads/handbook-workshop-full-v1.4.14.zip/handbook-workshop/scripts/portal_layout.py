"""P09 项目资料中心 + L18 资料封面入口卡。"""
from html import escape
from urllib.parse import urlsplit


def safe_href(value):
    if not value or urlsplit(value).scheme.lower() not in ('','http','https'):
        raise ValueError('资料入口只接受相对路径、锚点或 http(s) 链接')
    return escape(value,quote=True)


def render(block,A):
    cards=[]
    for item in block['items']:
        title=escape(item['title'])
        cover=(f'<img src="assets/{escape(A.get(item["cover"],item["cover"]),quote=True)}" alt="" loading="lazy" decoding="async">' if item.get('cover') else '<div class="resource-cover-fallback" aria-hidden="true">资料</div>')
        tag=f'<span class="resource-tag">{escape(item["tag"])}</span>' if item.get('tag') else ''
        desc=f'<p class="resource-desc">{escape(item["desc"])}</p>' if item.get('desc') else ''
        bullets='<ul>'+''.join('<li>'+escape(x)+'</li>' for x in item.get('bullets',[]))+'</ul>' if item.get('bullets') else ''
        actions=[]
        for action in item.get('actions',[]):
            kind=action.get('kind','read')
            label=escape(action['label'])
            if kind=='pending':
                actions.append(f'<span class="resource-pending">{label} · 待补充</span>');continue
            href=safe_href(action['href'])
            attrs=' download' if kind=='download' else ' target="_blank" rel="noopener"' if kind=='external' else ''
            symbol='↓' if kind=='download' else '↗' if kind=='external' else '→'
            actions.append(f'<a class="resource-action {"secondary" if kind!="read" else "primary"}" href="{href}"{attrs}>{label}<span aria-hidden="true">{symbol}</span></a>')
        cards.append(f'<article class="resource-card"><div class="resource-cover">{cover}</div><div class="resource-body">{tag}<h3>{title}</h3>{desc}{bullets}<div class="resource-actions">'+''.join(actions)+'</div></div></article>')
    return '<div class="resource-grid">'+''.join(cards)+'</div>'


CSS=r'''
.resource-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,17rem),1fr));gap:1.5rem;min-inline-size:0}
.resource-card{display:flex;flex-direction:column;min-inline-size:0;background:var(--surface);border:1px solid var(--border);border-radius:1.25rem;overflow:clip;box-shadow:var(--shadow)}
.resource-cover{aspect-ratio:16/9;background:var(--accent-soft);border-block-end:1px solid var(--border)}
.resource-cover img{display:block;inline-size:100%;block-size:100%;object-fit:contain}
.resource-cover-fallback{display:grid;place-items:center;block-size:100%;color:var(--accent);font-size:2rem;font-weight:700}
.resource-body{padding:1.5rem;display:flex;flex:1;flex-direction:column;gap:.875rem;min-inline-size:0}
.resource-tag{align-self:flex-start;background:var(--accent-soft);color:var(--accent);padding:.375rem .625rem;border-radius:.5rem;font-size:.8125rem}
.resource-body h3{font-size:1.25rem;color:var(--brand);margin:0;line-height:1.4;overflow-wrap:anywhere}
.resource-desc,.resource-body li{color:var(--muted);font-size:1rem;line-height:1.75;margin:0;overflow-wrap:anywhere}
.resource-body ul{padding-inline-start:1.25rem;margin:0 0 1rem}
.resource-actions{margin-block-start:auto;display:grid;gap:.625rem}
.resource-action{display:flex;align-items:center;justify-content:center;gap:.5rem;min-block-size:2.75rem;padding:.75rem;text-align:center;text-decoration:none;font-size:.9375rem;font-weight:600;border-radius:.75rem;border:1px solid var(--border);color:var(--brand);background:var(--accent-soft)}
.resource-action.primary{background:var(--brand);color:var(--surface);border-color:var(--brand)}
.resource-pending{font-size:.875rem;color:var(--muted);padding:.75rem;border:1px dashed var(--border);border-radius:.75rem}
.resource-action:active{transform:scale(.985)}
@media(hover:hover) and (pointer:fine){.resource-card{transition:transform .18s,box-shadow .18s}.resource-card:hover{transform:translateY(-3px);box-shadow:var(--shadow-lift)}.resource-action:hover{border-color:var(--accent)}.resource-action.primary:hover{background:var(--accent)}}
.portal-page{background:var(--surface)}
.portal-topbar{display:flex;align-items:center;gap:1.25rem;padding:1rem 2rem;border-block-end:1px solid var(--border);background:var(--surface)}
.portal-topbar span{color:var(--brand);font-size:1.0625rem;font-weight:500}
.portal-hero{position:relative;isolation:isolate;text-align:center;padding:6.5rem 1.5rem 5.5rem;background:var(--flow-paper);overflow:clip}
.portal-hero .cover-fluid{position:absolute;z-index:-1}
.portal-hero .cover-motion-toggle{position:absolute}
.portal-hero::after{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;background-image:linear-gradient(color-mix(in srgb,var(--accent) 4.5%,transparent) 1px,transparent 1px),linear-gradient(90deg,color-mix(in srgb,var(--accent) 4.5%,transparent) 1px,transparent 1px);background-size:4rem 4rem;mask-image:radial-gradient(ellipse 58% 66% at 50% 44%,#000 10%,transparent 76%)}
.portal-hero-inner{position:relative;z-index:1;inline-size:100%;max-inline-size:53.75rem;margin-inline:auto;text-align:center}
/* Own the complete title box: shared cover h1 limits must not offset a portal. */
.portal-hero .portal-hero-inner>h1{inline-size:100%;max-inline-size:none;font-size:clamp(2.125rem,4.4vw,3.5rem);font-weight:500;line-height:1.12;letter-spacing:-.022em;margin:0 auto 1.25rem;color:var(--brand);text-align:center;text-wrap:balance}
.portal-kicker{display:inline-flex;align-items:center;gap:.5rem;max-inline-size:100%;color:var(--accent);font-size:.78125rem;font-weight:400;line-height:1.6;background:var(--accent-soft);border:1px solid var(--border);padding:.4375rem .9375rem;border-radius:99px;margin-block-end:1.625rem}
.portal-kicker::before{content:"";flex:none;inline-size:.3125rem;block-size:.3125rem;border-radius:50%;background:currentColor}
.portal-hero .portal-hero-inner>p{font-size:clamp(.9375rem,1.5vw,1.1875rem);font-weight:330;line-height:1.65;color:var(--muted);max-inline-size:none;margin:0 auto;text-align:center}
.portal-wrap{max-inline-size:70rem;padding:0 1.5rem 4rem;margin-inline:auto;position:relative}
.portal-steps{display:flex;align-items:stretch;gap:.75rem;max-inline-size:62.5rem;margin:-2.75rem auto 5.25rem;position:relative;z-index:1}
.portal-step{flex:1 1 0;min-inline-size:0;background:var(--surface);border:1px solid var(--border);border-radius:1rem;padding:1.125rem 1.25rem;display:flex;align-items:center;gap:.875rem;box-shadow:var(--shadow)}
.portal-step>div{min-inline-size:0}
.portal-step b{display:block;font-size:.90625rem;font-weight:500;line-height:1.4}.portal-step p{font-size:.8125rem;color:var(--muted);line-height:1.5;margin:.1875rem 0 0}
.portal-step-num{flex:none;inline-size:1.75rem;block-size:1.75rem;border-radius:50%;display:grid;place-items:center;background:var(--accent-soft);color:var(--accent);font-size:.8125rem;font-weight:500;line-height:1}
.portal-step-arrow{align-self:center;flex:none;color:var(--border);font-size:1.0625rem;line-height:1}
.portal-wrap h2{font-size:1rem;color:var(--muted);margin-block:0 1.25rem}
.portal-footer{text-align:center;font-size:.875rem;color:var(--muted);padding:2.5rem 1.5rem}
@media(max-width:600px){.portal-topbar{padding:1rem;gap:.75rem}.portal-hero{padding:5rem 1.5rem 4rem}.portal-wrap{padding-inline:1rem}.resource-body{padding:1.25rem}}
'''


def build_page(data,A=None,config=None):
    from handbook_core import CSS as CORE_CSS,APPLE_BASE_CSS,resolve_config,social_meta,share_thumb_tag
    import cover_design
    import desktop_gate
    cfg=resolve_config(config)
    tokens=':root{'+''.join(k+':'+v+';' for k,v in cfg['theme'].items())+'}'
    title=escape(data['title'])
    steps='<span class="portal-step-arrow" aria-hidden="true">→</span>'.join(f'<div class="portal-step"><span class="portal-step-num">{i+1}</span><div><b>{escape(s["title"])}</b><p>{escape(s.get("desc",""))}</p></div></div>' for i,s in enumerate(data.get('steps',[])))
    cards=render(dict(items=data['resources']),A or {})
    return f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="text-scale" content="scale"><title>{title}</title>{social_meta(cfg,data['title'],data.get('desc',''))}<style>{CORE_CSS}{APPLE_BASE_CSS}{cover_design.CSS}{CSS}{tokens}</style></head>
<body class="portal-page">{share_thumb_tag(cfg)}<header class="portal-topbar"><img class="brand-logo" src="assets/logo.png" alt="大金 DAIKIN"><span>{title}</span></header>
<div class="portal-hero cover-fluid-mode">{cover_design.MARKUP}<div class="portal-hero-inner"><span class="portal-kicker">{escape(data.get('kicker',''))}</span><h1>{title}</h1><p>{escape(data.get('desc',''))}</p></div></div>
<main class="portal-wrap"><div class="portal-steps">{steps}</div><h2>{escape(data.get('cards_label','资料入口'))}</h2>{cards}</main><footer class="portal-footer">{escape(data.get('footer',''))}</footer><script>{desktop_gate.JS}{cover_design.JS}</script></body></html>'''
