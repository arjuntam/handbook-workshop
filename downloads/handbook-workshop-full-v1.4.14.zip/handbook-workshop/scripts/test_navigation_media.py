"""导航与录音的内容合同：显式目标、稳定关联、多块递归和旧写法兼容。"""
import copy
import json
from pathlib import Path
import re
import unittest
import navigation_media as media
from handbook_core import render_blocks, build_html
from lint_content import walk_blocks, collect_images
from audit_sources import strings
from gallery_layouts import render as gallery


class NavigationMediaTests(unittest.TestCase):
    def setUp(self):
        self.examples = json.loads((Path(__file__).resolve().parent.parent / 'assets/navigation-media-examples.json').read_text())

    def section(self, blocks, sid='sample'):
        return dict(id=sid,title='演示',nav='演示',blocks=blocks)

    def test_each_new_type_renders(self):
        for kind in media.TYPES:
            self.assertTrue(media.render(self.examples[kind]))

    def test_missing_chapter_target_stops_build(self):
        with self.assertRaises(ValueError):
            media.validate_sections([self.section([self.examples['chapter_cover']])])

    def test_letter_is_single_latin_capital(self):
        for value in ['章节','AB','1','<A>']:
            block=copy.deepcopy(self.examples['chapter_cover']);block['letter']=value
            with self.assertRaises(ValueError):media.validate(block)

    def test_local_anchor_targets_are_scoped(self):
        jump=dict(t='section_jump',items=[dict(title='检查',target='check')])
        with self.assertRaises(ValueError):
            media.validate_sections([self.section([jump]),self.section([dict(t='h3',id='check',v='检查')],'other')])

    def test_same_anchor_in_two_sections_is_unique_in_html(self):
        section=self.section([dict(t='h3',id='check',v='检查')])
        other={**section,'id':'other'}
        html=build_html('验收','',dict(title='验收'),[section,other])
        self.assertIn('id="hw-anchor-sample--check"',html)
        self.assertIn('id="hw-anchor-other--check"',html)

    def test_duplicate_local_anchor_rejected(self):
        with self.assertRaises(ValueError):media.validate_sections([self.section([dict(t='h3',id='x',v='一'),dict(t='h3',id='x',v='二')])])

    def test_audio_tracks_bind_by_key(self):
        tabs=self.examples['audio_tabs'];tabs['items'].reverse();tabs['items'][0]['tab']='改名后的标签'
        media.validate_sections([self.section([tabs,self.examples['audio']])])

    def test_missing_audio_key_and_wrong_group_rejected(self):
        for prop,value in [('tabset','missing')]:
            audio=copy.deepcopy(self.examples['audio']);audio[prop]=value
            with self.assertRaises(ValueError):media.validate_sections([self.section([self.examples['audio_tabs'],audio])])
        audio=copy.deepcopy(self.examples['audio']);audio['tracks'][0]['key']='typo'
        with self.assertRaises(ValueError):media.validate_sections([self.section([self.examples['audio_tabs'],audio])])

    def test_duplicate_group_and_track_keys_rejected(self):
        tabs=self.examples['audio_tabs']
        with self.assertRaises(ValueError):media.validate_sections([self.section([tabs,tabs])])
        audio=self.examples['audio'];audio['tracks'][1]['key']=audio['tracks'][0]['key']
        with self.assertRaises(ValueError):media.validate(audio)

    def test_bad_audio_paths_rejected(self):
        for value in ['javascript:alert(1)','data:audio/wav;base64,x','file:///tmp/audio.wav','../secret.wav','%2e%2e/secret.wav','//host/test.mp3','/absolute/audio.wav']:
            with self.subTest(value=value),self.assertRaises(ValueError):media.media_source(value)

    def test_empty_track_has_no_empty_src_request(self):
        block=self.examples['audio'];block['default']='pending'
        html=media.render(block)
        self.assertNotIn('src=""',html)
        self.assertIn('preload="none"',html)
        self.assertNotIn('autoplay',html)

    def test_two_players_have_unique_control_ids(self):
        html=media.render(self.examples['audio'])+media.render(self.examples['audio'])
        ids=re.findall(r'\bid="([^"]+)"',html)
        self.assertEqual(len(ids),len(set(ids)))

    def test_tabs_multi_blocks_override_old_block(self):
        block=dict(t='tabs',items=[dict(tab='样例',num='01',block=dict(t='text',v='不应出现'),blocks=[dict(t='text',v='第一块'),dict(t='text',v='第二块')])])
        html=render_blocks([block],{})
        self.assertIn('第一块',html);self.assertIn('第二块',html);self.assertNotIn('不应出现',html)
        self.assertNotIn('class="card-num"',html)
        block['items'][0]['blocks']=[]
        self.assertNotIn('不应出现',render_blocks([block],{}))

    def test_old_single_block_remains_usable(self):
        block=dict(t='tabs',items=[dict(tab='样例',block=dict(t='text',v='旧写法'))])
        self.assertIn('旧写法',render_blocks([block],{}))

    def test_lint_walks_images_in_multi_blocks(self):
        block=dict(t='tabs',items=[dict(tab='样例',blocks=[dict(t='img',src='one.png'),dict(t='img',src='two.png')])])
        images=[image for b,_ in walk_blocks([block],'sample') for image in collect_images(b)]
        self.assertEqual(images,['one.png','two.png'])

    def test_portrait_is_opt_in_and_only_filmstrip(self):
        def image(*_):return '<figure>示例</figure>'
        self.assertIn('g-portrait',gallery(self.examples['portrait'],image))
        block=copy.deepcopy(self.examples['portrait']);block.pop('fit')
        self.assertNotIn('g-portrait',gallery(block,image))
        block['fit']='portrait';block['layout']='grid'
        with self.assertRaises(ValueError):gallery(block,image)

    def test_audio_text_is_kept_in_source_audit(self):
        self.assertIn('录音原文',list(strings(dict(tracks=[dict(transcript='录音原文')]))))


if __name__=='__main__':unittest.main()
