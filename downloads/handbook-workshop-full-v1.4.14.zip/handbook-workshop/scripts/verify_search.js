// Real-browser acceptance: generated fixture, generated gallery, output directory.
const fs=require('fs'),path=require('path'),{pathToFileURL}=require('url');
const {launchBrowser}=require('./browser_runtime');
const [fixture,gallery,out]=process.argv.slice(2);
if(!out)throw Error('Usage: node verify_search.js fixture.html gallery.html output');
fs.mkdirSync(out,{recursive:true});
(async()=>{
 const browser=await launchBrowser(),checks=[],errors=[];
 const ck=(name,ok,detail)=>{checks.push({name,ok,detail});if(!ok)throw Error(name+' '+JSON.stringify(detail||''));};
 try{
  const page=await browser.newPage({viewport:{width:1440,height:1050},reducedMotion:'reduce'});
  page.on('pageerror',e=>errors.push(String(e)));
  await page.goto(pathToFileURL(path.resolve(fixture)).href+'#body',{waitUntil:'domcontentloaded'});
  const input=page.locator('.search-box input').first(),results=page.locator('.search-result');
  async function query(q){await input.fill(q);await page.waitForTimeout(220);}
  async function open(q,id){await query(q);ck('命中 '+q,await results.count()===1);await results.first().click();await page.locator('#'+id+'.active').waitFor();}
  await query('排序试词');ck('标题命中优先于前面的正文命中',await results.count()===2&&await results.first().getAttribute('data-section')==='rank');
  ck('片段标记与章节聚合',await results.first().locator('mark').count()>0);
  await input.press('Enter');ck('回车打开排序后首项',await page.locator('#rank').evaluate(x=>x.classList.contains('active')));
  ck('打开结果关闭面板并移动焦点',await page.locator('.search-results').first().isHidden()&&await page.locator('.search-target').evaluate(x=>document.activeElement===x));
  await open('表格独有词','body');ck('表格匹配定位',await page.locator('td.search-target').textContent()==='表格独有词');
  await open('连续短语','body');ck('跨行内节点连续匹配',await page.locator('.search-target').textContent()==='连续短语测试。');
  await open('矢量独有词','body');ck('可选中的图表文字可搜索',await page.locator('svg.search-target').isVisible());
  await open('98765','body');ck('数字统计的原始数值可搜',await page.locator('.search-target').evaluate(x=>x.getBoundingClientRect().height>1));
  await query('  mixedcase  ');ck('英文大小写及首尾空白',await results.count()===1);
  await query('跨段甲 跨段乙');ck('多词在章节内取交集',await results.count()===1);
  await query('跨段甲 不存在的乙');ck('缺一个词不会命中',await results.count()===0);
  await open('折叠独有词','hidden');ck('自动展开原生折叠内容',await page.locator('#hidden .faq').first().getAttribute('open')!==null&&await page.locator('.search-target').isVisible());
  await open('嵌套独有词','hidden');ck('先切标签再展开内层卡片',await page.locator('#hidden .tab-panel.on').getAttribute('data-idx')==='1'&&await page.locator('.search-target').isVisible());
  await open('阶段独有词','hidden');ck('阶段面板切换到命中项',await page.locator('#hidden .metro-panel.on').getAttribute('data-stop')==='1'&&await page.locator('.search-target').isVisible());
  await open('详情独有词','detail');ck('L25 未选中详情可搜并正确联动',await page.locator('#detail .hw-detail-table').getAttribute('data-current-key')==='two'&&await page.locator('.search-target').isVisible());
  await open('未选中对象','detail');ck('搜索对象名称同步选中',await page.locator('#detail .hw-detail-table').getAttribute('data-current-key')==='two');
  await query('绝对无结果词');const old=await page.locator('.section.active').getAttribute('id');await input.press('Enter');ck('零命中回车不误跳',await page.locator('.section.active').getAttribute('id')===old&&await results.count()===0);
  await query('排序试词');await input.press('ArrowDown');ck('方向键进入结果按钮',await results.first().evaluate(x=>document.activeElement===x));await page.keyboard.press('ArrowDown');ck('方向键选择下一结果',await results.nth(1).evaluate(x=>document.activeElement===x));await page.keyboard.press('Escape');ck('Escape 回到输入框并关闭',await input.evaluate(x=>document.activeElement===x)&&await page.locator('.search-results').first().isHidden());
  await input.fill('');ck('清空恢复关闭且目录保留',await page.locator('.search-results').first().isHidden()&&await page.locator('.nav-link[style*="display: none"]').count()===0);
  await input.evaluate(x=>{x.dispatchEvent(new CompositionEvent('compositionstart'));x.value='折叠独有词';x.dispatchEvent(new InputEvent('input',{bubbles:true,isComposing:true}));x.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',isComposing:true,bubbles:true}));});await page.waitForTimeout(220);ck('中文组词中不搜索或跳页',await page.locator('.search-results').first().isHidden()&&await page.locator('.section.active').getAttribute('id')===old);await input.evaluate(x=>x.dispatchEvent(new CompositionEvent('compositionend')));ck('中文组词完成才搜索',await results.count()===1);
  await query('<img src=x onerror=alert(1)>');ck('搜索片段按文字安全呈现',await results.count()===1&&await page.locator('.search-results img').count()===0);
  await open('复制验收词','control');await page.locator('#control .copy-button').click();await page.locator('#control .copy-button[data-copied]').waitFor({timeout:3000});ck('定位高亮后复制事件仍存在',await page.locator('#control .copy-button').getAttribute('data-copied')!==null);
  await page.evaluate(()=>{document.querySelector('#control .copy-text').textContent='新增动态验收词'});await query('新增动态验收词');ck('正文变更后索引更新',await results.count()===1);
  const fallback=await browser.newPage({viewport:{width:1440,height:1050}});await fallback.addInitScript(()=>{window.Highlight=undefined});await fallback.goto(pathToFileURL(path.resolve(fixture)).href+'#body',{waitUntil:'domcontentloaded'});await fallback.locator('.search-box input').fill('详情独有词');await fallback.waitForTimeout(220);await fallback.locator('.search-result').click();ck('不支持高亮 API 时仍可定位',await fallback.locator('#detail .search-target').isVisible());await fallback.close();
  await page.goto(pathToFileURL(path.resolve(gallery)).href+'#palette',{waitUntil:'domcontentloaded'});
  for(const width of [1440,1024])for(const font of ['misans','source-han-sans','source-han-serif'])for(const shell of ['light','dark']){
   const mode=[width,font,shell].join('-');await page.setViewportSize({width,height:1050});
   await page.evaluate(()=>location.hash='palette');await page.locator('#palette.active').waitFor();await page.locator('#palette button[data-font="'+font+'"]').click();
   await page.locator('#palette button[data-shell-mode="'+shell+'"]').click();
   await page.locator('#palette button[data-type="presentation"]').click();await page.locator('#type-size-slider').evaluate(x=>{x.value='150';x.dispatchEvent(new Event('input',{bubbles:true}))});
   await query('资料');ck('外框模式实际切换 '+mode,await page.locator('body > .topbar').getAttribute('data-surface')===shell);
   ck('实际样式库正文有命中 '+mode,await results.count()>0);
   const rect=await page.locator('.search-results').first().boundingBox();ck('大字号搜索面板可读且不越窗 '+mode,rect.x>=0&&rect.x+rect.width<=width+1&&rect.height<=1050&&!(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+2)),rect);
   if(width===1440&&font==='misans'&&shell==='light')await page.screenshot({path:path.join(out,'全文搜索.png')});
   await page.keyboard.press('Escape');
  }
  ck('无页面脚本错误',errors.length===0,errors);
 }finally{
  await browser.close();fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({checks:checks.length,failures:checks.filter(x=>!x.ok).length,errors,results:checks},null,2));
 }
 console.log('Search checks passed: '+checks.length);
})().catch(e=>{console.error(e);process.exitCode=1});
