"""B04 optional static share metadata. No network, SDK, or client guarantees."""
from html import escape
from urllib.parse import urlsplit

SHARE_KEYS = ('share_enabled','share_image','share_thumb','share_url','share_title',
              'share_description','share_image_width','share_image_height','share_image_alt')


def enabled(cfg):
    flag = cfg.get('share_enabled')
    if flag is not None and not isinstance(flag, bool):
        raise ValueError('share_enabled 必须为 true 或 false')
    return flag if flag is not None else any(cfg.get(k) for k in ('share_image','share_thumb','share_url'))


def absolute_url(value, key):
    if not value:
        return ''
    if not isinstance(value, str) or any(c.isspace() or ord(c)<32 for c in value):
        raise ValueError(key+' 必须为完整的 http(s) URL')
    try:
        parts = urlsplit(value)
        if parts.scheme.lower() not in ('http','https') or not parts.hostname or parts.username or parts.password:
            raise ValueError()
        parts.port
    except ValueError:
        raise ValueError(key+' 必须为不含账号密码的完整 http(s) URL') from None
    return value


def validate(cfg):
    if not enabled(cfg):
        return
    for key in ('share_image','share_thumb','share_url'):
        absolute_url(cfg.get(key), key)
    dims = [cfg.get('share_image_width'), cfg.get('share_image_height')]
    if any(x is not None for x in dims):
        if not all(isinstance(x,int) and not isinstance(x,bool) and 0<x<=50000 for x in dims):
            raise ValueError('share_image_width / share_image_height 须同时提供正整数，并与实际图片一致')
    for key in ('share_title','share_description','share_image_alt'):
        if key in cfg and not isinstance(cfg[key],str):
            raise ValueError(key+' 必须为文字')


def social_meta(cfg, title, desc, url=''):
    validate(cfg)
    if not enabled(cfg) or not (cfg.get('share_image') or cfg.get('share_url') or url):
        return ''
    title = cfg.get('share_title') or title
    desc = cfg.get('share_description') or desc
    page_url = absolute_url(url or cfg.get('share_url'), 'share_url')
    image = cfg.get('share_image') or ''
    rows = [('og:type','website'),('og:title',title),('og:description',desc)]
    if page_url:
        rows.append(('og:url',page_url))
    if image:
        rows += [('og:image',image),('og:image:alt',cfg.get('share_image_alt') or title)]
        if cfg.get('share_image_width') is not None:
            rows += [('og:image:width',cfg['share_image_width']),('og:image:height',cfg['share_image_height'])]
    tags = ''.join('<meta data-handbook-share="B04" property="'+k+'" content="'+escape(str(v),quote=True)+'">' for k,v in rows)
    if image:
        tags += '<meta data-handbook-share="B04" name="twitter:card" content="summary_large_image">'
        tags += '<meta data-handbook-share="B04" name="twitter:image" content="'+escape(image,quote=True)+'">'
        tags += '<link data-handbook-share="B04" rel="image_src" href="'+escape(image,quote=True)+'">'
    return tags


def share_thumb_tag(cfg):
    validate(cfg)
    if not enabled(cfg) or not cfg.get('share_thumb'):
        return ''
    # Self-contained retrofit: no shared stylesheet dependency. Intentionally eager
    # for the optional crawler hint, low priority so it does not compete with LCP.
    return ('<img data-handbook-share="B04" class="share-thumb" src="'+escape(cfg['share_thumb'],quote=True)+
            '" alt="" aria-hidden="true" width="300" height="300" fetchpriority="low" '
            'style="position:fixed;left:-10000px;top:0;width:300px;height:300px;max-width:none;border:0;pointer-events:none">')
