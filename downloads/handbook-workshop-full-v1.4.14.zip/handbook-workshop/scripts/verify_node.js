// 用无头浏览器验证生成的手册：封面/正文切换、按钮、交叉引用、图片、JS 错误。
// 使用当前项目的 Playwright 与浏览器；可用环境变量指定依赖。
// 用法：node verify_node.js <index.html路径>
const path = require('path');
const { pathToFileURL } = require('url');
const { launchBrowser } = require('./browser_runtime');

(async () => {
  const site = process.argv[2];
  if (!site) { console.error('用法: node verify_node.js <index.html路径>'); process.exit(1); }
  const browser = await launchBrowser();
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  const url = pathToFileURL(path.resolve(site)).href + '?t=' + Date.now();
  await page.goto(url, { waitUntil: 'load' });
  await page.waitForTimeout(400);

  const cover = await page.evaluate(() => ({
    coverVisible: getComputedStyle(document.getElementById('cover')).display !== 'none',
    layoutHidden: getComputedStyle(document.querySelector('.layout')).display === 'none',
    hasStart: !!document.getElementById('cover-start'),
    homeBtns: document.querySelectorAll('.topbar .home-btn').length,
    sections: document.querySelectorAll('.section[id]').length,
  }));
  console.log('封面态:', JSON.stringify(cover));

  const start = await page.$('#cover-start');
  if (start) { await start.click(); await page.waitForTimeout(300); }
  const after = await page.evaluate(() => ({
    viewing: document.body.classList.contains('viewing'),
    coverHidden: getComputedStyle(document.getElementById('cover')).display === 'none',
    activeSections: document.querySelectorAll('.section.active').length,
    pos: (document.getElementById('pager-pos') || {}).textContent?.trim(),
  }));
  console.log('进入正文:', JSON.stringify(after));

  let xref = 'n/a';
  const chip = await page.$('.section.active .xref-chip');
  if (chip) {
    const before = await page.evaluate(() => document.querySelector('.section.active h2')?.textContent);
    const target = await page.evaluate(() => document.querySelector('.section.active .xref-chip')?.getAttribute('data-goto'));
    await chip.click(); await page.waitForTimeout(300);
    const now = await page.evaluate(() => document.querySelector('.section.active h2')?.textContent);
    xref = (before !== now && now) ? 'OK' : 'FAIL';
    console.log(`交叉引用(${target}):`, xref);
  }

  // 懒加载图片需先进入视口才会加载：逐节切换并等待，再统计真实断图
  const total = await page.evaluate(() => document.querySelectorAll('.section[id]').length);
  for (let i = 0; i < total; i++) {
    await page.evaluate((idx) => { if (window.__showSection) window.__showSection(idx); }, i);
    await page.waitForTimeout(120);
    await page.evaluate(async () => {
      const imgs = [...document.querySelectorAll('.section img')];
      imgs.forEach(im => { im.loading = 'eager'; });
      await Promise.all(imgs.map(im => im.complete ? Promise.resolve() :
        new Promise(r => { im.onload = r; im.onerror = r; setTimeout(r, 3000); })));
    });
  }
  const imgs = await page.evaluate(() => {
    const a = [...document.querySelectorAll('.section img')];
    return { total: a.length, broken: a.filter(i => i.naturalWidth === 0).length };
  });
  console.log('图片:', JSON.stringify(imgs));
  console.log('JS 错误:', errs.length, errs.slice(0, 2));

  const ok = cover.coverVisible && cover.hasStart && after.viewing && after.coverHidden
    && after.activeSections === 1 && imgs.broken === 0 && errs.length === 0
    && (xref === 'n/a' || xref === 'OK');
  console.log('结论:', ok ? '通过' : '未通过');
  await browser.close();
  process.exit(ok ? 0 : 1);
})().catch(e => { console.error('FATAL', e); process.exit(1); });
