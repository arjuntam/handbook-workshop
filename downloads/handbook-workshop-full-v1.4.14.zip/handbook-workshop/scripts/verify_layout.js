// Local rendered checks for all sections and tab panels. No publishing.
const fs = require('fs');
const path = require('path');
const { pathToFileURL } = require('url');
const { launchBrowser } = require('./browser_runtime');
const site = process.argv[2];
if (!site) throw new Error('用法：node verify_layout.js index.html [检查输出目录]');
const out = path.resolve(process.argv[3] || path.join(path.dirname(site), '版式检查'));
fs.mkdirSync(out, { recursive: true });
(async () => {
  const browser = await launchBrowser();
  const records = [], faults = [];
  try {
    for (const mode of [
      { name: 'desktop', width: 1440, height: 900, scale: 1 },
      { name: 'desktop1024', width: 1024, height: 768, scale: 1 },
      { name: 'phone', width: 390, height: 844, scale: 1 },
      { name: 'text200', width: 1440, height: 900, scale: 2 }
    ]) {
      const page = await browser.newPage({ viewport: { width: mode.width, height: mode.height }, reducedMotion: 'reduce' });
      page.on('pageerror', e => faults.push({ mode: mode.name, issue: 'JS', message: String(e) }));
      await page.goto(pathToFileURL(path.resolve(site)).href, { waitUntil: 'load' });
      if (mode.scale === 2) await page.addStyleTag({ content: 'html{font-size:200% !important}' });
      if (await page.locator('html.mobile-blocked').count()) {
        records.push({mode:mode.name,access:'blocked-as-required',note:'仅验证电脑端提示，未做移动端适配'});
        await page.close(); continue;
      }
      await page.locator('#cover-start').click();
      const ids = await page.locator('.section[id]').evaluateAll(xs => xs.map(x => x.id));
      for (let i=0; i<ids.length; i++) {
        await page.evaluate(n => window.__showSection(n), i);
        await page.evaluate(() => window.scrollTo(0, 0));
        await page.waitForTimeout(35);
        await page.evaluate(async () => {
          const images = [...document.querySelectorAll('.section.active img')];
          images.forEach(im=>im.loading='eager');
          await Promise.all(images.map(im => Promise.race([im.decode().catch(() => {}),new Promise(r=>setTimeout(r,4000))])));
        });
        async function measure(panel = '') {
          const m = await page.evaluate(() => {
            const s = document.querySelector('.section.active');
            const root = document.documentElement;
            const broken = [...s.querySelectorAll('img')].filter(x => x.getClientRects().length && !x.naturalWidth).map(x => x.getAttribute('src'));
            const pager = document.querySelector('.pagerbar').getBoundingClientRect();
            const btns = [...document.querySelectorAll('.pager-btn')].map(x=>x.getBoundingClientRect());
            const overflow = root.scrollWidth > root.clientWidth + 2;
            const hiddenText = [...s.querySelectorAll('p,h2,h3,h4,td,th')].filter(x => x.getClientRects().length &&
              /hidden|clip/.test(getComputedStyle(x).overflowY) && x.scrollHeight > x.clientHeight+2).length;
            return { overflow, broken, hiddenText, active: document.querySelectorAll('.section.active').length,
              sectionHeight: Math.round(s.getBoundingClientRect().height),
              pagerButtonsFit: btns.every(r => r.left>=-1 && r.right<=innerWidth+1 && r.top>=pager.top-1 && r.bottom<=innerHeight+1) };
          });
          records.push({ mode: mode.name, id: ids[i], panel, ...m });
          if (m.overflow || m.broken.length || m.hiddenText || m.active!==1 || !m.pagerButtonsFit)
            faults.push({ mode: mode.name, id: ids[i], panel, issue: 'layout', measurement: m });
        }
        await measure();
        const tabs = page.locator('.section.active .tab-head');
        for (let t=0; t<await tabs.count(); t++) {
          await tabs.nth(t).click();
          await measure('tab-'+t);
        }
        await page.evaluate(() => window.scrollTo(0, 0));
        await page.screenshot({ path: path.join(out, `${mode.name}-${ids[i]}.png`), fullPage: true });
      }
      // Exercise both pager buttons and return-to-cover controls.
      if (ids.length>1) {
        await page.evaluate(() => window.__showSection(0));
        await page.locator('#pager-next').click();
        if (await page.locator('.section.active').getAttribute('id') !== ids[1]) faults.push({mode:mode.name, issue:'next'});
        await page.locator('#pager-prev').click();
        if (await page.locator('.section.active').getAttribute('id') !== ids[0]) faults.push({mode:mode.name, issue:'prev'});
      }
      await page.locator('#home-btn').click();
      if (await page.locator('body.viewing').count()) faults.push({mode:mode.name,issue:'cover'});
      await page.close();
    }
  } finally { await browser.close(); }
  const report = { testedModes: ['desktop','desktop1024','phone-blocked','text200'], measurements: records.length,
    faults, records, boundary: '文字 200% 为注入根字号模拟；浏览器测量与截图不等于目视验收、原稿比对或真实设备测试。' };
  fs.writeFileSync(path.join(out,'report.json'), JSON.stringify(report,null,2));
  console.log(JSON.stringify({measurements:records.length, faults:faults.length, report:path.join(out,'report.json')}));
  process.exitCode = faults.length ? 1 : 0;
})().catch(e => { console.error(e); process.exitCode=1; });
