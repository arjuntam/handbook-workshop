"""Resolve the complete original font locally or from a verified shared-package resource.

Only font data is downloaded. No downloaded code is executed. The installation
directory can remain read-only; resources are cached in a writable temp directory.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
from urllib.parse import urlsplit
from urllib.request import Request, urlopen
import font_catalog

ROOT = Path(__file__).resolve().parent.parent
FONT = 'MiSans-VF.ttf'

class ResourceError(RuntimeError):
    pass

def copy_resource(source, destination):
    """Copy to owned output while leaving a read-only skill installation intact."""
    source = Path(source)
    destination = Path(destination)
    if source.resolve() == destination.resolve():
        return destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    # copytree preserves input directory permissions; output directories must
    # remain writable even when an installed skill's assets are read-only.
    destination.parent.chmod(destination.parent.stat().st_mode | 0o700)
    part = None
    try:
        with tempfile.NamedTemporaryFile(dir=destination.parent, prefix='.font-copy-', delete=False) as out:
            part = Path(out.name)
        shutil.copyfile(source, part)
        part.chmod(0o644)
        os.replace(part, destination)
        return destination
    finally:
        if part and part.exists():
            part.unlink()

def copy_font(destination, source=None):
    return copy_resource(source or font_source(), destination)

def copy_resources(source, destination, ignore=None):
    destination = Path(destination)
    shutil.copytree(source, destination, dirs_exist_ok=True, copy_function=copy_resource, ignore=ignore)
    for folder in [destination, *(p for p in destination.rglob('*') if p.is_dir())]:
        folder.chmod(folder.stat().st_mode | 0o700)
    return destination

def _matches(path, resource):
    return path.is_file() and path.stat().st_size == resource['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest() == resource['sha256']

def font_source(root=None, font_file=None, cache_dir=None, font_family='misans'):
    root = Path(root or ROOT).resolve()
    face = font_catalog.spec(font_family, root)
    local = root/'assets/fonts'/face['file']
    manifest_path = root/'resource-manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8')) if manifest_path.is_file() else {}
    if manifest and manifest.get('schema_version') not in (1, 2):
        raise ResourceError('字体资源清单版本无效。')
    resource = (manifest.get('fonts', {}).get(font_family) if manifest.get('schema_version') == 2
                else manifest.get('font') if manifest and font_family == 'misans' else face)
    if (not resource or not isinstance(resource.get('bytes'), int)
            or isinstance(resource['bytes'], bool) or not 1 <= resource['bytes'] <= 50_000_000
            or not re.fullmatch(r'[0-9a-f]{64}', resource.get('sha256',''))):
        raise ResourceError('字体资源清单无效，停止构建。')
    if local.is_file():
        if not _matches(local, resource):
            raise ResourceError('包内字体与资源清单不符，停止构建；请重新获取技能包。')
        return local
    cache = Path(cache_dir or Path(tempfile.gettempdir())/'handbook-workshop-resources')/resource['sha256']
    cache.mkdir(parents=True, exist_ok=True)
    target = cache/face['file']
    if _matches(target, resource):
        return target
    if target.exists():
        target.unlink()  # Only this hash-keyed, skill-owned cache entry.

    def install(reader):
        part = None
        try:
            with tempfile.NamedTemporaryFile(dir=cache, prefix='.font-', suffix='.part', delete=False) as out:
                part = Path(out.name)
                total = 0
                while True:
                    chunk = reader.read(256*1024)
                    if not chunk:
                        break
                    total += len(chunk)
                    if total > resource['bytes']:
                        raise ResourceError('字体下载大小超出清单，已拒绝使用。')
                    out.write(chunk)
            if not _matches(part, resource):
                raise ResourceError('字体大小或 SHA-256 校验失败，已拒绝使用。')
            os.replace(part, target)
            return target
        finally:
            if part and part.exists():
                part.unlink()

    if font_file:
        with Path(font_file).open('rb') as source:
            return install(source)
    failures = []
    for url in resource.get('urls', []):
        parsed = urlsplit(url)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
            raise ResourceError('字体资源只允许无账号密码的 HTTPS 下载地址。')
        try:
            req = Request(url, headers={'User-Agent':'handbook-workshop/resource-preparation'})
            with urlopen(req, timeout=20) as response:
                return install(response)
        except Exception as exc:
            failures.append(type(exc).__name__+': '+str(exc))
    raise ResourceError('无法准备完整 '+face['name']+' 字体，未继续构建，也未替换系统字体。请检查联网与文件写入权限，或使用Full 包；也可运行 prepare_resources.py --font '+font_family+' --font-file 已有官方字体路径。'+(' 原因：'+'; '.join(failures) if failures else ''))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--font-file', help='离线提供原始完整字体，仍须通过资源清单校验')
    parser.add_argument('--font', default='misans', choices=list(font_catalog.catalog()), help='只准备选中的字体')
    args = parser.parse_args()
    result = font_source(font_file=args.font_file, font_family=args.font)
    print(font_catalog.spec(args.font)['name']+' 字体已准备并校验：'+str(result))
