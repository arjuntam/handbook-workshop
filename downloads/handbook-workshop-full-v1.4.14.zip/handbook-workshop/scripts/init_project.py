#!/usr/bin/env python3
"""生成一个新手册项目的配置骨架与目录，供 Agent/用户填写内容后构建。

用法：
  python3 init_project.py --out <项目目录> --name <手册名称>

生成内容：
  <项目目录>/config.json      配置模板（品牌、主题、封面、首页链接）
  <项目目录>/content.py       章节数据模板（sections / attachments / xref / hero）
  <项目目录>/build.py         构建入口：读取配置与内容，调用 handbook_core 生成 index.html
  <项目目录>/assets/          放 logo.png 与 cover-wave.png（可选）
  <项目目录>/附件/            放本地附件（可选）
"""
import argparse, json
from pathlib import Path

CONFIG = {
    "title": "手册标题",
    "subtitle": "一句话说明（写入 meta 与顶栏）",
    "home_href": "../index.html",
    "mobile_block": True,
    "brand": "",
    "brand_logo": "",
    "cover_image": "",
    "dock_note": "",
    "theme": {"--brand": "#0d3b66", "--brand2": "#1b5c96", "--accent": "#2b7fd4"},
}

CONTENT = '''# -*- coding: utf-8 -*-
"""手册内容：按章节填写。块类型与字段见 references/content-model.md。"""
import sys
from pathlib import Path
sys.path.insert(0, r"{core_dir}")

HERO = {{
    "kicker": "版本 · 年份",
    "title": "手册主标题",
    "desc": "一句话说明本手册解决什么问题。",
    "meta": "部门 · 年份",
}}

SECTIONS = [
    {{
        "id": "intro",
        "nav": "开场",
        "group": "第一部分",
        "title": "第一节标题",
        "kicker": "01 开场",
        "subtitle": "本节一句话说明",
        "blocks": [
            {{"t": "lede", "v": "开篇导语"}},
            {{"t": "text", "v": "正文段落"}},
            {{"t": "callout", "label": "要点", "tone": "blue", "v": "提示内容"}},
        ],
    }},
]

ATTACHMENTS = [
    # {{"name": "模板.xlsx", "path": "附件/模板.xlsx", "kind": "local"}}
    # {{"name": "网盘大文件", "path": "https://pan.baidu.com/s/...", "kind": "netdisk"}}
]

XREF = {{
    "intro": [],
}}

SEARCH_PLACEHOLDER = "搜索章节 / 关键词"
'''

BUILD = '''# -*- coding: utf-8 -*-
"""构建入口：读取 config.json 与 content.py，生成 index.html。"""
import sys, json
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, r"{core_dir}")
from handbook_core import build_html, prepare_assets, ensure_brand_assets, resolve_config
from content import HERO, SECTIONS, ATTACHMENTS, XREF, SEARCH_PLACEHOLDER

cfg = json.loads((HERE / "config.json").read_text(encoding="utf-8"))
# 相对路径按项目目录解析
for key in ("brand_logo", "cover_image"):
    if cfg.get(key):
        p = Path(cfg[key])
        cfg[key] = str(p if p.is_absolute() else HERE / p)

ensure_brand_assets(HERE, cfg)
A = prepare_assets(HERE / "assets", HERE)

html = build_html(
    cfg["title"], cfg["subtitle"], HERO, SECTIONS, ATTACHMENTS, A,
    search_placeholder=SEARCH_PLACEHOLDER, xref=XREF, config=cfg,
)
(HERE / "index.html").write_text(html, encoding="utf-8")
print(f"生成: {{HERE / 'index.html'}}  章节: {{len(SECTIONS)}}")
'''


def main():
    ap = argparse.ArgumentParser(description="初始化网页手册项目骨架")
    ap.add_argument("--out", required=True, help="项目输出目录")
    ap.add_argument("--name", default="我的手册", help="手册名称，写入配置")
    args = ap.parse_args()

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "assets").mkdir(exist_ok=True)
    (out / "附件").mkdir(exist_ok=True)

    config = dict(CONFIG)
    config["title"] = args.name
    (out / "config.json").write_text(
        json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")

    core_dir = str(Path(__file__).parent)
    (out / "content.py").write_text(
        CONTENT.format(core_dir=core_dir), encoding="utf-8")
    (out / "build.py").write_text(
        BUILD.format(core_dir=core_dir), encoding="utf-8")

    print(f"项目骨架已生成：{out}")
    print("下一步：填写 content.py 的章节，放入 logo/封面图到 assets/，运行 build.py")


if __name__ == "__main__":
    main()
