"""L17 多图画廊的三个固定变体，复用原图放大。"""
import html


def render(block, image):
    layout=block.get('layout','grid')
    if layout=='coverflow': layout='focus'
    if layout not in ('grid','filmstrip','focus'):
        raise ValueError('imgs.layout 必须为 grid / filmstrip / focus')
    fit=block.get('fit','default')
    if fit not in ('default','portrait') or fit=='portrait' and layout!='filmstrip':
        raise ValueError('imgs.fit=portrait 仅用于 filmstrip')
    portrait=' g-portrait' if fit=='portrait' else ''
    items=block['items']
    if layout=='grid':
        return f'<div class="gallery gallery-{block.get("cols",3)} gallery-grid">'+''.join(image(x['src'],'gallery-item',x.get('cap','')) for x in items)+'</div>'
    count=len(items)
    default=max(0,min(int(block.get('default',0)),count-1))
    title=html.escape(block.get('title','多图画廊'),quote=True)
    slides=''.join(f'<div class="g-slide" role="group" aria-roledescription="幻灯片" aria-label="第 {i+1} 张，共 {count} 张"><div class="g-visual">'+image(x['src'],'gallery-item',x.get('cap',''))+'</div></div>' for i,x in enumerate(items))
    markers=''.join(f'<button type="button" class="g-marker" data-index="{i}" aria-label="查看第 {i+1} 张：{html.escape(x.get("cap", "图片"),quote=True)}">{i+1}</button>' for i,x in enumerate(items))
    if layout=='focus':
        markers=''.join(f'<button type="button" class="g-marker" data-index="{i}" aria-label="查看第 {i+1} 张"><span class="sr-only">{i+1}</span></button>' for i in range(count))
    return f'''<div class="gallery multi-gallery g-{layout}{portrait}" data-default="{default}" role="region" aria-roledescription="轮播图" aria-label="{title}">
<div class="g-controls"><button type="button" class="g-prev">‹ 上一张</button><span class="g-count">{default+1} / {count}</span><button type="button" class="g-next">下一张 ›</button></div>
<div class="g-frame"><div class="g-track" tabindex="0" role="group" aria-label="图片列表，左右方向键切换，回车放大图片">{slides}</div></div>
<div class="g-markers" aria-label="选择图片">{markers}</div><p class="g-status sr-only" role="status" aria-live="polite"></p>
</div>'''


CSS=r'''
.multi-gallery{display:block;min-inline-size:0;margin-block:1.5rem}
.g-controls{display:flex;align-items:center;justify-content:center;gap:1rem;margin-block-end:.75rem}
.g-controls button,.g-marker{font:inherit;color:var(--brand);background:var(--surface);border:1px solid var(--border);cursor:pointer;border-radius:.75rem;min-block-size:2.75rem;padding:.5rem .875rem}
.g-controls button:disabled{opacity:.4;cursor:not-allowed}
.g-count{font-size:.875rem;font-variant-numeric:tabular-nums;color:var(--muted);min-inline-size:4rem;text-align:center}
.g-frame{container-type:inline-size;min-inline-size:0;background:linear-gradient(180deg,var(--accent-soft),var(--surface));border:1px solid var(--border);border-radius:1rem}
.g-track{--g-slide:min(64cqi,35rem);display:flex;gap:0;overflow-x:auto;scroll-snap-type:x mandatory;overscroll-behavior-x:contain;
 padding-block:2rem 1rem;padding-inline:max(1rem,calc((100% - var(--g-slide))/2));scroll-padding-inline:max(1rem,calc((100% - var(--g-slide))/2));
 scrollbar-width:thin;scrollbar-color:var(--border) transparent;min-inline-size:0}
.g-slide{flex:0 0 var(--g-slide);min-inline-size:0;scroll-snap-align:center;scroll-snap-stop:always;padding:.5rem}
.g-visual{transform:perspective(1000px) rotateY(0);transform-origin:center;opacity:1}
.g-visual .gallery-item{margin:0;padding:.625rem;border-radius:.875rem;background:var(--surface);box-shadow:var(--shadow)}
.g-visual .gallery-item img{block-size:clamp(10rem,32cqi,20rem);inline-size:100%;object-fit:contain;user-select:none;-webkit-user-drag:none}
.g-visual .gallery-item figcaption{min-block-size:2.75rem;margin:.75rem .25rem .25rem;font-size:var(--fs-note);overflow-wrap:anywhere}
.g-slide.is-current .gallery-item{outline:2px solid var(--accent);outline-offset:2px}
.g-filmstrip .g-track{--g-slide:min(42cqi,23rem);gap:.5rem}
.g-filmstrip .g-visual .gallery-item img{block-size:clamp(10rem,30cqi,17rem)}
.g-markers{display:flex;flex-wrap:wrap;justify-content:center;gap:.5rem;margin-block-start:.875rem}
.g-marker{min-inline-size:2.5rem;min-block-size:2.5rem;padding:.375rem .625rem;font-size:.8125rem}
.g-marker[aria-current=true]{background:var(--accent-soft);border-color:var(--accent);outline:1px solid var(--accent);outline-offset:2px;font-weight:700}
.g-track.dragging{scroll-snap-type:none;cursor:grabbing}
@media(prefers-reduced-motion:no-preference){
 .g-track{scroll-behavior:smooth}
}
.g-focus{display:grid;grid-template-columns:minmax(0,1fr) auto;grid-template-areas:"stage stage" "dots arrows";row-gap:1.25rem}
.g-focus .g-frame{grid-area:stage;background:transparent;border:0;border-radius:0}
.g-focus .g-controls{grid-area:arrows;margin:0;gap:.625rem;align-self:center}
.g-focus .g-count{font-size:.8125rem;min-inline-size:3rem}
.g-focus .g-controls button{min-inline-size:2.5rem;inline-size:2.5rem;block-size:2.5rem;min-block-size:2.5rem;padding:0;border:0;border-radius:50%;background:var(--accent-soft);font-size:0;color:var(--brand)}
.g-focus .g-prev::after{content:"‹";font-size:1.75rem;line-height:1}.g-focus .g-next::after{content:"›";font-size:1.75rem;line-height:1}
.g-focus .g-track{--g-slide:min(78cqi,38rem);padding-block:.5rem 1rem;gap:1.25rem;scrollbar-width:none;scroll-padding-inline:0}
.g-focus .g-track::-webkit-scrollbar{display:none}
.g-focus .g-slide{padding:0}
.g-focus .g-visual{transform:none;opacity:1}
.g-focus .g-visual .gallery-item{border:0;box-shadow:none;padding:0;background:transparent;border-radius:0;outline:none}
.g-focus .g-slide.is-current .gallery-item{outline:none}
.g-focus .gallery-item img{height:auto;block-size:auto;max-block-size:32rem;aspect-ratio:4/3;object-fit:contain;border-radius:1.5rem;background:var(--bg)}
.g-focus .gallery-item figcaption{font-size:1rem;min-block-size:0;margin:1rem .25rem 0;text-align:start;color:var(--text)}
.g-focus .g-markers{grid-area:dots;justify-content:flex-start;margin:0;gap:.125rem;align-self:center;min-inline-size:0}
.g-focus .g-marker{inline-size:2rem;block-size:2rem;min-inline-size:2rem;min-block-size:2rem;padding:.625rem;border:0;background:transparent;outline:none;font-size:0}
.g-focus .g-marker::after{content:"";display:block;inline-size:.5rem;block-size:.5rem;border-radius:99px;background:var(--muted);opacity:.35}
.g-focus .g-marker[aria-current=true]::after{inline-size:.875rem;background:var(--brand);opacity:1}
@media(prefers-reduced-motion:reduce){.g-slide .g-visual{transform:none!important;opacity:1!important}}
@media(max-width:600px){.g-track{--g-slide:78cqi;padding-block:1rem}.g-filmstrip .g-track{--g-slide:78cqi}.g-controls{gap:.5rem}.g-controls button{font-size:.875rem}}
'''

JS=r'''
(function(){
 const reduce=matchMedia('(prefers-reduced-motion:reduce)');
 document.querySelectorAll('.multi-gallery').forEach(g=>{
  const track=g.querySelector('.g-track'),slides=[...g.querySelectorAll('.g-slide')],markers=[...g.querySelectorAll('.g-marker')];
  const prev=g.querySelector('.g-prev'),next=g.querySelector('.g-next'),count=g.querySelector('.g-count'),status=g.querySelector('.g-status');
  if(!slides.length)return;
  let current=-1,pending=null,frame=0,timer,lastAnnounced=-1,user=false,drag=null,suppressClickUntil=0;
  const center=i=>slides[i].offsetLeft+slides[i].offsetWidth/2-track.offsetLeft-track.clientWidth/2;
  // offsetLeft may be relative to different offset parents; rectangles provide track-local deltas.
  function target(i){const a=slides[i].getBoundingClientRect(),b=track.getBoundingClientRect();return track.scrollLeft+a.left+a.width/2-b.left-track.clientWidth/2;}
  function nearest(){let best=0,d=Infinity;slides.forEach((s,i)=>{const r=s.getBoundingClientRect(),t=track.getBoundingClientRect();const x=Math.abs(r.left+r.width/2-t.left-track.clientWidth/2);if(x<d){d=x;best=i;}});return best;}
  function paint(i){
   current=i;slides.forEach((s,k)=>{s.classList.toggle('is-current',k===i);s.classList.toggle('is-before',k<i);s.classList.toggle('is-after',k>i)});
   markers.forEach((m,k)=>m.setAttribute('aria-current',String(k===i)));count.textContent=(i+1)+' / '+slides.length;
   prev.disabled=i===0;next.disabled=i===slides.length-1;
   // Keep keyboard focus reachable when the active edge button becomes disabled.
   if(document.activeElement===prev&&prev.disabled&&!next.disabled)next.focus({preventScroll:true});
   if(document.activeElement===next&&next.disabled&&!prev.disabled)prev.focus({preventScroll:true});
  }
  function settled(){
   if(!track.clientWidth)return;
   const i=nearest();
   if(pending!==null&&i!==pending){clearTimeout(timer);timer=setTimeout(()=>{pending=null;settled()},200);return;}
   pending=null;paint(i);
   if(user&&i!==lastAnnounced){status.textContent='第 '+(i+1)+' 张，共 '+slides.length+' 张';lastAnnounced=i;}
  }
  function go(i,instant=false){
   if(!track.clientWidth)return;
   i=Math.max(0,Math.min(slides.length-1,i));pending=i;paint(i);
   const left=target(i),behavior=instant||reduce.matches?'instant':'smooth';track.scrollTo({left,behavior});
   if(Math.abs(track.scrollLeft-left)<1){pending=null;settled();}
  }
  prev.addEventListener('click',()=>{user=true;go((pending??current)-1)});
  next.addEventListener('click',()=>{user=true;go((pending??current)+1)});
  markers.forEach((m,i)=>m.addEventListener('click',()=>{user=true;go(i)}));
  track.addEventListener('scroll',()=>{
   if(!frame&&pending===null)frame=requestAnimationFrame(()=>{frame=0;if(track.clientWidth)paint(nearest())});
   if(!('onscrollend' in track)){clearTimeout(timer);timer=setTimeout(settled,130)}
  },{passive:true});
  if('onscrollend' in track)track.addEventListener('scrollend',settled);
  track.addEventListener('wheel',()=>{user=true;pending=null},{passive:true});
  track.addEventListener('touchstart',()=>{user=true;pending=null},{passive:true});
  track.addEventListener('keydown',e=>{
   if(e.target.closest('button,input,textarea,a'))return;
   let n=null;if(e.key==='ArrowLeft')n=(pending??current)-1;if(e.key==='ArrowRight')n=(pending??current)+1;if(e.key==='Home')n=0;if(e.key==='End')n=slides.length-1;
   if(n!==null){e.preventDefault();e.stopPropagation();user=true;go(n)}
   else if((e.key==='Enter'||e.key===' ')&&e.target.matches('img')&&slides.indexOf(e.target.closest('.g-slide'))!==current){e.preventDefault();e.stopPropagation();user=true;go(slides.indexOf(e.target.closest('.g-slide')))}
  });
  track.addEventListener('click',e=>{
   if(Date.now()<suppressClickUntil){e.preventDefault();e.stopPropagation();return;}
   const slide=e.target.closest('.g-slide');if(!slide)return;
   const i=slides.indexOf(slide);
   if(i!==current){e.preventDefault();e.stopPropagation();user=true;go(i)}
  },true);
  track.querySelectorAll('img').forEach(im=>im.draggable=false);
  track.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse'||e.button!==0)return;drag={x:e.clientX,left:track.scrollLeft,id:e.pointerId,moved:false}});
  track.addEventListener('pointermove',e=>{if(!drag)return;if(!e.buttons){endDrag();return;}const dx=e.clientX-drag.x;if(Math.abs(dx)>6){drag.moved=true;user=true;pending=null;track.classList.add('dragging');track.setPointerCapture(e.pointerId)}if(drag.moved){e.preventDefault();track.scrollTo({left:drag.left-dx,behavior:'instant'})}});
  function endDrag(){if(!drag)return;const moved=drag.moved,id=drag.id;drag=null;track.classList.remove('dragging');if(track.hasPointerCapture(id))track.releasePointerCapture(id);if(moved){suppressClickUntil=Date.now()+350;go(nearest())}}
  track.addEventListener('pointerup',endDrag);track.addEventListener('pointercancel',endDrag);
  function portraitPadding(){
   if(!g.classList.contains('g-portrait')||!track.clientWidth)return;
   track.style.paddingInlineStart=Math.max(16,(track.clientWidth-slides[0].offsetWidth)/2)+'px';
   track.style.paddingInlineEnd=Math.max(16,(track.clientWidth-slides[slides.length-1].offsetWidth)/2)+'px';
  }
  if(g.classList.contains('g-portrait'))track.querySelectorAll('img').forEach(im=>im.addEventListener('load',()=>{portraitPadding();go(current>=0?current:(Number(g.dataset.default)||0),true)}));
  const initial=Number(g.dataset.default)||0;let wasVisible=false;
  const resize=new ResizeObserver(()=>{if(!track.clientWidth){wasVisible=false;return;}portraitPadding();go(current>=0?current:initial,true);wasVisible=true;});resize.observe(track);
 });
})();
'''

CSS += r"""
.g-filmstrip.g-portrait .g-track{gap:.875rem;padding-block:1rem;scroll-padding-inline:1rem}
.g-filmstrip.g-portrait .g-slide{flex:0 0 auto;max-inline-size:calc(100cqi - 2rem)}
.g-filmstrip.g-portrait .gallery-item{display:flex;flex-direction:column;align-items:center;max-inline-size:100%}
.g-filmstrip.g-portrait .gallery-item img{block-size:clamp(12rem,30cqi,19rem);inline-size:auto;max-inline-size:100%;object-fit:contain;border-radius:.5rem}
.g-filmstrip.g-portrait .gallery-item figcaption{min-inline-size:10rem;max-inline-size:15rem;min-block-size:0;text-align:center}
"""
