"""稳定名称是内容编辑的选择接口；不以项目内容命名组件。"""
# id, engine type, name, scope, avoid, interaction
ROWS = [
('T01','lede','开篇导语','一节开头的核心说明','长文或多条并列信息','静态阅读'),
('T02','text','标准正文','完整段落、条件和解释','用字号或颜色临时表达层级','静态阅读'),
('T03','h3','段内小标题','同节内的第二层说明','堆成多个章节的替代品','静态阅读'),
('T04','quote','重点引语','原稿明确的一句话重点','普通段落或无依据的宣传结论','默认静态；明确设置 reveal 时展开查看'),
('T04-A','solution','折叠解决方案区','先讲现状，再展开引语与一组方案要点','只有引语时用 T04 reveal；需要同时对比的内容','原生折叠；内部沿用展示卡或单选卡的既有交互'),
('T05','callout','语义提示卡','重点、提醒或说明','整页所有正文','静态阅读；语义蓝/绿/琥珀/红不随主题改义'),
('T06','warn','风险提醒卡','确实有风险或禁止事项','普通解释和正向卖点','静态阅读；保留红色风险语义'),
('T07','divider','内容分隔线','同节内轻量分隔','靠大量分隔线制造层级','无交互'),
('L01','grid','并列要点卡','少量同层级短信息','长段落、统一字段的大量明细','展示；独立操作必须用明确按钮，不定义整卡选中'),
('L01-A','number_strip','编号横条卡','少量编号、短标题与简短说明，可突出指定项目','长段正文、过多要点；编号不自动代表业务先后','静态展示；自适应实际条数，不制造点击状态'),
('L01-B','watermark','水印编号卡','多个编号板块，每块包含标题、副标和成对信息','大量固定字段明细用表格；不靠水印承载唯一编号','静态展示；小编号为主，大编号只作装饰'),
('L02','pick','单选高亮卡','同组只选一个方案','单纯展示、真实多选、未实现的提交结果','鼠标/触屏/键盘选择；柔底+主题边框+竖线+外描边；禁用不能选'),
('L02-A','tracks','双赛道选择面板','两套互斥体系，各有要点、总结与独立章节入口','纯对照用 L04；三套以上或不需要选择','原生 radio 单选；底部独立按钮跳章；选择不自动导航'),
('L03','tabs','场景切换卡','多个可独立阅读的场景','需要同时对比的数据、只有一个场景','点击标签切换；方向键/Home/End；活动标签与内容同步'),
('L04','compare','双栏对照','明确的一一对应关系','仅因 PPT 上左右摆放就猜为对照','静态同时呈现；窄屏上下排列'),
('L05','table','通用数据表','多列数据、表单字段与清单','为了套版式删列；未经确认猜表头','局部横纵滚动；已指定表头时粘性显示；可键盘滚动'),
('L06','roster','人员分工表','事项/执行/负责/时间等固定字段','字段不同或超过固定五列的任意表格','紧凑阅读与局部滚动；不是可填写表单'),
('L07','total','汇总指标条','原稿已确认的合计指标','凭空求和或与明细混排','静态汇总；不自动计算'),
('L08','stats','数字指标卡','少量数字且单位口径明确','正文中的任意数值或不同单位混加','可选入场计数；减少动态时静态数字；不是实时数据'),
('L09','steps','步骤流程','明确先后顺序的简短操作','并列要点或未确认的因果关系','静态顺序阅读'),
('L10','runsheet','时间流程单','明确时间点的会议或执行节点','没有时间信息却补造时间轴','静态时间线；高亮节点只表示源稿确认重点'),
('L11','metro','阶段导航条','阶段进度、当前阶段与下一阶段','所有流程一律地铁化','选择阶段查看详情；默认不跳章节，章节跳转使用独立按钮'),
('L12','scriptlib','话术复制库','按场景分组、可直接使用的话术','把解释或禁用条件混进可复制正文','展开/收起 + 单段复制 + 成功/失败反馈；tabs 内默认 flat'),
('L13','faq','折叠问答','读者按问题查找答案','需要同时比较的内容或纯标题','原生展开/收起；答案复制有反馈'),
('L14','chat','对话演示','明确说话人的沟通示例','把技术说明伪装成真实聊天记录','按气泡阅读/复制；身份与头像需有来源'),
('L15','moments','朋友圈范例','发圈文案与配图示例','真实社交动态或保存承诺','演示点赞/评论；仅当前页面状态，不冒充已发布'),
('L16','img','单张原图','需要完整阅读的一张图','把完整网页变成不可搜索截图','点击或键盘放大、Escape 关闭'),
('L17','imgs','多图画廊','多张有对应说明的图片','裁掉图表关键部分','点击放大、同组切图、关闭返回；图片说明保留'),
('L18','resources','资料封面入口卡','同一项目的手册、模板与附件入口','把待补链接伪装成可下载；整卡链接中再嵌按钮','封面并排、底部动作对齐；阅读/下载/外链使用独立原生链接'),
('L19','china_map','中国城市分布地图','城市覆盖、区域布局与项目分布，已有明确点位和数据口径','未经确认的覆盖数、路线规划、精确测绘或自动猜坐标','悬停看名称；点击城市保持选中；区域汇总说明卡；按钮/键盘缩放与复位，拖动平移；Ctrl/⌘+滚轮缩放'),
('L20','decision','分流决策面板','明确判断分为两条路径，每路为顺序步骤或情形动作','三路以上复杂决策图；不从并列内容猜条件','静态并列阅读；步骤和情形使用不同结构，不伪造可选状态'),
('L21','chapter_nav','章节导航卡','章节扉页列出本章内容与阅读顺序','普通页重复堆导航按钮；目标不明确','原生按钮跳到实际章节，同步目录与底部翻页栏'),
('L22','checklist','复选清单','逐项核对、完成标记；允许多项同时勾选并取消','互斥方案选择；未接保存时声称已提交或保存','原生 checkbox；整行可点，空格切换；各项独立，可禁用'),
('L23','icon_folds','图标折叠卡','少量带图标的标准、维度与说明，按需展开','必须同时可见的重要正文；纯展示卡或单选方案','原生 details 独立展开；图标与箭头提示；展开用柔底、边框、左竖线高亮'),
('L24','number_folds','编号折叠卡网格','编号主题按网格组织，点击后阅读对应说明','编号不代表先后时不得补造流程；不要冒充单选卡','原生 details 独立展开与收起；编号保留，展开高亮；支持嵌入原生块'),
('L25','detail_table','汇总详情联动','多个对象需要横向比较关键字段，并分别查阅完整资料','只有短数据、不需要明细；案例编辑、保存或自动诊断','对象名称按钮与行高亮、详情同步；键盘可操作；不自动滚动；零值与缺失分开'),
('A01','note','配套附件提示','提醒有可下载配套资料','承载正文或假装附件已存在','提示本身不下载；实际入口在附件组件'),
('A02','downloads','就地附件下载区','当前章节有明确对应附件，在内容旁提供入口','未明确归属的附件；缺文件不得伪装可下载','引用全局附件同源记录；下载、打开、待补分别呈现'),
('X01','html','受控自定义图形','已审查的 SVG/图形嵌入','逃离样式库手写普通页面；注入原稿脚本','交互单独定义和验证，不自动执行来源内容'),
]
CATALOG = [dict(id=i,type=t,name=n,scope=s,avoid=a,interaction=x,
               colors=('固定风险红与浅红底' if t=='warn' else '按语义使用蓝/绿/琥珀/红' if t=='callout' else '继承同一项目样式基准；不继承 PPT 单页颜色'),
               states=('默认/悬停/键盘焦点/选中/禁用' if t=='pick' else '当前标签/非当前标签/键盘焦点' if t=='tabs' else '按上述交互定义；静态块无伪造点击状态'))
           for i,t,n,s,a,x in ROWS]
BASE = [
 dict(id='B04',name='分享卡片元信息',scope='需要转发链接的静态手册与资料中心；默认关闭，配置后注入',avoid='保证微信出图、自动接入 SDK、冒充公众号图文或自动适配手机阅读',interaction='无页面交互；生成静态元信息与可选首图提示；已有 HTML 可另存副本追加；客户端结果需真机确认',colors='分享图片保持原图；不随页面配色重绘',sample='index.html#share-card'),
 dict(id='B03',name='底部翻页导航',scope='采用章节翻页的网页手册；与 B01 页头、B02 目录共同构成固定外框',interaction='左侧上一节；中间当前节/总节数及章节名；右侧下一节；随当前章节同步，首尾边界禁用；固定在正文区底部并预留空间',colors='继承项目主题与统一浅底；深浅外框共用尺寸、位置与三栏布局'),
 dict(id='T08',name='词组与数字换行',scope='正文、引语和标题中的明确固定词组、数字与单位',interaction='基础词库 + 项目短语 + 内容标记；保留原文，空间不足时允许折行',colors='继承所在文本颜色，不额外染色'),
 dict(id='B02',name='两级目录导航',scope='统一手册目录层级',interaction='一级无圆点；可折叠分组保留箭头；二级灰点，当前条目主题色圆点和柔底',colors='继承项目主题，颜色不单独表示层级'),
 dict(id='B01',name='标准品牌页头',scope='同资料中心全部手册',interaction='目录/搜索/回封面；只有手册名称变化',colors='浅底原色 logo、深底白色 logo；品牌区不得用文字替代'),
 dict(id='C01',name='流光封面',scope='原稿没有适合网页的封面素材',interaction='缓慢流动、可暂停、减少动态时静止',colors='继承项目配色，标题区保持可读'),
 dict(id='C02',name='图片封面',scope='已有可用且经用户指定的封面图',interaction='开始阅读；原图不随配色重绘',colors='根据实际标题背景指定明暗；匹配原色或白色 logo'),
]
# Override only states whose interaction differs from the generic catalogue text.
for entry in CATALOG:
    if entry['type'] == 'tracks':
        entry['states'] = '初始未选/选中/焦点/禁用；选中不自动导航'
    elif entry['type'] in ('number_strip','watermark','decision'):
        entry['states'] = '静态展示；强调项只反映明确内容，不代表选择'
    elif entry['type'] == 'checklist':
        entry['states'] = '未勾选/已勾选/焦点/禁用；多项独立、可取消；不宣称保存'
    elif entry['type'] in ('icon_folds','number_folds'):
        entry['states'] = '收起/展开/键盘焦点；高亮表示展开，不表示单选'
    elif entry['type'] == 'detail_table':
        entry['states'] = '默认对象/当前行/键盘焦点/无对象/详情待补；选择仅更新本组件，不保存或跳页'
    elif entry['type'] == 'downloads':
        entry['states'] = '下载/打开/待补；待补项没有可点击下载链接'
    elif entry['type'] == 'solution':
        entry['states'] = '收起/展开；内部块沿用各自状态合同'

RECIPES = [
 dict(id='P01',name='信息概览页',blocks=['T01','L01','T05']),dict(id='P02',name='方案选择页',blocks=['T02','L02','T05']),
 dict(id='P03',name='方案对照页',blocks=['T01','L04','T02']),dict(id='P04',name='执行流程页',blocks=['T01','L09','L10','T06']),
 dict(id='P05',name='数据清单页',blocks=['T02','L05','L07']),dict(id='P06',name='话术问答页',blocks=['T02','L12','L13']),
 dict(id='P07',name='场景切换页',blocks=['T02','L03']),dict(id='P08',name='原图解释页',blocks=['T01','L16','T02']),
]

GALLERY_VARIANTS = [
 dict(id='L17-A',name='网格图册',layout='grid',scope='2–6 张需要同时比较的现场照、产品图或截图',avoid='大量图片挤成小缩略图',interaction='完整并列呈现；点击放大和同组切图'),
 dict(id='L17-B',name='横向胶片',layout='filmstrip',scope='多张照片按顺序浏览，保留相邻图片预览',avoid='需要同时逐列核对的数据图',interaction='横向滚动/触屏滑动/鼠标拖动；按钮、序号、左右键；当前图片可放大'),
 dict(id='L17-C',name='焦点大图画廊',layout='focus',scope='案例、活动或作品展示，一次突出一张主图',avoid='密集表格、技术参数或要求全部同时可读的图片',interaction='平面大图横向滑动，相邻图片露出；侧图先居中，再点放大；圆形箭头和位置圆点；拖动/方向键可切换；不自动播放'),
]
RECIPES.append(dict(id='P09',name='项目资料中心',blocks=['B01','L18']))
RECIPES.append(dict(id='P10',name='汇总详情页',blocks=['T01','L25','A02']))

# Browse by the reader's content need; stable component IDs remain unchanged.
CONTENT_CATEGORIES = [
    dict(id='text', name='文字与重点', description='写说明、讲重点、做提醒。',
         hint='完整解释用标准正文；一句重点用重点引语；提醒或注意事项用提示卡。',
         types=['lede','text','h3','quote','solution','callout','warn','divider']),
    dict(id='cards', name='卡片与选择', description='摆要点、选方案、逐项核对、按需展开。',
         hint='只展示用并列要点卡；只选一项用单选卡；多项勾选用复选清单；补充说明可用折叠卡。',
         types=['grid','number_strip','watermark','pick','tracks','tabs','checklist','icon_folds','number_folds']),
    dict(id='data', name='数据与对照', description='看数字、查明细、对比差异、展示分布。',
         hint='逐项比较用双栏对照；多列明细用数据表；少量核心数字用指标卡；已知城市点位用地图；比较对象并查明细用汇总详情联动。',
         types=['compare','table','roster','total','stats','china_map','detail_table']),
    dict(id='flow', name='流程与导航', description='讲步骤、排时间、看阶段、找章节。',
         hint='先后动作选步骤流程；明确时间选时间流程单；判断两条路径选分流决策；章节入口选导航卡。',
         types=['steps','runsheet','metro','decision','chapter_nav']),
    dict(id='scripts', name='话术与问答', description='复制话术、查问答、看对话与发圈示例。',
         hint='直接取用话术选复制库；按问题找答案选折叠问答；展示交流过程选对话演示。',
         types=['scriptlib','faq','chat','moments']),
    dict(id='media', name='图片与资料', description='展示图片、浏览图册、打开或下载资料。',
         hint='一张图用原图；多张图按并列、顺序或主图选择画廊；手册入口用封面卡；下载文件用附件区。',
         types=['img','imgs','resources','note','downloads','html']),
]
for category in CONTENT_CATEGORIES:
    for entry in CATALOG:
        if entry['type'] in category['types']:
            entry['category'] = category['id']
            entry['category_name'] = category['name']
for entry in GALLERY_VARIANTS:
    entry['category'] = 'media'
    entry['category_name'] = '图片与资料'
if len({kind for c in CONTENT_CATEGORIES for kind in c['types']}) != sum(len(c['types']) for c in CONTENT_CATEGORIES) or any('category' not in x for x in CATALOG):
    raise ValueError('内容样式分类必须完整且不能重复')
