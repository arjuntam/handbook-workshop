"""从实际手册抽取的受控组件；业务文案由内容提供，不执行来源 HTML。"""
from html import escape
from itertools import count

TYPES = {'solution', 'tracks', 'number_strip', 'watermark', 'decision', 'downloads', 'chapter_nav',
         'checklist', 'icon_folds', 'number_folds'}
_ids = count(1)
ICONS = {
    'person':'<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
    'badge':'<rect x="3" y="5" width="18" height="15" rx="2"/><path d="M8 5V2m8 3V2M8 11h3m-3 5h8"/>',
    'pen':'<path d="m4 16 12-12 4 4L8 20l-5 1zM14 6l4 4"/>',
    'image':'<rect x="2" y="3" width="20" height="18" rx="2"/><circle cx="8" cy="9" r="2"/><path d="m3 19 6-6 4 4 4-7 5 9"/>',
    'building':'<path d="M4 22V6l10-4v20M14 10h6v12M1 22h22M7 8h3m-3 4h3m-3 4h3"/>',
    'calendar':'<rect x="2" y="5" width="20" height="17" rx="2"/><path d="M7 2v6m10-6v6M2 11h20m-15 5h3m4 0h3"/>',
    'info':'<circle cx="12" cy="12" r="10"/><path d="M12 10v7m0-12v1"/>',
}


def attachment_index(attachments):
    result = {}
    for a in attachments or []:
        key = a.get('id') or a.get('path')
        if key:
            if key in result:
                raise ValueError('附件标识重复：' + str(key))
            result[key] = a
    return result


def validate(b, section_ids=None, attachments=None):
    t = b['t']
    if t == 'number_folds' and b.get('layout', 'default') not in ('default', 'stages', 'fields'):
        raise ValueError('number_folds.layout 只能为 default / stages / fields')
    if t == 'solution':
        if not b.get('quote') or not b.get('blocks'):
            raise ValueError('solution 需要 quote 与 blocks；只有引语时使用 quote.reveal')
    elif t == 'downloads':
        refs = b.get('attachment_ids', [])
        if not refs or len(refs) != len(set(refs)):
            raise ValueError('downloads 需要非空且不重复的 attachment_ids')
        if attachments is not None:
            index = attachment_index(attachments)
            for ref in refs:
                if ref not in index:
                    raise ValueError('就地附件引用不存在：' + str(ref))
    elif t == 'decision':
        if len(b.get('branches', [])) != 2:
            raise ValueError('decision 必须恰有两个分支')
        for branch in b['branches']:
            if not branch.get('title') or bool(branch.get('steps')) == bool(branch.get('cases')):
                raise ValueError('分支需要 title，且 steps / cases 只选一种')
        if len(b.get('conclusions', [])) > 2:
            raise ValueError('decision 最多两条结论')
    else:
        items = b.get('items', [])
        if not items:
            raise ValueError(t + ' 的 items 不能为空')
        if t == 'tracks' and len(items) != 2:
            raise ValueError('tracks 必须恰有两个互斥体系；纯对照使用 compare')
        if t == 'tracks' and not -1 <= int(b.get('default', -1)) < len(items):
            raise ValueError('tracks.default 超出选项范围')
        for item in items:
            if not item.get('title'):
                raise ValueError(t + ' 每项需要 title')
            if t == 'checklist':
                for flag in ('checked', 'disabled'):
                    if flag in item and not isinstance(item[flag], bool):
                        raise ValueError('checklist.' + flag + ' 必须为布尔值')
            if t in ('icon_folds','number_folds'):
                if not item.get('body') and not item.get('blocks') and not (t == 'number_folds' and item.get('rows')):
                    raise ValueError('折叠卡需要 body、blocks 或编号卡 rows，不能创建空展开入口')
                if 'open' in item and not isinstance(item['open'], bool):
                    raise ValueError('折叠卡 open 必须为布尔值')
                if t == 'icon_folds' and item.get('icon','info') not in ICONS:
                    raise ValueError('未知折叠卡图标：' + str(item.get('icon')))
                if t == 'number_folds':
                    if b.get('layout') == 'stages' and not item.get('summary'):
                        raise ValueError('阶段展开卡需要始终可见的 summary')
                    if b.get('layout') == 'fields' and not item.get('rows'):
                        raise ValueError('字段说明卡需要 rows')
                    if 'rows' in item:
                        if not isinstance(item['rows'], list) or not item['rows']:
                            raise ValueError('编号卡 rows 需要非空字段列表')
                        for row in item['rows']:
                            if not isinstance(row, dict) or not row.get('title') or not str(row.get('body', '')).strip():
                                raise ValueError('每个字段需要 title 与 body；未知内容请明确写未提供')
            if t == 'watermark' and not item.get('rows'):
                raise ValueError('watermark 每板块需要 rows')
            if t == 'chapter_nav' and not item.get('target'):
                raise ValueError('章节导航缺 target')
            target = item.get('target') if t == 'chapter_nav' else item.get('goto') if t == 'tracks' else None
            if target and section_ids is not None and target not in section_ids:
                raise ValueError('章节目标不存在：' + str(target))


def validate_tree(blocks, section_ids, attachments):
    import data_views
    for b in blocks:
        if b.get('t') == 'detail_table':
            data_views.validate(b)
            for item in b['items']:
                validate_tree(item.get('blocks', []), section_ids, attachments)
        if b.get('t') == 'table' and b.get('layout') == 'matrix':
            data_views.validate_matrix(b)
        if b.get('t') in TYPES:
            validate(b, section_ids, attachments)
        if b.get('t') == 'solution':
            validate_tree(b.get('blocks', []), section_ids, attachments)
        if b.get('t') in ('icon_folds','number_folds'):
            for item in b.get('items', []):
                validate_tree(item.get('blocks', []), section_ids, attachments)
        if b.get('t') == 'tabs':
            for item in b.get('items', []):
                if item.get('block'):
                    validate_tree([item['block']], section_ids, attachments)


def render(b, render_children, attachment_rows, attachments):
    validate(b, attachments=attachments)
    t = b['t']
    def e(v): return escape(str(v), quote=True)
    def text(v): return e(v).replace('\n', '<br>')
    def heading(v): return '<h3 class="hw-title">' + text(v) + '</h3>' if v else ''
    def goto(target, label):
        return '<button type="button" class="xref-chip" data-goto="' + e(target) + '">' + text(label) + '<span class="xc-arrow" aria-hidden="true">→</span></button>'
    if t == 'checklist':
        uid='hw-check-'+str(next(_ids));rows=[]
        for i,item in enumerate(b['items']):
            checked=' checked' if item.get('checked') else ''
            disabled=' disabled' if item.get('disabled') else ''
            body='<span class="hw-check-desc">'+text(item['body'])+'</span>' if item.get('body') else ''
            rows.append('<label class="hw-check-row"><input type="checkbox" name="'+uid+'" value="'+str(i)+'"'+checked+disabled+'><span><span class="hw-check-title">'+text(item['title'])+'</span>'+body+'</span></label>')
        return '<fieldset class="hw-checklist"><legend'+(' class="sr-only"' if not b.get('title') else '')+'>'+text(b.get('title','逐项核对清单'))+'</legend>'+''.join(rows)+'</fieldset>'
    if t in ('icon_folds','number_folds'):
        cards=[]
        layout=b.get('layout','default') if t=='number_folds' else 'default'
        for i,item in enumerate(b['items']):
            if t == 'icon_folds':
                mark='<span class="hw-fold-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">'+ICONS[item.get('icon','info')]+'</svg></span>'
            else:
                mark='<span class="hw-fold-num">'+text(item.get('num',str(i+1).zfill(2)))+'</span>'
            marker='<span class="hw-fold-toggle" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg></span>'
            content=('<p>'+text(item['body'])+'</p>' if item.get('body') else '')+render_children(item.get('blocks',[]))
            if t=='number_folds' and item.get('rows'):
                content='<dl class="hw-fold-fields">'+''.join('<div><dt>'+text(row['title'])+'</dt><dd>'+text(row['body'])+'</dd></div>' for row in item['rows'])+'</dl>'+content
            preview='<span class="hw-fold-preview">'+text(item['summary'])+'</span>' if t=='number_folds' and item.get('summary') else ''
            state=''
            if layout!='default':
                marker='<span class="hw-fold-toggle hw-fold-indicator" aria-hidden="true"><span class="hw-fold-state"><span class="hw-fold-closed">展开</span><span class="hw-fold-open">收起</span></span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg></span>'
            cards.append('<details class="hw-fold-card"'+(' open' if item.get('open') else '')+'><summary>'+mark+'<span class="hw-fold-title">'+text(item['title'])+'</span>'+marker+preview+state+'</summary><div class="hw-fold-body">'+content+'</div></details>')
        variant=' hw-fold-'+layout if layout!='default' else ''
        return '<div class="hw-fold-wrap"><div class="hw-fold-grid hw-'+('icon-folds' if t=='icon_folds' else 'number-folds')+variant+'" role="group" aria-label="'+e(b.get('title','折叠内容卡'))+'">'+''.join(cards)+'</div></div>'
    if t == 'solution':
        return ('<details class="quote-reveal hw-solution"><summary><span class="qr-title">' + text(b.get('title', '解决方案')) +
                '</span><span class="qr-btn" aria-hidden="true">展开查看</span></summary><blockquote class="quote">' + text(b['quote']) +
                '</blockquote><div class="hw-solution-body">' + render_children(b['blocks']) + '</div></details>')
    if t == 'tracks':
        uid = 'hw-track-' + str(next(_ids)); cards = []
        for i, item in enumerate(b['items']):
            rid = uid + '-' + str(i)
            checked = ' checked' if i == int(b.get('default', -1)) and not item.get('disabled') else ''
            disabled = ' disabled' if item.get('disabled') else ''
            points = ''.join('<span class="hw-track-point"><b>' + text(x['title']) + '</b><span>' + text(x.get('body', '')) + '</span></span>' for x in item.get('items', []))
            action = '<footer>' + goto(item['goto'], item.get('action_label', '查看' + item['title'])) + '</footer>' if item.get('goto') else ''
            # Selection label and navigation are siblings: no action button inside a label.
            cards.append('<article class="hw-track"><input class="hw-track-radio" type="radio" name="' + uid + '" id="' + rid + '" value="' + str(i) + '"' + checked + disabled + '><label class="hw-track-label" for="' + rid + '"><span class="hw-title">' + text(item['title']) + '</span><span class="hw-track-hint">' + text(item.get('hint', '选择此体系')) + '</span><span class="hw-track-points">' + points + '</span><span class="hw-track-foot">' + text(item.get('footer', '')) + '</span></label>' + action + '</article>')
        return '<fieldset class="hw-tracks"><legend>' + text(b.get('title', '选择一个体系')) + '</legend><div class="hw-tracks-grid">' + ''.join(cards) + '</div></fieldset>'
    if t == 'number_strip':
        cards = ''.join('<li class="hw-number-item' + (' is-highlight' if x.get('highlight') else '') + '"><span class="hw-number">' + e(x.get('num', str(i + 1).zfill(2))) + '</span><h4>' + text(x['title']) + '</h4><p>' + text(x.get('body', '')) + '</p></li>' for i, x in enumerate(b['items']))
        return '<div class="hw-number-strip">' + heading(b.get('title')) + '<ol>' + cards + '</ol></div>'
    if t == 'watermark':
        cards = []
        for i, x in enumerate(b['items']):
            n = e(x.get('num', str(i + 1).zfill(2)))
            rows = ''.join('<div><dt>' + text(r['title']) + '</dt><dd>' + text(r.get('body', '')) + '</dd></div>' for r in x['rows'])
            cards.append('<article class="hw-watermark"><span class="hw-watermark-mark" aria-hidden="true">' + n + '</span><header><span class="hw-badge">' + n + '</span><h4>' + text(x['title']) + '</h4>' + ('<p>' + text(x['sub']) + '</p>' if x.get('sub') else '') + '</header><dl>' + rows + '</dl></article>')
        return '<div class="hw-watermarks">' + ''.join(cards) + '</div>'
    if t == 'decision':
        branches = []
        for x in b['branches']:
            body = '<ol class="hw-branch-steps">' + ''.join('<li>' + text(v) + '</li>' for v in x['steps']) + '</ol>' if x.get('steps') else '<dl class="hw-branch-cases">' + ''.join('<div><dt>' + text(v['title']) + '</dt><dd>' + text(v.get('body', '')) + '</dd></div>' for v in x['cases']) + '</dl>'
            branches.append('<article class="hw-branch"><header><span class="hw-branch-tag">' + text(x.get('tag', '')) + '</span><h4>' + text(x['title']) + '</h4></header><p class="hw-desc">' + text(x.get('desc', '')) + '</p>' + body + '</article>')
        conclusions = ''.join('<article><h4>' + text(x['title']) + '</h4><p>' + text(x.get('body', '')) + '</p></article>' for x in b.get('conclusions', []))
        return '<div class="hw-decision">' + heading(b.get('title')) + '<div class="hw-branches">' + ''.join(branches) + '</div>' + ('<div class="hw-conclusions">' + conclusions + '</div>' if conclusions else '') + '</div>'
    if t == 'downloads':
        index = attachment_index(attachments)
        return '<div class="hw-downloads">' + heading(b.get('title', '本章配套附件')) + attachment_rows([index[ref] for ref in b['attachment_ids']]) + '</div>'
    if t == 'chapter_nav':
        return '<nav class="hw-chapter-nav" aria-label="' + e(b.get('title', '本章内容导航')) + '">' + heading(b.get('title', '本章内容导航')) + '<p class="hw-desc">' + text(b.get('desc', '')) + '</p><div>' + ''.join(goto(x['target'], x['title']) for x in b['items']) + '</div></nav>'
    raise ValueError('未知扩展组件：' + t)


CSS = r'''
.hw-checklist{border:0;padding:0;min-inline-size:0;margin:1rem 0;display:grid;gap:.75rem}
.hw-checklist>legend{font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);color:var(--brand);margin-block-end:1rem}
.hw-check-row{display:flex;align-items:center;gap:1rem;padding:1rem 1.25rem;min-block-size:4rem;border:1px solid var(--border);border-radius:var(--r-ctl);background:var(--surface);cursor:pointer;min-inline-size:0}
.hw-check-row>span{min-inline-size:0;overflow-wrap:anywhere}
.hw-check-row input{appearance:none;display:inline-grid;place-content:center;inline-size:1.5rem;block-size:1.5rem;flex:none;border:2px solid var(--border);border-radius:.375rem;background:var(--surface);color:var(--surface);margin:0;cursor:pointer}
.hw-check-row input:checked{background:var(--accent);border-color:var(--accent)}
.hw-check-row input:checked::before{content:'';inline-size:.8rem;block-size:.8rem;background:currentColor;mask:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cpath d='m5 12 4 4L20 5' fill='none' stroke='black' stroke-width='3.5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") no-repeat center/contain}
.hw-check-row:has(input:checked){background:var(--selected-bg);border-color:var(--selected-border)}
.hw-check-row:has(input:focus-visible){outline:3px solid var(--focus);outline-offset:3px}
.hw-check-row:has(input:disabled){opacity:.5;cursor:not-allowed}.hw-check-row input:disabled{cursor:not-allowed}
.hw-check-title{display:block;font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);line-height:1.5;color:var(--accent)}
.hw-check-desc{display:block;font-size:var(--fs-text);line-height:1.7;color:var(--muted);margin-block-start:.375rem}
.hw-check-row:has(input:checked) .hw-check-title{color:var(--muted)}
.hw-fold-wrap{container:hw-folds/inline-size;min-inline-size:0}
.hw-fold-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1rem;align-items:start;margin-block:1rem;min-inline-size:0}
@container hw-folds (inline-size < 42rem){.hw-fold-grid{grid-template-columns:1fr}}
.hw-fold-card{position:relative;border:1px solid var(--border);border-radius:var(--r-card);background:var(--surface);min-inline-size:0;color:var(--brand)}
.hw-fold-card::before{content:'';position:absolute;inset-inline-start:0;inset-block:1rem;inline-size:4px;border-radius:0 4px 4px 0;background:transparent}
.hw-fold-card[open]{background:var(--selected-bg);border-color:var(--selected-border)}
.hw-fold-card[open]::before{background:var(--selected-border)}
.hw-fold-card>summary{list-style:none;display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center;gap:.75rem;padding:1.125rem;min-block-size:4.5rem;cursor:pointer}
.hw-fold-card>summary::-webkit-details-marker{display:none}
.hw-fold-card>summary:focus-visible{outline:3px solid var(--focus);outline-offset:3px;border-radius:var(--r-card)}
.hw-fold-icon{color:var(--accent);display:inline-flex}.hw-fold-icon svg{inline-size:1.5rem;block-size:1.5rem}
.hw-fold-title{font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);line-height:1.5;overflow-wrap:anywhere;min-inline-size:0}
.hw-fold-num{display:inline-grid;place-items:center;inline-size:1.75rem;min-block-size:1.75rem;padding:.25rem;border-radius:.5rem;font-size:var(--fs-note);font-weight:var(--weight-title,500);background:var(--brand);color:var(--surface);justify-self:start}
.hw-fold-toggle{display:inline-grid;place-items:center;inline-size:1.5rem;block-size:1.5rem;border-radius:.375rem;background:var(--accent-soft);color:var(--accent)}
.hw-fold-toggle svg{inline-size:1rem;block-size:1rem}
.hw-fold-card[open] .hw-fold-toggle{background:var(--accent);color:var(--surface)}
.hw-fold-card[open] .hw-fold-toggle svg{transform:rotate(180deg)}
.hw-number-folds .hw-fold-card>summary{grid-template-areas:'num toggle' 'title title';grid-template-columns:minmax(0,1fr) auto;row-gap:.75rem}
.hw-number-folds .hw-fold-num{grid-area:num}.hw-number-folds .hw-fold-title{grid-area:title}.hw-number-folds .hw-fold-toggle{grid-area:toggle}
.hw-fold-body{margin:0 1.125rem 1.125rem;padding:1rem;border:1px solid var(--border);border-radius:var(--r-ctl);background:var(--surface);font-size:var(--fs-text);color:var(--text);line-height:1.75;min-inline-size:0;overflow-wrap:anywhere}
.hw-fold-body>p{margin:0}.hw-fold-body>p+*{margin-block-start:1rem}.hw-fold-body>:last-child{margin-block-end:0}
@media(forced-colors:active){.hw-check-row input{appearance:auto;forced-color-adjust:auto}.hw-check-row input::before{display:none}.hw-fold-card[open]{outline:2px solid Highlight}}
.hw-title{display:block;font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);line-height:1.4;color:var(--brand);margin:0 0 .75rem;overflow-wrap:anywhere}
.hw-desc{font-size:var(--fs-note);color:var(--muted);line-height:1.7;margin:.5rem 0 1rem;overflow-wrap:anywhere}
.hw-solution-body{padding:0 1rem 1.125rem}
.hw-tracks{min-inline-size:0;border:0;padding:0;margin:1rem 0;container:hw-tracks/inline-size}
.hw-tracks>legend{font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);color:var(--brand);margin-block-end:1rem}
.hw-tracks-grid,.hw-branches{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,20rem),1fr));gap:1rem}
.hw-track{position:relative;display:flex;flex-direction:column;min-inline-size:0;border:1px solid var(--border);border-radius:var(--r-card);background:var(--accent-soft);padding:1.125rem;container:hw-track/inline-size}
.hw-track::before{content:'';position:absolute;inset-inline-start:0;inset-block:1rem;inline-size:4px;border-radius:0 4px 4px 0;background:transparent}
.hw-track:has(>.hw-track-radio:checked){background:var(--selected-bg);border-color:var(--selected-border);box-shadow:var(--selected-shadow)}
.hw-track:has(>.hw-track-radio:checked)::before{background:var(--selected-border)}
.hw-track:has(>.hw-track-radio:focus-visible){outline:3px solid var(--focus);outline-offset:4px}
.hw-track:has(>.hw-track-radio:disabled){opacity:.55}
.hw-track-radio{position:absolute;inline-size:1px;block-size:1px;margin:-1px;padding:0;border:0;clip-path:inset(50%);white-space:nowrap}
.hw-track-label{display:flex;flex-direction:column;flex:1;gap:.75rem;cursor:pointer;min-inline-size:0}
.hw-track:has(>.hw-track-radio:disabled) .hw-track-label{cursor:not-allowed}
.hw-track-label>.hw-title{text-align:center;margin:0}.hw-track-hint{font-size:var(--fs-note);text-align:center;color:var(--muted)}
.hw-track-points{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,10rem),1fr));gap:.75rem;flex:1;align-content:start}
.hw-track-point,.hw-track-foot{display:block;background:var(--surface);border:1px solid var(--border);border-radius:var(--r-ctl);padding:.75rem;overflow-wrap:anywhere}
.hw-track-point b{display:block;font-size:var(--fs-text);font-weight:var(--weight-title,500);line-height:1.5}.hw-track-point>span{display:block;font-size:var(--fs-note);color:var(--muted);line-height:1.7;margin-block-start:.375rem}
.hw-track-foot{margin-block-start:auto;font-size:var(--fs-text);text-align:center;line-height:1.6;color:var(--text)}
.hw-track>footer{margin-block-start:1rem;display:flex;justify-content:center}.hw-track .xref-chip{white-space:normal;max-inline-size:100%}
@container hw-track (inline-size >= 22rem){.hw-track-point:last-child:nth-child(odd){grid-column:1/-1}}
.hw-number-strip>ol{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,8rem),1fr));gap:.75rem;list-style:none;margin:0 0 1.125rem;padding:0}
.hw-number-item{min-inline-size:0;border:1px solid var(--border);border-block-start:2px solid var(--accent);border-radius:var(--r-ctl);padding:1rem .75rem;background:var(--surface);overflow-wrap:anywhere}
.hw-number{display:block;font-size:var(--fs-note);font-weight:var(--weight-title,500);color:var(--accent);margin-block-end:.75rem}
.hw-number-item h4,.hw-watermark h4,.hw-branch h4,.hw-conclusions h4{font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);line-height:1.5;margin:0;color:var(--brand);overflow-wrap:anywhere}
.hw-number-item p{font-size:var(--fs-note);line-height:1.7;color:var(--muted);margin:.5rem 0 0}
.hw-number-item.is-highlight{background:var(--brand);border-color:var(--brand)}
.hw-number-item.is-highlight :is(.hw-number,h4,p){color:var(--surface)}
.hw-watermark{position:relative;min-inline-size:0;border:1px solid var(--border);border-radius:var(--r-card);padding:1.125rem;margin-block-end:1rem;background:var(--surface);container:hw-watermark/inline-size}
.hw-watermark-mark{position:absolute;inset-inline-end:1rem;inset-block-start:.25rem;font-size:5.2rem;line-height:1;font-weight:600;color:var(--accent);opacity:.05;pointer-events:none;user-select:none}
.hw-watermark>header{position:relative;display:flex;flex-wrap:wrap;align-items:center;gap:.75rem;margin-block-end:1rem}
.hw-badge{display:inline-grid;place-items:center;min-inline-size:1.75rem;min-block-size:1.75rem;padding:.25rem;border-radius:.5rem;background:var(--brand);color:var(--surface);font-size:var(--fs-note);font-weight:var(--weight-title,500)}
.hw-watermark header p{margin:0;padding-inline-start:.75rem;border-inline-start:1px solid var(--border);font-size:var(--fs-note);color:var(--muted);overflow-wrap:anywhere}
.hw-watermark dl,.hw-branch-cases{position:relative;margin:0;display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,20rem),1fr));gap:.75rem 1.25rem}
.hw-watermark dl>div,.hw-branch-cases>div{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,2fr);gap:.75rem;align-items:baseline;border-block-end:1px dashed var(--border);padding-block:.5rem;min-inline-size:0}
.hw-watermark dt,.hw-branch-cases dt{font-size:var(--fs-text);font-weight:var(--weight-title,500);color:var(--text);overflow-wrap:anywhere}
.hw-watermark dd,.hw-branch-cases dd{font-size:var(--fs-text);line-height:1.7;color:var(--muted);margin:0;overflow-wrap:anywhere}
@container hw-watermark (inline-size < 22rem){.hw-watermark dl>div{grid-template-columns:1fr;gap:.25rem}}
.hw-decision{margin-block:1rem}.hw-branch{border:1px solid var(--border);border-block-start:3px solid var(--accent);border-radius:var(--r-card);padding:1.125rem;min-inline-size:0;background:var(--surface)}
.hw-branch:nth-child(2){border-block-start-color:var(--brand)}.hw-branch>header{display:flex;flex-wrap:wrap;align-items:center;gap:.75rem}
.hw-branch-tag{display:inline-block;background:var(--accent-soft);border-radius:999px;padding:.25rem .625rem;font-size:var(--fs-note);color:var(--brand)}
.hw-branch:nth-child(2) .hw-branch-tag{background:var(--brand);color:var(--surface)}
.hw-branch-steps{counter-reset:hw-step;list-style:none;display:grid;gap:.625rem;padding:0;margin:0}
.hw-branch-steps li{display:flex;align-items:baseline;gap:.75rem;border-radius:var(--r-ctl);padding:.75rem;background:var(--accent-soft);font-size:var(--fs-text);line-height:1.7;overflow-wrap:anywhere}
.hw-branch-steps li::before{counter-increment:hw-step;content:counter(hw-step);flex:none;display:inline-grid;place-items:center;min-inline-size:1.5rem;min-block-size:1.5rem;border-radius:.375rem;background:var(--brand);color:var(--surface);font-size:var(--fs-note)}
.hw-branch-cases{grid-template-columns:1fr}.hw-conclusions{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,20rem),1fr));gap:1rem;margin-block-start:1rem}
.hw-conclusions>article{border:1px solid var(--border);border-radius:var(--r-card);padding:1rem;background:var(--accent-soft);min-inline-size:0}
.hw-conclusions p{font-size:var(--fs-text);line-height:1.7;margin:.5rem 0 0;overflow-wrap:anywhere}
.hw-downloads,.hw-chapter-nav{border:1px solid var(--border);border-radius:var(--r-card);padding:1rem;margin-block:1rem;background:var(--surface);min-inline-size:0}
.hw-downloads .dl-row{font-size:var(--fs-text);min-inline-size:0;margin-block:.375rem}.hw-downloads .dl-name{min-inline-size:0;overflow-wrap:anywhere}.hw-downloads .dl-go{margin-inline-start:auto;flex:none;font-size:var(--fs-note)}
.hw-downloads .dl-row:hover{background:var(--accent-soft)}.hw-chapter-nav>div{display:flex;flex-wrap:wrap;gap:.625rem}
.hw-chapter-nav .xref-chip{margin:0;white-space:normal;overflow-wrap:anywhere;max-inline-size:100%}
'''

# Optional structured variants; numbered cards share aligned row boundaries.
CSS += r"""
.hw-number-folds{align-items:stretch}
.hw-fold-stages{align-items:stretch;grid-template-columns:repeat(auto-fit,minmax(min(100%,max(18rem,calc(var(--fs-text)*16))),1fr))}
.hw-fold-fields{margin:0}
.hw-fold-grid.hw-fold-fields{align-items:stretch;grid-template-columns:repeat(auto-fit,minmax(min(100%,max(24rem,calc(var(--fs-text)*20))),1fr))}
.hw-fold-stages .hw-fold-card,.hw-fold-grid.hw-fold-fields .hw-fold-card{container:hw-fold-card/inline-size}
.hw-fold-stages .hw-fold-card>summary{grid-template-areas:'num toggle' 'title title' 'preview preview'}
.hw-fold-grid.hw-fold-fields .hw-fold-card>summary{grid-template-areas:'num title toggle';grid-template-columns:auto minmax(0,1fr) auto}
.hw-fold-grid.hw-fold-fields .hw-fold-card>summary:has(.hw-fold-preview){grid-template-areas:'num title toggle' 'preview preview preview'}
.hw-fold-preview{grid-area:preview;font-size:var(--fs-text);line-height:1.7;font-weight:var(--weight-body,400);color:var(--muted);overflow-wrap:anywhere}
.hw-fold-state{font-size:var(--fs-note);color:var(--accent);font-weight:var(--weight-title,500)}
.hw-fold-indicator{display:flex;inline-size:auto;gap:.375rem;background:transparent;color:var(--accent)}.hw-fold-card[open] .hw-fold-indicator{background:transparent;color:var(--accent)}.hw-fold-indicator .hw-fold-state{color:inherit}
.hw-fold-open,.hw-fold-card[open] .hw-fold-closed{display:none}.hw-fold-card[open] .hw-fold-open{display:inline}
.hw-fold-stages .hw-fold-body,.hw-fold-grid.hw-fold-fields .hw-fold-body{padding:1rem 0 0;border:0;border-block-start:1px solid var(--border);border-radius:0;background:transparent}
.hw-fold-fields>div{display:grid;grid-template-columns:minmax(0,8em) minmax(0,1fr);gap:.75rem;padding-block:.75rem;border-block-end:1px dashed var(--border);font-size:var(--fs-text);line-height:1.75}
.hw-fold-fields>div:first-child{padding-block-start:0}.hw-fold-fields>div:last-child{border-block-end:0}
.hw-fold-fields dt{font-weight:var(--weight-title,500);color:var(--brand);overflow-wrap:anywhere}.hw-fold-fields dd{margin:0;color:var(--muted);overflow-wrap:anywhere}
.hw-fold-fields+*{margin-block-start:1rem}
@container hw-fold-card (inline-size < 28rem){.hw-fold-fields>div{grid-template-columns:1fr;gap:.25rem}}
"""
