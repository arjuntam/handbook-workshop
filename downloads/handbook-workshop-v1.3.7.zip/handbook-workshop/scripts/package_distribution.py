#!/usr/bin/env python3
"""生成完整离线样式库、真实下载包与校验清单，不执行线上发布。"""
import argparse,hashlib,json,shutil,tempfile,zipfile
from pathlib import Path
from build_design_gallery import build
from prepare_resources import font_source, copy_font
SKILL=Path(__file__).resolve().parent.parent
WEB_UPLOAD_LIMIT=5_242_880

def zip_folder(folder,target):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in sorted(folder.rglob('*')):
            if f.is_file() and f.name!='.DS_Store' and '__pycache__' not in f.parts and '.git' not in f.parts:
                z.write(f,Path(folder.name)/f.relative_to(folder))
    with zipfile.ZipFile(target) as z:
        if z.testzip():raise ValueError('压缩包校验失败')

def package(out,public_base_url):
    out=Path(out).resolve()
    if out.exists() and any(out.iterdir()):raise FileExistsError('输出目录非空，请新建版本目录')
    out.mkdir(parents=True,exist_ok=True)
    profile=json.loads((SKILL/'assets/base-style.json').read_text())
    version=profile['design_version'];name='handbook-workshop-v'+version+'.zip'
    offline_name='handbook-workshop-v'+version+'-offline.zip'
    public_url=public_base_url.rstrip('/')+'/downloads/'+name
    offline_url=public_base_url.rstrip('/')+'/downloads/'+offline_name
    original_font=font_source()
    font_record=dict(bytes=original_font.stat().st_size,sha256=hashlib.sha256(original_font.read_bytes()).hexdigest(),urls=[public_base_url.rstrip('/')+'/assets/fonts/MiSans-VF.ttf'])
    with tempfile.TemporaryDirectory(prefix='handbook-distribution-') as td:
        temp=Path(td);gallery=temp/'网页手册样式库';build(gallery,skill_download_href='downloads/'+name,offline_download_href='downloads/'+offline_name)
        snapshot=temp/'handbook-workshop'
        shutil.copytree(SKILL,snapshot,ignore=shutil.ignore_patterns('design-gallery','__pycache__','.DS_Store','.git'))
        (snapshot/'resource-manifest.json').unlink(missing_ok=True)
        copy_font(snapshot/'assets/fonts/MiSans-VF.ttf',original_font)
        embedded=snapshot/'design-gallery';shutil.copytree(gallery,embedded)
        # One original font serves both the skill engine and its bundled gallery.
        # Standalone web output keeps its own font and remains independently usable.
        duplicate_font=embedded/'assets'/'fonts'/'MiSans-VF.ttf'
        duplicate_font.unlink()
        for html_file in embedded.rglob('*.html'):
            text=html_file.read_text(encoding='utf-8')
            text=text.replace('assets/fonts/MiSans-VF.ttf','../assets/fonts/MiSans-VF.ttf')
            text=text.replace('href="downloads/'+name+'"','href="'+public_url+'"')
            text=text.replace('href="downloads/'+offline_name+'"','href="'+offline_url+'"')
            html_file.write_text(text,encoding='utf-8')
        skill_zip=out/('handbook-workshop-技能包-v'+version+'.zip');zip_folder(snapshot,skill_zip)
        shared=temp/'shared'/'handbook-workshop'
        shutil.copytree(snapshot,shared,ignore=shutil.ignore_patterns('design-gallery','MiSans-VF.ttf'))
        (shared/'resource-manifest.json').write_text(json.dumps(dict(schema_version=1,font=font_record),ensure_ascii=False,indent=2),encoding='utf-8')
        shared_zip=out/('handbook-workshop-网页版共享包-v'+version+'.zip');zip_folder(shared,shared_zip)
        if shared_zip.stat().st_size>WEB_UPLOAD_LIMIT:
            raise ValueError('网页版共享包超出 5 MiB 上限，未生成发布站点')
        site=out/'网页手册样式库';shutil.copytree(gallery,site)
        (site/'downloads').mkdir();shutil.copy2(shared_zip,site/'downloads'/name);shutil.copy2(skill_zip,site/'downloads'/offline_name);(site/'.nojekyll').write_text('')
        record=dict(version=version,package=dict(path='downloads/'+name,flavor='shared',bytes=shared_zip.stat().st_size,sha256=hashlib.sha256(shared_zip.read_bytes()).hexdigest(),upload_limit_bytes=WEB_UPLOAD_LIMIT,initial_font_download=True),offline_package=dict(path='downloads/'+offline_name,flavor='offline',bytes=skill_zip.stat().st_size,sha256=hashlib.sha256(skill_zip.read_bytes()).hexdigest()))
        (site/'release.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
        (out/'交付包校验.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
        zip_folder(site,out/('网页手册样式库-v'+version+'.zip'))
    print(out)
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',required=True)
    ap.add_argument('--public-base-url',default='https://arjuntam.github.io/handbook-workshop/')
    a=ap.parse_args();package(a.out,a.public_base_url)
