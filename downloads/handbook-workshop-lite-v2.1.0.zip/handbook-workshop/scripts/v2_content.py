"""Native 2.0 content: feature composition, portrait reader, and video."""
from html import escape
from itertools import count
from navigation_media import media_source

TYPES={'feature','image_reader','video'}
_ids=count(1)


def validate(b):
    kind=b['t']
    if not b.get('title'):raise ValueError(kind+' 需要 title')
    if kind=='image_reader':
        if not isinstance(b.get('items'),list) or not b['items']:raise ValueError('image_reader 需要图片 items')
        for item in b['items']:
            if not isinstance(item,dict) or not item.get('src') or not item.get('caption'):raise ValueError('竖图需要 src 和 caption')
            media_source(item['src'])
    if kind=='video':
        media_source(b.get('src',''))
        if b.get('poster'):media_source(b['poster'])
        for track in b.get('captions',[]):
            if not track.get('lang') or not track.get('label'):raise ValueError('字幕需要 lang 与 label')
            media_source(track['src'])
        for key in ('width','height'):
            if not isinstance(b.get(key,1280 if key=='width' else 720),int) or not 1<=b.get(key,1280 if key=='width' else 720)<=8000:raise ValueError('视频尺寸必须是有效整数')
    if kind=='feature' and b.get('role','chapter') not in ('chapter','case','method','explain','data','region','media'):raise ValueError('feature.role 无效')
    if kind=='feature':
        if b.get('src'):media_source(b['src'])
        if b.get('image_mode','inline') not in ('inline','underlay'):raise ValueError('feature.image_mode 无效')
        if b.get('image_kind','information') not in ('information','photo'):raise ValueError('feature.image_kind 无效')
        if b.get('image_mode')=='underlay' and (not b.get('src') or b.get('image_kind')!='photo'):
            raise ValueError('渐变压底只允许有 src 的氛围照片，须指定 image_kind=photo')


def render(b, render_children, images):
    validate(b)
    e=lambda v:escape(str(v),quote=True)
    text=lambda v:e(v).replace('\n','<br>')
    def image(src):return media_source(images.get(src,src))
    kind=b['t'];uid='hw-v2-'+str(next(_ids))
    if kind=='feature':
        visual=(f'<figure><img src="{e(image(b["src"]))}" alt="{e(b.get("caption",b["title"]))}" loading="lazy" decoding="async"><figcaption>{text(b.get("caption",""))}</figcaption></figure>' if b.get('src') else '')
        metric=(f'<p class="hw-feature-metric"><strong>{text(b["metric"])}</strong><span>{text(b.get("unit",""))}</span></p>' if b.get('metric') is not None else '')
        underlay=' is-underlay' if b.get('image_mode')=='underlay' else ''
        return f'<article class="hw-feature hw-feature-{e(b.get("role","chapter"))}{" has-visual" if visual else ""}{underlay}" aria-labelledby="{uid}"><div class="hw-feature-copy"><p class="hw-feature-kicker">{text(b.get("label",""))}</p><h3 id="{uid}">{text(b["title"])}</h3>{metric}<p class="hw-feature-body">{text(b.get("body",""))}</p>' + (f'<p class="hw-demo-note">{text(b["notice"])}</p>' if b.get('notice') else '') + '</div>'+visual+'</article>'+render_children(b.get('blocks',[]))
    if kind=='image_reader':
        figures=''.join(f'<figure><img class="hw-long-image" tabindex="0" role="button" src="{e(image(x["src"]))}" alt="{e(x["caption"])}" aria-label="按宽度放大：{e(x["caption"])}" loading="lazy" decoding="async"><figcaption>图 {i+1} · {text(x["caption"])}</figcaption></figure>' for i,x in enumerate(b['items']))
        return f'<section class="hw-image-reader" aria-labelledby="{uid}"><div class="hw-reader-copy"><h3 id="{uid}">{text(b["title"])}</h3><p>{text(b.get("body",""))}</p>'+render_children(b.get('blocks',[]))+f'</div><div class="hw-reader-visual"><div class="hw-reader-controls"><span>按顺序阅读 · 可上下滚动</span><button type="button" class="hw-pan-toggle" aria-pressed="false">自动慢移</button><label>速度 <select class="hw-pan-speed"><option value="12">慢</option><option value="28">中</option><option value="50">快</option></select></label></div><div class="hw-portrait-scroll" tabindex="0" role="region" aria-label="{e(b["title"])}图片阅读区">{figures}</div><p class="hw-pan-status" role="status">点击图片可按宽度放大阅读</p></div></section>'
    src=b.get('src','')
    if b.get('external'):
        return f'<article class="hw-video"><h3>{text(b["title"])}</h3><p>{text(b.get("body",""))}</p><a href="{e(media_source(src))}" target="_blank" rel="noopener noreferrer">打开视频平台页面 ↗</a></article>'
    if not src:return f'<article class="hw-video"><h3>{text(b["title"])}</h3><p class="hw-media-status">视频待补，当前没有可播放文件。</p></article>'
    tracks=''.join(f'<track data-src="{e(media_source(t["src"]))}" kind="captions" srclang="{e(t["lang"])}" label="{e(t["label"])}"'+(' default' if t.get('default') else '')+'>' for t in b.get('captions',[]))
    w,h=b.get('width',1280),b.get('height',720)
    poster=f' data-poster="{e(image(b["poster"]))}"' if b.get('poster') else ''
    return f'<figure class="hw-video" aria-labelledby="{uid}"><figcaption><h3 id="{uid}">{text(b["title"])}</h3><p>{text(b.get("body",""))}</p></figcaption><video controls playsinline loading="lazy" preload="none" width="{w}" height="{h}" data-src="{e(media_source(src))}"{poster} aria-labelledby="{uid}">{tracks}</video><button type="button" class="hw-video-start">播放视频</button><p class="hw-media-status" role="status">点击播放后加载视频</p>'+(f'<details><summary>查看文字稿</summary><p class="body-text">{text(b["transcript"])}</p></details>' if b.get('transcript') else '')+'</figure>'


CSS=r'''
.hw-feature{display:block;background:var(--feature-bg,var(--accent-soft));border-radius:var(--feature-radius,1rem);padding:clamp(1.5rem,4cqi,3rem);margin:1.5rem 0 2rem;container-type:inline-size}.hw-feature.has-visual{display:grid;grid-template-columns:1.1fr 1fr;gap:2rem;align-items:center}.hw-feature-copy{min-inline-size:0}.hw-feature h3{font-size:var(--feature-size,2.05rem);font-weight:var(--weight-title,650);line-height:1.35;padding:0;border:0;margin:.625rem 0 1rem;color:var(--brand);text-wrap:balance}.hw-feature-kicker{font-size:var(--fs-note);font-weight:var(--weight-medium,550);letter-spacing:.08em;color:var(--feature-accent,var(--accent))}.hw-feature-body{font-size:var(--fs-lede);line-height:1.8;max-inline-size:44ch}.hw-feature figure{margin:0;min-inline-size:0}.hw-feature img{display:block;inline-size:100%;max-block-size:29rem;object-fit:contain;border-radius:.75rem}.hw-feature figcaption,.hw-demo-note{font-size:var(--fs-note);color:var(--muted);line-height:1.7;margin-top:.75rem}.hw-feature-metric strong{font-size:clamp(2.5rem,6cqi,4rem);line-height:1.2;color:var(--feature-accent,var(--accent));font-weight:var(--weight-metric,700)}.hw-feature-metric span{margin-inline-start:.75rem}.hw-feature-method{border-inline-start:5px solid var(--accent)}.hw-feature-case.has-visual{grid-template-columns:1fr 1.15fr}.hw-feature-region,.hw-feature-media{background:var(--bg)}
.hw-image-reader{display:grid;grid-template-columns:minmax(0,1.2fr) minmax(20rem,.8fr);align-items:start;gap:2rem;margin:1.5rem 0}.hw-reader-copy{min-inline-size:0;font-size:var(--fs-text);line-height:1.9}.hw-reader-visual{position:sticky;top:calc(var(--header-height) + 1rem);min-inline-size:0;border:1px solid var(--border);border-radius:1rem;padding:1rem;background:var(--surface)}.hw-reader-controls{display:flex;flex-wrap:wrap;align-items:center;gap:.5rem;font-size:var(--fs-note);margin-bottom:.625rem}.hw-reader-controls button,.hw-reader-controls select{font:inherit;min-block-size:2.75rem;padding:.4rem .6rem;border:1px solid var(--accent);border-radius:.5rem;color:var(--brand);background:var(--surface)}.hw-portrait-scroll{overflow:auto;max-block-size:clamp(14rem,60dvh,36rem);scrollbar-width:auto}.hw-portrait-scroll figure{margin:0 0 1.25rem}.hw-portrait-scroll img{inline-size:100%;block-size:auto;max-block-size:none;cursor:zoom-in}.hw-portrait-scroll figcaption{font-size:var(--fs-note);color:var(--muted);margin-top:.5rem}.hw-pan-status{font-size:var(--fs-note);color:var(--muted);margin:.625rem 0 0}
.hw-long-dialog{border:0;border-radius:1rem;padding:1rem;max-inline-size:95dvw;inline-size:min(64rem,95dvw);max-block-size:94dvh;background:var(--surface);color:var(--text)}.hw-long-dialog::backdrop{background:#101d2bbf}.hw-long-toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:.75rem;margin-bottom:.5rem}.hw-long-toolbar button{font:inherit;padding:.5rem .75rem;background:var(--surface);color:var(--brand);border:1px solid var(--border);border-radius:.5rem}.hw-long-viewport{max-block-size:76dvh;overflow:auto}.hw-long-viewport img{display:block;max-inline-size:none;max-block-size:none;block-size:auto;inline-size:100%}
.hw-video{margin:1.5rem 0;padding:1.25rem;border:1px solid var(--border);border-radius:1rem;background:var(--surface)}.hw-video video{display:block;max-inline-size:100%;inline-size:auto;max-block-size:65dvh;block-size:auto;margin:1rem auto;background:#111;object-fit:contain}.hw-video-start{font:inherit;padding:.65rem 1rem;min-block-size:2.75rem;color:#fff;background:var(--accent);border:1px solid var(--accent);border-radius:.625rem}.hw-media-status{font-size:var(--fs-note);color:var(--muted)}.hw-video summary{padding:.5rem;cursor:pointer;color:var(--accent)}
@container(max-width:42rem){.hw-feature.has-visual{grid-template-columns:1fr}.hw-feature h3{font-size:var(--fs-title)}}
@media(max-width:1100px){.hw-image-reader{grid-template-columns:1fr;gap:1rem}.hw-reader-visual{position:static}.hw-feature.has-visual{grid-template-columns:1fr}}
@media(max-height:600px){.hw-reader-visual{position:static}.hw-portrait-scroll{max-block-size:18rem}}
@media print{.hw-reader-visual{position:static}.hw-portrait-scroll{overflow:visible;max-block-size:none}.hw-image-reader{display:block}.hw-reader-controls,.hw-video-start{display:none}.hw-feature{break-inside:avoid}}
'''

JS=r'''
(()=>{
 const reduce=matchMedia('(prefers-reduced-motion:reduce)');
 const visible=el=>el.getClientRects().length&&el.getBoundingClientRect().bottom>0&&el.getBoundingClientRect().top<innerHeight;
 document.querySelectorAll('.hw-video video').forEach(v=>{
  const box=v.closest('.hw-video'),button=box.querySelector('.hw-video-start'),status=box.querySelector('.hw-media-status');
  new IntersectionObserver(entries=>{entries.forEach(x=>{if(x.isIntersecting&&v.dataset.poster){v.poster=v.dataset.poster;delete v.dataset.poster;}})}).observe(v);
  button.addEventListener('click',async()=>{try{if(!v.getAttribute('src')){v.src=v.dataset.src;v.querySelectorAll('track[data-src]').forEach(t=>t.src=t.dataset.src);v.load();}status.textContent='正在加载…';await v.play();button.hidden=true;}catch(e){status.textContent='未能播放，请检查文件、网络或使用浏览器支持的视频格式。';button.hidden=false;button.textContent='重试播放';}});
  v.addEventListener('playing',()=>status.textContent='正在播放');v.addEventListener('pause',()=>{if(!v.ended)status.textContent='已暂停';});v.addEventListener('ended',()=>status.textContent='播放结束');v.addEventListener('error',()=>{status.textContent='视频加载失败，请检查媒体地址与格式。';button.hidden=false;button.textContent='重试播放';});
 });
 document.addEventListener('play',e=>{if(e.target.matches('audio,video'))document.querySelectorAll('audio,video').forEach(m=>{if(m!==e.target)m.pause();});},true);
 const pauseHidden=()=>document.querySelectorAll('audio,video').forEach(m=>{if(document.hidden||!m.getClientRects().length)m.pause();});
 document.addEventListener('visibilitychange',pauseHidden);addEventListener('hb:sectionchange',pauseHidden);
 document.querySelectorAll('.hw-image-reader').forEach(reader=>{
  const box=reader.querySelector('.hw-portrait-scroll'),button=reader.querySelector('.hw-pan-toggle'),speed=reader.querySelector('.hw-pan-speed'),status=reader.querySelector('.hw-pan-status');
  let running=false,frame=0,last=0,position=0;
  function stop(message='已暂停，继续阅读后可主动恢复'){running=false;cancelAnimationFrame(frame);button.textContent='自动慢移';button.setAttribute('aria-pressed','false');status.textContent=message;}
  function tick(now){if(!running)return;if(document.hidden||!visible(box)){stop();return;}if(last){position+=(now-last)/1000*Number(speed.value);box.scrollTop=position;}last=now;if(box.scrollTop+box.clientHeight>=box.scrollHeight-1){stop('已到图片末尾');return;}frame=requestAnimationFrame(tick);}
  button.addEventListener('click',()=>{if(running){stop();return;}if(reduce.matches){stop('系统已减少动态效果，请手动滚动阅读。');return;}if(box.scrollHeight<=box.clientHeight){stop('图片已经完整显示，无需滚动。');return;}running=true;last=0;position=box.scrollTop;button.textContent='暂停慢移';button.setAttribute('aria-pressed','true');status.textContent='演示模式：正在缓慢向下浏览';frame=requestAnimationFrame(tick);});
  ['wheel','pointerdown','keydown','focusin'].forEach(type=>box.addEventListener(type,()=>stop(),{passive:true}));
  box.addEventListener('mouseenter',()=>{if(running)stop();});addEventListener('hb:sectionchange',()=>stop());document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});reduce.addEventListener('change',()=>stop());
 });
 const dialog=document.createElement('dialog');dialog.className='hw-long-dialog';dialog.setAttribute('aria-label','按宽度阅读长图');dialog.innerHTML='<div class="hw-long-toolbar"><button type="button" class="hw-long-close">关闭</button><label>放大 <input aria-label="长图放大比例" type="range" min="100" max="300" step="10" value="100"></label><span>可上下滚动；放大后可左右滚动</span></div><div class="hw-long-viewport"><img alt=""></div>';
 document.body.append(dialog);const im=dialog.querySelector('img'),range=dialog.querySelector('input');let opener;
 function open(image){opener=image;im.src=image.src;im.alt=image.alt;range.value='100';im.style.inlineSize='100%';dialog.showModal();dialog.querySelector('.hw-long-viewport').scrollTo(0,0);}
 document.querySelectorAll('.hw-long-image').forEach(image=>{image.addEventListener('click',()=>open(image));image.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();open(image);}});});
 dialog.querySelector('.hw-long-close').addEventListener('click',()=>dialog.close());dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dialog.close();}});range.addEventListener('input',()=>im.style.inlineSize=range.value+'%');dialog.addEventListener('close',()=>opener?.focus({preventScroll:true}));addEventListener('hb:sectionchange',()=>{if(dialog.open)dialog.close();});
})();
'''
