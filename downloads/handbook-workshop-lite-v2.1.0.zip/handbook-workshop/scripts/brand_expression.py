"""Two expression layers over the shared, content-preserving handbook runtime."""

CSS = r'''
/* The directory retains the same layout and left-aligned text in both expressions. */
.hw-directory .nav-link{position:relative;text-align:start;inline-size:100%;box-sizing:border-box}
.hw-directory .nav-link.target-current{background:var(--nav-active-bg);color:var(--nav-text);box-shadow:none;border-radius:.5rem}
.hw-directory .nav-link.target-current::before{content:'';position:absolute;inset-inline-start:0;inset-block-start:50%;inline-size:3px;block-size:1.125rem;transform:translateY(-50%);border-radius:2px;background:var(--nav-active-text)}
.hw-directory .nav-group-links .nav-link.target-current::before{inset-block-end:auto;inset-block-start:50%;block-size:1.125rem;background:var(--nav-active-text)}
.hw-directory .nav-group-links{margin-inline-start:0}
.hw-directory .nav-group-links .nav-link{padding-inline:.625rem}
@media(hover:hover){.hw-directory .nav-link:not(.target-current):hover{background:color-mix(in oklab,var(--nav-bg),var(--nav-text) 5%);color:var(--nav-text)}}

/* Reading widths are bounded even on very large monitors. The shell stays unchanged. */
.layout>main>.section{max-inline-size:94rem;margin-inline:auto}
.hw-expression-motion{display:none;align-items:center;justify-content:center;gap:.4rem;min-block-size:2.75rem;padding:.5rem .8rem;border:1px solid var(--border);border-radius:.65rem;color:var(--muted);background:var(--surface);font:inherit;font-size:.8125rem;cursor:pointer}
.hw-expression-motion:focus-visible{outline:3px solid var(--focus);outline-offset:3px}
.hw-expression-motion[disabled]{display:none;cursor:default}
[data-expression=brand] .hw-expression-motion{display:inline-flex;margin-block-start:.75rem}
[data-expression=brand]{--hw-display-gap:clamp(1.25rem,3cqi,2.5rem)}
[data-expression=brand] .layout>main{background:var(--surface)}
[data-expression=brand] .section{--brand-paper:color-mix(in oklab,var(--surface),var(--accent) 2%);--brand-tint:color-mix(in oklab,var(--surface),var(--accent) 6%);--brand-halo:color-mix(in oklab,var(--surface),var(--accent) 18%);--brand-shadow:color-mix(in oklab,var(--surface),var(--accent) 12%);border:0;box-shadow:none;background:var(--surface);padding:clamp(1.25rem,3.5cqi,3.5rem);border-radius:0}
[data-expression=brand] .section>:not(.section-head){max-inline-size:75rem;margin-inline:auto}
[data-expression=brand] .section-head{position:relative;border:0;padding-block:clamp(1rem,2cqi,2rem);margin-block-end:clamp(1.75rem,3cqi,3rem)}
[data-expression=brand] .section h2{font-size:clamp(1.8rem,3.6cqi,3rem);letter-spacing:-.025em;line-height:1.3;text-wrap:balance}
[data-expression=brand] .section :is(h3,.card-title,.hw-title){letter-spacing:-.015em}
[data-expression=brand] .section :is(.body-text,.lede){line-height:1.9}
[data-expression=brand] .body-text,[data-expression=brand] .section>.body-text{max-inline-size:66ch;margin-inline:0 auto}
[data-expression=brand] .section .lede{padding:clamp(1.25rem,3cqi,2rem);border-inline-start:0;border-radius:1rem;background:linear-gradient(110deg,var(--brand-tint),var(--surface));font-weight:var(--weight-medium,550)}
[data-expression=brand] :is(.grid,.hw-fold-grid,.hw-tracks-grid){gap:var(--hw-display-gap);align-items:stretch}
[data-expression=brand] :is(.card,.step,.cmp-card,.hw-fold-wrap,.hw-track,.hw-number-item,.resource-card){border:0;background:var(--surface);box-shadow:0 .625rem 2rem color-mix(in oklab,var(--brand-shadow),transparent 55%);border-radius:1rem}
[data-expression=brand] :is(.card,.step,.cmp-card,.hw-fold-card,.hw-track){padding:clamp(1.25rem,2.4cqi,2rem)}
[data-expression=brand] .card-num{font-size:clamp(1.5rem,3cqi,2.5rem);background:transparent;color:var(--brand2);inline-size:auto;block-size:auto;border-radius:0}
[data-expression=brand] .card-title{font-size:clamp(1.25rem,2cqi,1.65rem)}
[data-expression=brand] :is(.stat-val,.hw-number){font-size:clamp(2.5rem,5cqi,4.5rem);letter-spacing:-.04em}
[data-expression=brand] .section :is(.callout-blue,.callout:not(.callout-red)){background:var(--brand-tint);border:0;border-inline-start:3px solid var(--accent);border-radius:0 .75rem .75rem 0}
[data-expression=brand] .section .subhead{border:0;padding-inline:0}
[data-expression=brand] .attach-note{background:var(--brand-paper);border:0;color:var(--muted)}
[data-expression=brand] .section :is(.quote,.quote-reveal,.hw-solution){border:0;background:var(--brand-paper);border-radius:1rem}
[data-expression=brand] :is(.faq,.sl-group){border-inline:0;border-radius:0;box-shadow:none;background:var(--surface)}
[data-expression=brand] :is(.faq-q,.sl-h){padding-block:1.15rem}
[data-expression=brand] :is(.tab-panel,.metro-panel,.hw-detail-panel){border:0;background:var(--surface);box-shadow:none;padding-block:1.5rem}
[data-expression=brand] :is(.metro-board,.tabs,.hw-detail-table,.hw-matrix,.hw-section-jump,.hw-chapter-nav){border-color:transparent;background:var(--brand-paper);border-radius:1rem}
[data-expression=brand] :is(.hw-section-jump,.hw-chapter-nav){padding:1rem}
[data-expression=brand] :is(.hw-section-jump button,.tab-head,.metro-stop){transition:background-color 180ms ease,color 180ms ease}
[data-expression=brand] .pick-card{border:1px solid var(--border)}
[data-expression=brand] .pick-card:is(.on,:has(.pick-control:checked)){border-color:var(--accent);background:var(--selected-bg);box-shadow:0 0 0 2px var(--accent)}
[data-expression=brand] .hw-fold-wrap:has(.hw-fold-open){background:var(--brand-paper)}
[data-expression=brand] :is(.data-table-scroll,.rt-scroll){border:0;border-radius:.875rem;background:var(--surface)}
[data-expression=brand] :is(.data-table,.rt) thead{background:var(--brand-tint);color:var(--brand)}
[data-expression=brand] :is(.data-table,.rt) th{background:var(--brand-tint);color:var(--brand);font-weight:var(--weight-title,650)}
[data-expression=brand] .hw-summary-table thead th{text-align:center;vertical-align:middle}
[data-expression=brand] .hw-summary-table thead th:first-child{text-align:start}
[data-expression=brand] .hw-summary-table tr:has(.hw-data-choice[aria-pressed=true])>*{background:var(--brand-tint)}
[data-expression=brand] :is(.hw-chart,.hw-image-reader,.hw-video){border:0;border-radius:1rem;background:var(--brand-paper);padding:clamp(1rem,2.5cqi,2rem)}
[data-expression=brand] .hw-chart :is(svg,.data-table){background:var(--surface)}
[data-expression=brand] .hw-reader-visual{border:0;box-shadow:0 .75rem 2.5rem color-mix(in oklab,var(--brand-shadow),transparent 55%);background:var(--surface)}
[data-expression=brand] .hw-video video{border-radius:.75rem}
[data-expression=brand] :is(.gallery,.gallery-item){border:0;box-shadow:none}
[data-expression=brand] .gallery :is(img,video){border-radius:.875rem}
[data-expression=brand] :is(.catalog-row,.category-card){border:0;background:var(--brand-paper)}
[data-expression=brand] :is(.type-adjust,.v2-authoring,.design-export){border:0;background:var(--brand-paper)}

/* All seven feature roles share the same main-color family and readable foreground. */
[data-expression=brand] .hw-feature{position:relative;isolation:isolate;overflow:clip;border:0;border-radius:1.25rem;padding:clamp(1.5rem,4cqi,3.5rem);background:linear-gradient(125deg,var(--brand-tint),var(--brand-paper) 65%,var(--surface));margin-block:1.5rem 3rem}
[data-expression=brand] .hw-feature.has-visual{grid-template-columns:1fr 1fr;gap:clamp(1.5rem,4cqi,3rem)}
[data-expression=brand] .hw-feature-copy{position:relative;z-index:2}
[data-expression=brand] .hw-feature h3{font-size:var(--feature-size);line-height:1.25;max-inline-size:22ch;letter-spacing:-.035em;text-align:start;text-wrap:balance;margin-block:.75rem 1.5rem}
[data-expression=brand] .hw-feature-body{font-size:clamp(1rem,1.6cqi,1.25rem);line-height:1.9}
[data-expression=brand] .hw-feature-kicker{color:var(--brand2)}
[data-expression=brand] .hw-feature-metric strong{font-size:clamp(3rem,7cqi,5rem);color:var(--brand2)}
[data-expression=brand] .hw-feature::after{content:'';position:absolute;inset:-10%;z-index:-1;pointer-events:none;background:radial-gradient(ellipse at 80% 15%,var(--brand-halo),transparent 55%);animation:hw-brand-light 9s ease-in-out infinite alternate;animation-play-state:paused}
[data-expression=brand]:not(.hw-motion-paused):not(.hw-motion-hidden) .hw-feature.hw-in-view::after{animation-play-state:running}
@keyframes hw-brand-light{from{opacity:.3;transform:translate3d(-2%,0,0)}to{opacity:.75;transform:translate3d(2%,1%,0)}}
/* Atmosphere photos opt in. Screenshots, charts and diagrams never get masked. */
[data-expression=brand] .hw-feature.is-underlay{display:block;min-block-size:clamp(28rem,50cqi,40rem);border-radius:0;padding:clamp(2rem,5cqi,4rem) clamp(1.5rem,4cqi,3rem) clamp(6rem,12cqi,10rem);background:linear-gradient(180deg,var(--brand-paper) 65%,var(--surface) 96%)}
[data-expression=brand] .hw-feature.is-underlay::after{display:none}
[data-expression=brand] .hw-feature.is-underlay .hw-feature-copy{max-inline-size:32rem}
[data-expression=brand] .hw-feature.is-underlay h3{font-size:clamp(2.5rem,7cqi,5.5rem);max-inline-size:10ch;line-height:1.15}
[data-expression=brand] .hw-feature.is-underlay figure{position:absolute;inset:0;z-index:0;margin:0;pointer-events:none}
[data-expression=brand] .hw-feature.is-underlay img{position:absolute;inset:0 0 0 auto;inline-size:82%;block-size:100%;max-block-size:none;object-fit:cover;object-position:center;border-radius:0;opacity:.9}
[data-expression=brand] .hw-feature.is-underlay figure::after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,var(--brand-paper) 0% 22%,color-mix(in oklab,var(--brand-paper),transparent 3%) 36%,color-mix(in oklab,var(--brand-paper),transparent 28%) 52%,transparent 80%),linear-gradient(180deg,color-mix(in oklab,var(--brand-paper),transparent 24%),transparent 30% 55%,var(--surface) 98%)}
[data-expression=brand] .hw-feature.is-underlay figure::before{content:'';position:absolute;inset:auto 0 0;block-size:clamp(7rem,14cqi,12rem);z-index:1;background:linear-gradient(180deg,transparent,var(--surface) 92%)}
[data-expression=brand] .hw-feature.is-underlay figcaption{position:absolute;inset:auto 1.5rem .25rem;z-index:3;text-align:end;color:var(--muted);max-inline-size:45ch;margin-inline-start:auto}
[data-expression=brand] .hw-feature.is-underlay .hw-feature-body{background:none;padding:0}
[data-expression=brand] .hw-story-actions{display:grid;grid-template-columns:1.1fr 1fr;gap:1.25rem;margin-block:2rem}
[data-expression=brand] .hw-story-actions .card:first-child{grid-row:span 2;background:var(--accent);color:var(--brand-on-accent);padding:clamp(1.5rem,3cqi,2.5rem)}
[data-expression=brand] .hw-story-actions .card:first-child .card-num{display:block;font-size:clamp(4rem,10cqi,7rem);line-height:1;margin-block-end:1.5rem}
[data-expression=brand] .hw-story-actions .card:first-child .card-title{font-size:clamp(1.5rem,3cqi,2rem);margin-block-start:1rem}
[data-expression=brand] .hw-story-actions .card:first-child :is(.card-title,.card-body,.card-num){color:var(--brand-on-accent);background:transparent}
[data-expression=professional] .hw-story-actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:1rem;margin-block:1.5rem}
@media(hover:hover) and (pointer:fine){[data-expression=brand] .hw-lit-card{background-image:radial-gradient(20rem circle at var(--hw-light-x,50%) var(--hw-light-y,50%),color-mix(in oklab,var(--accent),transparent 93%),transparent 65%)}}
@container(max-width:45rem){[data-expression=brand] .hw-feature.has-visual{grid-template-columns:1fr}[data-expression=brand] .hw-feature.is-underlay{min-block-size:30rem;padding-block-end:10rem}[data-expression=brand] .hw-feature.is-underlay img{inline-size:100%;opacity:.35}[data-expression=brand] .hw-feature.is-underlay figure::after{background:linear-gradient(90deg,var(--brand-paper),transparent 170%),linear-gradient(180deg,transparent 30%,var(--surface) 98%)}.hw-story-actions{grid-template-columns:1fr!important}[data-expression=brand] .hw-story-actions .card:first-child{grid-row:auto}}
@media(prefers-reduced-motion:reduce){[data-expression=brand] .hw-feature::after{animation:none;opacity:.25}[data-expression=brand] .hw-lit-card{background-image:none}}
@media(forced-colors:active){.hw-directory .nav-link.target-current{outline:1px solid Highlight}.hw-directory .nav-link.target-current::before{background:Highlight}[data-expression=brand] .hw-feature.is-underlay figure{position:static}[data-expression=brand] .hw-feature.is-underlay img{position:static;inline-size:100%;opacity:1;max-block-size:28rem;object-fit:contain}[data-expression=brand] .hw-feature.is-underlay figcaption{position:static;text-align:start}[data-expression=brand] .hw-feature.is-underlay figure::before,[data-expression=brand] .hw-feature.is-underlay figure::after,[data-expression=brand] .hw-feature::after{display:none}[data-expression=brand] :is(.card,.hw-feature,.hw-track,.hw-number-item,.resource-card){border:1px solid CanvasText}}
@media print{.hw-expression-motion{display:none!important}[data-expression=brand] .hw-feature.is-underlay{display:block;min-block-size:0;padding:1rem;background:none}[data-expression=brand] .hw-feature.is-underlay figure{position:static;break-inside:avoid}[data-expression=brand] .hw-feature.is-underlay img{position:static;inline-size:100%;block-size:auto;max-block-size:20rem;object-fit:contain;opacity:1}[data-expression=brand] .hw-feature.is-underlay figcaption{position:static;text-align:start}[data-expression=brand] .hw-feature::after,[data-expression=brand] .hw-feature.is-underlay figure::before,[data-expression=brand] .hw-feature.is-underlay figure::after{display:none}[data-expression=brand] .section{max-inline-size:none}}
'''

JS = r'''
(()=>{
 const root=document.documentElement,reduce=matchMedia('(prefers-reduced-motion:reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
 // Migrate old expression IDs without changing business content or requiring a theme editor.
 if(['warm','showcase'].includes(root.dataset.expression))root.dataset.expression='brand';
 let paused=false;try{paused=localStorage.getItem('handbook-display-motion-paused')==='true';}catch(e){}
 const animated=new WeakSet(),active=new Set(),running=new Set();
 const targets=[...document.querySelectorAll('.hw-feature,.section .grid>.card,.hw-story-actions>.card,.hw-image-reader,.hw-chart')];
 function allowed(){return root.dataset.expression==='brand'&&!paused&&!reduce.matches&&!document.hidden;}
 function reveal(el){if(!allowed()||animated.has(el)||!el.getClientRects().length)return;animated.add(el);const a=el.animate([{opacity:.65,transform:'translateY(12px)'},{opacity:1,transform:'none'}],{duration:550,easing:'cubic-bezier(.22,1,.36,1)'});running.add(a);a.finished.catch(()=>{}).finally(()=>running.delete(a));}
 function sync(){root.classList.toggle('hw-motion-paused',paused||reduce.matches);root.classList.toggle('hw-motion-hidden',document.hidden);document.querySelectorAll('.hw-expression-motion').forEach(b=>{b.textContent=reduce.matches?'已遵循减少动态设置':paused?'恢复动效':'暂停动效';b.disabled=reduce.matches;b.setAttribute('aria-pressed',String(paused||reduce.matches));});if(!allowed())running.forEach(a=>a.cancel());else active.forEach(reveal);if(!allowed())document.querySelectorAll('.hw-lit-card').forEach(c=>c.classList.remove('hw-lit-card'));}
 document.querySelectorAll('.section').forEach(section=>{if(!section.querySelector('.hw-feature,.card,.hw-chart,.hw-image-reader'))return;const head=section.querySelector('.section-head');if(!head)return;const b=document.createElement('button');b.type='button';b.className='hw-expression-motion';b.addEventListener('click',()=>{paused=!paused;try{localStorage.setItem('handbook-display-motion-paused',String(paused));}catch(e){}sync();});head.append(b);});
 if('IntersectionObserver' in window){const io=new IntersectionObserver(rows=>{for(const row of rows){row.target.classList.toggle('hw-in-view',row.isIntersecting);if(row.isIntersecting){active.add(row.target);reveal(row.target);}else active.delete(row.target);}},{threshold:.08});targets.forEach(el=>io.observe(el));}
 document.querySelectorAll('.section :is(.card,.hw-track,.resource-card)').forEach(card=>{let frame=0;card.addEventListener('pointermove',e=>{if(!allowed()||!fine.matches||e.pointerType==='touch')return;cancelAnimationFrame(frame);const x=e.clientX,y=e.clientY;frame=requestAnimationFrame(()=>{const r=card.getBoundingClientRect();card.style.setProperty('--hw-light-x',(x-r.left)+'px');card.style.setProperty('--hw-light-y',(y-r.top)+'px');card.classList.add('hw-lit-card');});});card.addEventListener('pointerleave',()=>{cancelAnimationFrame(frame);card.classList.remove('hw-lit-card');});});
 new MutationObserver(sync).observe(root,{attributes:true,attributeFilter:['data-expression']});reduce.addEventListener('change',sync);document.addEventListener('visibilitychange',sync);addEventListener('hb:sectionchange',()=>{running.forEach(a=>a.cancel());sync();});sync();
})();
'''
