"""Original, explicitly synthetic examples shared by the library and editable export."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
NOTICE='原创演示：项目、对话和数字均为模拟，用于说明版式，不代表真实经营成果。'


def examples():
    d=json.loads((ROOT/'assets/v2-examples/chart-data.json').read_text())
    months=[r['month'][5:]+'月' for r in d['monthly']]
    base=dict(t='chart',unit='次',source='原创模拟数据，非实际访问统计',period=d['period'],note=d['definition'])
    total=dict(name='入口点击次数',values=[r['total'] for r in d['monthly']])
    series=[dict(name=d['series_labels'][k],values=[r[k] for r in d['monthly']]) for k in ('courses','cases','templates')]
    charts={
        'column':dict(**base,kind='column',title='各月入口点击次数',categories=months,series=[total],summary='模拟数据中，6月为展示期间最高值。'),
        'bar':dict(**base,kind='bar',title='三类入口累计点击次数',categories=['案例入口','课程入口','模板入口'],series=[dict(name='半年累计',values=[570,530,400])]),
        'line':dict(**base,kind='line',title='点击次数随月份的变化',categories=months,series=series,summary='各条线分别表示一种入口，查看趋势时仍保留每月实际数值。'),
        'stacked':dict(**base,kind='stacked',title='每月点击次数的组成',categories=months,series=series),
        'donut':dict(**base,kind='donut',title='三类入口占半年点击总量的比例',categories=['课程入口','案例入口','模板入口'],series=[dict(name='半年累计',values=[530,570,400])],summary='分母为1500次点击，三类入口互斥并构成全部。')}
    signed=dict(t='chart',kind='column',title='数量净变化：正负与零',unit='份',source='原创模拟数据',categories=['示例甲','示例乙','示例丙'],series=[dict(name='净变化',values=[-3,5,0])],note='负数表示数量减少，不自动判定好坏。')
    negative=dict(**{**signed,'title':'全负数也保留零基线','series':[dict(name='净变化',values=[-2,-7,-1])]})
    crossing=dict(t='chart',kind='line',title='跨零折线与缺失月份',unit='份',source='原创模拟数据',categories=['1月','2月','3月','4月','5月'],series=[dict(name='净变化',values=[-4,0,6,None,-2])],summary='2月为已知零值，4月未提供，折线在缺失处断开。')
    diverging=dict(t='chart',kind='stacked',title='正负贡献分别堆叠',unit='份',source='原创模拟数据',categories=['示例期甲','示例期乙','示例期丙'],series=[dict(name='新增',values=[8,3,5]),dict(name='撤回',values=[-5,-7,-5]),dict(name='修订净变化',values=[-1,0,0])],summary='正向合计、负向合计与净值分别表达；丙期净值为零，但仍有新增与撤回。')
    stages=[('明确用途','先确定阅读对象与使用场景。','任务说明'),('登记来源','原稿、图片、附件分别登记；未知项明确标注。','来源清单'),('安排结构','区分结论、依据和行动，按信息关系选型。','章节草图'),('制作页面','设置项目主题，加入正文、图注与附件。','可浏览初稿'),('检查阅读','核对数据、入口、小窗口与长内容操作。','修订记录'),('完成交接','保留版本、配置、素材和使用说明。','交付目录')]
    checkpoints=[
        ['明确受众：本示例面向首次接手项目的资料制作人，读者不需要提前熟悉原稿的文件命名。','说明使用场景：制作人需要在准备、核对和交接时找到对应资料，页面因此同时保留快速入口与完整解释。','列出核心问题：已经拿到什么、还有什么缺口、哪些信息需要确认，分别放在能找到的位置。','确定资料边界：这套演示不提供实际客户成果，也不把登记数量解释为经营提升。','记录待确认项：任何无法从材料核实的名称、用途和统计口径独立列出，不用视觉效果掩盖。','完成任务说明：用一段话写清对象、用途和必须回答的问题，作为后续选型的依据。','进入下一阶段：任务说明能让另一位制作人复述阅读目标，再开始整理来源。'],
        ['分别登记：原稿按份、图片按张、附件按份记录，不把不同单位相加为完成度。','记录版本：同一材料存在修订版时，写清当前使用版本，其他版本归档，避免重复计数。','保留出处：标题、重要数字和图片说明能回到对应文件；后续修改能知道应该核对哪里。','区分未知和零：示例项目乙图片未提供，附件已确认不需要，因此分别记录 null 和 0。','确认图片用途：每张图说明它支持什么判断；长截图保留全部必要条件，不能只截有利片段。','确认附件归属：把模板或清单放在使用它的章节附近，缺文件时保留待补状态。','进入下一阶段：已知材料与缺口都有明确记录后，安排阅读结构。'],
        ['先写结论：每节先说明读者能获得什么，再放依据和操作，避免先堆一屏素材。','识别关系：有明确先后才用阶段流程，需要同时核对时用对照或表格。','分清总览和详情：L25 汇总帮助比较对象，详情补充背景、行动与来源，二者共享同一标识。','定义图文关系：说明旁边放能支持该说明的截图；没有对应关系时使用普通画廊。','安排主视觉：章节命题、案例证据或关键数字承担主要关注点，辅助信息减少视觉竞争。','设置回查入口：长内容保留必要导航，普通短段落保持自然阅读，不重复堆放入口。','进入下一阶段：章节与资料去向核对后，再填入统一主题的页面。'],
        ['确定项目主题：选择阅读表达、配色与字体，成品读者沿用制作人的方案。','填充完整内容：正文、图注和数据口径一并进入页面，保留条件与例外，不能只留下宣传标题。','放入实际素材：演示图片、视频和数字都带模拟标识；替换真实材料时补充来源。','接入图表：数值由结构化数据生成，正负、零与缺失分别处理，明细表与图形同步。','接入媒体：视频默认点击播放，有字幕或文字稿时一起提供，不能创建没有文件的播放承诺。','核对入口：章节跳转、资料打开、下载与外链使用各自明确的控件。','进入下一阶段：初稿中所有可点击元素都有可解释的结果，再开始完整检查。'],
        ['核对原稿：检查数字、单位、条件和来源去向，记录任何实质改写。','检查小窗口：目录能收起，正文、图表和竖图保持可读，根页面不被宽表格撑开。','检查大字号：标题可以正常换行，控件与表格不裁切，重要操作不会被固定栏遮住。','检查长内容：Metro 与对象切换只占必要的一行空间，离开模块后释放。','检查媒体：自动换图可暂停，进入阅读时停下，视频与录音不会同时出声。','检查缺项：未知、零值、加载失败和待补均有正确说明，不能显示成假完成。','进入下一阶段：修正记录能够说明改了什么、还需要什么设备验收，再交付。'],
        ['整理目录：页面、图片、字幕、视频、附件和配置按相对路径完整保留。','保存配置：保留制作人选择的项目方案与实际资料日期，不用导出时间覆盖资料日期。','说明使用方法：写清阅读入口、替换内容的方法和哪些功能只在本机页面内生效。','保留来源与边界：模拟材料继续标注模拟，真实资料保留可核对出处。','验证离线副本：本地资源能打开；网络资源仍需要网络，不能因为文件存在就宣称完整离线。','提供更新方式：公共功能用统一工具另存升级，新增媒体或图表时补充配置，原件可回退。','完成交接：另一位制作人能够找到文件、识别缺口，并继续维护这套资料。']]
    metro=dict(t='metro',items=[dict(num=str(i+1),title=title,sub=summary,body='\n'.join([f'目标：{summary}',f'交付物：{output}',*checkpoints[i]])) for i,(title,summary,output) in enumerate(stages)])
    reader=dict(t='image_reader',title='从沟通记录里找到交接信息',body='左侧解释要点，右侧保留完整的演示对话。读图时核对已提供资料、缺项与下一步动作。',blocks=[dict(t='h3',v='已提供什么'),dict(t='text',v='示例项目甲已登记8份原稿、12张图片和3份附件；这些数量分别计数，不合并成完成度。'),dict(t='h3',v='还缺什么'),dict(t='text',v='示例项目乙的图片未提供，附件已确认不需要，因此分别显示“未提供”和“0”。'),dict(t='h3',v='下一步怎么做'),dict(t='text',v='补齐文件时同步核对来源、用途和所属章节。完整对话保留在右侧，点击可按宽度放大。')],items=[dict(src='v2-examples/conversation.svg',caption='原创演示对话：资料数量、缺项与交接动作')])
    video=dict(t='video',title='一份清楚的资料交接',body='原创演示短片，字幕与文字稿使用同一份内容。',src='v2-examples/overview.mp4',poster='v2-examples/video-poster.svg',width=960,height=540,captions=[dict(src='v2-examples/overview.vtt',lang='zh-CN',label='中文',default=True)],transcript='本视频为原创演示，数字为模拟。第一步，分开登记原稿、图片和附件。第二步，区分已确认的零与尚未提供。第三步，选中项目查看对应资料。第四步，保留来源和配置，完成可继续更新的交接。')
    detail=dict(t='detail_table',title='三个示例项目的资料准备情况（模拟数据）',columns=[dict(key='manuscript',label='原稿',unit='份',max=10),dict(key='images',label='图片',unit='张',max=20),dict(key='attachments',label='附件',unit='份',max=10)],items=[])
    for i,(name,values) in enumerate([('示例项目甲',[8,12,3]),('示例项目乙',[5,None,0]),('示例项目丙',[2,6,None])]):
        detail['items'].append(dict(id='sample-'+str(i),title=name,values=dict(zip(('manuscript','images','attachments'),values)),blocks=[dict(t='feature',role='case',label='原创演示 · 模拟资料',title=name+'：让每份资料都有去处',src='v2-examples/workspace.svg',caption='原创资料协作示意图',body='已登记、未提供与已确认无需提供分别呈现，帮助接手者判断后续动作。',notice=NOTICE),*[dict(t='text',v=line) for line in [
                '阅读对象：本项目面向需要接手资料制作与维护的同事。页面先提供清单，再解释来源、缺项和后续动作，方便在不同工作阶段回查。',
                '当前登记：原稿 '+str(values[0])+' 份；图片 '+('未提供' if values[1] is None else str(values[1])+' 张')+'；附件 '+('未提供' if values[2] is None else str(values[2])+' 份')+'。这些数值为模拟清单记录，不是经营结果，也不能直接相加为完成度。',
                '素材来源：示例图片由本库原创制作，沟通记录为编写的演示对话。实际项目应替换为有来源且可使用的素材，并重新核对图注。',
                '准备动作：逐份确定文件用途与当前版本；同一文件的历史版本单独归档，避免在清单中重复计数。把待确认项独立记录，方便后续更新。',
                '缺项处理：未提供表示目前没有对应登记信息；0表示已经确认数量为零。两者需要不同的后续动作，不能为了让页面完整而互相替代。',
                '阅读安排：汇总表提供横向比较，当前对象的说明在下方展开。向下阅读时保留精简切换入口，既能继续读完整内容，也能切换另一个项目。',
                '图片使用：现场或过程图片需要能支持旁边的说明。聊天长图保留关键条件，采用按宽度阅读的方式，避免把整张截图压缩成看不清的缩略图。',
                '附件交接：有文件时提供实际入口，并说明用途与所属章节；没有文件时保留待补说明。网络资料需要注明访问条件，本地文件应随交付目录保留。',
                '核对与确认：重要数值、文件数量和名称应能对应来源清单。检查主题颜色、长标题、小窗口、大字号和键盘操作后，记录剩余的设备验收项。',
                '后续维护：替换自己的名称、内容和素材后重新核对口径。公共功能升级可另存为新副本；新增图表或媒体时补充数据与文件，保留原版和资料日期。'
            ]]]))
    return dict(charts=charts,signed=signed,negative=negative,crossing=crossing,diverging=diverging,metro=metro,reader=reader,video=video,detail=detail)


def sections(sec, code):
    ex=examples();notice=dict(t='html',v='<p class="hw-demo-note">'+NOTICE+'</p>')
    result=[]
    names={'column':'L28-A 柱状图','bar':'L28-B 横向条形图','line':'L28-C 折线图','stacked':'L28-D 堆叠图','donut':'L28-E 环形与饼图'}
    for kind,chart in ex['charts'].items():
        blocks=[notice,chart,code(chart)]
        if kind in ('column','bar'):
            signed={**ex['signed'],'kind':kind};blocks.extend([dict(t='h3',v='负数与全负值'),signed,{**ex['negative'],'kind':kind}])
        if kind=='line':blocks += [ex['crossing'],dict(t='callout',label='缺失处理',v='零是有效数据；缺失使用 null 并在折线中断开。')]
        if kind=='stacked':blocks += [ex['diverging'],dict(t='h3',v='百分比堆叠'),{**chart,'title':'各月入口结构（百分比）','percent':True},dict(t='warn',v='百分比组成遇到负数时拒绝绘制，不静默取绝对值。')]
        if kind=='donut':blocks += [{**chart,'kind':'pie','title':'同一组数据的饼图'},dict(t='chart',kind='donut',title='全零边界',unit='份',source='原创模拟数据',categories=['甲','乙'],series=[dict(name='登记数',values=[0,0])]),dict(t='warn',v='环形和饼图要求非负、完整的总体。负增长率应使用柱、条或折线。')]
        result.append(sec('chart-'+kind,names[kind],'数据与对照',blocks))
    result += [sec('blk-image_reader','L17-D 图文对读','图片与资料',[notice,ex['reader'],code(ex['reader'])]),sec('blk-video','L27 视频播放卡','图片与资料',[notice,ex['video'],dict(t='video',title='竖屏视频：相同比例保留完整画面',src='v2-examples/portrait.mp4',width=540,height=960,transcript=ex['video']['transcript']),dict(t='video',title='素材待补状态'),code(ex['video'])])]
    roles=[('chapter','章节开篇','把分散资料变成一处可查的入口','先交代这章要解决的问题，再提供清楚的阅读顺序。','workspace.svg'),('case','案例成果','让每份资料，都有清楚的去处','案例的事实、证据和下一步行动依次展开，不用相同大小的卡片掩盖重点。','workspace.svg'),('method','核心方法','每一步，都留下可检查的交付物','阶段关系帮助建立全局认识，长内容阅读时保留精简导航。',None),('explain','图文讲解','对照原始沟通，读懂交接条件','解释与长图保持对应，关键条件完整保留。',None),('data','数据判断','先读出变化，再核对实际数值','有明确口径的数据才进入图表，结论与明细相互支持。',None),('region','区域布局','同一套说明，服务不同地区的接手者','点位用于演示资料的区域组织，不代表实际服务覆盖。',None),('media','媒体展示','用一段短片，讲清一个动作','播放控件、字幕和文字稿让读者按自己的节奏理解。','video-poster.svg')]
    features=[]
    for role,label,title,body,img in roles:
        f=dict(t='feature',role=role,label=label,title=title,body=body,notice=NOTICE)
        if img:f.update(src='v2-examples/'+img,caption='原创演示示意图')
        if role=='case':f.update(metric='15',unit='份已登记原稿（模拟）')
        features.extend([dict(t='h3',id=role,v=label),f])
        if role=='chapter':features.append(dict(t='chapter_nav',items=[dict(title='资料准备与案例',target='v2-case'),dict(title='六阶段方法',target='v2-method'),dict(title='图表与数据',target='chart-column')]))
        if role=='method':features.append(ex['metro'])
        if role=='explain':features.append(ex['reader'])
        if role=='data':features.append(ex['charts']['column'])
        if role=='region':features.append(dict(t='china_map',title='原创模拟点位',cities=[dict(name='广州示例',province='广东',region='华南示例',lng=113.2644,lat=23.1291,detail='示意坐标，不代表实际业务覆盖'),dict(name='上海示例',province='上海',region='华东示例',lng=121.4737,lat=31.2304,detail='示意坐标，不代表实际业务覆盖')]))
        if role=='media':features.append(ex['video'])
    result.append(sec('blk-feature','T09 主视觉编排','文字与重点',[dict(t='section_jump',items=[dict(title=x[1],target=x[0]) for x in roles]),*features,code(dict(t='feature',role='case',title='你的案例命题',body='有来源的解释与事实。',src='v2-examples/workspace.svg',caption='替换成你的图片',metric='15',unit='份（模拟）',notice=NOTICE))]))
    result += [sec('v2-case','完整案例 · 从资料准备到交接','完整场景示例',[notice,dict(t='feature',role='case',label='资料交接案例',title='资料有归属，交接有依据',body='这份模拟案例连接汇总、详情与缺项处理。数量属于登记事实，不当成经营成果。',src='v2-examples/workspace.svg',caption='原创资料协作示意图'),ex['detail']]),sec('v2-method','完整方法 · 六阶段与长内容','完整场景示例',[notice,dict(t='feature',role='method',label='完整方法',title='从明确用途，到完成交接',body='向下阅读时观察精简的阶段导航；选择阶段只切换本模块详情。'),ex['metro']])]
    result.extend(expression_sections(sec))
    return result


def expression_sections(sec):
    """Same editable content in both expressions; no invented business outcomes."""
    ex=examples()
    hero=dict(t='feature',role='chapter',label='城市合伙人 · 联合启动会',title='从共识\n到行动',body='让参与者知道为什么合作、各自做什么，以及会后如何共同推进。',src='v2-examples/conference.jpg',image_kind='photo',image_mode='underlay',caption='既有资料实景图，仅作版式配图。',notice='原创演示文案，不代表真实项目成效。')
    actions=dict(t='grid',cols=3,layout='story',items=[dict(num='01',title='讲清价值',body='围绕参与者关心的问题，讲清合作能解决什么，以及哪些事项仍需确认。\n现场行动：收集问题，逐项回应并确认理解。\n留下什么：一份共同认可的价值说明。'),dict(num='02',title='明确分工',body='把“大家一起做”拆成各自能执行的任务，明确责任人与协作关系。\n留下什么：一张分工清单。'),dict(num='03',title='安排跟进',body='约定下一次沟通时间、检查内容和需要补齐的资料。\n留下什么：一张会后跟进表。')])
    reading=[dict(t='feature',role='method',label='启动会 · 会后执行',title='把约定变成\n可跟进的清单',body='先确认事项，再安排进度。'),dict(t='h3',v='先确认事项，再安排进度')]
    for title,body in [('保留判断依据','会议结束前，把已确认事项和待确认事项分开记录。对已确认的行动，写明责任人、需要协作的人和下一次检查时间；对暂时无法判断的问题，保留原题，并标注由谁补充信息。'),('沿用同一份清单','会后更新沿用同一份清单。每次沟通只补充新增信息、进展与阻碍，避免反复制作不同版本。已确认的零与尚未提供的信息分别记录，不用推测填满空位。'),('核对实际资料','把相关图片、原稿和附件按用途登记，保留来源与资料日期。示例数量只用于说明表格结构，正式使用时替换成可核对的数据。')]:
        reading.extend([dict(t='h3',v=title),dict(t='text',v=body)])
    reading.extend([dict(t='callout',label='记录原则',v='“待确认”要保留，不能直接写成“已完成”。演示表中的责任人与时间需要按项目补充。'),ex['detail'],ex['signed']])
    return [sec('brand-opening','完整场景 · 会议开篇与照片压底','完整场景示例',[hero,dict(t='h3',v='把价值讲清，把下一步定下来。'),dict(t='grid',cols=3,items=[dict(title='讲清价值',body='建立共同理解'),dict(title='明确分工',body='约定各自行动'),dict(title='安排跟进',body='形成可查的清单')])]),sec('brand-actions','完整场景 · 三项现场行动','完整场景示例',[dict(t='feature',role='method',label='启动会 · 现场组织',title='让下一步\n具体起来',body='把会议内容整理成三项现场动作。每项写清怎么做，并留下可以继续使用的交付物。'),actions,dict(t='callout',label='完成标准',v='参与者能说清：为什么合作、自己做什么、接下来何时碰头。'),dict(t='note',v='原创演示文案，不代表真实项目成效。')]),sec('brand-reading','完整场景 · 长文、汇总与正负图表','完整场景示例',reading)]
