"""统一更新同引擎手册；检查全部目标后另存副本，不覆盖旧项目，不重新提取正文。"""
import argparse
import json
from pathlib import Path
import re
import shutil
import tempfile
from html import escape
import managed_runtime as m
from prepare_resources import copy_resources

HERE=Path(__file__).resolve().parent
REGISTRY=HERE.parent/'assets/runtime-compat.json'


def registry():
    return json.loads(REGISTRY.read_text())


def root_attrs(html):
    tag=re.search(r'<html\b[^>]*>',html,re.I)
    return dict(re.findall(r'([\w-]+)="([^"]*)"',tag[0])) if tag else {}


def infer_style(html,css):
    from design_tokens import PALETTES,tokens
    import font_catalog
    attrs=root_attrs(html);old=dict(re.findall(r'(--[\w-]+)\s*:\s*([^;{}]+)',css))
    palette=next((k for k,p in PALETTES.items() if p['accent'].lower()==old.get('--accent','').lower()),'air-blue')
    cfg=dict(palette=palette,shell_mode=attrs.get('data-shell','light'),font_family=attrs.get('data-font','misans'),type_scale=attrs.get('data-type-scale','standard'),type_scale_factor=float(attrs.get('data-type-scale-factor','1')),style_preset='apple')
    base={**tokens(cfg),**font_catalog.tokens(cfg['font_family'])}
    cfg['theme']={k:v for k,v in old.items() if base.get(k)!=v}
    return m.validate_style(cfg)


def legacy(html,reg):
    tags=m.Tags(html).tags
    scripts=[t for t in tags if t['tag']=='script' and m.sha(t['body']) in reg['js']]
    styles=[t for t in tags if t['tag']=='style' and m.sha(t['body']) in reg['css']]
    if len(scripts)!=1 or len(styles)!=1:
        raise ValueError('旧页公共代码不是已登记版本，需单独核对，未修改')
    script,style=scripts[0],styles[0]
    if any(t['attrs'].get('id')=='handbook-custom-style' for t in tags):raise ValueError('旧页已有同名项目覆盖引用，需先单独核对')
    # Reject additional, unrecognized copies of common handlers.
    for t in tags:
        if t['tag']=='script' and t is not script and any(s in t['body'] for s in ('window.__showSection=show','// 全文搜索：按章节聚合')):
            if m.sha(t['body']) not in reg['extra_js']:raise ValueError('存在未识别的重复功能脚本')
    themes=[t for t in tags if t['tag']=='style' and t['a']>=style['b'] and t['body'].startswith(':root{')]
    if not themes:raise ValueError('未找到可保留的项目主题')
    theme=themes[0];theme_body=theme['body']
    changes=[]
    for t,id in ((script,m.COMMON_SCRIPT),(style,m.COMMON_STYLE)):
        changes.append((t['a'],t['b'],'<'+t['tag']+' id="'+id+'">'+t['body']+'</'+t['tag']+'>'))
    for t in tags:
        id=t['attrs'].get('id','')
        if id=='handbook-design-v11':
            start=t['body'].rfind(':root{');prefix=t['body'][:start]
            if start<0 or m.sha(prefix) not in reg.get('extra_design_prefixes',{}):raise ValueError('旧追加样式有定制修改，需单独核对')
            theme_body+=t['body'][start:]
            changes.append((t['a'],t['b'],''))
        elif id in ('handbook-full-text-search-style','handbook-full-text-search'):
            allowed=reg['extra_css'] if t['tag']=='style' else reg['extra_js']
            if m.sha(t['body']) not in allowed:raise ValueError('额外搜索代码被修改，需单独核对')
            changes.append((t['a'],t['b'],''))
        # apply_design's older extra cover handlers would otherwise initialize twice.
        elif t is not script and t['tag']=='script' and m.sha(t['body']) in reg['extra_js']:
            changes.append((t['a'],t['b'],''))
    variables=dict(re.findall(r'(--[\w-]+)\s*:\s*([^;{}]+)',theme_body))
    theme_body=':root{'+''.join(k+':'+v+';' for k,v in variables.items())+'}'+re.sub(r':root\{[^}]*\}','',theme_body)
    changes.append((theme['a'],theme['b'],'<style id="'+m.THEME_STYLE+'">'+theme_body+'</style>'))
    config=infer_style(html,theme_body)
    html=m.edit(html,changes)
    if 'class="search-results"' not in html:
        from upgrade_search import SearchBox
        import full_text_search
        parser=SearchBox(html);parser.feed(html)
        if len(parser.matches)!=1:raise ValueError('旧页搜索框结构无法确定')
        a,b=parser.matches[0];html=m.edit(html,[(a,b,full_text_search.markup())])
    return html,config,theme_body,reg['js'][m.sha(script['body'])]


def refs_record(html,record,manifest):
    tags=m.Tags(html).tags
    expected={m.COMMON_STYLE:('link','assets/handbook-runtime.css'),m.COMMON_SCRIPT:('script','assets/handbook-runtime.js'),m.THEME_STYLE:('link',record['theme_file']),'handbook-custom-style':('link','assets/handbook-custom.css')}
    from urllib.parse import urlsplit
    for id,(kind,rel) in expected.items():
        matches=[t for t in tags if t['attrs'].get('id')==id]
        if len(matches)!=1:raise ValueError('运行引用缺失或重复：'+id)
        t=matches[0];value=t['attrs'].get('href' if kind=='link' else 'src','')
        digest=record['theme_file_sha256'] if id==m.THEME_STYLE else record['custom_sha256'] if id=='handbook-custom-style' else manifest['files'][rel]
        if t['tag']!=kind or urlsplit(value).path!=m.asset_ref(rel,digest) or urlsplit(value).scheme or urlsplit(value).netloc:
            raise ValueError('运行引用指向已改变：'+id)
    for t in tags:
        if t['tag']=='script' and any(x in t['body'] for x in ('window.__showSection=show','// 全文搜索：按章节聚合')):
            raise ValueError('托管页面残留内联公共功能')


def apply_style_attrs(html,config):
    attrs={'data-expression':config.get('expression','professional'),'data-shell':config.get('shell_mode','light'),'data-font':config.get('font_family','misans'),'data-type-scale':config.get('type_scale','standard'),'data-type-scale-factor':str(config.get('type_scale_factor',1))}
    def patch(match):
        text=match[0]
        for key,value in attrs.items():
            text=re.sub(r'\s'+key+r'="[^"]*"','',text)
            text=text[:-1]+' '+key+'="'+escape(value,quote=True)+'">'
        return text
    html=re.sub(r'<html\b[^>]*>',patch,html,count=1)
    shell=config.get('shell_mode','light');logo='logo-white.png' if shell=='dark' else 'logo.png'
    html=re.sub(r'(<header\b[^>]*class="topbar"[^>]*data-surface=")[^"]*',r'\g<1>'+shell,html,count=1)
    html=re.sub(r'(<img\b[^>]*class="brand-logo"[^>]*src=")assets/logo(?:-white)?\.png',r'\g<1>assets/'+logo,html)
    return html


def source_check(folder,reg):
    build=folder/'build.py'
    if not build.is_file() or not (folder/'runtime').is_dir():return None
    source=folder/'handbook-source.json'
    if source.is_file():
        info=json.loads(source.read_text())
        if info.get('schema')!=1 or info.get('api')!=m.API:raise ValueError('源工程接口不兼容')
        if m.version_tuple(info['version'])>m.version_tuple(m.VERSION):raise ValueError('源工程版本高于当前工具，请使用新版工具')
        expected=info['files'];build_sha=info['build_sha256']
    else:
        if m.sha(build.read_bytes()) not in reg['builds']:raise ValueError('源工程 build.py 有定制修改；需单独迁移或显式 --html-only')
        candidates=[]
        for snapshot in reg['source_runtimes']:
            okay=True
            for p in (folder/'runtime').glob('*.py'):
                if p.name in snapshot['files'] and m.sha(p.read_bytes())!=snapshot['files'][p.name]:okay=False;break
            if okay:candidates.append(snapshot)
        if not candidates:raise ValueError('源工程运行代码有定制修改；需单独迁移或显式 --html-only')
        expected={p.name:candidates[-1]['files'][p.name] for p in (folder/'runtime').glob('*.py') if p.name in candidates[-1]['files']}
        build_sha=m.sha(build.read_bytes())
    if m.sha(build.read_bytes())!=build_sha:raise ValueError('源工程构建脚本已修改')
    for name,digest in expected.items():
        if name not in m.RUNTIME_FILES:continue
        p=m.safe_path(folder/'runtime',name)
        if not p.is_file() or m.sha(p.read_bytes())!=digest:raise ValueError('源工程运行文件已修改：'+name)
    return True


def write_source_record(folder):
    info=dict(schema=1,api=m.API,version=m.VERSION,build_sha256=m.sha((folder/'build.py').read_bytes()),files={name:m.sha((folder/'runtime'/name).read_bytes()) for name in m.RUNTIME_FILES})
    (folder/'handbook-source.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n')


def update(src,out=None,style=None,custom_css=None,html_only=False,inspect=False):
    src=Path(src).resolve();root=src.parent if src.is_file() else src
    if not root.is_dir():raise ValueError('项目不存在')
    if not inspect:
        out=Path(out).resolve()
        if out.exists():raise FileExistsError('目标已存在，请使用新的副本目录')
        if out==root or root in out.parents or out in root.parents:raise ValueError('新版副本须放在源项目之外')
    # Never copy links that would silently escape the supplied project.
    if any(p.is_symlink() for p in root.rglob('*') if not any(x in p.relative_to(root).parts for x in ('.git','node_modules','.venv','__pycache__'))):raise ValueError('项目包含符号链接，需先核对实际资源范围')
    reg=registry();style=m.validate_style(json.loads(Path(style).read_text())) if style else None
    custom=Path(custom_css).read_text() if custom_css else None
    pages=[src] if src.is_file() else sorted(root.rglob('*.html'))
    pages=[p for p in pages if not any(x in p.relative_to(root).parts for x in ('.git','runtime','node_modules','.venv'))]
    plans=[];ignored=[];manifests={};sources={}
    for p in pages:
        html=p.read_bytes().decode('utf-8');folder=p.parent;rel=p.relative_to(root).as_posix()
        if 'id="handbook-common-script"' not in html and 'window.__showSection=show' not in html:
            ignored.append(rel);continue
        if not re.search(r'<main\b',html) or not re.search(r'<section\b[^>]*class="section(?: [^"]*)?"',html):raise ValueError('页面不满足已支持的章节结构')
        for required in ('cover','cover-start','home-btn','pager-prev','pager-next'):
            if 'id="'+required+'"' not in html:raise ValueError('页面缺少公共控件：'+required)
        if folder not in manifests:
            manifests[folder]=m.read_manifest(folder)
            if manifests[folder]:
                m.verify(folder,manifests[folder])
                if m.version_tuple(manifests[folder]['runtime_version'])>m.version_tuple(m.VERSION):raise ValueError('页面运行版本高于当前工具，请使用新版工具')
            elif any((folder/x).exists() for x in ('assets/handbook-runtime.css','assets/handbook-runtime.js')):raise ValueError('发现无清单的同名运行文件，未覆盖')
        manifest=manifests[folder]
        if manifest:
            if p.name not in manifest['pages']:raise ValueError('页面未登记在运行清单中：'+rel)
            record=manifest['pages'][p.name];refs_record(html,record,manifest)
            config=json.loads((folder/record['style_file']).read_text());theme=(folder/record['theme_file']).read_text();version=manifest['runtime_version']
        else:
            html,config,theme,version=legacy(html,reg)
        if not html_only and folder not in sources:sources[folder]=source_check(folder,reg)
        # All managed siblings share one runtime, even when --src names one HTML.
        if manifest and not set(manifest['pages']).issubset({x.name for x in pages if x.parent==folder}):
            raise ValueError('该目录有多页共用运行文件，请将 --src 指向项目目录')
        font_prefix=(manifest or {}).get('font_prefix','../assets/fonts/' if 'url("../assets/fonts/' in html else 'assets/fonts/')
        if not (folder/font_prefix).resolve().is_relative_to(root):raise ValueError('共享字体在项目之外，请提供包含共享资源的完整根目录')
        plans.append(dict(font_prefix=font_prefix,path=p,relative=rel,html=html,config=config,theme=theme,before_version=version,before_content=m.content_fingerprint(p.read_text()),source_sha256=m.sha(p.read_bytes())))
    if not plans:raise ValueError('没有找到可更新的同引擎手册')
    report=dict(version=m.VERSION,api=m.API,original_untouched=True,mode='html-only' if html_only else 'project',pages=[],ignored_pages=ignored,source_projects=[],style_requested=bool(style),custom_css_requested=custom is not None)
    if inspect:
        return dict(**report,compatible=True,targets=[dict(path=x['relative'],version=x['before_version'],source_project=bool(sources.get(x['path'].parent))) for x in plans])
    out.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.handbook-update-',dir=out.parent) as tmp:
        stage=Path(tmp)/'project';copy_resources(root,stage,ignore=shutil.ignore_patterns('.git','__pycache__','.DS_Store','node_modules','.venv'))
        # Do not let an old project manifest dictate new file hashes during writing.
        for folder in manifests:
            (stage/folder.relative_to(root)/m.MANIFEST).unlink(missing_ok=True)
        for plan in plans:
            p=plan['path'];folder=stage/p.parent.relative_to(root);target=folder/p.name;html=plan['html'];config=plan['config']
            if style:
                config=m.validate_style({**config,**style})
                css=m.theme_css(config)
                # Only replace variables. Preserve project-specific cover fallback rules.
                theme=re.sub(r':root\{[^}]*\}',lambda _:css,plan['theme'],count=1)
                html=apply_style_attrs(html,config)
            else:
                config=m.validate_style(config)
                theme=re.sub(r':root\{[^}]*\}',lambda _:m.theme_css(config),plan['theme'],count=1)
                html=apply_style_attrs(html,config)
            plan['config']=config
            tags=m.Tags(html).tags
            t=[t for t in tags if t['attrs'].get('id')==m.THEME_STYLE][0]
            html=m.edit(html,[(t['a'],t['b'],'<style id="'+m.THEME_STYLE+'">'+theme+'</style>')])
            config_json=json.dumps(config,ensure_ascii=False).replace('<','\\u003c')
            html=html.replace('</head>','<script id="handbook-style-config" type="application/json">'+config_json+'</script></head>',1)
            if custom is not None:(folder/'assets/handbook-custom.css').write_text(custom)
            m.write_handbook(target,html,font_prefix=plan['font_prefix'])
            after=target.read_text()
            if m.content_fingerprint(after)!=plan['before_content']:raise ValueError('正文或资料日期校验不一致，已取消')
            if style:
                import font_catalog
                from prepare_resources import font_source,copy_font,copy_resource
                face=font_catalog.spec(config.get('font_family','misans'));font_target=folder/plan['font_prefix']/face['file']
                if not font_target.is_file() or font_target.stat().st_size!=face['bytes'] or m.sha(font_target.read_bytes())!=face['sha256']:
                    copy_font(font_target,font_source(font_family=config.get('font_family','misans')))
                for notice in (HERE.parent/'assets/fonts').iterdir():
                    if notice.suffix in ('.txt','.md') and not (font_target.parent/notice.name).exists():copy_resource(notice,font_target.parent/notice.name)
                copy_resource(HERE.parent/'assets/font-catalog.json',folder/'assets/font-catalog.json')
            report['pages'].append(dict(path=plan['relative'],before_version=plan['before_version'],after_version=m.VERSION,before_sha256=plan['source_sha256'],after_sha256=m.sha(after),content_sha256=m.content_fingerprint(after),material_date_preserved=True))
        from draft_handbook import BUILD
        for folder,known in sources.items():
            if not known:continue
            dest=stage/folder.relative_to(root)
            for name in m.RUNTIME_FILES:shutil.copy2(HERE/name,dest/'runtime'/name)
            (dest/'build.py').write_text(BUILD)
            shutil.copy2(HERE.parent/'assets/font-catalog.json',dest/'assets/font-catalog.json')
            cfg=next(x['config'] for x in plans if x['path'].parent==folder and x['path'].name=='index.html')
            date=re.search(r'class="credit-date"[^>]*>.*?(\d{4}-\d{2}-\d{2})',next(x['html'] for x in plans if x['path'].parent==folder and x['path'].name=='index.html'),re.S)
            if date:cfg={**cfg,'updated_at':date[1]}
            (dest/'handbook-style-override.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n')
            write_source_record(dest);report['source_projects'].append(folder.relative_to(root).as_posix())
        for folder in manifests:
            dest=stage/folder.relative_to(root);m.verify(dest,m.read_manifest(dest))
        (stage/'handbook-update-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
        stage.rename(out)
    return report


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--src',required=True);ap.add_argument('--out');ap.add_argument('--style',help='样式库导出的配置 JSON；资料日期字段不参与更新');ap.add_argument('--custom-css',help='显式替换项目覆盖样式，未提供时原样保留');ap.add_argument('--html-only',action='store_true',help='只更新页面，明确保留旧源工程');ap.add_argument('--inspect',action='store_true',help='只检查兼容性，不写入')
    a=ap.parse_args()
    if not a.inspect and not a.out:ap.error('请提供新的 --out 副本目录')
    try:print(json.dumps(update(a.src,a.out,a.style,a.custom_css,a.html_only,a.inspect),ensure_ascii=False,indent=2))
    except (ValueError,FileExistsError,FileNotFoundError,KeyError) as exc:ap.exit(1,'未更新：'+str(exc)+'\n')
