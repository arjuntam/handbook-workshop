"""Author-only theme controls, embedded exclusively in the design library."""
import v2_theme

LABELS={'accent':'主色','secondary':'图表辅助色','title':'标题色','text':'正文色','muted':'辅助文字色','bg':'页面背景','surface':'卡片底色'}


def markup():
    def fields(keys):
        return '<div class="v2-color-fields">'+''.join('<div class="v2-color-field"><label for="v2-color-'+k+'">'+LABELS[k]+'</label><input type="color" id="v2-color-'+k+'" data-color-role="'+k+'" value="#0a6ed1"><input type="text" data-color-code="'+k+'" aria-label="'+LABELS[k]+'十六进制色号" value="#0a6ed1" maxlength="7" spellcheck="false"></div>' for k in keys)+'</div>'
    buttons=''.join('<button type="button" data-expression="'+k+'" aria-pressed="'+str(k=='professional').lower()+'">'+v+'</button>' for k,v in v2_theme.EXPRESSIONS.items())
    return '<section class="v2-authoring" id="v2-theme-editor" aria-labelledby="v2-theme-title"><h3 id="v2-theme-title">视觉表达</h3><p>制作时预览整本并保存配置。生成的业务页面固定采用制作人的方案，不显示读者换色工具。</p><p class="v2-expression-help">简约阅读侧重查阅；品牌展陈增加主色光感、主视觉层次与轻动效。选择后可到任意样式预览。</p><div class="preview-toolbar" role="group" aria-label="视觉表达">'+buttons+'</div><details class="v2-custom-settings"><summary>自定义配色与方案</summary><div class="v2-custom-body"><label class="v2-scheme-name">方案名称 <input id="v2-scheme-name" maxlength="40" placeholder="例如：培训资料·暖白"></label>'+fields(('accent','secondary'))+'<details class="v2-advanced-colors"><summary>高级配色：文字与底色</summary>'+fields(('title','text','muted','bg','surface'))+'</details><p id="v2-color-status" role="status" aria-live="polite"></p><div class="preview-toolbar"><button type="button" id="v2-repair">使用推荐修正</button><button type="button" id="v2-reset">恢复默认配色</button><button type="button" id="v2-save">保存为我的方案</button><button type="button" id="v2-copy">复制当前方案</button><label class="v2-import-label">导入配置<input type="file" id="v2-import" accept=".json,application/json"></label></div><label>我的方案 <select id="v2-saved"><option value="">选择已保存方案</option></select></label><p id="v2-scheme-status" role="status"></p></div></details></section>'


CSS=r'''
.v2-custom-settings{border-block-start:1px solid var(--border);margin-block-start:1rem;padding-block-start:.5rem}.v2-custom-settings>summary{font-weight:var(--weight-title,600);color:var(--brand);min-block-size:2.75rem;line-height:1.7}.v2-custom-body{padding-block:1rem .25rem}.v2-custom-settings>summary:focus-visible{outline:3px solid var(--focus);outline-offset:2px}

.v2-authoring{margin:1.5rem 0;padding:1.25rem;border:1px solid var(--border);border-radius:1rem;background:var(--surface);font-size:1rem;line-height:1.7}.v2-authoring h3{margin-top:0}.v2-color-fields{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,17rem),1fr));gap:1rem;margin:1rem 0}.v2-color-field{display:grid;grid-template-columns:1fr 3rem 7rem;align-items:center;gap:.5rem}.v2-color-field input[type=color]{inline-size:3rem;block-size:2.75rem;padding:.2rem;background:var(--surface);border:1px solid var(--muted);border-radius:.5rem}.v2-color-field input[type=text],.v2-authoring select,.v2-scheme-name input{font:inherit;font-size:1rem;padding:.5rem .625rem;min-block-size:2.75rem;min-inline-size:0;max-inline-size:100%;border:1px solid var(--muted);border-radius:.5rem;background:var(--surface);color:var(--text)}.v2-color-field input[aria-invalid=true]{outline:2px solid #b42318}.v2-authoring summary{cursor:pointer;padding:.5rem}.v2-scheme-name{display:flex;flex-wrap:wrap;align-items:center;gap:.75rem}.v2-import-label{display:inline-flex;align-items:center;min-block-size:2.75rem;gap:.5rem}.v2-import-label input{max-inline-size:16rem;font:inherit}#v2-color-status{font-size:.875rem}#v2-scheme-status{font-size:.875rem;color:var(--muted)}
'''

JS=v2_theme.JS+r'''
function v2Values(){return {expression:currentExpression,custom_colors:customColors,custom_name:customName,shell_mode:currentShell};}
function v2Problems(t){
 const labels={'--brand':'标题','--text':'正文','--muted':'辅助文字'};const problems=[];
 Object.entries(labels).forEach(([k,label])=>['--surface','--bg'].forEach(bg=>{const r=HWTheme.contrast(t[k],t[bg]);if(r<4.5)problems.push(label+'与'+(bg==='--surface'?'卡片':'页面')+'背景对比不足（'+r.toFixed(2)+'∶1）');}));
 document.querySelectorAll('[data-color-code][aria-invalid=true]').forEach(x=>problems.push('色号应为 #RRGGBB'));return problems;
}
function applyV2Theme(){
 const t=HWTheme.tokens(v2Values(),designPalettes[currentPalette][currentShell]);Object.entries(t).forEach(([k,v])=>document.documentElement.style.setProperty(k,v));document.documentElement.dataset.expression=currentExpression;
 document.querySelectorAll('[data-expression]').forEach(x=>{if(x.matches('button'))x.setAttribute('aria-pressed',String(x.dataset.expression===currentExpression));});
 const map={accent:'--accent',secondary:'--chart-2',title:'--brand',text:'--text',muted:'--muted',bg:'--bg',surface:'--surface'};
 Object.entries(map).forEach(([k,key])=>{const picker=document.querySelector('[data-color-role="'+k+'"]'),code=document.querySelector('[data-color-code="'+k+'"]');if(picker)picker.value=customColors[k]||t[key];if(code&&document.activeElement!==code){code.value=customColors[k]||t[key];code.removeAttribute('aria-invalid');}});
 const name=document.getElementById('v2-scheme-name');if(name&&document.activeElement!==name)name.value=customName;
 const problems=v2Problems(t);const status=document.getElementById('v2-color-status');if(status)status.textContent=problems.length?problems.join('；')+'。可使用推荐修正。':'文字与背景对比度符合阅读要求。按钮主色已匹配可读文字。';
 if(document.getElementById('download-design'))document.getElementById('download-design').disabled=problems.length>0;
 try{localStorage.setItem('handbook-author-style-v2',JSON.stringify(v2Values()));}catch(e){}
}
function v2Import(cfg){
 if(!cfg||typeof cfg!=='object'||Array.isArray(cfg))throw Error('配置格式不正确');
 if(cfg.custom_colors&&Object.entries(cfg.custom_colors).some(([k,v])=>!['accent','secondary','title','text','muted','bg','surface'].includes(k)||typeof v!=='string'||!/^#[0-9a-f]{6}$/i.test(v)))throw Error('自定义颜色包含无效角色或色号');
 HWTheme.canonical(cfg.expression);
 if(cfg.palette&&!designPalettes[cfg.palette])throw Error('配色预设不存在');if(cfg.shell_mode&&!['light','dark'].includes(cfg.shell_mode))throw Error('外框模式无效');
 if(cfg.font_family&&!designFonts[cfg.font_family])throw Error('字体不存在');if(cfg.type_scale&&!designTypes[cfg.type_scale])throw Error('字号预设无效');
 if(cfg.type_scale_factor!==undefined&&(!Number.isFinite(cfg.type_scale_factor)||cfg.type_scale_factor<.8||cfg.type_scale_factor>1.5))throw Error('字号微调范围为0.8–1.5');
 currentExpression=HWTheme.canonical(cfg.expression);customColors={...(cfg.custom_colors||{})};customName=String(cfg.custom_name||'').slice(0,40);if(cfg.palette)currentPalette=cfg.palette;if(cfg.shell_mode)currentShell=cfg.shell_mode;if(cfg.type_scale)currentType=cfg.type_scale;if(cfg.type_scale_factor!==undefined)currentTypeFactor=cfg.type_scale_factor;if(typeof cfg.show_update_date==='boolean')showUpdateDate=cfg.show_update_date;
 document.querySelectorAll('[data-color-code]').forEach(x=>x.removeAttribute('aria-invalid'));applyDesign();if(cfg.font_family&&cfg.font_family!==currentFont)chooseFont(cfg.font_family);
}
(()=>{
 const status=document.getElementById('v2-scheme-status');if(!status)return;
 document.querySelectorAll('button[data-expression]').forEach(b=>b.addEventListener('click',()=>{currentExpression=b.dataset.expression;applyDesign();}));
 document.querySelectorAll('[data-palette]').forEach(b=>b.addEventListener('click',()=>{customColors={};customName='';},true));
 document.querySelectorAll('[data-color-role]').forEach(x=>x.addEventListener('input',()=>{customColors[x.dataset.colorRole]=x.value;const code=document.querySelector('[data-color-code="'+x.dataset.colorRole+'"]');code.value=x.value;code.removeAttribute('aria-invalid');applyDesign();}));
 document.querySelectorAll('[data-color-code]').forEach(x=>x.addEventListener('input',()=>{if(!/^#[0-9a-f]{6}$/i.test(x.value)){x.setAttribute('aria-invalid','true');document.getElementById('download-design').disabled=true;document.getElementById('v2-color-status').textContent='色号应为 #RRGGBB，例如 #28715a';return;}x.removeAttribute('aria-invalid');customColors[x.dataset.colorCode]=x.value;applyDesign();}));
 document.getElementById('v2-scheme-name').addEventListener('input',e=>{customName=e.target.value;applyDesign();});
 document.getElementById('v2-repair').addEventListener('click',()=>{const t=HWTheme.tokens(v2Values(),designPalettes[currentPalette][currentShell]);if(HWTheme.contrast(t['--surface'],t['--bg'])>3)customColors.bg=t['--surface'];const bg=customColors.bg||t['--bg'];[['title','--brand'],['text','--text'],['muted','--muted']].forEach(([k,v])=>{let c=HWTheme.readable(t[v],t['--surface']);if(HWTheme.contrast(c,bg)<4.5)c=HWTheme.readable(c,bg);customColors[k]=c;});document.querySelectorAll('[data-color-code]').forEach(x=>x.removeAttribute('aria-invalid'));applyDesign();});
 document.getElementById('v2-reset').addEventListener('click',()=>{customColors={};customName='';currentExpression='professional';currentPalette='air-blue';currentShell='light';document.querySelectorAll('[data-color-code]').forEach(x=>x.removeAttribute('aria-invalid'));applyDesign();});
 let saved=[];try{saved=JSON.parse(localStorage.getItem('handbook-author-schemes-v2')||'[]');if(!Array.isArray(saved))saved=[];}catch(e){}
 const select=document.getElementById('v2-saved');function refresh(){select.replaceChildren(new Option('选择已保存方案',''));saved.forEach((x,i)=>select.add(new Option(x.custom_name,String(i))));}
 function save(copy=false){if(v2Problems(HWTheme.tokens(v2Values(),designPalettes[currentPalette][currentShell])).length){status.textContent='请先修正配色或色号。';return;}customName=(customName||'我的配色')+(copy?' 副本':'');saved=saved.filter(x=>x.custom_name!==customName);saved.push({...v2Values(),palette:currentPalette,font_family:currentFont,type_scale:currentType,type_scale_factor:currentTypeFactor,show_update_date:showUpdateDate});try{localStorage.setItem('handbook-author-schemes-v2',JSON.stringify(saved));status.textContent='已保存在本机浏览器。导出配置可跨设备复用。';}catch(e){status.textContent='浏览器无法保存，请导出配置。';}refresh();applyDesign();}
 document.getElementById('v2-save').addEventListener('click',()=>save());document.getElementById('v2-copy').addEventListener('click',()=>save(true));select.addEventListener('change',()=>{if(select.value!=='')try{v2Import(saved[Number(select.value)]);}catch(e){status.textContent=e.message;}});
 document.getElementById('v2-import').addEventListener('change',async e=>{try{const file=e.target.files[0];if(!file)return;if(file.size>100000)throw Error('配置文件过大');v2Import(JSON.parse(await file.text()));status.textContent='已导入配置，正在预览。';}catch(error){status.textContent='导入失败：'+error.message;}finally{e.target.value='';}});
 refresh();try{const old=typeof initialAuthorStyle!=='undefined'?initialAuthorStyle:JSON.parse(localStorage.getItem('handbook-author-style-v2')||'null');if(old)v2Import(old);}catch(e){status.textContent='已忽略无效的旧配色记录。';}applyDesign();
})();
'''
