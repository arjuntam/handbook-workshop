# 2.0 组件、数据与复用

## 选型

- 项目表达：`expression` 为 `professional`（简约阅读）、`brand`（品牌展陈）；旧 warm/showcase 兼容归入 brand。它影响整体基调，主次仍由实际内容编排决定。
- T09 `feature`：章节命题、重要事实与主图。`role` 可为 chapter/case/method/explain/data/region/media；标题、正文、主图、指标均由资料提供，不为填版编造真实成果。
- L17-D `image_reader`：解释与竖图对读，宽屏左右、窄屏上下；长图默认手动，点击按宽度放大；慢移只用于明确开始的演示。
- L27 `video`：本地视频或 HTTPS 可播放直链，原生控制、按需加载、可选字幕与文字稿。`external:true` 表示平台观看页的外部入口；缺 src 明确显示待补。
- L28 `chart`：A column、B bar、C line、D stacked、E donut/pie。新增样式需要配置和素材，升级公共运行文件不会自行生成业务内容。

完整数据配置可运行 `scripts/build_design_gallery.py --out 新目录` 获取根目录中的 `2.0完整配置示例.json`，或直接参考 `scripts/v2_examples.py` 和 `assets/v2-examples/chart-data.json`。六类入口与原有编号继续有效，图表在“数据与对照”，图文和视频在“图片与资料”。

## 图表配置

```json
{
  "t":"chart", "kind":"column", "title":"数量净变化（模拟）",
  "unit":"份", "period":"同一检查周期", "source":"原创模拟数据",
  "note":"变化量，不是最终库存。", "summary":"正负与零分别呈现。",
  "categories":["示例甲","示例乙","示例丙"],
  "series":[{"name":"净变化","values":[-3,5,0]}]
}
```

每个系列逐类别对应，数值为有限数；未提供为 `null`，不是 `0`。标题、单位和来源必填。最多60类、6系列，密集内容应分图或用表格。生成可离线 SVG，保留原始数据表和来源；摘要、表格可被本手册全文搜索读取。

柱/条形保留零基线；全负数朝负向延伸。折线在 null 处断开，跨零允许。若时间不等间隔，提供与类别逐项对应且严格递增的 `x_values`（ISO日期或有限数），例如 `["2026-01-01","2026-01-02","2026-01-11"]`；不猜测或排序来源时间。

普通堆叠将正、负贡献分别累计，明细列出净值；净值为零仍保留正负贡献。`percent:true` 为百分比堆叠，只接受非负值，同一列总量为零显示状态，缺项不补零。

环形/饼图只接受一系列、最多5类、非负且完整的总体；负数拒绝生成，全零显示无可计算占比，缺项提示总体不完整。负增长率应使用柱、条、折线。颜色不自动将负数判为坏结果。

## 主视觉与图文

```json
{"t":"feature","role":"case","label":"原创演示","title":"让资料交接更清楚","body":"可核对的事实与说明。","src":"v2-examples/workspace.svg","caption":"原创示意图","metric":"15","unit":"份（模拟）","notice":"演示数据，非实际成果。"}
```

```json
{"t":"image_reader","title":"交接信息对读","body":"核对已提供、缺项与下一步。","blocks":[{"t":"text","v":"完整解释。"}],"items":[{"src":"v2-examples/conversation.svg","caption":"原创演示对话，非真实聊天。"}]}
```

图片属于当前项目的 assets；保留图号与说明。正文和图片没有既定关系时不要强行对读。长图放大提供宽度缩放和原生滚动，关闭返回原焦点。

## 视频

```json
{"t":"video","title":"资料交接演示","src":"v2-examples/overview.mp4","poster":"v2-examples/video-poster.svg","width":960,"height":540,"captions":[{"src":"v2-examples/overview.vtt","lang":"zh-CN","label":"中文","default":true}],"transcript":"与视频一致的文字说明。"}
```

横竖视频写真实宽高。默认点击后加载，离开章节或隐藏页面暂停，与录音协调。在线直链仍需网络，本地资源随项目交付后离线播放。浏览器需支持视频编码和字幕资源；不承诺平台观看链接直接嵌入。不自动转写、OCR，也不自动读取附件正文。

## 自定义颜色

制作人通过样式库设置：主色与图表辅助色、可选标题/正文/辅助文字/页面/卡片色。`custom_colors` 使用角色名和六位十六进制色号；表达与颜色保存在项目共用配置，导入后检查全部必要状态。低对比组合提示并提供修正，导出和构建都检查配置。

```json
{"palette":"forest","shell_mode":"light","expression":"brand","custom_name":"培训资料松绿","custom_colors":{"accent":"#356148","secondary":"#a45226"}}
```

成品页面不提供读者配色切换、个人方案保存或系统自动主题切换。默认配色保持制作人的选择；正式 logo 与原始素材不重染。

## 导航与升级

宽度不足时目录收起为可关闭抽屉。长内容的 Metro、顶层场景标签、L25 对象或话术分组可显示一条精简导航；离开模块即释放。节内分区已有滚动定位，与精简导航协调，不叠出多层。表格在自身容器内保留表头。普通卡片不因为正文长就固定。

统一升级继续使用 `update_handbook.py --src 原目录 --out 新副本 [--style 样式配置.json]`。保留正文、资料日期、素材与项目覆盖。2.0 不自动把旧正文改造成新图表；源工程同步更新运行依赖，后续重建保持新版功能。

Full 的共享图片与演示媒体由包根目录供离线样式库引用，必须完整解压，不能只拷 design-gallery 子目录。独立导出的网页样式库另带自己的必要资源。

用已有 Full 字体准备后续 Lite 环境：`python scripts/prepare_resources.py --cache-from Full解压后的handbook-workshop目录`。完整校验后写入按指纹隔离的资源缓存，源字体不改动。环境改变或缓存不存在时，Lite 仍需准备字体。

## 长问答的分组入口

L13 `faq.items` 可给问题添加 `group` 文字，连续同组共用标题。存在多个明确分组且正文较长时，阅读过程显示精简分组选择器；短问答不固定。L12 的分组选择根据当前位置同步，不把所有已展开的组都标为当前组。

```json
{"t":"faq","items":[{"group":"准备资料","q":"需要什么？","answer":"原稿及有来源的素材。"},{"group":"交付检查","q":"交付前核对什么？","answer":"正文、素材、日期和实际操作。"}]}
```

整库表达、氛围图压底、三项行动与动效规则见 [expressions.md](expressions.md)。
