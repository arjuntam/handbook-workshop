# -*- coding: utf-8 -*-
"""网页手册工坊 · 核心引擎：设计系统 CSS/JS + 内容块渲染 + 图片去重。

设计依据：modern-web-guidance 的 scrollspy / copy-button / content-first-noise-reduction。
本模块不含任何品牌或业务专属内容，全部通过 config 传入。详见 SKILL.md 与 references/。
"""
import os, re, json, hashlib, shutil
from pathlib import Path
from itertools import count
from design_tokens import tokens, selection
import cover_design
import desktop_gate
import gallery_layouts
import portal_layout
import typography_rules
import china_map
from datetime import datetime
from zoneinfo import ZoneInfo
_UI_IDS = count(1)

# 默认配置：调用方可整体或部分覆盖。
# brand_logo / cover_image 指向本地图片文件（绝对路径或相对 cwd），会被复制为 assets/logo.png 与 assets/cover-wave.png。
DEFAULT_CONFIG = {
    "brand": "大金 DAIKIN",                 # 品牌名，如「大金 DAIKIN」；用于 alt 文案，留空则用 title
    "brand_logo": "",            # logo 图片路径；留空则不写入 logo（页面自动降级为文字标题）
    "cover_image": "",           # 封面背景图路径；留空则用纯色渐变
    "dock_note": "",             # 附件抽屉底部说明，如网盘提取码；留空不显示
    "home_href": "../index.html",# 「首页」按钮链接；单手册项目可留空
    "mobile_block": True,       # 未做移动端适配时设 True：手机/平板打开显示「请用电脑打开」
    "style_preset": "apple",     # 设计基线；设 "classic" 回到旧版式（字号/间距/圆角/阴影/材质）
    "cover_mode": "auto",
    "cover_surface": "light",
    "header_surface": "light",
    "palette": "air-blue",
    "shell_mode": "light",
    "type_scale": "standard",
    "logo_header_height": 28,
    "logo_cover_height": 48,
    "theme": {},                 # CSS 变量覆盖，如 {"--brand":"#0d3b66","--accent":"#2b7fd4"}
}


def resolve_config(config=None):
    cfg = dict(DEFAULT_CONFIG)
    if config:
        cfg.update(config)
    if not isinstance(cfg["theme"], dict):
        cfg["theme"] = {}
    # Same collection -> same project-style.json. Per-manual palette/title-size drift is ignored.
    profile_path = Path(cfg.get("project_style_file") or (Path(__file__).resolve().parent.parent / "assets" / "base-style.json"))
    profile = json.loads(profile_path.read_text(encoding="utf-8"))
    if not cfg.get("style_preview", False):
        for key in ("design_version", "designer", "palette", "shell_mode", "type_scale", "logo_header_height", "logo_cover_height", "header_surface", "theme", "protected_phrases"):
            if key in profile:
                cfg[key] = profile[key]
    cfg["show_update_date"] = (config or {}).get("show_update_date", profile.get("show_update_date", True))
    if not isinstance(cfg["show_update_date"], bool):
        raise ValueError("show_update_date 必须为 true 或 false")
    cfg["updated_at"] = (config or {}).get("updated_at") or profile.get("updated_at") or datetime.now(ZoneInfo("Asia/Shanghai")).date().isoformat()
    brand_dir = Path(__file__).resolve().parent.parent / "assets" / "brand"
    cfg["mobile_block"] = True
    cfg["brand"] = "大金 DAIKIN"
    cfg["brand_logo"] = str(brand_dir / "daikin-color.png")
    cfg["brand_logo_white"] = str(brand_dir / "daikin-white.png")
    if "shell_mode" not in profile and not cfg.get("style_preview", False):
        cfg["shell_mode"] = profile.get("header_surface", cfg["shell_mode"])
    cfg["palette"], cfg["shell_mode"] = selection(cfg)
    cfg["theme"] = {**tokens(cfg), **cfg["theme"]}
    cfg["header_surface"] = cfg["shell_mode"]
    cfg["theme"]["--sans"] = '"MiSans",sans-serif'
    return cfg


def ensure_brand_assets(out_dir, config=None):
    """把品牌 logo 与封面背景复制到 out_dir/assets，并按配置重命名。
    缺少源文件时静默跳过，模板内置降级样式，不会导致页面破损。"""
    cfg = resolve_config(config)
    dst_dir = out_dir / "assets"
    dst_dir.mkdir(parents=True, exist_ok=True)
    font_src = Path(__file__).resolve().parent.parent / "assets" / "fonts" / "MiSans-VF.ttf"
    font_dst = dst_dir / "fonts" / "MiSans-VF.ttf"
    font_dst.parent.mkdir(parents=True, exist_ok=True)
    if not font_src.is_file():
        raise FileNotFoundError("固定 MiSans 字体文件缺失")
    if font_src.resolve() != font_dst.resolve():
        shutil.copy2(font_src,font_dst)
    map_src = Path(__file__).resolve().parent.parent / "assets" / "maps"
    if map_src.is_dir() and map_src.resolve() != (dst_dir / "maps").resolve():
        shutil.copytree(map_src, dst_dir / "maps", dirs_exist_ok=True)
    pairs = [(cfg["brand_logo"], "logo.png"), (cfg["brand_logo_white"], "logo-white.png"), (cfg["cover_image"], "cover-wave.png")]
    for src, name in pairs:
        if not src:
            continue
        src_path = Path(src)
        if not src_path.is_file():
            raise FileNotFoundError(f"已配置的品牌素材不存在：{src_path}")
        if src_path.resolve() != (dst_dir / name).resolve():
            shutil.copy2(src_path, dst_dir / name)

def esc(s):
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))

def nl2br(s, phrases=None):
    return typography_rules.text(s, phrases)

# ---------- 图片资源：按内容 md5 去重复制 ----------
DIMS = {}   # 去重后文件名 -> (宽, 高)，供 img 标签写 width/height 防 CLS

def _img_size(path):
    """读取图片像素尺寸（PNG/JPEG/GIF/WebP），用于渲染 width/height 防 CLS。
    失败返回 None，退化为不写尺寸。"""
    try:
        with open(path, "rb") as f:
            head = f.read(32)
        if head[:8] == b"\x89PNG\r\n\x1a\n":
            import struct
            w, h = struct.unpack(">II", head[16:24])
            return int(w), int(h)
        if head[:6] in (b"GIF87a", b"GIF89a"):
            import struct
            w, h = struct.unpack("<HH", head[6:10])
            return int(w), int(h)
        if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
            if head[12:16] == b"VP8X":
                import struct
                w = int.from_bytes(head[24:27], "little") + 1
                h = int.from_bytes(head[27:30], "little") + 1
                return w, h
        if head[:2] == b"\xff\xd8":  # JPEG：扫描 SOF 段
            with open(path, "rb") as f:
                f.read(2)
                while True:
                    b = f.read(1)
                    if not b:
                        return None
                    if b != b"\xff":
                        continue
                    marker = f.read(1)
                    while marker == b"\xff":
                        marker = f.read(1)
                    if not marker:
                        return None
                    m = marker[0]
                    if m in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7,
                             0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                        f.read(2)
                        h = int.from_bytes(f.read(2), "big")
                        w = int.from_bytes(f.read(2), "big")
                        return int(w), int(h)
                    if m in (0xD8, 0xD9) or 0xD0 <= m <= 0xD7:
                        continue
                    seg = f.read(2)
                    if len(seg) < 2:
                        return None
                    f.read(int.from_bytes(seg, "big") - 2)
    except Exception:
        return None
    return None


def prepare_assets(src_dir, out_dir):
    """把 src_dir 下所有图片按内容 md5 去重复制到 out_dir/assets，
    返回 {原文件名: 去重后文件名}。src_dir 不存在时返回空映射。"""
    src = Path(src_dir)
    dst = Path(out_dir) / "assets"
    dst.mkdir(parents=True, exist_ok=True)
    if not src.exists():
        return {}
    seen = {}
    mapping = {}
    for f in sorted(src.iterdir()):
        if not f.is_file() or f.suffix.lower() not in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".bmp", ".tif", ".tiff", ".emf", ".wmf"}:
            continue
        h = hashlib.md5(f.read_bytes()).hexdigest()[:10]
        if h in seen:
            mapping[f.name] = seen[h]
            continue
        ext = f.suffix.lower()
        new = f"{h}{ext}"
        if f.resolve() != (dst / new).resolve():
            shutil.copy2(f, dst / new)
        seen[h] = new
        mapping[f.name] = new
        size = _img_size(f)
        if size:
            DIMS[new] = size
    return mapping

# ---------- 内容块渲染 ----------
def render_blocks(blocks, A):
    """A: 图片映射 dict（原文件名 -> 去重后名）"""
    def img(name, cls="", cap=""):
        fn = A.get(name, name)
        cap_html = f'<figcaption>{nl2br(cap)}</figcaption>' if cap else ''
        wh = DIMS.get(fn)
        dim_attr = f' width="{wh[0]}" height="{wh[1]}"' if wh else ''
        return f'<figure class="{cls}"><img src="assets/{fn}"{dim_attr} decoding="async" class="zoomable" tabindex="0" role="button" aria-label="放大查看：{esc(cap or name)}" alt="{esc(cap or name)}">{cap_html}</figure>'

    out = []
    for b in blocks:
        t = b["t"]
        if t == "lede":
            out.append(f'<p class="lede">{nl2br(b["v"], b.get("keep_phrases"))}</p>')
        elif t == "text":
            out.append(f'<p class="body-text">{nl2br(b["v"], b.get("keep_phrases"))}</p>')
        elif t == "table":
            # 不把任意表格塞进固定五列 roster；head 只能由内容编辑者明确设置。
            head = b.get("head", [])
            caption = b.get("caption", "数据表")
            th = "".join(f'<th scope="col">{nl2br(v)}</th>' for v in head)
            rows = "".join('<tr>' + "".join(f'<td>{nl2br(v)}</td>' for v in row) + '</tr>' for row in b["rows"])
            out.append(f'<div class="data-table-scroll" tabindex="0" role="region" aria-label="{esc(caption)}">'
                       f'<table class="data-table"><caption>{esc(caption)}</caption>'
                       + (f'<thead><tr>{th}</tr></thead>' if head else '')
                       + f'<tbody>{rows}</tbody></table></div>')
        elif t == "html":
            """原样注入 HTML 片段：用于内联 SVG 图表等外部生成内容"""
            out.append(b["v"])
        elif t == "h3":
            out.append(f'<h3 class="subhead">{esc(b["v"])}</h3>')
        elif t == "callout":
            label = b.get("label", "要点")
            tone = b.get("tone", "blue")
            out.append(f'<div class="callout callout-{tone}"><span class="callout-label">{esc(label)}</span>'
                       f'<div class="callout-body">{nl2br(b["v"], b.get("keep_phrases"))}</div></div>')
        elif t == "warn":
            out.append(f'<div class="callout callout-red"><span class="callout-label">避坑提醒</span>'
                       f'<div class="callout-body">{nl2br(b["v"], b.get("keep_phrases"))}</div></div>')
        elif t == "pick":
            # Native radios retain keyboard/disabled behavior; card highlight is presentation.
            cols, default = b.get("cols", 3), int(b.get("default", 0))
            uid = f"pick-{next(_UI_IDS)}"
            cards = []
            for i, it in enumerate(b["items"]):
                disabled = bool(it.get("disabled"))
                on = i == default and not disabled
                cls = "pick-card" + (" on" if on else "") + (" is-disabled" if disabled else "")
                num = f'<span class="card-num">{esc(it["num"])}</span>' if it.get("num") else ""
                sub = f'<span class="card-sub">{nl2br(it["sub"])}</span>' if it.get("sub") else ""
                body = f'<span class="card-body">{nl2br(it["body"])}</span>' if it.get("body") else ""
                checked_attr = " checked" if on else ""
                disabled_attr = " disabled" if disabled else ""
                cards.append(f'<label class="{cls}" data-pick="{i}">'
                             f'<input class="pick-control" type="radio" name="{uid}" value="{i}"{checked_attr}{disabled_attr}>'
                             f'{num}<span class="card-title">{nl2br(it.get("title",""))}</span>{sub}{body}</label>')
            out.append(f'<div class="grid grid-{cols} pick-grid" role="radiogroup" aria-label="{esc(b.get("label","选项"))}">' + "".join(cards) + '</div>')
        elif t == "tabs":
            """标签切换卡：点标签换面板；item.block 可嵌任意内容块"""
            heads, panels = [], []
            tid = f"ts-{next(_UI_IDS)}-" + hashlib.md5("".join(
                str(it.get("tab", it.get("title", ""))) for it in b["items"]).encode()).hexdigest()[:6]
            for i, it in enumerate(b["items"]):
                on, sel = (' on', 'true') if i == 0 else ('', 'false')
                hid, pid = f"{tid}-t{i}", f"{tid}-p{i}"
                hn = it.get("num", i + 1)
                hn = f'<span class="tab-hnum">{esc(hn)}</span>' if hn != "" else ""
                heads.append(f'<button type="button" class="tab-head{on}" id="{hid}" data-idx="{i}" role="tab" '
                             f'aria-selected="{sel}" aria-controls="{pid}">'
                             f'{hn}{esc(it.get("tab", it.get("title","")))}</button>')
                num = (f'<span class="card-num">{esc(it.get("num",""))}</span>'
                       if it.get("num") and not it.get("block") else "")
                sub = f'<div class="card-sub">{nl2br(it["sub"])}</div>' if it.get("sub") else ""
                body = f'<p class="card-body">{nl2br(it["body"])}</p>' if it.get("body") else ""
                pic = img(it["img"], "tab-img", it.get("cap", "")) if it.get("img") else ""
                embed = render_blocks([it["block"]], A) if it.get("block") else ""
                ttl = f'<h4 class="tab-title">{nl2br(it["title"])}</h4>' if it.get("title") else ""
                panels.append(f'<div class="tab-panel{on}" id="{pid}" data-idx="{i}" role="tabpanel" '
                              f'aria-labelledby="{hid}">{num}{ttl}{sub}{body}{pic}{embed}</div>')
            out.append(f'<div class="tabset"><div class="tab-heads" role="tablist" aria-label="内容切换">' + "".join(heads) +
                       '</div><div class="tab-stage">' + "".join(panels) + '</div></div>')
        elif t == "metro":
            """地铁报站导航：多阶段流程用；navigate=True 点站跳 id，compact=True 隐藏详情"""
            items, default = b["items"], int(b.get("default", 0))
            stops, panels = [], []
            for i, it in enumerate(items):
                on, pressed = (' on', 'true') if i == default else ('', 'false')
                num, title, sub = esc(it.get("num", i+1)), esc(it.get("title", "")), esc(it.get("sub", ""))
                rows = []
                for line in [x.strip() for x in it.get("body", "").split("\n") if x.strip()]:
                    step = line[:2] if len(line) > 2 and line[:2].isdigit() and line[2] == " " else ""
                    text = esc(line[3:] if step else line)
                    cls = ' class="ml-note"' if not step else ''
                    lead = f'<span class="ml-n">{esc(step)}</span>' if step else ''
                    rows.append(f'<li{cls}>{lead}<span class="ml-t">{text}</span></li>')
                goto_attr = f' data-goto="{esc(it["goto"])}"' if it.get("goto") else ''
                stops.append(f'<button type="button" class="metro-stop{on}" data-stop="{i}" aria-pressed="{pressed}"{goto_attr}>'
                             f'<span class="metro-dot"><span class="metro-num">{num}</span></span>'
                             f'<span class="metro-label"><b>{title}</b><small>{sub}</small></span></button>')
                link = (f'<button type="button" class="xref-chip metro-goto" data-goto="{esc(it["goto"])}">'
                        f'{esc(b.get("goto_label","查看完整内容"))} <span class="xc-arrow">→</span></button>') if it.get("goto") else ""
                panels.append(f'<div class="metro-panel{on}" data-stop="{i}"><div class="metro-panel-body">'
                              f'<div class="metro-panel-head"><span class="metro-panel-num">{num}</span>'
                              f'<div class="metro-panel-title"><b>{title}</b><span>{sub}</span></div></div>'
                              f'<ul class="metro-list">{"".join(rows)}</ul>{link}</div></div>')
            first = esc(items[default].get("title", "")) if items else ""
            if default + 1 < len(items):
                nxt = f'<span class="metro-next">下一站 · <b>{esc(items[default+1].get("title",""))}</b></span>'
            else:
                nxt = '<span class="metro-next" hidden>下一站 · <b></b></span>'
            cls = 'metro' + (' metro-nav' if b.get('compact') else '')
            navattr = ' data-nav="1"' if b.get('navigate') else ''
            out.append(f'<div class="{cls}"{navattr}>'
                       f'<div class="metro-board" aria-live="polite"><span class="metro-now">当前站 · <b>{first}</b></span>{nxt}</div>'
                       f'<div class="metro-track" style="--metro-n:{len(items)};--metro-edge:{50.0/len(items):.4f}%">'
                       '<span class="metro-fill"></span><span class="metro-train"></span>' + "".join(stops) + '</div>'
                       '<div class="metro-detail">' + "".join(panels) + '</div></div>')
        elif t == "runsheet":
            """流程单：一张卡片装完整条时间线。item = {time, name, tag?, hi?} 或 {sep:"分组名"}"""
            items = b.get("items", [])
            rows, last_idx = [], len(items) - 1
            for i, it in enumerate(items):
                if it.get("sep"):
                    rows.append(f'<li class="rs-sep"><span>{esc(it["sep"])}</span></li>')
                    continue
                cls = "rs-row"
                if it.get("hi"):
                    cls += " hi"
                if i == 0:
                    cls += " rs-first"
                if i == last_idx:
                    cls += " rs-last"
                tag = f'<span class="rs-tag">{esc(it["tag"])}</span>' if it.get("tag") else ""
                rows.append(
                    f'<li class="{cls}"><span class="rs-t">{esc(it.get("time", ""))}</span>'
                    f'<span class="rs-rail"><i></i></span>'
                    f'<span class="rs-n">{esc(it.get("name", ""))}{tag}</span></li>')
            title = esc(b.get("title", "流程单"))
            meta = f'<span>{esc(b["meta"])}</span>' if b.get("meta") else ""
            out.append(
                '<div class="rs"><div class="rs-head">'
                f'<b>{title}</b>{meta}</div>'
                '<ol class="rs-list">' + "".join(rows) + '</ol></div>')
        elif t == "stats":
            """数字统计卡：进入视口时数字从 0 滚向目标值。
            item: {num:"30", suffix:"+", label:"覆盖城市", note:"可选说明", prefix:"可选"}
            num 可含小数（如 "11.2"），滚动时保留 1 位小数。"""
            cols = b.get("cols", 4)
            cards = []
            for i, it in enumerate(b["items"]):
                num = str(it.get("num", ""))
                suffix = it.get("suffix", "")
                prefix = it.get("prefix", "")
                suffix_html = f'<span class="stat-suffix">{esc(suffix)}</span>' if suffix else ""
                prefix_html = f'<span class="stat-prefix">{esc(prefix)}</span>' if prefix else ""
                note = f'<div class="stat-note">{nl2br(it["note"])}</div>' if it.get("note") else ""
                dur = it.get("dur", 1100)
                # 滚动数字对读屏是噪音：可视数字 aria-hidden，另给静态可读值
                sr = f'{it.get("prefix","")}{num}{suffix}'
                cards.append(
                    f'<div class="stat-card anim-item" style="--d:{i*70}ms">'
                    f'<div class="stat-num" data-count="{esc(num)}" data-dur="{esc(str(dur))}" aria-hidden="true">'
                    f'{prefix_html}<span class="stat-v">0</span>{suffix_html}</div>'
                    f'<span class="sr-only">{esc(sr)}</span>'
                    f'<div class="stat-label">{esc(it.get("label",""))}</div>{note}</div>')
            out.append(f'<div class="stat-grid stat-grid-{cols}">' + "".join(cards) + '</div>')
        elif t == "compare":
            """左右对照卡：item = {num, title, left, right}"""
            cards = []
            bl = b.get("left_tag", "现状")
            br = b.get("right_tag", "需要")
            for i, it in enumerate(b["items"]):
                num = f'<span class="cmp-num">{esc(it.get("num", i+1))}</span>' if it.get("num") else ""
                left_tag = it.get("left_tag", bl)
                right_tag = it.get("right_tag", br)
                cards.append(
                    f'<article class="cmp-card anim-item" style="--d:{i*70}ms">'
                    f'<div class="cmp-head">{num}<h4>{nl2br(it.get("title",""))}</h4></div>'
                    f'<div class="cmp-body">'
                    f'<div class="cmp-side cmp-now"><span class="cmp-tag">{esc(left_tag)}</span>'
                    f'<p>{nl2br(it.get("left",""))}</p></div>'
                    f'<span class="cmp-arrow" aria-hidden="true">→</span>'
                    f'<div class="cmp-side cmp-need"><span class="cmp-tag">{esc(right_tag)}</span>'
                    f'<p>{nl2br(it.get("right",""))}</p></div>'
                    f'</div></article>')
            cols = b.get("cols", 1)
            style = f' style="grid-template-columns:repeat({cols},minmax(0,1fr))"' if cols > 1 else ""
            out.append(f'<div class="cmp-list"{style}>' + "".join(cards) + '</div>')
        elif t == "grid":
            cols = b.get("cols", 2)
            cards = []
            for it in b["items"]:
                pic = img(it["img"], "card-img", it.get("cap", "")) if it.get("img") else ""
                num = f'<span class="card-num">{esc(it["num"])}</span>' if it.get("num") else ""
                body = f'<p class="card-body">{nl2br(it["body"])}</p>' if it.get("body") else ""
                sub = f'<div class="card-sub">{nl2br(it["sub"])}</div>' if it.get("sub") else ""
                copy = ""
                if it.get("copy"):
                    cid = "cp-" + hashlib.md5(("".join(it.get("copy",[])) + it.get("title","")).encode()).hexdigest()[:8]
                    lines = it["copy"] if isinstance(it["copy"], list) else [it["copy"]]
                    copy = (f'<div class="copy-wrap"><span class="copy">'
                            f'<button type="button" class="copy-button" command="--copy" commandfor="{cid}" data-copy-target="{cid}" aria-label="复制{esc(it.get("title",""))}">'
                            f'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 8h10M9 12h10M9 16h10M5 8h.01M5 12h.01M5 16h.01" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>'
                            f'</button><span class="tip" role="status"></span></span>'
                            f'<div class="copy-text" id="{cid}">' + "\n".join(nl2br(x) for x in lines) + '</div></div>')
                icon = (f'<img class="card-icon" src="assets/{A.get(it["icon"], it["icon"])}" alt="">' if it.get("icon") else "")
                idx = len(cards)
                cards.append(f'<article class="card anim-item" style="--d:{idx*60}ms">{num}<h4 class="card-title">{icon}{nl2br(it.get("title",""))}</h4>{sub}{pic}{copy}{body}</article>')
            out.append(f'<div class="grid grid-{cols}">' + "".join(cards) + '</div>')
        elif t == "chat":
            """对话气泡：bubbles = [{role:'sales'|'client', text, img?}]"""
            bs = []
            for m in b["bubbles"]:
                role = m.get("role", "sales")
                avatar = m.get("avatar") or m.get("img")
                person = ('<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8.6" r="4"/>'
                          '<path d="M4.6 21c0-4.1 3.3-6.4 7.4-6.4s7.4 2.3 7.4 6.4z"/></svg>')
                av = (f'<img class="avatar" src="assets/{A.get(avatar,avatar)}" alt="">' if avatar
                      else f'<span class="avatar avatar-ph {role}" aria-hidden="true">{person}</span>')
                txt = nl2br(m["text"])
                cid = "cp-" + hashlib.md5(m["text"].encode()).hexdigest()[:8]
                copy = (f'<span class="copy"><button type="button" class="copy-button" command="--copy" commandfor="{cid}" data-copy-target="{cid}" aria-label="复制这条话术">'
                        f'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 8h10M9 12h10M9 16h10M5 8h.01M5 12h.01M5 16h.01" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>'
                        f'</button><span class="tip" role="status"></span></span>')
                bs.append(f'<div class="bubble-row {role}">{av}<div class="bubble"><span class="copy-text" id="{cid}">{txt}</span>{copy}</div></div>')
            caption = f'<div class="chat-cap">{nl2br(b["caption"])}</div>' if b.get("caption") else ''
            out.append(f'<div class="chat">{caption}' + "".join(bs) + '</div>')
        elif t == "moments":
            """仿真朋友圈：name/time/text/imgs/avatar/likes/comments；点赞评论可互动"""
            name, time = esc(b.get("name", "")), esc(b.get("time", ""))
            txt = nl2br(b.get("text", ""))
            av = b.get("avatar")
            avatar = (f'<span class="mm-avatar"><img src="assets/{A.get(av,av)}" alt=""></span>' if av
                      else '<span class="mm-avatar" aria-hidden="true"></span>')
            grid = ""
            if b.get("imgs"):
                n = min(len(b["imgs"]), 9)
                cells = "".join(f'<img class="mm-photo zoomable" src="assets/{A.get(p,p)}" loading="lazy" alt="朋友圈配图">' for p in b["imgs"])
                grid = f'<div class="mm-photos mm-photos-{n}">{cells}</div>'
            heart = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21s-8-4.9-8-10.4C4 7.5 6 5.5 8.6 5.5c1.5 0 2.7.7 3.4 1.8.7-1.1 1.9-1.8 3.4-1.8C18 5.5 20 7.5 20 10.6 20 16.1 12 21 12 21z"/></svg>'
            comment = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h16v12H8l-4 4z"/></svg>'
            comments = b.get("comments", [])
            fake = []
            for c in comments:
                ci = c.get("img")
                cav = (f'<span class="mm-c-avatar"><img src="assets/{A.get(ci,ci)}" alt=""></span>' if ci
                       else f'<span class="mm-c-avatar">{esc(c.get("name","")[:1])}</span>')
                fake.append(f'<div class="mm-comment-item fake">{cav}<span class="mm-c-body">'
                            f'<b>{esc(c.get("name",""))}</b><span>{esc(c.get("text",""))}</span></span></div>')
            likes = esc(b.get("likes", ""))
            likes_html = (f'<div class="mm-likes"><span class="mm-likes-heart">♥</span>'
                          f'<span class="mm-likes-text" data-base="{likes}">{likes}</span></div>') if likes else ""
            out.append(
                '<div class="moments">'
                f'<div class="mm-head">{avatar}<div class="mm-name">{name}</div><div class="mm-time">{time}</div></div>'
                f'<div class="mm-text">{txt}</div>{grid}'
                f'<div class="mm-actions"><button type="button" class="mm-act mm-like" aria-label="点赞" aria-pressed="false">{heart}<span class="mm-act-label">点赞</span></button>'
                f'<button type="button" class="mm-act mm-comment" aria-label="评论" aria-expanded="false">{comment}<span class="mm-act-label">评论</span></button></div>'
                f'{likes_html}'
                '<div class="mm-comment-box"><input class="mm-comment-input" type="text" maxlength="120" placeholder="说点什么…" aria-label="评论内容">'
                '<button type="button" class="mm-comment-send">发送</button></div>'
                f'<div class="mm-comments" aria-live="polite">{"".join(fake)}</div><p class="mm-feedback" role="status"></p>'
                '</div>'
            )
        elif t == "steps":
            items = []
            for i, it in enumerate(b["items"], 1):
                body = f'<div class="step-body">{nl2br(it.get("body",""))}</div>' if it.get("body") else ""
                items.append(f'<li class="step"><span class="step-n">{esc(it.get("num", i))}</span>'
                             f'<div><h4 class="step-title">{nl2br(it.get("title",""))}</h4>{body}</div></li>')
            out.append('<ol class="steps">' + "".join(items) + '</ol>')
        elif t == "china_map":
            out.append(china_map.render(b))
        elif t == "resources":
            out.append(portal_layout.render(b,A))
        elif t == "imgs":
            out.append(gallery_layouts.render(b,img))
        elif t == "img":
            out.append(img(b["src"], b.get("cls",""), b.get("cap","")))
        elif t == "quote":
            if b.get("reveal"):
                # 默认收起，点击后才揭晓的金句
                label = b.get("label", "升级方向")
                btn = b.get("btn", "点开看看")
                out.append(f'<details class="quote-reveal"><summary>'
                           f'<span class="qr-title">{esc(label)}</span>'
                           f'<span class="qr-btn" aria-hidden="true">{esc(btn)}'
                           f'<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" '
                           f'stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round">'
                           f'<path d="M9 6l6 6-6 6"/></svg></span></summary>'
                           f'<blockquote class="quote">{nl2br(b["v"], b.get("keep_phrases"))}</blockquote></details>')
            else:
                out.append(f'<blockquote class="quote">{nl2br(b["v"], b.get("keep_phrases"))}</blockquote>')
        elif t == "note":
            out.append(f'<div class="attach-note"><span class="attach-ico">📎</span><div>{nl2br(b["v"], b.get("keep_phrases"))}</div></div>')
        elif t == "faq":
            items = []
            for it in b["items"]:
                principle = f'<div class="faq-principle"><b>应答思路</b>{nl2br(it["principle"])}</div>' if it.get("principle") else ""
                cid = "cp-" + hashlib.md5(it["q"].encode()).hexdigest()[:8]
                copy = (f'<span class="copy"><button type="button" class="copy-button" command="--copy" commandfor="{cid}" data-copy-target="{cid}" aria-label="复制话术">'
                        f'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 8h10M9 12h10M9 16h10M5 8h.01M5 12h.01M5 16h.01" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>'
                        f'</button><span class="tip" role="status"></span></span>')
                ans = (f'<div class="faq-answer"><span class="copy-text" id="{cid}">{nl2br(it["answer"])}</span>{copy}</div>'
                       if it.get("answer") else "")
                items.append(f'<details class="faq"><summary><span class="faq-q">{nl2br(it["q"])}</span></summary>'
                             f'<div class="faq-inner">{principle}{ans}</div></details>')
            out.append('<div class="faq-list">' + "".join(items) + '</div>')
        elif t == "total":
            """合计汇总条：把总量从明细卡里拎出来，单独一层。
            item = {v, label, suffix?}"""
            cells = []
            for it in b.get("items", []):
                suf = f'<span class="tt-suf">{esc(it["suffix"])}</span>' if it.get("suffix") else ""
                cells.append(f'<div class="tt-cell"><span class="tt-v">{esc(it.get("v", ""))}{suf}</span>'
                             f'<span class="tt-l">{esc(it.get("label", ""))}</span></div>')
            out.append(
                '<div class="tt"><div class="tt-head"><span class="tt-tag">合计</span>'
                f'<span class="tt-note">{esc(b.get("note", ""))}</span></div>'
                '<div class="tt-body">' + "".join(cells) + '</div></div>')
        elif t == "roster":
            """分工表：紧凑表格。item = {num, name, note?, who, own, time}"""
            head = b.get("head", ["#", "事项", "执行", "负责", "时间"])
            hi = {str(x) for x in b.get("hi", [])}
            body = []
            for i, it in enumerate(b["items"]):
                num = str(it.get("num", i + 1))
                cls = "rt-row hi" if num in hi or str(i) in hi else "rt-row"
                note = f'<span class="rt-note">{esc(it["note"])}</span>' if it.get("note") else ""
                body.append(
                    f'<tr class="{cls}"><td class="rt-n">{esc(num.zfill(2))}</td>'
                    f'<td class="rt-name">{esc(it.get("name", ""))}{note}</td>'
                    f'<td class="rt-who">{esc(it.get("who", ""))}</td>'
                    f'<td class="rt-own">{esc(it.get("own", ""))}</td>'
                    f'<td class="rt-time">{esc(it.get("time", ""))}</td></tr>')
            cols = "".join(f"<th>{esc(h)}</th>" for h in head)
            cap = b.get("title") or ""
            cap_html = (f'<div class="rt-cap"><b>{esc(cap)}</b>'
                        f'<span>{esc(b.get("meta", ""))}</span></div>') if cap else ""
            out.append(
                '<div class="rt">' + cap_html +
                f'<div class="rt-scroll"><table><thead><tr>{cols}</tr></thead>'
                '<tbody>' + "".join(body) + '</tbody></table></div></div>')
        elif t == "scriptlib":
            """话术拓展库：从 scripts.json 渲染可折叠分组，对话逐条可复制"""
            data = b["data"]  # list of {group, blocks:[{type,text}]}
            groups = []
            for g in data:
                rows = []
                for it in g["blocks"]:
                    if it["type"] == "h":
                        rows.append(f'<div class="sl-h">{esc(it["text"])}</div>')
                    elif it["type"] == "say":
                        cid = "cp-" + hashlib.md5(it["text"].encode()).hexdigest()[:8]
                        who = it.get("who", "")
                        wh = f'<span class="sl-who">{esc(who)}</span>' if who else ""
                        copy = (f'<span class="copy"><button type="button" class="copy-button" command="--copy" commandfor="{cid}" data-copy-target="{cid}" aria-label="复制话术">'
                                f'<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 8h10M9 12h10M9 16h10M5 8h.01M5 12h.01M5 16h.01" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>'
                                f'</button><span class="tip" role="status"></span></span>')
                        rows.append(f'<div class="sl-line">{wh}<span class="copy-text" id="{cid}">{nl2br(it["text"])}</span>{copy}</div>')
                    else:
                        rows.append(f'<p class="sl-p">{nl2br(it["text"])}</p>')
                gopen = " open" if b.get("open") else ""
                if b.get("flat"):
                    groups.append(f'<div class="sl-group sl-flat"><div class="sl-flat-h"><span>{esc(g["group"])}</span>'
                                  f'<span class="sl-count">{g.get("count", "")}</span></div>'
                                  f'<div class="sl-body">' + "".join(rows) + '</div></div>')
                else:
                    groups.append(f'<details class="sl-group"{gopen}><summary><span>{esc(g["group"])}</span><span class="sl-count">{g.get("count","")}</span></summary>'
                                  f'<div class="sl-body">' + "".join(rows) + '</div></details>')
            out.append('<div class="scriptlib">' + "".join(groups) + '</div>')
        elif t == "divider":
            out.append('<hr class="divider">')
    return "\n".join(out)

# ---------- 下载抽屉 ----------
def render_dock(attachments, note=""):
    """attachments: [{name, path, kind}]，kind ∈ local | netdisk | pending | link。
    note: 抽屉底部说明文案，来自 config['dock_note']。"""
    rows = []
    for a in attachments:
        name, path, kind = a["name"], a.get("path", ""), a["kind"]
        if kind == "local":
            rows.append(f'<a class="dl-row" href="{esc(path)}" download><span class="dl-ico">📄</span>'
                        f'<span class="dl-name">{esc(name)}</span><span class="dl-go">下载</span></a>')
        elif kind == "netdisk":
            rows.append(f'<a class="dl-row" href="{esc(path)}" target="_blank" rel="noopener noreferrer">'
                        f'<span class="dl-ico">📦</span>'
                        f'<span class="dl-name">{esc(name)}</span><span class="dl-go">网盘下载</span></a>')
        elif kind == "link":
            rows.append(f'<a class="dl-row" href="{esc(path)}" target="_blank" rel="noopener noreferrer">'
                        f'<span class="dl-ico">🔗</span>'
                        f'<span class="dl-name">{esc(name)}</span><span class="dl-go">打开</span></a>')
        elif kind == "pending":
            rows.append(f'<div class="dl-row dl-pending"><span class="dl-ico">📦</span>'
                        f'<span class="dl-name">{esc(name)}</span><span class="dl-tag">链接待补</span></div>')
    if not rows:
        return ""
    foot = f'<div class="dl-foot">{nl2br(note)}</div>' if note else ""
    return ('<details class="dl-dock" id="dl-dock"><summary><span class="dl-dock-ico">📎</span>配套附件</summary>'
            '<div class="dl-panel"><div class="dl-title">配套附件下载</div>' + "".join(rows) +
            foot + '</div></details>')

# ---------- CSS ----------
CSS = r"""
:root{
  --brand:#0d3b66; --brand2:#1b5c96; --accent:#2b7fd4; --accent-soft:#e8f1fb;
  --bg:#f4f6f9; --surface:#fff; --text:#1b2733; --muted:#63748a; --border:#e2e8f0;
  --green:#1f8a5b; --green-soft:#e8f6ef; --red:#c0392b; --red-soft:#fdecea;
  --amber:#9a6b12; --amber-soft:#fdf3e0; --radius:14px; --shadow:0 2px 14px rgba(16,42,71,.07);
  --sans:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB","Microsoft YaHei",sans-serif;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--text);font-family:var(--sans);font-size:16px;line-height:1.75;-webkit-font-smoothing:antialiased}
a{color:inherit}
/* 顶栏 */
.topbar{position:sticky;top:0;z-index:50;height:60px;background:rgba(255,255,255,.94);backdrop-filter:saturate(1.6) blur(10px);
  border-bottom:1px solid var(--border);display:flex;align-items:center;gap:16px;padding:0 24px}
.brand{display:flex;align-items:center;gap:9px;font-weight:800;font-size:18px;letter-spacing:.04em;color:var(--brand);white-space:nowrap}
.brand-mark{width:26px;height:26px;background:var(--brand);color:#fff;border-radius:6px;display:grid;place-items:center;font-size:12px;font-weight:900}
.brand-logo{height:26px;width:auto;display:block}
.brand-text{font-size:16px;font-weight:800;color:var(--brand);white-space:nowrap}
.topbar-title{font-size:14px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.topbar-sp{flex:1}
.home-btn{flex:none;display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 13px;border:1px solid var(--border);
  background:#fff;color:var(--brand2);border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;text-decoration:none;transition:background .15s,border-color .15s}
.home-btn:hover{background:var(--accent-soft);border-color:var(--accent)}
.home-btn svg{width:17px;height:17px}
.search-box{position:relative;flex:none}
.search-box input{width:210px;height:36px;border:1px solid var(--border);background:#fff;border-radius:9px;padding:0 12px 0 34px;font-size:13px;outline:none;transition:border .15s,box-shadow .15s}
.search-box input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--accent-soft)}
/* 键盘焦点统一可见（鼠标点击不显示） */
:where(a,button,summary,input,[tabindex]):focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:6px}
.section:focus{outline:none}
.search-box svg{position:absolute;left:10px;top:9px;width:17px;height:17px;color:var(--muted)}
.menu-btn{display:none;width:38px;height:38px;border:1px solid var(--border);background:#fff;border-radius:9px;font-size:18px;cursor:pointer}
/* 布局 */
.layout{max-width:1360px;margin:0 auto;display:grid;grid-template-columns:248px minmax(0,1fr);gap:32px;padding:28px 24px 96px}
.sidebar{position:sticky;top:88px;align-self:start;max-height:calc(100vh - 110px);overflow:auto;padding-right:6px}
.side-hint{font-size:11px;letter-spacing:.12em;color:var(--muted);margin:4px 10px 12px;font-weight:700}
.nav-group{margin-bottom:2px;border-bottom:1px solid #edf1f6;padding-bottom:6px}
.nav-group summary{list-style:none;cursor:pointer;user-select:none}
.nav-group summary::-webkit-details-marker{display:none}
.nav-group-title{display:flex;align-items:center;justify-content:space-between;font-size:14.5px;font-weight:800;color:var(--brand);padding:10px 10px;letter-spacing:.01em;border-radius:7px}
.nav-group-title:hover{background:#eef3f9;color:var(--brand)}
.nav-group-title::after{content:"▾";font-size:11px;transition:transform .18s;color:#9fb0c4}
.nav-group[open] .nav-group-title::after{transform:rotate(180deg)}
.nav-group-links{padding:2px 0}
.nav-link{display:flex;align-items:center;gap:7px;padding:6px 11px 6px 14px;border-radius:8px;color:#5c7189;text-decoration:none;font-size:13px;line-height:1.4;margin:1px 0;transition:background .12s,color .12s}
.nav-link:hover{background:#eef3f9;color:var(--brand)}
.nav-link.target-current{background:var(--accent-soft);color:var(--brand2);font-weight:700}
.nav-link .nav-dot{width:5px;height:5px;border-radius:50%;background:#b9c6d6;flex:none}
.nav-link.target-current .nav-dot{background:var(--accent)}
main{min-width:0}
/* 章节：一次显示一节（翻页模式） */
.section{scroll-margin-top:84px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);
  box-shadow:var(--shadow);padding:38px 44px;margin-bottom:14px;display:none}
.section.active{display:block}
.section .section-head:first-child{margin-top:0}
/* 翻页导航 */
.pagerbar{position:fixed;left:0;right:0;bottom:0;z-index:40;pointer-events:none;
  background:#f7fafd;
  -webkit-backdrop-filter:saturate(180%) blur(14px);backdrop-filter:saturate(180%) blur(14px)}
.pagerbar::before{content:"";position:absolute;left:0;right:0;bottom:100%;height:20px;
  background:linear-gradient(180deg,rgba(247,250,254,0),#f7fafd);pointer-events:none}
.pager{pointer-events:auto;max-width:1360px;margin:0 auto;
  padding:var(--sp-1) 24px var(--sp-1) 304px;
  display:grid;grid-template-columns:1fr auto 1fr;align-items:center;gap:12px}
.pager>#pager-prev{justify-self:start}
.pager>#pager-next{justify-self:end}
.pager-btn{display:inline-flex;align-items:center;gap:8px;border:1px solid var(--border);background:var(--surface);color:var(--brand2);
  border-radius:10px;padding:9px 16px;font-size:14px;font-weight:700;font-family:inherit;cursor:pointer;
  box-shadow:0 2px 8px rgba(16,42,71,.05);transition:background .15s,border-color .15s}
.pager-pos{font-size:13px;color:var(--muted);font-variant-numeric:tabular-nums}
.pager-pos b{color:var(--brand2);font-size:15px}
.pager-label{display:block;font-size:11px;color:var(--muted);font-weight:500}
.section-head{margin-bottom:22px;padding-bottom:18px;border-bottom:1px solid var(--border)}
.sec-kicker{display:inline-block;font-size:11px;font-weight:800;letter-spacing:.14em;color:var(--accent);background:var(--accent-soft);
  padding:4px 10px;border-radius:20px;margin-bottom:12px}
.section h2{margin:0 0 8px;font-size:26px;line-height:1.35;color:var(--brand);letter-spacing:-.01em}
.sec-sub{margin:0;color:var(--muted);font-size:15px}
.lede{font-size:16.5px;color:#2b3a4b;background:linear-gradient(90deg,var(--accent-soft),transparent);
  border-left:4px solid var(--accent);padding:14px 18px;border-radius:0 10px 10px 0;margin:0 0 22px}
.body-text{margin:0 0 16px;color:#33445a}
.subhead{font-size:17px;color:var(--brand);margin:26px 0 14px;padding-left:11px;border-left:3px solid var(--accent)}
/* 卡片网格 */
.grid{display:grid;gap:16px;margin:0 0 18px}
.grid-2{grid-template-columns:repeat(2,minmax(0,1fr))}
.grid-3{grid-template-columns:repeat(3,minmax(0,1fr))}
.grid-4{grid-template-columns:repeat(4,minmax(0,1fr))}
.card{position:relative;border:1px solid var(--border);border-radius:12px;padding:20px;background:#fcfdfe;transition:box-shadow .15s,transform .15s}
.card:hover{box-shadow:var(--shadow);transform:translateY(-2px)}
.card-num{display:inline-grid;place-items:center;min-width:26px;height:26px;padding:0 6px;border-radius:7px;background:var(--brand);color:#fff;
  font-size:12px;font-weight:800;margin-bottom:10px}
.card-title{font-size:16px;margin:0 0 8px;color:var(--brand2);line-height:1.45;display:flex;align-items:center;gap:9px}
.card-icon{width:22px;height:22px;object-fit:contain;flex:none}
.card-sub{font-size:12px;color:var(--accent);font-weight:700;margin:-3px 0 8px}
.card-body{font-size:14px;color:#455a72;margin:0;line-height:1.7}
.card-img{margin:14px 0 0}
.card-img img{width:100%;border-radius:9px;display:block}
.card-img figcaption{font-size:12px;color:var(--muted);margin-top:7px}
/* 数字统计卡（滚动计数） */
.stat-grid{display:grid;gap:14px;margin:0 0 20px}
.stat-grid-2{grid-template-columns:repeat(2,minmax(0,1fr))}
.stat-grid-3{grid-template-columns:repeat(3,minmax(0,1fr))}
.stat-grid-4{grid-template-columns:repeat(4,minmax(0,1fr))}
.stat-grid-5{grid-template-columns:repeat(5,minmax(0,1fr))}
.stat-card{position:relative;border:1px solid var(--border);border-radius:13px;padding:20px 16px;background:linear-gradient(160deg,#fbfdff,#f2f7fc);text-align:center;overflow:hidden;transition:transform .18s,box-shadow .18s,border-color .18s}
.stat-card::before{content:"";position:absolute;inset:0 0 auto;height:3px;background:linear-gradient(90deg,var(--accent),var(--brand2));opacity:.85}
.stat-card:hover{transform:translateY(-3px);box-shadow:var(--shadow);border-color:#cfe1f5}
.stat-num{font-size:34px;font-weight:900;line-height:1.1;color:var(--brand);letter-spacing:-.01em;font-variant-numeric:tabular-nums;display:inline-flex;align-items:baseline;gap:1px}
.stat-num .stat-suffix{font-size:20px;font-weight:800;color:var(--accent)}
.stat-num .stat-prefix{font-size:20px;font-weight:800;color:var(--accent)}
.stat-label{font-size:13px;color:#41546a;margin-top:8px;font-weight:700;line-height:1.4}
.stat-note{font-size:11.5px;color:var(--muted);margin-top:5px;line-height:1.5}
/* 仅屏幕阅读器可见 */
.sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}
/* 进场动画：小节切换时卡片依次上浮（默认静态，仅在允许动效时启用） */
@media(prefers-reduced-motion:no-preference){
  .section.active .anim-item{animation:riseIn .42s cubic-bezier(.22,.68,.36,1) both;animation-delay:var(--d,0ms)}
}
@keyframes riseIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
/* 顶部阅读进度条：只用 transform 合成，不触发布局 */
.read-progress{position:fixed;top:0;left:0;height:3px;width:100%;background:linear-gradient(90deg,var(--accent),var(--brand2));
  z-index:60;transform:scaleX(var(--p,0));transform-origin:0 50%;transition:transform .18s ease;pointer-events:none;will-change:transform}
@media(prefers-reduced-motion:reduce){.read-progress{transition:none}}
/* 提示卡 */
.callout{border-radius:11px;padding:15px 18px;margin:0 0 18px;border:1px solid}
.callout-label{display:inline-block;font-size:11px;font-weight:800;letter-spacing:.06em;padding:2px 9px;border-radius:6px;margin-bottom:7px}
.callout-body{font-size:14.5px;line-height:1.75}
.callout-blue{background:var(--accent-soft);border-color:#cfe1f5;color:#1c4a7a}
.callout-blue .callout-label{background:var(--accent);color:#fff}
.callout-red{background:var(--red-soft);border-color:#f6cfc9;color:#8d2c20}
.callout-red .callout-label{background:var(--red);color:#fff}
.callout-green{background:var(--green-soft);border-color:#c7e9d7;color:#1c6646}
.callout-green .callout-label{background:var(--green);color:#fff}
.callout-amber{background:var(--amber-soft);border-color:#f0dfb8;color:#7d5710}
.callout-amber .callout-label{background:var(--amber);color:#fff}
/* 对话气泡 */
.chat{background:#f7f9fc;border:1px solid var(--border);border-radius:13px;padding:20px;margin:0 0 18px}
.chat-cap{font-size:13px;color:var(--muted);margin-bottom:16px;text-align:center;font-weight:600}
.bubble-row{display:flex;gap:10px;margin-bottom:14px;align-items:flex-start}
.bubble-row.client{flex-direction:row-reverse}
.avatar{width:38px;height:38px;border-radius:50%;object-fit:cover;flex:none;border:2px solid #fff;box-shadow:0 1px 5px rgba(0,0,0,.12)}
.avatar-ph{display:grid;place-items:center;background:#e6effa;color:#3f7fb8;font-size:14px;font-weight:800;overflow:hidden}
.avatar-ph svg{width:22px;height:22px;fill:currentColor}
.avatar-ph.client{background:#eef2f7;color:#93a7ba}
.bubble{position:relative;max-width:min(78%,620px);background:#fff;border:1px solid #dfe7f0;border-radius:4px 13px 13px 13px;
  padding:12px 42px 12px 15px;font-size:14.5px;line-height:1.72;box-shadow:0 1px 3px rgba(16,42,71,.04)}
.bubble-row.client .bubble{background:#dceafc;border-color:#cddff4;border-radius:13px 4px 13px 13px}
.bubble .copy{position:absolute;top:7px;right:8px}
/* 仿真微信朋友圈 */
.moments{background:#fff;border:1px solid var(--border);border-radius:14px;padding:22px 24px 16px;margin:0 0 20px;
  box-shadow:0 3px 16px rgba(16,42,71,.06)}
.mm-head{display:flex;align-items:center;gap:12px;margin-bottom:14px}
.mm-avatar{width:44px;height:44px;border-radius:8px;background:linear-gradient(135deg,#2f7fd6,#1b5fa8);flex:none;
  display:grid;place-items:center;overflow:hidden}
.mm-avatar svg{width:30px;height:30px;fill:#fff}
.mm-name{font-size:16px;font-weight:800;color:#1a3a5c;line-height:1.3}
.mm-time{font-size:13px;color:#9aa9bb;margin-left:auto;font-weight:500}
.mm-text{font-size:15px;line-height:1.8;color:#263748;margin:0 0 14px;word-break:break-word}
.mm-photos{display:grid;gap:4px;margin:0 0 14px;max-width:520px}
.mm-photos-1{grid-template-columns:1fr;max-width:340px}
.mm-photos-2{grid-template-columns:repeat(2,1fr);max-width:400px}
.mm-photos-3{grid-template-columns:repeat(3,1fr)}
.mm-photo{width:100%;aspect-ratio:1/1;object-fit:cover;border-radius:5px;background:#eef2f7;display:block;cursor:zoom-in}
.mm-actions{display:flex;gap:20px;border-top:1px solid #eef2f7;padding-top:12px}
.mm-act{width:26px;height:26px;display:grid;place-items:center;color:#aab7c6}
.mm-act svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linejoin:round;stroke-linecap:round}
/* 步骤 */
.steps{list-style:none;padding:0;margin:0 0 18px;display:grid;gap:12px}
.step{display:flex;gap:14px;background:#fcfdfe;border:1px solid var(--border);border-radius:11px;padding:15px 17px}
.step-n{flex:none;width:30px;height:30px;border-radius:9px;background:var(--accent-soft);color:var(--brand2);font-weight:800;
  font-size:13px;display:grid;place-items:center}
.step-title{font-size:15px;margin:2px 0 4px;color:var(--brand2)}
.step-body{font-size:14px;color:#4a5e75;line-height:1.68}
/* 图片画廊 */
.gallery{display:grid;gap:14px;margin:0 0 18px}
.gallery-2{grid-template-columns:repeat(2,1fr)} .gallery-3{grid-template-columns:repeat(3,1fr)} .gallery-4{grid-template-columns:repeat(4,1fr)}
.gallery-item{margin:0;background:#f7f9fc;border:1px solid var(--border);border-radius:10px;padding:8px;display:flex;flex-direction:column}
.gallery-item img{width:100%;object-fit:contain;border-radius:6px;display:block;cursor:zoom-in;background:#fff;transition:opacity .15s}
.gallery-1 .gallery-item img{height:300px} .gallery-2 .gallery-item img{height:210px} .gallery-3 .gallery-item img{height:170px} .gallery-4 .gallery-item img{height:140px}
.gallery-item img:hover{opacity:.9}
.gallery-item figcaption{font-size:12px;color:var(--muted);margin-top:8px;line-height:1.45;text-align:center;min-height:34px}
figure:not(.gallery-item) img{max-width:100%;height:auto;object-fit:contain;border-radius:10px;display:block;border:1px solid var(--border);cursor:zoom-in}
figure figcaption{font-size:12.5px;color:var(--muted);margin-top:8px}
/* 点击放大 lightbox */
.lightbox{position:fixed;inset:0;z-index:200;border:0;padding:0;background:rgba(8,20,34,.9);align-items:center;justify-content:center}
.lightbox[open]{display:flex}
.lightbox:modal{overscroll-behavior:contain}
.lightbox::backdrop{overflow:hidden;overscroll-behavior:contain}
.lightbox img{max-width:94vw;max-height:90vh;object-fit:contain;border-radius:8px;box-shadow:0 20px 70px rgba(0,0,0,.5)}
.lightbox-close{position:absolute;top:18px;right:22px;width:42px;height:42px;border-radius:50%;border:0;background:rgba(255,255,255,.15);
  color:#fff;font-size:26px;cursor:pointer;line-height:1;display:grid;place-items:center}
.lightbox-close:hover{background:rgba(255,255,255,.28)}
.lb-prev,.lb-next{position:absolute;top:50%;transform:translateY(-50%);width:52px;height:52px;border-radius:50%;border:0;
  background:rgba(255,255,255,.14);color:#fff;font-size:34px;line-height:1;cursor:pointer;display:grid;place-items:center;
  transition:background .15s,transform .15s;backdrop-filter:blur(4px)}
.lb-prev{left:3vw}.lb-next{right:3vw}
.lb-prev:hover,.lb-next:hover{background:rgba(255,255,255,.3);transform:translateY(-50%) scale(1.06)}
.lb-prev[hidden],.lb-next[hidden]{display:none}
.lightbox-cap{position:absolute;bottom:20px;left:50%;transform:translateX(-50%);color:rgba(255,255,255,.85);font-size:13px;
  background:rgba(0,0,0,.4);padding:6px 16px;border-radius:20px;max-width:80vw;text-align:center}
/* 金句 / 提示 / 分割 */
.quote{margin:0 0 18px;padding:20px 24px;background:linear-gradient(135deg,var(--brand),var(--brand2));color:#fff;border-radius:12px;
  font-size:18px;line-height:1.6;font-weight:600;text-align:center}
/* 点击揭晓金句：大标题 + 闪动按钮引导 */
.quote-reveal{border:1px solid var(--border);border-radius:14px;background:#f8fbff;margin:0 0 18px;overflow:hidden}
.quote-reveal summary{list-style:none;cursor:pointer;display:flex;align-items:center;justify-content:space-between;gap:16px;
  padding:18px 22px;user-select:none;transition:background .15s}
.quote-reveal summary::-webkit-details-marker{display:none}
.quote-reveal summary:hover{background:#eef4fb}
.qr-title{font-size:21px;font-weight:800;color:var(--brand);letter-spacing:.01em}
.qr-btn{display:inline-flex;align-items:center;gap:4px;padding:9px 16px;border-radius:22px;
  background:var(--accent);color:#fff;font-size:13.5px;font-weight:700;flex:none;
  animation:qrPulse 2.1s ease-out infinite}
.qr-btn svg{margin-right:-2px}
.quote-reveal summary:hover .qr-btn{background:var(--brand2)}
.quote-reveal[open] .qr-btn{display:none}
.quote-reveal[open] summary{padding-bottom:14px;border-bottom:1px dashed var(--border)}
.quote-reveal .quote{margin:0;border-radius:0 0 13px 13px}
@keyframes qrPulse{0%{box-shadow:0 0 0 0 rgba(43,127,212,.42)}70%{box-shadow:0 0 0 11px rgba(43,127,212,0)}100%{box-shadow:0 0 0 0 rgba(43,127,212,0)}}
@media (prefers-reduced-motion:reduce){.qr-btn{animation:none}}
@media(max-width:600px){.qr-title{font-size:17px}.quote-reveal summary{padding:14px 16px}.qr-btn{padding:8px 13px;font-size:12.5px}}
.attach-note{display:flex;gap:10px;align-items:flex-start;background:var(--amber-soft);border:1px solid #f0dfb8;color:#7d5710;
  border-radius:10px;padding:12px 16px;font-size:13.5px;margin:0 0 16px}
.attach-ico{font-size:16px;line-height:1.4}
.divider{border:0;border-top:1px dashed var(--border);margin:26px 0}
/* FAQ 折叠 */
.faq-list{display:grid;gap:9px;margin-bottom:16px}
.faq{border:1px solid var(--border);border-radius:10px;background:#fcfdfe;overflow:hidden}
.faq summary{cursor:pointer;padding:13px 16px;font-weight:650;color:var(--brand2);list-style:none;display:flex;align-items:center;gap:9px}
.faq summary::-webkit-details-marker{display:none}
.faq summary::before{content:"+";width:20px;height:20px;border-radius:6px;background:var(--accent-soft);color:var(--accent);
  display:grid;place-items:center;font-weight:800;flex:none}
.faq[open] summary::before{content:"−"}
.faq-inner{padding:0 16px 16px 45px}
.faq-principle{font-size:13.5px;color:#5a6b80;background:#f4f7fb;border-radius:8px;padding:10px 13px;margin-bottom:12px}
.faq-principle b{color:var(--brand2);margin-right:8px}
.faq-answer{position:relative;font-size:14px;line-height:1.75;background:#eef4fb;border:1px solid #dbe8f6;border-radius:9px;padding:13px 46px 13px 14px}
/* 话术库 */
.scriptlib{display:grid;gap:9px}
.sl-group{border:1px solid var(--border);border-radius:10px;background:#fcfdfe;overflow:hidden}
.sl-flat-h{display:flex;align-items:center;padding:13px 16px;font-size:13.5px;font-weight:800;color:var(--brand);
  background:linear-gradient(180deg,#f6fafd,#fcfdfe)}
.sl-flat .sl-body{padding-top:12px}
.sl-group summary{cursor:pointer;padding:12px 16px;font-weight:700;color:var(--brand2);list-style:none;display:flex;justify-content:space-between;align-items:center}
.sl-group summary::-webkit-details-marker{display:none}
.sl-group summary::after{content:"展开";font-size:11px;color:var(--muted);font-weight:600}
.sl-group[open] summary::after{content:"收起"}
.sl-count{font-size:11px;color:var(--muted);font-weight:500;margin-left:auto;margin-right:10px}
.sl-body{padding:4px 16px 16px;border-top:1px solid var(--border)}
.sl-h{font-size:14px;font-weight:800;color:var(--brand);margin:16px 0 8px;padding-left:10px;border-left:3px solid var(--accent)}
.sl-p{font-size:13.5px;color:#4a5e75;margin:6px 0;line-height:1.7}
.sl-line{position:relative;font-size:14px;line-height:1.72;background:#f4f8fc;border-radius:8px;padding:10px 46px 10px 13px;margin:6px 0;color:#2f4056}
.sl-who{display:inline-block;font-size:11px;font-weight:800;color:var(--accent);margin-right:9px;background:var(--accent-soft);padding:1px 7px;border-radius:5px}
/* 复制按钮（copy-button 指南） */
.copy-wrap{position:relative;margin-top:12px;padding:11px 42px 12px 14px;background:#f6f9fd;
  border-left:3px solid #cfe1f5;border-radius:8px}
.copy-wrap .copy{position:absolute;top:6px;right:6px}
.copy-wrap .copy-text{font-size:14px;line-height:1.8;color:#33475c}
.copy-wrap+.card-body{margin-top:9px!important;font-size:12.5px!important;color:#7b8fa4!important;line-height:1.7}
.copy{position:relative;display:inline-grid;place-items:center}
.copy-button{min-inline-size:26px;min-block-size:26px;width:26px;height:26px;border:1px solid var(--border);background:#fff;color:var(--muted);
  border-radius:7px;cursor:pointer;display:grid;place-items:center;transition:color .15s,background .15s,border .15s}
.copy-button:hover{color:var(--accent);border-color:var(--accent);background:var(--accent-soft)}
.copy-button svg{width:15px;height:15px}
.copy-button[data-copied]{color:var(--green);border-color:var(--green);background:var(--green-soft)}
.copy-button[data-failed]{color:var(--red);border-color:var(--red);background:var(--red-soft)}
.copy-button[data-copied] svg{display:none}
.copy-button[data-copied]::after{content:"✓";font-weight:900;font-size:15px}
.tip{position:absolute;bottom:calc(100% + 6px);left:50%;transform:translateX(-50%);background:#22364a;color:#fff;font-size:11px;
  padding:3px 8px;border-radius:6px;white-space:nowrap;opacity:0;transition:opacity .15s;pointer-events:none}
.copy-button[data-copied] ~ .tip,.copy-button[data-failed] ~ .tip{opacity:1}
.copy-text{white-space:pre-wrap}
/* 下载抽屉 */
.dl-dock{position:fixed;right:20px;bottom:20px;z-index:60;transition:bottom .2s}
body.viewing .dl-dock{bottom:calc(var(--sp-5) + var(--sp-6))}   /* 跟随文字缩放，始终高于底栏 */
.dl-dock>summary{list-style:none;cursor:pointer;background:var(--brand);color:#fff;border-radius:24px;
  height:42px;padding:0 16px;font-size:13.5px;font-weight:700;display:inline-flex;align-items:center;gap:7px;
  box-shadow:0 6px 18px rgba(13,59,102,.26);transition:background .15s,box-shadow .15s}
.dl-dock>summary:hover{background:var(--brand2);box-shadow:0 8px 22px rgba(13,59,102,.32)}
.dl-dock[open]>summary{background:var(--brand2)}
.dl-dock>summary::-webkit-details-marker{display:none}
.dl-dock-ico{font-size:15px;line-height:1}
.dl-panel{position:absolute;right:0;bottom:calc(100% + 10px);width:310px;background:#fff;border:1px solid var(--border);border-radius:13px;
  box-shadow:0 12px 40px rgba(16,42,71,.18);padding:14px;max-height:70vh;overflow:auto}
.dl-title{font-size:13px;font-weight:800;color:var(--brand);margin-bottom:9px}
.dl-row{display:flex;align-items:center;gap:9px;padding:9px 10px;border-radius:8px;text-decoration:none;color:var(--text);font-size:13px;border:1px solid transparent}
.dl-row:hover{background:#f4f8fc;border-color:var(--border)}
.dl-ico{font-size:15px}.dl-name{flex:1;line-height:1.4}
.dl-go{font-size:11px;color:var(--accent);font-weight:700}
.dl-pending{opacity:.72;cursor:default}
.dl-tag{font-size:10.5px;color:var(--amber);background:var(--amber-soft);padding:2px 7px;border-radius:5px;white-space:nowrap}
.dl-foot{font-size:11px;color:var(--muted);border-top:1px solid var(--border);padding-top:9px;margin-top:6px;line-height:1.5}
/* 封面：独立全屏开场页 */
.cover{position:fixed;inset:0;z-index:100;display:flex;align-items:center;justify-content:center;
  background:#dce9f7 url('assets/cover-wave.png') center center/cover no-repeat;padding:32px;overflow:auto}
.cover::before{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(235,244,252,.5),rgba(16,60,105,.26))}
.cover-inner{position:relative;z-index:1;background:rgba(255,255,255,.95);backdrop-filter:blur(16px);
  border:1px solid rgba(255,255,255,.9);border-radius:20px;padding:44px 52px 46px;max-width:720px;width:100%;
  text-align:center;box-shadow:0 24px 70px rgba(10,45,80,.22)}
.cover-logo{height:44px;width:auto;display:block;margin:0 auto 26px}
.cover-brand-text{font-size:20px;font-weight:800;letter-spacing:.08em;color:var(--brand);margin:0 auto 26px}
.cover-kicker{display:inline-flex;align-items:center;gap:10px;font-size:11px;letter-spacing:.18em;color:var(--accent);font-weight:800;margin-bottom:16px}
.cover-kicker::before,.cover-kicker::after{content:"";width:22px;height:2px;background:var(--accent);border-radius:2px;opacity:.6}
.cover h1{font-size:40px;line-height:1.3;margin:0 0 16px;letter-spacing:-.02em;color:var(--brand)}
.cover p{font-size:16px;color:#395679;margin:0 0 20px;line-height:1.75;font-weight:500}
.cover-meta{font-size:12px;color:#8296ad;letter-spacing:.08em;margin-bottom:30px}
.cover-start{display:inline-flex;align-items:center;gap:10px;border:0;cursor:pointer;background:var(--brand);color:#fff;
  font-size:15px;font-weight:700;letter-spacing:.04em;padding:14px 30px;border-radius:30px;
  box-shadow:0 8px 22px rgba(13,59,102,.28);transition:transform .15s,background .15s}
.cover-start:hover{background:var(--brand2);transform:translateY(-2px)}
.cover-start .cs-arrow{font-size:18px;line-height:1}
body.viewing .cover{display:none}
/* 封面态：隐藏正文 UI，只留封面 */
body:not(.viewing) .topbar,body:not(.viewing) .layout,body:not(.viewing) .dl-dock,body:not(.viewing) .read-progress{display:none}
body{overflow-x:hidden}
/* 相关章节交叉引用 */
.xref{margin-top:26px;padding-top:18px;border-top:1px dashed var(--border)}
.xref-hd{font-size:12px;font-weight:800;color:var(--muted);letter-spacing:.06em;margin-bottom:11px;display:flex;align-items:center;gap:7px}
.xref-hd::before{content:"↗";color:var(--accent);font-size:14px}
.xref-list{display:flex;flex-wrap:wrap;gap:8px}
.xref-chip{border:1px solid #cfe0f2;background:#f2f7fc;color:var(--brand2);border-radius:20px;padding:7px 14px;
  font-size:13px;font-weight:600;cursor:pointer;transition:background .14s,border .14s}
.xref-chip:hover{background:var(--accent-soft);border-color:var(--accent)}
.xref-chip .xc-arrow{opacity:.55;margin-left:4px}
/* 搜索无结果 */
.no-result{display:none;text-align:center;color:var(--muted);padding:50px 20px}
.no-result.show{display:block}
/* 响应式 */
@media(max-width:960px){
  .layout{grid-template-columns:1fr;gap:16px;padding:18px 14px 90px}
  .pager{padding:var(--sp-1) 14px;gap:8px}
  .pager-btn{padding:8px 12px;font-size:13px}
  .sidebar{position:fixed;top:60px;left:0;bottom:0;width:274px;background:#fff;z-index:45;transform:translateX(-102%);
    transition:transform .22s;box-shadow:6px 0 24px rgba(16,42,71,.12);max-height:none;padding:18px 14px}
  .sidebar.open{transform:none}
  .menu-btn{display:grid;place-items:center}
  .topbar{padding:0 14px;gap:10px}
  .topbar-title{display:none}
  .home-btn span{display:none}
  .home-btn{padding:0 10px}
  .search-box input{width:150px}
  .section{padding:24px 20px}
  .section h2{font-size:22px}
  .cover{padding:18px}
  .cover-inner{padding:30px 24px}
  .cover h1{font-size:29px}
  .grid-3,.grid-4{grid-template-columns:repeat(2,minmax(0,1fr))}
  .stat-grid-4,.stat-grid-5{grid-template-columns:repeat(3,minmax(0,1fr))}
  .bubble{max-width:86%}
}
@media(max-width:600px){
  .grid-2,.grid-3,.grid-4{grid-template-columns:1fr}
  .stat-grid-2,.stat-grid-3,.stat-grid-4,.stat-grid-5{grid-template-columns:repeat(2,minmax(0,1fr))}
  .stat-card{padding:16px 12px}
  .stat-num{font-size:24px}
  .gallery-3,.gallery-4{grid-template-columns:repeat(2,1fr)}
  .search-box input{width:118px}
  .topbar .search-box{display:none}
  .brand{font-size:15px}
  .cover h1{font-size:24px}
  .cover-inner{padding:26px 20px}
  .cover-logo{height:36px}
  .faq-inner{padding-left:16px}
}
@media print{
  .sidebar,.topbar,.dl-dock,.copy,.pager,.cover,.xref{display:none!important}
  body:not(.viewing) .layout{display:block!important}
  .layout{display:block;padding:0}
  .section{display:block!important;box-shadow:none;border:none;page-break-inside:avoid}
}
/* 左右对照卡（现状 → 需要） */
.cmp-list{display:grid;gap:12px;margin:0 0 18px}
.cmp-list[style*="repeat(2"] .cmp-body{grid-template-columns:1fr auto 1fr;gap:8px}
.cmp-list[style*="repeat(2"] .cmp-side{padding:9px 10px}
.cmp-list[style*="repeat(2"] .cmp-side p{font-size:12.5px}
.cmp-card{border:1px solid var(--border);border-radius:13px;background:#fff;padding:16px 18px 18px}
.cmp-head{display:flex;align-items:center;gap:9px;margin-bottom:12px}
.cmp-num{width:23px;height:23px;border-radius:7px;background:var(--accent-soft);color:var(--brand2);
  display:grid;place-items:center;font-size:11.5px;font-weight:800;flex:none}
.cmp-head h4{margin:0;font-size:15.5px;color:var(--brand);font-weight:800;line-height:1.4}
.cmp-body{display:grid;grid-template-columns:1fr auto 1fr;gap:12px;align-items:stretch}
.cmp-side{border-radius:10px;padding:10px 13px 11px;background:#f6f9fd}
.cmp-side p{margin:0;font-size:13.5px;line-height:1.72;color:#42586d}
.cmp-tag{display:inline-block;font-size:10.5px;font-weight:800;letter-spacing:.05em;
  padding:2px 7px;border-radius:5px;margin-bottom:6px}
.cmp-now .cmp-tag{background:#e6edf5;color:#5f7488}
.cmp-need{background:#eff6fd}
.cmp-need .cmp-tag{background:#d5e8fa;color:#1a5c96}
.cmp-arrow{align-self:center;color:#c2d2e2;font-size:15px;font-weight:700}
@media(max-width:640px){.cmp-body{grid-template-columns:1fr;gap:8px}.cmp-arrow{display:none}}
/* 单选高亮、Tab、地铁报站、朋友圈互动、移动端拦截（实战沉淀） */
.nav-link.nav-bare{margin:0;padding:10px 10px;font-weight:800;color:var(--brand);font-size:15px;
  letter-spacing:.01em;border-radius:8px}
.nav-link.nav-bare .nav-dot{background:var(--accent)}
.nav-flat{border-bottom:1px solid #edf1f6;padding:1px 0}
.nav-flat:last-child{border-bottom:0}
.pick-grid{margin:0 0 18px}
.pick-card{position:relative;border:1px solid var(--border);border-radius:12px;padding:20px;background:#fcfdfe;
  cursor:pointer;overflow:hidden;transition:background .18s,border-color .18s,box-shadow .18s,transform .18s}
.pick-card::before{content:"";position:absolute;left:0;top:0;bottom:0;width:4px;background:transparent;transition:background .18s}
.pick-card:hover{border-color:var(--accent);box-shadow:0 3px 12px rgba(16,42,71,.09);transform:translateY(-2px)}
.pick-card.on{background:#e8f1fc;border-color:var(--accent);box-shadow:0 6px 18px rgba(43,127,212,.18)}
.pick-card.on::before{background:linear-gradient(180deg,var(--accent),var(--brand))}
.pick-card.on .card-title{color:var(--brand);font-weight:800}
.pick-card:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.tabset{border:1px solid var(--border);border-radius:13px;background:var(--surface);padding:16px;margin:0 0 18px}
.tab-heads{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px}
.tab-head{border:1px solid var(--border);background:#f8fafc;color:#5c6d80;border-radius:20px;padding:8px 14px;
  font-size:13px;font-weight:700;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;gap:7px}
.tab-head.on{background:var(--accent);border-color:var(--accent);color:#fff}
.tab-hnum{font-size:11px;opacity:.8}
.tab-panel{display:none}.tab-panel.on{display:block;animation:tabIn .24s ease both}
.tab-panel>.grid{min-height:150px;align-content:start}
.tab-panel>.grid-1 .card{padding:24px 30px;background:linear-gradient(150deg,#fbfdff,#f4f9fe);border-radius:14px;
  display:flex;flex-direction:column;justify-content:center}
.tab-panel>.grid-1 .card>.card-num{align-self:flex-start;margin-bottom:10px}
.tab-panel>.grid-1 .card-title{font-size:19px;margin-bottom:10px}
.tab-panel>.grid-1 .card-sub{font-size:14.5px;font-weight:700;margin-bottom:8px}
.tab-panel>.grid-1 .card-body{max-width:60ch;font-size:14.5px;line-height:1.85;color:#4a6076}
@media(max-width:600px){.tab-panel>.grid-1 .card{padding:18px 18px}.tab-panel>.grid-1 .card-title{font-size:17px}}
.tab-panel .moments{margin-bottom:0}
/* 合计汇总条 */
.tt{display:flex;flex-wrap:wrap;align-items:center;gap:18px 26px;border-radius:13px;padding:14px 20px;
  background:linear-gradient(100deg,#0d3b66,#1b5c96);color:#fff;margin:0 0 18px}
.tt-head{display:flex;align-items:center;gap:10px;flex:none}
.tt-tag{font-size:12px;font-weight:800;letter-spacing:.14em;color:#cfe4f8;border:1px solid rgba(255,255,255,.35);
  border-radius:6px;padding:3px 9px}
.tt-note{font-size:11.5px;color:rgba(255,255,255,.6);font-weight:600}
.tt-body{display:flex;flex-wrap:wrap;gap:12px 34px;flex:1}
.tt-cell{display:flex;align-items:baseline;gap:7px}
.tt-v{font-size:23px;font-weight:800;letter-spacing:-.01em;font-variant-numeric:tabular-nums;line-height:1.1}
.tt-suf{font-size:13px;font-weight:700;margin-left:1px}
.tt-l{font-size:12px;color:rgba(255,255,255,.72);font-weight:600}
@media(max-width:600px){.tt{padding:12px 14px;gap:12px 18px}.tt-v{font-size:20px}}
/* 分工表：紧凑表格 */
.rt{border:1px solid var(--border);border-radius:13px;background:var(--surface);overflow:hidden;margin:0 0 18px}
.rt-cap{display:flex;align-items:baseline;justify-content:space-between;gap:12px;padding:12px 16px 10px;
  background:linear-gradient(180deg,#f7fbff,#fff);border-bottom:1px solid var(--border)}
.rt-cap b{font-size:14.5px;font-weight:800;color:var(--brand)}
.rt-cap span{font-size:11.5px;color:var(--muted);font-weight:600}
.rt-scroll{overflow-x:auto}
.rt table{width:100%;border-collapse:collapse;font-size:13px}
.rt thead th{padding:8px 12px;text-align:left;font-size:11px;font-weight:800;letter-spacing:.07em;
  color:#8fa2b6;background:#f6f9fc;border-bottom:1px solid var(--border);white-space:nowrap}
.rt tbody td{padding:9px 12px;border-bottom:1px solid #eef3f8;color:#42586d;line-height:1.5}
.rt tbody tr:last-child td{border-bottom:0}
.rt tbody tr:hover td{background:#fafdff}
.rt-n{width:42px;font-weight:800;color:#a6b6c7;font-variant-numeric:tabular-nums}
.rt-name{font-weight:700;color:var(--brand);min-width:180px}
.rt-note{display:inline;font-weight:500;font-size:11.5px;color:#9aa9bb;margin-left:7px}
.rt-who,.rt-own{white-space:nowrap}
.rt-time{white-space:nowrap;font-variant-numeric:tabular-nums;color:#5c7189}
.rt-row.hi td{background:#fffaf1}
.rt-row.hi .rt-n{color:#d08a2a}
.rt-row.hi .rt-name{color:#9a5c12}
@media(max-width:700px){.rt table{font-size:12.5px}.rt tbody td,.rt thead th{padding:8px 9px}}
/* 流程单：一张卡里的紧凑时间轴 */
.rs{border:1px solid var(--border);border-radius:14px;background:var(--surface);overflow:hidden;margin:0 0 18px}
.rs-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px;
  padding:13px 18px 11px;background:linear-gradient(180deg,#f7fbff,#fff);border-bottom:1px solid var(--border)}
.rs-head b{font-size:15.5px;font-weight:800;color:var(--brand);letter-spacing:.01em}
.rs-head span{font-size:11.5px;font-weight:600;color:var(--muted);font-variant-numeric:tabular-nums}
.rs-list{margin:0;padding:8px 18px 12px;list-style:none}
.rs-row{display:grid;grid-template-columns:54px 20px 1fr;align-items:center;
  padding:4px 8px 4px 0;border-radius:8px}
.rs-row.hi{background:#fffaf1;box-shadow:inset 0 0 0 1px #f6e2c4;margin:1px 0}
.rs-t{font-size:13px;font-weight:800;color:var(--brand2);font-variant-numeric:tabular-nums;letter-spacing:.01em}
.rs-rail{position:relative;display:grid;place-items:center;align-self:stretch}
.rs-rail::before{content:"";position:absolute;left:50%;top:-5px;bottom:-5px;width:2px;
  background:#e4ecf5;transform:translateX(-50%)}
.rs-first .rs-rail::before{top:50%}
.rs-last .rs-rail::before{bottom:50%}
.rs-rail i{position:relative;width:8px;height:8px;border-radius:50%;background:#c3d6e9;
  box-shadow:0 0 0 3px var(--surface);display:block}
.rs-row.hi .rs-rail i{background:#e8942c;box-shadow:0 0 0 3px #fffaf1}
.rs-n{font-size:13.5px;color:#42586d;line-height:1.45;padding-left:6px}
.rs-row.hi .rs-n{color:#9a5c12;font-weight:800}
.rs-tag{flex:none;font-size:10.5px;font-weight:800;letter-spacing:.04em;color:#b4690e;
  background:#fdeccd;border-radius:5px;padding:2px 7px;margin-left:10px;white-space:nowrap}
.rs-sep{display:flex;align-items:center;gap:9px;margin:9px 0 3px;font-size:11px;
  font-weight:800;letter-spacing:.08em;color:#9fb0c2}
.rs-sep::after{content:"";flex:1;height:1px;background:linear-gradient(90deg,#e6eef7 60%,transparent)}
@media(max-width:600px){.rs-list{padding:6px 12px 10px}.rs-row{grid-template-columns:46px 18px 1fr}.rs-n{font-size:13px}}
.metro{border:1px solid var(--border);border-radius:13px;background:var(--surface);padding:20px 22px 18px;margin:0 0 18px}
.metro.metro-nav{padding:14px 18px 10px;margin:0 0 16px;background:linear-gradient(180deg,#f8fbff,#fff)}
.metro.metro-nav .metro-detail{display:none}
.metro-board{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-bottom:22px}
.metro-now,.metro-next{font-size:12.5px;font-weight:700;border-radius:20px;padding:6px 13px;white-space:nowrap}
.metro-now{background:var(--accent-soft);color:var(--brand2)}.metro-now b{color:var(--brand)}
.metro-next{background:#f4f6f9;color:#7a8a9d}
.metro-track{position:relative;display:grid;grid-template-columns:repeat(var(--metro-n,4),minmax(0,1fr));padding-bottom:6px;margin-bottom:14px}
.metro-track::before{content:"";position:absolute;left:var(--metro-edge,12.5%);right:var(--metro-edge,12.5%);top:18px;height:4px;border-radius:4px;background:#e4ebf3}
.metro-fill{position:absolute;left:var(--metro-edge,12.5%);top:18px;height:4px;width:0;border-radius:4px;
  background:linear-gradient(90deg,var(--accent),var(--brand))}
.metro-stop{position:relative;border:0;background:transparent;padding:0;cursor:pointer;display:flex;flex-direction:column;
  align-items:center;gap:11px;font-family:inherit;z-index:2}
.metro-dot{width:40px;height:40px;border-radius:50%;background:#fff;border:3px solid #cdd9e7;display:grid;place-items:center;
  box-shadow:0 2px 8px rgba(16,42,71,.08);transition:border-color .25s,background .25s,transform .25s,box-shadow .25s}
.metro-num{font-size:13px;font-weight:900;color:#8698ad}
.metro-label{display:grid;gap:2px;text-align:center;min-width:0}
.metro-label b{font-size:14px;color:#5c6d80;white-space:nowrap}.metro-label small{font-size:12px;color:#9aa9bb;font-weight:600}
.metro-stop.on .metro-dot{background:var(--accent);border-color:var(--brand);transform:scale(1.12);
  box-shadow:0 0 0 5px rgba(43,127,212,.13),0 4px 14px rgba(43,127,212,.3)}
.metro-stop.on .metro-num{color:#fff}.metro-stop.on .metro-label b{color:var(--brand);font-weight:800}
.metro-train{position:absolute;left:var(--metro-edge,12.5%);top:-9px;width:15px;height:15px;border-radius:5px;background:var(--brand);
  border:2px solid #fff;box-shadow:0 2px 9px rgba(13,59,102,.4);transform:translateX(-50%);z-index:1;
  display:none}
.metro-detail{border-top:1px dashed #dce5ef;padding-top:16px}
.metro-panel{display:none;animation:tabIn .3s ease both}.metro-panel.on{display:block}
.metro-panel-body{display:grid;gap:12px}
.metro-panel-head{display:flex;align-items:center;gap:12px}
.metro-panel-num{min-width:38px;height:38px;border-radius:10px;background:var(--accent-soft);color:var(--brand);
  display:grid;place-items:center;font-size:14px;font-weight:900;flex:none}
.metro-panel-title{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}
.metro-panel-title b{font-size:15.5px;color:var(--brand)}.metro-panel-title span{font-size:12.5px;color:var(--accent);font-weight:700}
.metro-list{list-style:none;margin:0;padding:0;display:grid;gap:7px}
.metro-list li{display:flex;align-items:flex-start;gap:10px;font-size:13.5px;color:#455a72;line-height:1.55}
.ml-n{flex:none;min-width:24px;height:22px;padding:0 5px;border-radius:6px;background:#eef4fb;color:var(--brand2);
  font-size:11.5px;font-weight:800;display:grid;place-items:center}
.metro-list li.ml-note{margin-top:2px;padding:8px 11px;border-radius:8px;background:#f6f9fd;color:#5b6d80;font-size:13px}
.metro-goto{justify-self:end;margin-top:0}
.mm-actions{display:flex;gap:10px;align-items:center;border-top:1px solid #eef2f7;padding:10px 0 12px}
.mm-act{height:32px;display:inline-flex;align-items:center;gap:6px;padding:0 9px;border:0;border-radius:8px;
  background:transparent;color:#8494a7;cursor:pointer;position:relative;z-index:2;font-family:inherit;
  transition:background .18s,color .18s,transform .16s}
.mm-act:hover{background:#eef4fb;color:var(--brand2);transform:translateY(-1px)}
.mm-act:active{transform:scale(.94)}
.mm-act-label{font-size:12.5px;font-weight:700;white-space:nowrap}
.mm-act svg{width:20px;height:20px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linejoin:round;stroke-linecap:round;
  transition:transform .22s cubic-bezier(.2,1.4,.4,1)}
.mm-like:hover svg{transform:rotate(-9deg) scale(1.12)}
.mm-comment:hover svg{transform:rotate(6deg) scale(1.08)}
.mm-like.on{color:#f04438}.mm-like.on .mm-act-label{color:#f04438}
.mm-like.on svg{fill:#f04438;stroke:#f04438;animation:likePop .38s cubic-bezier(.2,1.5,.4,1)}
.mm-heart-burst{position:absolute;left:50%;top:50%;pointer-events:none;z-index:8}
.mm-heart{position:absolute;font-style:normal;color:#ff3b5c;opacity:0;animation:mmHeartFly .9s ease-out forwards}
@keyframes likePop{0%{transform:scale(.65)}55%{transform:scale(1.35)}100%{transform:scale(1)}}
@keyframes mmHeartFly{0%{opacity:0;transform:translate(-50%,-50%) scale(.35)}18%{opacity:1}
  100%{opacity:0;transform:translate(calc(-50% + var(--hx)),calc(-50% + var(--hy))) scale(1.15) rotate(var(--hr))}}
.mm-comment-box{display:none;gap:8px;margin-top:12px}.mm-comment-box.open{display:flex;animation:tabIn .24s ease both}
.mm-comment-input{flex:1;min-width:0;border:1px solid var(--border);border-radius:8px;padding:8px 11px;font-size:13px;outline:none;font-family:inherit}
.mm-comment-input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(43,127,212,.1)}
.mm-comment-send{border:0;border-radius:8px;background:var(--accent);color:#fff;font-size:13px;font-weight:700;padding:8px 14px;cursor:pointer;font-family:inherit}
.mm-comments{margin-top:10px;display:grid;gap:6px}
.mm-comment-item{display:flex;align-items:flex-start;gap:9px;font-size:13.5px;color:#33445a;background:#f6f9fd;border-radius:9px;padding:8px 11px;word-break:break-word}
.mm-comment-item.fake{display:none}
.moments.comments-shown .mm-comment-item.fake{display:flex;animation:commentPop .46s cubic-bezier(.2,1.4,.4,1) both}
.moments.comments-shown .mm-comment-item.fake:nth-child(2){animation-delay:.12s}
.moments.comments-shown .mm-comment-item.fake:nth-child(3){animation-delay:.2s}
@keyframes commentPop{from{opacity:0;transform:translateY(10px) scale(.93)}to{opacity:1;transform:none}}
.mm-c-avatar{flex:none;width:26px;height:26px;border-radius:50%;overflow:hidden;background:var(--accent-soft);color:#fff;display:grid;place-items:center;font-size:12px;font-weight:800}
.mm-c-avatar img{width:100%;height:100%;object-fit:cover;display:block}
.mm-c-body{display:grid;gap:2px;min-width:0}.mm-c-body b{color:var(--brand2);font-size:12.5px}
.mm-likes{display:flex;align-items:flex-start;gap:8px;margin:0 0 10px;padding:9px 12px;border-radius:9px;background:#f6f9fd;font-size:12.5px;color:#4d6379;line-height:1.5}
.mm-likes-heart{color:#f04438;font-size:12px;line-height:1.4;flex:none}
.mm-like-me{color:var(--brand);font-weight:800;animation:commentPop .35s ease both}
@keyframes mmHintBtn{0%{transform:none}35%{transform:translateY(-3px) scale(1.05)}70%{transform:translateY(-1px) scale(1.02)}100%{transform:none}}
@keyframes mmHintIcon{0%{transform:none}35%{transform:rotate(-8deg) scale(1.12)}70%{transform:rotate(3deg) scale(1.04)}100%{transform:none}}
.moments.mm-hint .mm-act{animation:mmHintBtn .7s ease .3s 2}
.moments.mm-hint .mm-like svg{animation:mmHintIcon .7s ease .3s 2}
.moments.mm-hint .mm-comment svg{animation:mmHintIcon .7s ease .38s 2}
.mobile-block{display:none}
html.mobile-blocked,html.mobile-blocked body{height:100%;overflow:hidden}
html.mobile-blocked body>*:not(.mobile-block){visibility:hidden!important}
.mobile-block{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;
  padding:28px;background:linear-gradient(160deg,#eaf2fb,#f8fbff);text-align:center}
.mb-card{background:#fff;border:1px solid #dfe8f2;border-radius:20px;padding:34px 26px;max-width:420px;width:100%;
  box-shadow:0 18px 50px rgba(16,42,71,.14)}
.mb-icon{width:64px;height:64px;border-radius:18px;background:var(--accent-soft);color:var(--accent);display:grid;place-items:center;margin:0 auto 18px}
.mb-icon svg{width:34px;height:34px}
.mb-card h2{font-size:22px;color:var(--brand);margin:0 0 10px}
.mb-copy{display:inline-flex;align-items:center;justify-content:center;margin-top:20px;height:42px;padding:0 22px;
  border-radius:22px;background:var(--brand);color:#fff;font-size:14px;font-weight:700;text-decoration:none}
.mb-copy.done{background:#1f9d55}
.mb-card p{font-size:14px;color:#5b6d80;line-height:1.7;margin:0}
.mb-foot{margin-top:18px;font-size:12px;color:#93a1b1;font-weight:700;letter-spacing:.04em}
@media(max-width:760px){.metro-track::before{left:25%;right:25%}.metro-fill,.metro-train{display:none}}
@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;transition:none!important;animation:none!important}}
"""

# 设计基线（Apple HIG 取向）：字阶、间距、圆角、阴影、材质、动效统一到一套令牌上。
# 追加在原 CSS 之后，靠层叠顺序覆盖既有声明，不改动上面的原始规则；
# 需要回到旧版式时，config 里设 "style_preset": "classic" 即可跳过本块。
APPLE_BASE_CSS = r"""
/* ── 令牌：字号用 rem，跟随系统/浏览器文字缩放；间距取 8 的倍数 ── */
:root{
  --fs-title:1.75rem;--fs-h3:1.3125rem;--fs-cardtitle:1.1875rem;
  --fs-lede:1.125rem;--fs-body:1.0625rem;--fs-text:1rem;
  --fs-note:.8125rem;--fs-tag:.6875rem;
  --sp-1:.5rem;--sp-2:.75rem;--sp-3:1rem;--sp-4:1.5rem;--sp-5:2rem;--sp-6:2.5rem;
  --r-ctl:.75rem;--r-card:1rem;
  --dur-fast:120ms;--dur:250ms;--ease:cubic-bezier(.2,0,0,1);
  --radius:1rem;
  --shadow:0 1px 2px rgba(16,42,71,.05),0 8px 24px rgba(16,42,71,.05);
  --shadow-lift:0 1px 2px rgba(16,42,71,.06),0 12px 32px rgba(16,42,71,.08);
}
html{-webkit-text-size-adjust:100%}
body{font-size:var(--fs-body);line-height:1.65}

/* ── 排版层级：字号与字重成对使用，标题靠字重和留白分层，不靠颜色堆 ── */
.section{padding:var(--sp-6) var(--sp-6);border-radius:var(--r-card)}
.section-head{margin-bottom:var(--sp-5);padding-bottom:var(--sp-3)}
.section h2{font-size:var(--fs-title);line-height:1.3;letter-spacing:-.012em;margin:0 0 var(--sp-1)}
.sec-sub{font-size:var(--fs-text);line-height:1.6;margin-top:var(--sp-1)}
.sec-kicker{font-size:var(--fs-tag);letter-spacing:.1em;border-radius:999px;padding:.25rem .625rem;margin-bottom:var(--sp-2)}
.lede{font-size:var(--fs-lede);line-height:1.6;padding:var(--sp-3) var(--sp-4);margin-bottom:var(--sp-4);
  border-radius:0 var(--r-ctl) var(--r-ctl) 0;border-left-width:4px}
.body-text{font-size:var(--fs-body);line-height:1.75;margin-bottom:var(--sp-3)}
.subhead{font-size:var(--fs-h3);line-height:1.4;margin:var(--sp-5) 0 var(--sp-3)}

/* ── 卡片：一档圆角、一档阴影，hover 只上浮 1px 配柔和投影 ── */
.grid{gap:var(--sp-3);margin-bottom:var(--sp-4)}
.card,.pick-card{padding:var(--sp-4);border-radius:var(--r-card);background:#fff;
  transition:box-shadow var(--dur) var(--ease),transform var(--dur) var(--ease)}
.card:hover,.pick-card:hover{transform:translateY(-1px);box-shadow:var(--shadow-lift);border-color:#d9e4f0}
.card-title{font-size:var(--fs-cardtitle);line-height:1.35;margin-bottom:var(--sp-1)}
.card-sub{font-size:var(--fs-note);margin:-.25rem 0 var(--sp-1)}
.card-body{font-size:var(--fs-text);line-height:1.6;color:#3f5468}
.card-num{border-radius:.5rem;font-size:var(--fs-tag)}
.card-img{margin-top:var(--sp-3)}
.card-img img{border-radius:var(--r-ctl)}

/* ── 强调与引用 ── */
.callout{border-radius:var(--r-card);padding:var(--sp-4);margin-bottom:var(--sp-4)}
.callout-body{font-size:var(--fs-body);line-height:1.65}
.callout-label{font-size:var(--fs-tag);border-radius:999px;padding:.1875rem .625rem;margin-bottom:var(--sp-1)}
.quote{font-size:1.375rem;line-height:1.5;padding:var(--sp-5) var(--sp-4);border-radius:var(--r-card);margin-bottom:var(--sp-4)}
.quote-reveal{border-radius:var(--r-card);margin-bottom:var(--sp-4)}
.qr-title{font-size:var(--fs-cardtitle)}
.qr-btn{font-size:var(--fs-note);border-radius:999px;padding:.5rem 1rem}
.attach-note{border-radius:var(--r-ctl);font-size:var(--fs-note);padding:var(--sp-2) var(--sp-3);margin-bottom:var(--sp-3)}
.divider{margin:var(--sp-5) 0}

/* ── 数据 ── */
.stat-grid{gap:var(--sp-3);margin-bottom:var(--sp-4)}
.stat-card{border-radius:var(--r-card);padding:var(--sp-4) var(--sp-3);
  transition:transform var(--dur) var(--ease),box-shadow var(--dur) var(--ease),border-color var(--dur) var(--ease)}
.stat-card:hover{transform:translateY(-2px);box-shadow:var(--shadow-lift)}
.stat-num{font-size:2.25rem}
.stat-label{font-size:var(--fs-note)}
.stat-note{font-size:var(--fs-tag)}
.total,.tt{border-radius:var(--r-card)}

/* ── 表格、流程、对照、报站 ── */
.rt,.rs,.cmp-card{border-radius:var(--r-card);margin-bottom:var(--sp-4)}
.rt td:empty{padding-inline:0}          /* 表头少于 5 列时，空单元格收成零宽，不留残列 */
.rt table th,.rt table td{font-size:var(--fs-note);padding:10px 12px}
.rt table th{font-weight:800;letter-spacing:.02em}
.rt-cap b{font-size:var(--fs-text)}
.rs-head b{font-size:var(--fs-text)}
.rs-t{font-size:var(--fs-note)}
.rs-n{font-size:var(--fs-note);line-height:1.5}
.cmp-card{padding:var(--sp-4)}
.cmp-head h4{font-size:var(--fs-text)}
.cmp-side{border-radius:var(--r-ctl)}
.cmp-side p{font-size:var(--fs-note);line-height:1.65}
.metro-list li{font-size:var(--fs-note);line-height:1.6}
.metro-list li.ml-note{font-size:var(--fs-note);border-radius:var(--r-ctl)}
.metro-panel-title b{font-size:var(--fs-text)}
.tabset{border-radius:var(--r-card);padding:var(--sp-3);margin-bottom:var(--sp-4)}
.tab-head{font-size:var(--fs-note);border-radius:999px;padding:.5rem .875rem;
  transition:background var(--dur-fast) var(--ease),border-color var(--dur-fast) var(--ease),color var(--dur-fast) var(--ease)}
.tab-panel>.grid-1 .card{padding:var(--sp-5) var(--sp-5);border-radius:var(--r-card)}
.tab-panel>.grid{min-height:8rem}       /* 标签间高度稳定，但不再撑出大片空白 */
.tab-panel>.grid-1 .card-title{font-size:var(--fs-cardtitle)}
.step-title{font-size:var(--fs-text)}
.step-body{font-size:var(--fs-note);line-height:1.65}

/* ── 话术与仿真 ── */
.faq,.sl-group{border-radius:var(--r-ctl);margin-bottom:0}
.faq summary,.sl-group summary{font-size:var(--fs-note)}
.faq-principle{font-size:var(--fs-note);border-radius:var(--r-ctl);padding:var(--sp-2) var(--sp-3)}
.faq-answer{font-size:var(--fs-text);line-height:1.7;border-radius:var(--r-ctl);padding:var(--sp-3) 3rem var(--sp-3) var(--sp-3)}
.sl-line{font-size:var(--fs-text);border-radius:var(--r-ctl)}
.sl-h{font-size:var(--fs-note)}
.sl-p{font-size:var(--fs-note);line-height:1.7}
.copy-wrap{border-radius:var(--r-ctl);padding:var(--sp-3) 2.75rem var(--sp-3) var(--sp-3)}
.copy-wrap .copy-text{font-size:var(--fs-text);line-height:1.7}
.bubble{font-size:var(--fs-text);line-height:1.6;border-radius:var(--r-card)}
.chat-cap{font-size:var(--fs-note);margin-bottom:var(--sp-3)}
.mm-text{font-size:var(--fs-text);line-height:1.7}
figure figcaption,.gallery-item figcaption{font-size:var(--fs-note)}

/* ── 导航与控制：半透明材质分层，点击区不小于 32px ── */
.layout{padding-bottom:6rem}          /* 文字放大后底栏变高，留白按 rem 一起长，避免压住正文 */
.topbar{background:rgba(255,255,255,.72);-webkit-backdrop-filter:saturate(180%) blur(20px);backdrop-filter:saturate(180%) blur(20px)}
.brand-text{font-size:var(--fs-text)}
.topbar-title{font-size:var(--fs-note)}
.search-box input{width:13rem}
.home-btn,.search-box input,.menu-btn{border-radius:var(--r-ctl);font-size:var(--fs-note)}
.nav-group-title{font-size:.9375rem;border-radius:var(--r-ctl);padding:.5rem .625rem}
.nav-link{font-size:.875rem;border-radius:.5rem;padding:.375rem .625rem .375rem .875rem}
.pager-btn{border-radius:var(--r-ctl);font-size:.9375rem;padding:.5625rem 1rem;min-block-size:2.25rem;
  transition:background var(--dur-fast) var(--ease),border-color var(--dur-fast) var(--ease)}
.pager-pos{font-size:var(--fs-note)}
.pager-pos b{font-size:var(--fs-text)}
.xref-chip{border-radius:999px;font-size:var(--fs-note);padding:.375rem .8125rem;
  transition:background var(--dur-fast) var(--ease),border-color var(--dur-fast) var(--ease)}
.dl-dock>summary{border-radius:999px;font-size:var(--fs-note);box-shadow:var(--shadow-lift);min-block-size:2.625rem}
:where(a,button,summary,input,[tabindex]):focus-visible{outline:3px solid var(--accent);outline-offset:3px;border-radius:var(--r-ctl)}

/* ── 窄屏：字号回落到原比例，避免新令牌把移动端顶满 ── */
@media(max-width:960px){
  .section{padding:var(--sp-4) var(--sp-3)}
  .section h2{font-size:1.5rem}
  .lede{font-size:1.0625rem;padding:var(--sp-2) var(--sp-3)}
  .quote{font-size:1.25rem}
  .card,.pick-card,.callout{padding:var(--sp-3)}
  .stat-num{font-size:1.75rem}
}
"""

# ---------- JS ----------
CSS += '\n/* 2026-11-19: intrinsic layout and full-cell table fallback */\n.data-table-scroll{overflow:auto;max-inline-size:100%;margin-block:0 1.5rem;\n  border:1px solid var(--border);border-radius:1rem;max-block-size:65dvh;overscroll-behavior:contain}\n.data-table{inline-size:100%;border-spacing:0;border-collapse:separate;font-size:1rem;line-height:1.6}\n.data-table caption{text-align:start;font-weight:700;color:var(--brand);padding:1rem}\n.data-table :is(th,td){padding:.75rem 1rem;text-align:start;vertical-align:top;\n  min-inline-size:7rem;max-inline-size:30rem;overflow-wrap:anywhere;border-block-end:1px solid var(--border)}\n.data-table thead{position:sticky;inset-block-start:0;z-index:1;background:#edf4fb}\n.data-table td{background:#fff}\n.layout main,.section,.card,.tab-panel{min-inline-size:0}\n.body-text,.section h2,.card-title,.card-body,.cover h1,.cover p{overflow-wrap:anywhere}\n.pager-pos-wrap{min-inline-size:0}\n@media(max-width:600px){.pager-label{display:none}.pager-btn{padding:.5rem;font-size:.8125rem}}\n'

CSS += '\n/* Visual contract: logo, heading hierarchy, palette, interaction states. */\n.brand-logo{block-size:var(--logo-header-height);inline-size:auto;max-inline-size:11rem;object-fit:contain}\n.cover-logo{block-size:var(--logo-cover-height);inline-size:auto;max-inline-size:min(70vw,18rem);object-fit:contain}\n.cover h1{font-size:var(--fs-cover);line-height:1.25;max-inline-size:20ch;margin-inline:auto;text-wrap:balance}\n.cover p{font-size:var(--fs-body);color:var(--muted)}\n.brand-text{max-inline-size:12rem;overflow-wrap:anywhere;white-space:normal;line-height:1.25}\n.body-text,.card-body,.tab-panel>.grid-1 .card-body{color:var(--text)}\n.card-sub,.sec-sub,.topbar-title{color:var(--muted)}\n.nav-link.target-current,.tab-head.on,.metro-stop.on .metro-dot{border-color:var(--accent)}\n.pick-card{display:block;min-inline-size:0;border-width:1px;font-weight:400}\n.pick-card .card-title,.pick-card .card-sub,.pick-card .card-body{display:block}\n.pick-card .card-title{font-weight:800}\n.pick-control{position:absolute;inline-size:1px;block-size:1px;margin:-1px;padding:0;clip-path:inset(50%);overflow:hidden;white-space:nowrap}\n.pick-card:is(.on,:has(.pick-control:checked)){background:var(--selected-bg);border-color:var(--selected-border);\n box-shadow:var(--selected-shadow);transform:none}\n.pick-card:is(.on,:has(.pick-control:checked)) .card-title{color:var(--selected-text);font-weight:800}\n.pick-card:has(.pick-control:focus-visible){outline:3px solid var(--focus);outline-offset:5px}\n.pick-card.is-disabled{opacity:.48;cursor:not-allowed;transform:none;box-shadow:none}\n.pick-card.is-disabled:hover{border-color:var(--border)}\n.pick-card::before{background:transparent}\n.pick-card:is(.on,:has(.pick-control:checked))::before{background:var(--selected-border);width:4px}\n.card:not(:has(a,button,input)){cursor:default}\n@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}}\n@media(max-width:600px){.cover h1{font-size:2rem}.brand-text{max-inline-size:9rem}.brand-logo{max-inline-size:8rem}}\n'

CSS += """
.mm-act{width:auto;inline-size:auto;min-inline-size:5rem;min-block-size:2.75rem;height:auto;padding:.5rem .75rem}
.mm-act svg{flex:0 0 1.25rem;inline-size:1.25rem;block-size:1.25rem}
.mm-act-label{font-size:.875rem}
.mm-feedback{min-block-size:1.5em;font-size:.8125rem;color:var(--muted);margin:.75rem 0 0}
.mm-comment-item.mine{animation:commentPop .24s ease both}
"""
CSS += gallery_layouts.CSS + portal_layout.CSS + china_map.CSS + typography_rules.CSS

JS = r"""
// 翻页导航：一次显示一个小节卡片
(function(){
  const secs=[...document.querySelectorAll('.section[id]')];
  const links=[...document.querySelectorAll('.nav-link')];
  if(!secs.length)return;
  let cur=0;
  const prev=document.getElementById('pager-prev');
  const next=document.getElementById('pager-next');
  const pos=document.getElementById('pager-pos');
  const title=document.getElementById('pager-title');
  function show(i,initial){
    cur=Math.max(0,Math.min(secs.length-1,i));
    secs.forEach((s,k)=>s.classList.toggle('active',k===cur));
    const id=secs[cur].id;
    links.forEach(a=>{const on=a.getAttribute('href')==='#'+id;
      a.classList.toggle('target-current',on);
      if(on){a.setAttribute('aria-current','true');const g=a.closest('.nav-group');
        if(g){g.open=true;document.querySelectorAll('.sidebar details.nav-group').forEach(d=>{if(d!==g)d.open=false;});}
        // 目录自动跟随：把当前项滚进侧栏可视区
        const side=a.closest('.sidebar');
        if(side){const ar=a.getBoundingClientRect(),sr=side.getBoundingClientRect();
          if(ar.top<sr.top+40||ar.bottom>sr.bottom-20){side.scrollTo({top:side.scrollTop+(ar.top-sr.top)-100,behavior:'smooth'});}}
      }
      else a.removeAttribute('aria-current');});
    if(pos)pos.innerHTML='第 <b>'+(cur+1)+'</b> / '+secs.length+' 节';
    if(title)title.textContent=secs[cur].querySelector('h2')?.textContent||'';
    if(prev)prev.disabled=cur===0;
    if(next)next.disabled=cur===secs.length-1;
    if(!initial){
      document.body.classList.add('viewing');
      secs[cur].scrollIntoView({block:'start'}); // 定位到当前小节顶部
    } else {
      window.scrollTo({top:0,behavior:'instant'});
    }
    try{history.replaceState(null,'','#'+id);}catch(e){}
    try{window.dispatchEvent(new CustomEvent('hb:sectionchange',{detail:{index:cur,id:id}}));}catch(e){}
  }
  window.__showSection=show;
  // 封面「开始阅读」：进入正文第一小节
  const startBtn=document.getElementById('cover-start');
  if(startBtn)startBtn.addEventListener('click',()=>{
    document.body.classList.add('viewing');
    show(0);
    try{history.replaceState(null,'',location.pathname);}catch(e){}
  });
  // 顶栏「封面」：回到开场封面
  const homeBtn=document.getElementById('home-btn');
  if(homeBtn)homeBtn.addEventListener('click',()=>{
    document.body.classList.remove('viewing');
    links.forEach(a=>{a.classList.remove('target-current');a.removeAttribute('aria-current');});
    try{history.replaceState(null,'',location.pathname);}catch(e){}
    window.scrollTo({top:0,behavior:'instant'});
  });
  links.forEach(a=>a.addEventListener('click',e=>{
    e.preventDefault();
    const i=secs.findIndex(s=>s.id===a.getAttribute('href').slice(1));
    if(i>=0)show(i);closeMenu();
  }));
  if(prev)prev.addEventListener('click',()=>show(cur-1));
  if(next)next.addEventListener('click',()=>show(cur+1));
  // 键盘左右翻页（输入框 / 弹窗 / tab / 报站控件内不触发）
  document.addEventListener('keydown',e=>{
    if(/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;
    const lb=document.getElementById('lightbox');
    if(lb&&lb.open)return; // 弹窗打开时方向键用于切图，不翻小节
    // tab / metro 等自带方向键的控件抢占焦点时不翻页
    if(document.activeElement.closest('[role="tab"],[role="tablist"],.tabset,.metro-stop,.metro,.multi-gallery,.china-map-component'))return;
    if(e.key==='ArrowLeft')show(cur-1);
    if(e.key==='ArrowRight')show(cur+1);
  });
  // 交叉引用：点相关章节 chip 跳到对应小节
  document.addEventListener('click',e=>{
    const chip=e.target.closest('.xref-chip');
    if(!chip)return;
    const i=secs.findIndex(s=>s.id===chip.getAttribute('data-goto'));
    if(i>=0){show(i);window.scrollTo({top:0,behavior:'smooth'});setTimeout(()=>secs[i].scrollIntoView({block:'start'}),60);}
  });
  // 深链接：带 hash 直接进正文；否则停在封面
  const h=decodeURIComponent(location.hash.slice(1));
  const start=secs.findIndex(s=>s.id===h);
  if(start>=0){show(start,true);document.body.classList.add('viewing');}
  else show(0,true);
  window.addEventListener('hashchange',()=>{const id=decodeURIComponent(location.hash.slice(1));const i=secs.findIndex(s=>s.id===id);if(i>=0){show(i,true);document.body.classList.add('viewing');}});
})();
// 移动菜单
function closeMenu(){document.querySelector('.sidebar')?.classList.remove('open');}
document.querySelector('.menu-btn')?.addEventListener('click',()=>document.querySelector('.sidebar')?.classList.toggle('open'));
// 图片点击放大（lightbox）
(function(){
  const box=document.getElementById('lightbox');
  if(!box)return;
  const im=box.querySelector('img');
  const cap=box.querySelector('.lightbox-cap');
  const close=box.querySelector('.lightbox-close');
  // 同一组图片（同一 gallery / 图组）内左右切换
  let group=[],gi=0;
  const prevBtn=box.querySelector('.lb-prev'),nextBtn=box.querySelector('.lb-next');
  function paint(){
    if(!group.length)return;
    const el=group[gi];im.src=el.src;im.alt=el.alt||'';
    cap.textContent=el.closest('figure')?.querySelector('figcaption')?.textContent||el.alt||'';
    const multi=group.length>1;
    if(prevBtn)prevBtn.hidden=!multi;
    if(nextBtn)nextBtn.hidden=!multi;
  }
  function step(d){if(group.length<2)return;gi=(gi+d+group.length)%group.length;paint();}
  document.addEventListener('click',e=>{
    const t=e.target.closest('img.zoomable, img.avatar, .gallery-item img');
    if(!t)return;
    if(t.classList.contains('avatar'))return; // 头像是装饰，不放大
    openAt(t);
  });
  function openAt(t){
    // 收集同组图片：优先同 figure 的兄弟，其次同 gallery / 同 section 的所有可放大图
    const scope=t.closest('.gallery')||t.closest('.section')||document;
    group=[...scope.querySelectorAll('img.zoomable, .gallery-item img')].filter(x=>!x.classList.contains('avatar'));
    if(!group.includes(t))group=[t];
    gi=Math.max(0,group.indexOf(t));
    paint();box.showModal();
  }
  // 键盘：图片可聚焦，回车 / 空格打开放大
  document.addEventListener('keydown',e=>{
    if(e.key!=='Enter'&&e.key!==' ')return;
    const t=e.target.closest('img.zoomable, .gallery-item img');
    if(!t)return;
    e.preventDefault();openAt(t);
  });
  if(prevBtn)prevBtn.addEventListener('click',e=>{e.stopPropagation();step(-1);});
  if(nextBtn)nextBtn.addEventListener('click',e=>{e.stopPropagation();step(1);});
  // 关闭：优先原生 closedby="any"（背景点击 / Esc / 返回手势），仅在不支持时补兜底
  close.addEventListener('click',()=>box.close());
  if(!('closedBy' in HTMLDialogElement.prototype)){
    // 回退：指针按下与抬起都在对话框外才关闭（避免文字选中拖拽误关）
    const outside=(e)=>{const r=box.getBoundingClientRect();
      return e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom;};
    let pressedOutside=false;
    box.addEventListener('pointerdown',e=>{pressedOutside=outside(e);});
    box.addEventListener('pointerup',e=>{if(pressedOutside&&outside(e))box.close();pressedOutside=false;});
  }
  // 左右键翻图；Esc 由原生模态处理，不重复拦截
  box.addEventListener('keydown',e=>{
    if(e.key==='ArrowLeft'){e.preventDefault();step(-1);}
    if(e.key==='ArrowRight'){e.preventDefault();step(1);}
  });
})();
// 复制：命令式 + 点击 fallback，Async Clipboard + 传统兜底（copy-button 指南）
let lastMsg='';
function legacyCopy(text){
  const f=document.createElement('textarea');f.value=text;f.setAttribute('readonly','');
  f.style.cssText='position:fixed;top:0;left:0;opacity:0';document.body.append(f);f.select();
  try{return document.execCommand('copy');}finally{f.remove();}
}
async function doCopyEl(btn,target){
  if(!target)return;
  const text=target.innerText.trim();if(!text)return;
  let ok=false;
  try{if(navigator.clipboard&&navigator.clipboard.writeText){await navigator.clipboard.writeText(text);ok=true;}}catch(e){}
  if(!ok)ok=legacyCopy(text);
  report(btn,ok);
}
function report(btn,ok){
  clearTimeout(btn._t);btn.removeAttribute('data-copied');btn.removeAttribute('data-failed');
  const tip=btn.nextElementSibling;let msg=ok?'已复制':'复制失败';
  if(msg===lastMsg)msg+='\u00A0';lastMsg=msg;
  void btn.offsetWidth;btn.setAttribute(ok?'data-copied':'data-failed','');
  requestAnimationFrame(()=>{if(tip)tip.textContent=msg;});
  btn._t=setTimeout(()=>{btn.removeAttribute('data-copied');btn.removeAttribute('data-failed');if(tip)tip.textContent='';},1800);
}
// Invoker Commands：command 事件不冒泡，用捕获阶段监听；event.source 是按钮，event.target 是 commandfor 元素
document.addEventListener('command',e=>{
  if(e.command!=='--copy')return;
  doCopyEl(e.source,e.target);
},true);
// 只有不支持 CommandEvent 的环境才注册点击路径，避免一次点击复制两次
if(!('CommandEvent' in window)){
  document.addEventListener('click',e=>{
    const b=e.target.closest('.copy-button[command]');if(!b)return;
    doCopyEl(b,document.getElementById(b.getAttribute('commandfor')));
  });
}
// 搜索：过滤目录项并定位首个命中
(function(){
  const input=document.querySelector('.search-box input');if(!input)return;
  const links=[...document.querySelectorAll('.nav-link')];
  const noRes=document.querySelector('.no-result');
  input.addEventListener('input',()=>{
    const q=input.value.trim().toLowerCase();let hit=0;
    links.forEach(a=>{const on=!q||a.textContent.toLowerCase().includes(q);
      a.style.display=on?'':'none';
      if(on&&q){hit++;const grp=a.closest('.nav-group');if(grp)grp.open=true;}});
    if(noRes)noRes.classList.toggle('show',q&&!hit);
  });
  input.addEventListener('keydown',e=>{
    if(e.key==='Enter'){const a=links.find(x=>x.style.display!=='none'&&x.getAttribute('href'));if(a){a.click();input.blur();input.value='';links.forEach(l=>l.style.display='');}}
  });
})();
// 原生单选卡：浏览器处理方向键、空格、禁用；高亮与 checked 同步。
(function(){
  document.querySelectorAll('.pick-grid').forEach(grid=>{
    const cards=[...grid.querySelectorAll('.pick-card')];
    grid.addEventListener('change',e=>{
      if(!e.target.matches('.pick-control'))return;
      cards.forEach(c=>c.classList.toggle('on',c.querySelector('.pick-control').checked));
    });
  });
})();
// Tab 切换（点击 + 键盘方向键 / Home / End，符合 tablist 交互）
(function(){
  document.querySelectorAll('.tabset').forEach(set=>{
    const heads=[...set.querySelectorAll('.tab-head')], panels=[...set.querySelectorAll('.tab-panel')];
    heads.forEach(h=>{h.tabIndex=h.classList.contains('on')?0:-1;});
    function pick(i,focus){
      heads.forEach((x,k)=>{const on=k===i;x.classList.toggle('on',on);x.tabIndex=on?0:-1;
        x.setAttribute('aria-selected',String(on));});
      panels.forEach(p=>p.classList.toggle('on',p.dataset.idx===String(i)));
      if(focus)heads[i].focus();
    }
    heads.forEach((h,i)=>{
      h.addEventListener('click',()=>pick(i,false));
      h.addEventListener('keydown',e=>{
        let n=null;
        if(e.key==='ArrowRight'||e.key==='ArrowDown')n=(i+1)%heads.length;
        else if(e.key==='ArrowLeft'||e.key==='ArrowUp')n=(i-1+heads.length)%heads.length;
        else if(e.key==='Home')n=0;
        else if(e.key==='End')n=heads.length-1;
        if(n!==null){e.preventDefault();pick(n,true);}
      });
    });
  });
})();
// 地铁报站导航
(function(){  document.querySelectorAll('.metro').forEach(metro=>{
    const track=metro.querySelector('.metro-track');
    const stops=[...metro.querySelectorAll('.metro-stop')],panels=[...metro.querySelectorAll('.metro-panel')];
    const fill=metro.querySelector('.metro-fill'),train=metro.querySelector('.metro-train');
    const now=metro.querySelector('.metro-now b'),nextChip=metro.querySelector('.metro-next');
    if(!stops.length)return;
    let current=Math.max(0,stops.findIndex(s=>s.classList.contains('on')));
    function place(i){
      if(!track||!fill||!train)return;
      const tr=track.getBoundingClientRect();
      const dots=stops.map(s=>s.querySelector('.metro-dot').getBoundingClientRect());
      const first=dots[0].left+dots[0].width/2-tr.left,cur=dots[i].left+dots[i].width/2-tr.left;
      fill.style.left=first+'px';fill.style.width=Math.max(0,cur-first)+'px';train.style.left=cur+'px';
    }
    function go(i){
      current=i;
      stops.forEach((s,k)=>{const on=k===i;s.classList.toggle('on',on);s.setAttribute('aria-pressed',String(on));});
      panels.forEach(p=>p.classList.toggle('on',p.dataset.stop===String(i)));
      if(now)now.textContent=stops[i].querySelector('.metro-label b')?.textContent||'';
      if(nextChip){const nx=stops[i+1]?.querySelector('.metro-label b')?.textContent||'';
        nextChip.hidden=!nx;const nb=nextChip.querySelector('b');if(nb)nb.textContent=nx;}
      place(i);
    }
    stops.forEach((s,i)=>s.addEventListener('click',()=>{
      go(i);
      if(metro.dataset.nav==='1'&&s.dataset.goto&&window.__showSection){
        const list=[...document.querySelectorAll('.section[id]')];
        const idx=list.indexOf(document.getElementById(s.dataset.goto));
        if(idx>=0)window.__showSection(idx);
      }
    }));
    go(current);
    window.addEventListener('resize',()=>place(current),{passive:true});
    window.addEventListener('hb:sectionchange',()=>{if(metro.getBoundingClientRect().width>0)place(current);});
  });
})();
// 数字滚动：进入当前小节时从 0 滚向目标值；尊重系统「减少动态」设置
(function(){
  const reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function fmt(v,decimals){
    if(decimals>0)return v.toFixed(decimals);
    return String(Math.round(v));
  }
  function run(el){
    if(el.dataset.done==='1')return;
    el.dataset.done='1';
    const raw=el.getAttribute('data-count')||'0';
    const target=parseFloat(raw.replace(/[^0-9.]/g,''))||0;
    const decimals=(raw.split('.')[1]||'').length;
    const dur=parseInt(el.getAttribute('data-dur')||'1100',10);
    const vEl=el.querySelector('.stat-v');
    if(!vEl)return;
    if(reduce){vEl.textContent=fmt(target,decimals);return;}
    const t0=performance.now();
    function tick(now){
      const p=Math.min(1,(now-t0)/dur);
      const eased=1-Math.pow(1-p,3); // easeOutCubic
      vEl.textContent=fmt(target*eased,decimals);
      if(p<1)requestAnimationFrame(tick);
      else vEl.textContent=fmt(target,decimals);
    }
    requestAnimationFrame(tick);
  }
  function runIn(section){
    if(!section)return;
    section.querySelectorAll('[data-count]').forEach(el=>{
      // 每次进入该节都重播：先清空标记
      el.dataset.done='';
      run(el);
    });
  }
  // 首屏：若已直接进入正文
  const first=document.querySelector('.section.active');
  if(first)runIn(first);
  window.addEventListener('hb:sectionchange',e=>{
    const list=[...document.querySelectorAll('.section[id]')];
    runIn(list[e.detail.index]);
  });
})();
// 顶部阅读进度条（按「第几节 + 本节滚动比例」计算；只写 transform，rAF 节流）
(function(){
  const bar=document.querySelector('.read-progress');
  if(!bar)return;
  let ticking=false;
  function upd(){
    const secs=[...document.querySelectorAll('.section[id]')];
    if(!secs.length){bar.style.setProperty('--p','0');return;}
    const active=document.querySelector('.section.active');
    const idx=active?secs.indexOf(active):0;
    const sc=window.scrollY||document.documentElement.scrollTop;
    const docH=document.documentElement.scrollHeight-window.innerHeight;
    const inner=docH>0?Math.min(1,Math.max(0,sc/docH)):0;
    const pct=Math.min(1,(Math.max(0,idx)+inner)/secs.length);
    bar.style.setProperty('--p',pct.toFixed(4));
    ticking=false;
  }
  function onScroll(){if(!ticking){ticking=true;requestAnimationFrame(upd);}}
  window.addEventListener('scroll',onScroll,{passive:true});
  window.addEventListener('resize',onScroll,{passive:true});
  window.addEventListener('hb:sectionchange',()=>setTimeout(upd,30));
  upd();
})();
// 朋友圈点赞 / 评论 / 进入提示
(function(){
  const hinted=new WeakSet();
  function tryHint(){
    document.querySelectorAll('.moments').forEach(card=>{
      if(hinted.has(card)||card.offsetParent===null)return;
      const r=card.getBoundingClientRect();if(!r.width||!r.height)return;
      hinted.add(card);card.classList.add('mm-hint');
      setTimeout(()=>card.classList.remove('mm-hint'),1800);
    });
  }
  document.querySelectorAll('.moments').forEach(card=>{
    const like=card.querySelector('.mm-like'),comment=card.querySelector('.mm-comment');
    const box=card.querySelector('.mm-comment-box'),input=card.querySelector('.mm-comment-input');
    const send=card.querySelector('.mm-comment-send'),list=card.querySelector('.mm-comments');
    function burst(btn){
      if(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches)return;
      const wrap=document.createElement('span');wrap.className='mm-heart-burst';
      const xs=[-26,-12,0,12,26],ys=[-32,-44,-52,-42,-30],rs=['-18deg','-8deg','0deg','9deg','18deg'];
      xs.forEach((x,i)=>{const h=document.createElement('i');h.className='mm-heart';h.textContent='♥';
        h.style.setProperty('--hx',x+'px');h.style.setProperty('--hy',ys[i]+'px');h.style.setProperty('--hr',rs[i]);
        h.style.animationDelay=(i*38)+'ms';wrap.appendChild(h);});
      btn.appendChild(wrap);setTimeout(()=>wrap.remove(),1250);
    }
    if(like)like.addEventListener('click',()=>{
      const on=!like.classList.contains('on');
      like.classList.toggle('on',on);like.setAttribute('aria-pressed',String(on));
      const lt=card.querySelector('.mm-likes-text');
      if(lt){const base=lt.dataset.base||'';
        if(on){lt.textContent='';const me=document.createElement('span');me.className='mm-like-me';me.textContent='我';
          lt.append(me,document.createTextNode('、'+base));}else lt.textContent=base;}
      if(on)burst(like);
    });
    if(comment)comment.addEventListener('click',()=>{
      const open=box.classList.toggle('open');comment.setAttribute('aria-expanded',String(open));
      card.classList.remove('comments-shown');void card.offsetWidth;card.classList.add('comments-shown');
      if(open)input?.focus();
    });
    function addComment(){
      const feedback=card.querySelector('.mm-feedback');
      const v=input?.value.trim();if(!v){if(feedback)feedback.textContent='请先输入评论';return;}card.classList.add('comments-shown');
      const row=document.createElement('div');row.className='mm-comment-item mine';
      const av=document.createElement('span');av.className='mm-c-avatar mine';av.textContent='我';
      const body=document.createElement('span');body.className='mm-c-body';
      const who=document.createElement('b');who.textContent='我';
      const txt=document.createElement('span');txt.textContent=v;
      body.append(who,txt);row.append(av,body);list?.appendChild(row);input.value='';if(feedback)feedback.textContent='评论已添加到本页示例';
    }
    if(send)send.addEventListener('click',addComment);
    if(input)input.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.isComposing&&e.keyCode!==229){e.preventDefault();addComment();}});
  });
  window.addEventListener('hb:sectionchange',()=>setTimeout(tryHint,90));
  document.addEventListener('click',()=>setTimeout(tryHint,90));
  window.addEventListener('load',()=>setTimeout(tryHint,320));
  setTimeout(tryHint,420);
})();
"""

def render_header(title, search_placeholder="搜索章节 / 关键词", config=None):
    """同资料中心全部子手册复用此组件；只允许文档名、搜索词和首页目标变化。"""
    cfg = resolve_config(config)
    surface = cfg.get("header_surface", "light")
    if surface not in ("light", "dark"):
        raise ValueError("header_surface 必须为 light 或 dark")
    logo = "logo-white.png" if surface == "dark" else "logo.png"
    project, separator, document = title.partition(" · ")
    header_title = f'<span class="project-name">{esc(project)}</span>' + (f'<span class="document-name"> · {esc(document)}</span>' if separator else "")
    home = (f'<a class="home-btn" href="{esc(cfg["home_href"])}" aria-label="回到首页">首页</a>'
            if cfg.get("home_href") else "")
    skill_download = (f'<a class="home-btn skill-download" href="{esc(cfg["skill_download_href"])}" download="handbook-workshop-v{esc(cfg.get("design_version","1.3.3"))}.zip" aria-label="下载完整技能包"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4"/></svg><span>下载技能包</span></a>' if cfg.get("skill_download_href") else '')
    return f'''<header class="topbar" data-surface="{surface}">
  <button class="menu-btn" aria-label="打开目录">☰</button>
  <div class="brand"><img class="brand-logo" src="assets/{logo}" alt="大金 DAIKIN"></div>
  <div class="topbar-title">{header_title}</div>
  <div class="topbar-sp"></div>
  <div class="search-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4-4"/></svg>
    <input type="search" placeholder="{esc(search_placeholder)}" aria-label="搜索章节"></div>
  {skill_download}
  {home}
  <button type="button" class="home-btn" id="home-btn" title="回到封面" aria-label="回到封面">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>
    <span>封面</span></button>
</header>'''


def render_credit(cfg):
    version=esc(cfg.get('design_version','1.3.3'))
    designer=esc(cfg.get('designer','吖君'))
    date=esc(cfg.get('updated_at',''))
    hidden='' if cfg.get('show_update_date',True) else ' hidden'
    return f'<div class="design-credit"><span>版本号 V{version}</span><span>设计者：{designer}</span><span class="credit-date"{hidden}>更新日期：{date}</span></div>'


def build_html(title, subtitle, hero, sections, attachments=None, A=None,
               search_placeholder="搜索章节 / 场景 / 关键词", xref=None, config=None):
    """生成完整 HTML 字符串。

    title/subtitle: 页面标题与 meta 描述
    hero: {kicker,title,desc,meta} 独立封面信息
    sections: [{id,nav,group,title,kicker,subtitle,blocks}] 章节列表
    attachments: [{name,path,kind}] 附件，kind ∈ local|netdisk|link|pending
    A: 图片映射 {原文件名: 输出文件名}，来自 prepare_assets
    xref: {section_id: [目标section_id,...]} 交叉引用
    config: 品牌/主题/首页链接等配置，见 DEFAULT_CONFIG
    """
    cfg = resolve_config(config)
    typography_rules.project_phrases = cfg.get("protected_phrases", [])
    attachments = attachments or []
    A = A or {}
    xref = xref or {}
    brand = cfg["brand"] or title
    has_logo = True
    cover_mode = cfg.get("cover_mode", "auto")
    if cover_mode == "auto":
        cover_mode = "image" if cfg["cover_image"] else "fluid"
    if cover_mode not in ("fluid", "image", "plain"):
        raise ValueError("cover_mode 必须为 auto/fluid/image/plain")
    flow_markup = cover_design.MARKUP if cover_mode == "fluid" else ""
    cover_class = "cover cover-fluid-mode" if cover_mode == "fluid" else "cover cover-plain-mode" if cover_mode == "plain" else "cover"
    cover_logo_file = "logo-white.png" if cfg.get("cover_surface") == "dark" else "logo.png"
    header_logo_file = "logo-white.png" if cfg.get("header_surface") == "dark" else "logo.png"
    sec_by_id = {s["id"]: s for s in sections}

    # 目录分组：group="__bare__" 为独立条目，按章节顺序排在分组之间
    def nav_link(s, cls="nav-link"):
        return f'<a class="{cls}" href="#{s["id"]}"><span class="nav-dot"></span>{esc(s["nav"])}</a>'
    nav = []
    i = 0
    while i < len(sections):
        s = sections[i]
        g = s.get("group", "内容")
        if g == "__bare__":
            nav.append(nav_link(s, "nav-link nav-bare"))
            i += 1
            continue
        items = []
        while i < len(sections) and sections[i].get("group", "内容") == g and sections[i].get("group", "内容") != "__bare__":
            items.append(sections[i])
            i += 1
        # 分组下只有一个章节时，不做二级目录，直接以一级标题作为独立链接
        if len(items) == 1:
            x = items[0]
            nav.append(f'<div class="nav-flat"><a class="nav-link nav-bare" href="#{x["id"]}">'
                       f'<span class="nav-dot"></span>{esc(g)}</a></div>')
            continue
        links = "".join(nav_link(x) for x in items)
        is_first_group = not any('<details' in n for n in nav)
        open_attr = " open" if is_first_group else ""
        nav.append(f'<details class="nav-group" data-group="{len(nav)}"{open_attr}>'
                   f'<summary><div class="nav-group-title">{esc(g)}</div></summary>'
                   f'<div class="nav-group-links">{links}</div></details>')

    # 正文
    sec_html = []
    for s in sections:
        kicker = f'<span class="sec-kicker">{esc(s["kicker"])}</span>' if s.get("kicker") else ""
        sub = f'<p class="sec-sub">{nl2br(s["subtitle"])}</p>' if s.get("subtitle") else ""
        body = render_blocks(s["blocks"], A)
        xrefs = xref.get(s["id"], [])
        chips = "".join(
            f'<button type="button" class="xref-chip" data-goto="{esc(t)}">'
            f'{esc(sec_by_id[t]["nav"] if t in sec_by_id else t)}<span class="xc-arrow">→</span></button>'
            for t in xrefs if t in sec_by_id)
        xref_html = (f'<div class="xref"><div class="xref-hd">相关章节</div>'
                     f'<div class="xref-list">{chips}</div></div>') if chips else ""
        sec_html.append(
            f'<section class="section" id="{s["id"]}" aria-labelledby="h-{s["id"]}"><div class="section-head">{kicker}'
            f'<h2 id="h-{s["id"]}">{nl2br(s["title"])}</h2>{sub}</div>{body}{xref_html}</section>')

    # 主题覆盖：把 config.theme 转成 CSS 变量声明；无封面图时用纯色渐变兜底
    override_lines = [f'{k}:{v};' for k, v in cfg["theme"].items() if k.startswith("--")]
    cover_fallback = ""
    if not cfg["cover_image"]:
        cover_fallback = ".cover::before{background:linear-gradient(180deg,rgba(235,244,252,.7),rgba(90,130,175,.18))}"
    theme_css = f'<style>:root{{{";".join(override_lines)}}}{cover_fallback}</style>'
    # 设计基线：默认启用；config 里设 "style_preset": "classic" 可回到旧版式
    base_css = "" if cfg.get("style_preset") == "classic" else APPLE_BASE_CSS

    # 固定品牌资产；不允许退回品牌文字占位。
    cover_logo = f'<img class="cover-logo" src="assets/{cover_logo_file}" alt="大金 DAIKIN">'
    header_html = render_header(title, search_placeholder, cfg)
    cover_download = (f'<a class="cover-download skill-download" href="{esc(cfg["skill_download_href"])}" download="handbook-workshop-v{esc(cfg.get("design_version","1.3.3"))}.zip">下载技能包 <span aria-hidden="true">↓</span></a>' if cfg.get("skill_download_href") else '')

    pager = '''<div class="pagerbar"><nav class="pager" id="pager" aria-label="小节翻页">
  <button class="pager-btn" id="pager-prev"><span class="arrow">‹</span>上一节</button>
  <div class="pager-pos-wrap"><div class="pager-pos" id="pager-pos"></div><span class="pager-label" id="pager-title"></span></div>
  <button class="pager-btn" id="pager-next">下一节<span class="arrow">›</span></button>
</nav></div>'''
    lightbox = '''<dialog class="lightbox" id="lightbox" aria-label="图片放大查看" closedby="any">
  <button class="lightbox-close" aria-label="关闭">×</button>
  <button class="lb-prev" aria-label="上一张">‹</button>
  <button class="lb-next" aria-label="下一张">›</button>
  <img src="" alt=""><div class="lightbox-cap"></div>
</dialog>'''

    # 封面背景是 LCP 元素：有封面图时预加载，避免首屏延迟
    cover_preload = ('<link rel="preload" as="image" href="assets/cover-wave.png" fetchpriority="high">'
                     if cfg["cover_image"] else "")

    return f'''<!DOCTYPE html>
<html lang="zh-CN" data-shell="{cfg.get('shell_mode','light')}"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="text-scale" content="scale">
<meta name="description" content="{esc(subtitle)}">
<title>{esc(title)}</title>
{cover_preload}<style>{CSS}{base_css}{cover_design.SKIN_CSS}{cover_design.CSS}</style>{theme_css}</head>
<body data-mobile-block="{'1' if cfg['mobile_block'] else '0'}">
<div class="read-progress" aria-hidden="true"></div>
<div class="{cover_class}" id="cover" data-surface="{esc(cfg.get('cover_surface','light'))}">
  {flow_markup}
  <div class="cover-inner">
    {cover_logo}
    <div class="cover-kicker">{esc(hero.get("kicker",""))}</div>
    <h1>{nl2br(hero["title"])}</h1>
    <p>{nl2br(hero.get("desc",""))}</p>
    <div class="cover-meta">{esc(hero.get("meta",""))}</div>
    <div class="cover-actions"><button type="button" class="cover-start" id="cover-start">开始阅读 <span class="cs-arrow">→</span></button>{cover_download}</div>
    {render_credit(cfg)}
  </div>
</div>
{header_html}
<div class="layout">
  <aside class="sidebar" aria-label="内容目录"><div class="side-hint">内容目录</div>{''.join(nav)}</aside>
  <main>
    {''.join(sec_html)}
    <div class="no-result">没有找到匹配的章节，换个关键词试试</div>
    {pager}
  </main>
</div>
{render_dock(attachments, cfg["dock_note"])}
{lightbox}
<script>{desktop_gate.JS}{JS}{cover_design.JS}{gallery_layouts.JS}{china_map.JS}</script>
</body></html>'''
