#!/usr/bin/env python3
"""为同引擎已有 HTML 应用固定视觉基准；只创建新目录，不覆盖源文件。"""
import argparse
import json
import re
import shutil
from pathlib import Path
from design_tokens import tokens, selection
from cover_design import MARKUP,CSS,JS,SKIN_CSS
from typography_rules import CSS as TYPE_CSS


def apply(src,out,palette='air-blue',cover_mode='fluid',cover_surface='light',shell_mode='light'):
    src,out=Path(src).resolve(),Path(out).resolve()
    if out==src.parent or src.parent in out.parents:
        raise ValueError('新版输出必须位于源项目之外，避免递归复制')
    if out.exists(): raise FileExistsError('新版目录已存在，请使用新版本目录')
    s=src.read_text(encoding='utf-8')
    if 'id="cover"' not in s or 'class="brand"' not in s:
        raise ValueError('只支持 handbook-workshop 的独立封面 HTML，不强改其他网页')
    # Older reader pages include engine version and designer in this generated
    # row. Migrate only that row, preserving the material date and its visibility.
    date_match=re.search(r'<span\b[^>]*class="credit-date"[^>]*>(.*?)</span>',s,re.S)
    material_date=re.search(r'\d{4}-\d{2}-\d{2}',date_match[1]) if date_match else None
    show_date=bool(date_match and not re.search(r'\bhidden\b',date_match[0].split('>',1)[0]))
    def date_only(match):
        date_span=re.search(r'<span\b[^>]*class="credit-date"[^>]*>.*?</span>',match[1],re.S)
        return '<div class="design-credit">'+date_span[0]+'</div>' if date_span else ''
    s=re.sub(r'<div\b[^>]*class="design-credit"[^>]*>(.*?)</div>',date_only,s,flags=re.S)
    shutil.copytree(src.parent,out,ignore=shutil.ignore_patterns('.DS_Store'))
    assets=out/'assets';assets.mkdir(exist_ok=True)
    brand=Path(__file__).resolve().parent.parent/'assets'/'brand'
    shutil.copy2(brand/'daikin-color.png',assets/'logo.png')
    shutil.copy2(brand/'daikin-white.png',assets/'logo-white.png')
    logo='logo-white.png' if cover_surface=='dark' else 'logo.png'
    s=re.sub(r'<div class="cover-brand-text">.*?</div>',f'<img class="cover-logo" src="assets/{logo}" alt="大金 DAIKIN">',s,count=1,flags=re.S)
    s=re.sub(r'(<div class="brand">).*?(</div>)',r'\1<img class="brand-logo" src="assets/logo.png" alt="大金 DAIKIN">\2',s,count=1,flags=re.S)
    s=s.replace('<div class="cover" id="cover">',f'<div class="cover'+(' cover-fluid-mode' if cover_mode=='fluid' else '')+f'" id="cover" data-surface="{cover_surface}">\n'+(MARKUP if cover_mode=='fluid' else ''),1)
    palette,shell_mode=selection(dict(palette=palette,shell_mode=shell_mode))
    cfg=dict(palette=palette,shell_mode=shell_mode,type_scale='standard',cover_mode=cover_mode,cover_surface=cover_surface,header_surface=shell_mode,logo_header_height=28,logo_cover_height=48)
    if material_date:
        cfg.update(updated_at=material_date[0],show_update_date=show_date)
    fonts=Path(__file__).resolve().parent.parent/'assets'/'fonts'
    shutil.copytree(fonts,assets/'fonts',dirs_exist_ok=True)
    s=re.sub(r'(<html\b[^>]*)(?=>)',lambda m:re.sub(r' data-shell="[^"]*"','',m[1])+' data-shell="'+shell_mode+'"',s,count=1)
    s=re.sub(r'<header class="topbar"[^>]*>', '<header class="topbar" data-surface="'+shell_mode+'">',s,count=1)
    if shell_mode=='dark':
        s=s.replace('class="brand-logo" src="assets/logo.png"','class="brand-logo" src="assets/logo-white.png"')
    overrides=':root{'+''.join(k+':'+v+';' for k,v in tokens(cfg).items())+'}'
    s=s.replace('</head>','<style id="handbook-design-v11">'+SKIN_CSS+CSS+TYPE_CSS+overrides+'</style></head>',1)
    s=s.replace('</body>','<script>'+JS+'</script></body>',1)
    (out/'index.html').write_text(s,encoding='utf-8')
    (out/'design.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'tokens.css').write_text(overrides,encoding='utf-8')
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--src',required=True);ap.add_argument('--out',required=True)
    ap.add_argument('--palette',default='air-blue');ap.add_argument('--cover-mode',choices=['fluid','plain'],default='fluid')
    ap.add_argument('--cover-surface',choices=['light','dark'],default='light')
    ap.add_argument('--shell-mode',choices=['light','dark'],default='light')
    a=ap.parse_args();print(apply(a.src,a.out,a.palette,a.cover_mode,a.cover_surface,a.shell_mode))
