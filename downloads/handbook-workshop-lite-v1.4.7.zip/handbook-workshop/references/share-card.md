# B04 分享卡片元信息

适用：手册或资料中心的链接需要转发时，提供标题、描述、规范链接和图片。归“基础规范”，不是正文内容块。默认关闭；不配分享字段时不插入任何分享标签或首图，不改变既有页面。分享信息不随通用“配色、字体与字号”配置导出。

## 能力与边界

生成静态 Open Graph 元信息，配置图片时补充 Twitter Card 与 image_src；可选在 body 首位插入移出视口的方图提示。没有额外公众号、域名申请或服务器签名依赖，但实际分享的页面和图片需能被目标平台访问。

首图提示使用空 alt、aria-hidden、固定定位和低资源优先级；不参与阅读、键盘操作或页面宽度。它是项目经验形成的可选尝试，不是微信公开保证。不能承诺任何客户端一定出图、卡片形态、来源名称或缓存刷新时效。手机/电脑及不同账号的结果分别记录，不能用一次实测代替平台规则。

样式库成品样例使用用户提供的截图，代表那一次实际效果；不作为本版独立真机验收。B04 不改变手册既定的手机/平板拦截策略。

## 配置

这些是发布设置，不是色系设置。可以在 `project-style.json` 提供公共图片默认值；在各页 `content.json` 的 `config` 或页面构建配置中设置自己的 `share_url`。页面显式值优先，包括 `share_enabled:false` 和空字符串（取消继承）。多本手册不能无意共用同一个规范链接。

```json
{
  "share_url": "https://example.com/manual/index.html",
  "share_title": "门店工作手册",
  "share_description": "按阶段查阅与执行",
  "share_image": "https://example.com/assets/share-cover.png",
  "share_thumb": "https://example.com/assets/share-thumb.png"
}
```

- `share_image`：分享封面绝对 http(s) URL，建议不透明图。建议尺寸是 1200×630，但不是强制裁切规则。
- `share_thumb`：可选方图绝对 http(s) URL，建议 600×600、信息少且缩小仍可读；省略则不插首图。
- `share_url`：当前页对外的完整 http(s) 链接；不自动复制 query 中的凭证。章节锚点不能保证独立卡片。
- `share_title` / `share_description`：可选；省略时沿用页面标题和说明，不改变网页可见标题或正文。
- `share_image_width` / `share_image_height`：可选，必须同时给正整数并与真实像素一致；未知时省略，不固定编造尺寸。
- `share_image_alt`：可选图片说明，省略时用分享标题。
- `share_enabled`：可选布尔值。默认根据三个 URL 字段是否配置启用；设为 false 可在页面级关闭继承。三个 URL 都不配时关闭。

URL 只接受完整 http(s) 地址，不接受相对路径、javascript/data/file、空白字符或带账号密码的地址。构建不请求图片、不偷偷下载外部资源；生成通过不等于爬虫可访问。

图片如果需要登录或被防盗链阻止，优先提供明确允许公开访问的独立缩略图。不要把 cookie、密钥或项目分享码塞进公共样例、默认配置或视觉配置下载。仅在用户明确选择可转发的带凭证链接时保留该完整 URL；不可自动给其他资源追加凭证。

## 给已经做好的页面加 B04

**升级技能不会自动改写旧页面或旧项目自带的 runtime。**

### 已有成品 HTML，或旧版手册不想换排版

保留原目录，准备一份上述结构的 `share-card.json`，用新版技能执行：

```sh
python3 scripts/apply_share_card.py --src 已有项目/index.html --config share-card.json --out 已有项目-B04版
```

输出必须是原项目外的全新目录。脚本复制同目录资源，只替换该页的分享元信息和旧 share-thumb，不重新排版，不改正文、HTML 可见标题、字体、交互或资料更新日期。适用于完整 UTF-8 静态 HTML；不执行其中的脚本，不强改框架模板。原目录永远保留；含符号链接的项目先提供携带实际资源的发布目录。

输出保留原 HTML 文件名，并附 `share-card.json`，用于以后重复应用。再次追加会替换既有分享字段而非重复堆叠；输出目录仍须另用新名称。此方式不修改旧 build.py：**以后重建正文后，需要再次运行追加步骤**。若要长期随重建生效，应在源工程的新版引擎接入下面的配置流程。

### 已接入 V1.4.7 或更新引擎的源工程

把发布配置放入页面构建配置；项目共用图片可放 project-style.json。运行原 build.py；资料中心的 build_page 同样支持。每页 share_url 显式指定，原资料日期不刷新。引擎复制进独立项目时须携带 share_card.py；不要用旧 WorkBuddy 核心文件整份覆盖新版引擎。

### 给 Agent 的可复用指令

> 使用网页手册工坊，给【现有项目目录】追加 B04 分享卡片。页面地址【URL】，分享标题【标题】，说明【一句话】，封面图【公开图片 URL】，方形缩略图【可选 URL】。另存新版，保留原排版、正文、字体、交互和资料日期，SDK 不启用。核对标签与图片可访问性，微信效果标记“未验证，需真机确认”。

## 校验和关闭

检查静态 head 的标题、说明、图片与当前页 URL 是否正确；图片尺寸声明是否与实际一致；body 首图是否移出视口；页面无横溢及新增 JS 错误。发布后不带 cookie 检查图片实际响应和内容类型；状态 200 不能代替客户端真机确认。设置中的“卡片示意”不是实际微信渲染器。

未配置与显式关闭均应无注入。新引擎删除发布字段或设 share_enabled:false 后重建；成品追加工具可用 `{"share_enabled":false}` 另存关闭版。回到原件目录也是完整回滚。成品追加会管理同名 Open Graph / Twitter Card / image_src 字段，其他元信息保留。

## SDK 后续能力：仅预留，未接入

- 微信内网页 JS-SDK：需有接口权限的服务号、可验证安全域名及后端签名；未启用不加载 SDK。
- PC OpenSDK：网站应用审核、业务域名、分享权限及后端一次性 ticket；主动分享与普通转发链接是两件事，官方可用范围仍需在启用时复核。
- 移动 App OpenSDK：自有 App 场景；不是静态网页插件。

本版不申请账号、不配置域名、不部署签名服务、不添加空壳分享按钮。密钥只在服务端。真实客户端效果：**未验证，需真机确认**。

官方资料：[Open Graph](https://ogp.me/)、[微信网页 JS-SDK](https://developers.weixin.qq.com/doc/service/guide/h5/jssdk.html)、[PC 分享](https://developers.weixin.qq.com/doc/oplatform/Website_App/WeChat_PC_APIs/share.html)、[移动 App 分享](https://developers.weixin.qq.com/doc/oplatform/Mobile_App/Share_and_Favorites/Share_and_Favorites.html)。
