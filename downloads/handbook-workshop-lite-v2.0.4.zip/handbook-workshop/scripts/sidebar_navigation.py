"""Shared, theme-aware handbook directory; native HTML, no icon-font dependency."""
CSS=r'''
/* Hallmark · component: handbook directory · genre: modern-minimal · theme: existing project
 * pre-emit critique: P5 H5 E5 S5 R5 V4 · states follow native disclosure and navigation. */
:root{--hw-sidebar-expanded:16rem;--hw-sidebar-icon:1.125rem;--hw-sidebar-duration:280ms;--hw-sidebar-ease:cubic-bezier(.22,1,.36,1)}
html{scrollbar-gutter:stable}
body>.topbar .menu-btn.home-btn{display:inline-flex;align-items:center;justify-content:center;gap:.375rem;inline-size:auto;width:auto;block-size:2.25rem;min-block-size:2.25rem;padding:0 .8125rem;font-size:var(--fs-note);border-radius:var(--r-ctl)}
body>.topbar .menu-btn.home-btn svg{inline-size:1.0625rem;block-size:1.0625rem;flex:none}
body>.topbar .menu-btn[hidden]{display:none}
.hw-directory-icon{display:block;inline-size:var(--hw-sidebar-icon);block-size:var(--hw-sidebar-icon);flex:none;color:currentColor}
.layout>.sidebar.hw-directory{display:flex;flex-direction:column;padding:.75rem .625rem .5rem;overflow:hidden;border-inline-end:1px solid var(--nav-line);background:var(--nav-bg);color:var(--nav-text)}
.hw-directory-head{display:flex;align-items:center;gap:.5rem;flex:none;padding:.25rem .5rem .875rem;min-block-size:3.25rem}
.hw-directory .side-hint{display:flex;align-items:baseline;justify-content:space-between;gap:.5rem;flex:1;margin:0;font-size:.8125rem;font-weight:var(--weight-medium,550);letter-spacing:0;color:var(--nav-text)}
.hw-directory .side-hint small{display:none;font-size:.75rem;font-weight:var(--weight-body,450);color:var(--nav-muted);white-space:nowrap}
.hw-directory .hw-directory-items{flex:1;min-block-size:0;overflow:auto;overscroll-behavior:contain;padding:.125rem .25rem .5rem;scrollbar-width:thin;scrollbar-color:var(--nav-line) transparent}
.hw-directory .nav-group,.hw-directory .nav-flat{margin:0 0 .25rem;border:0;padding:0}
.hw-directory .nav-group summary{border-radius:.625rem}
.hw-directory .nav-group-title,.hw-directory .nav-link.nav-bare{display:flex;align-items:center;justify-content:flex-start;gap:.375rem;min-block-size:2.5rem;margin:0;padding:.5rem .625rem;border-radius:.375rem;font-size:.875rem;line-height:1.5;color:var(--nav-text);font-weight:var(--weight-navigation,550)}
.hw-directory .nav-group-title::after{display:none}.hw-nav-label{flex:1;min-inline-size:0;overflow-wrap:anywhere;text-align:start}
.hw-nav-count{flex:none;font-size:.6875rem;line-height:1.5;color:var(--nav-muted);font-variant-numeric:tabular-nums;min-inline-size:1.125rem;text-align:center}
.hw-nav-chevron{inline-size:.875rem;block-size:.875rem;flex:none;transition:transform var(--hw-sidebar-duration) var(--hw-sidebar-ease)}
.hw-directory .nav-group[open] .hw-nav-chevron{transform:rotate(180deg)}
.hw-directory .nav-group-links{border:0;margin:0 0 .375rem .625rem;padding:0}
.hw-directory .nav-group-links .nav-link{position:relative;gap:.5rem;margin:0;padding:.375rem .5rem;min-block-size:2.25rem;font-size:.8125rem;line-height:1.55;border-radius:.25rem;color:var(--nav-muted)}
.hw-directory .nav-group-links .nav-dot{display:none}
.hw-directory .nav-group-title[data-current=true]{background:transparent;color:var(--nav-text);font-weight:var(--weight-title,600)}
.hw-directory .nav-link.target-current{background:var(--nav-active-bg);color:var(--nav-active-text)}
.hw-directory .nav-link.target-current{font-weight:var(--weight-navigation,600)}
.hw-directory .nav-group-links .nav-link.target-current::before{content:'';position:absolute;inset-inline-start:0;inset-block:.625rem;inline-size:3px;border-radius:2px;background:currentColor}
.hw-sidebar-toggle,.hw-drawer-close{display:inline-flex;align-items:center;justify-content:center;gap:.625rem;flex:none;min-block-size:2.75rem;min-inline-size:2.75rem;font:inherit;font-size:.8125rem;border:1px solid var(--nav-line);border-radius:.625rem;background:transparent;color:var(--nav-text);cursor:pointer}
.hw-sidebar-toggle{margin:0;padding:0;justify-content:center;border:0;inline-size:2.5rem;block-size:2.5rem;min-block-size:2.5rem;min-inline-size:2.5rem}.hw-drawer-close{display:none;margin:0;padding:0}
.hw-directory .design-credit{flex:none;font-size:.6875rem;line-height:1.5;margin:.5rem .5rem .125rem;padding:.5rem 0 0;border-color:var(--nav-line);color:var(--nav-muted)}
.hw-directory :is(a,summary,button):focus-visible,body>.topbar .menu-btn:focus-visible{outline:3px solid var(--nav-active-text);outline-offset:-2px}
body>.topbar[data-surface=light] .menu-btn:focus-visible{outline-color:var(--focus)}
.hw-directory :is(a,summary,button):active,body>.topbar .menu-btn:active{transform:translateY(1px)}
.hw-directory [aria-disabled=true],body>.topbar .menu-btn:disabled{opacity:.5;cursor:not-allowed;transform:none}
.hw-directory [aria-busy=true]{cursor:progress}.hw-directory [data-state=error]{outline:2px solid var(--nav-text)}.hw-directory [data-state=success]{border-color:var(--nav-active-text)}
.hw-drawer-backdrop[hidden]{display:none}
.hw-directory .hw-directory-section-label{margin:.875rem .625rem .375rem;font-size:.6875rem;line-height:1.5;font-weight:var(--weight-medium,550);color:var(--nav-muted);letter-spacing:.035em}
.hw-directory .hw-directory-section-label:first-child{margin-block-start:.25rem}
.hw-directory .nav-group-links .nav-link:has(.hw-nav-code){display:grid;grid-template-columns:2.75rem minmax(0,1fr);gap:.375rem;align-items:baseline}
.hw-nav-code{font-size:.75rem;line-height:1.55;font-weight:var(--weight-body,450);font-variant-numeric:tabular-nums;white-space:nowrap}
.hw-nav-title{min-inline-size:0;overflow-wrap:anywhere}
@media(hover:hover){.hw-directory :is(.nav-link,.nav-group-title,.hw-sidebar-toggle,.hw-drawer-close):hover{background:var(--nav-active-bg);color:var(--nav-text)}body>.topbar .menu-btn:hover{background:var(--accent-soft)}body>.topbar[data-surface=dark] .menu-btn:hover{background:var(--nav-active-bg)}}
/* A single open/closed sidebar at every desktop window width; no icon rail. */
:root{--sidebar-width:var(--hw-sidebar-expanded)}
html.hw-nav-collapsed{--sidebar-width:0rem}
body .layout{display:grid;grid-template-columns:var(--sidebar-width) minmax(0,1fr);gap:0;padding-inline:0}
body .layout>main{grid-column:2;min-inline-size:0;inline-size:100%}
body .layout>.sidebar.hw-directory{position:fixed;inset-inline-start:0;top:var(--header-height,3.75rem);bottom:0;inline-size:var(--hw-sidebar-expanded);width:var(--hw-sidebar-expanded);block-size:calc(100dvh - var(--header-height,3.75rem));max-block-size:none;max-height:none;transform:none;visibility:visible;z-index:40}
html.hw-nav-collapsed body .layout>.sidebar.hw-directory{transform:translateX(-100%);visibility:hidden}
.hw-directory-ready body .layout{transition:grid-template-columns 220ms var(--hw-sidebar-ease)}
.hw-directory-ready body .layout>.sidebar.hw-directory{transition:transform 220ms var(--hw-sidebar-ease),visibility 0s}
html.hw-directory-ready.hw-nav-collapsed body .layout>.sidebar.hw-directory{transition:transform 180ms var(--hw-sidebar-ease),visibility 0s 180ms}
body .pagerbar{inset-inline-start:var(--sidebar-width)}
.hw-directory-ready body .pagerbar{transition:inset-inline-start 220ms var(--hw-sidebar-ease)}
.hw-directory .hw-sidebar-toggle{display:inline-flex;inline-size:auto;min-inline-size:3rem;padding-inline:.5rem;font-size:.75rem}
@media(prefers-reduced-motion:reduce){.hw-nav-chevron{transition:none}.hw-directory-ready body :is(.layout,.layout>.sidebar.hw-directory,.pagerbar){transition:none!important}.hw-directory :is(a,summary,button):active,body>.topbar .menu-btn:active{transform:none}}
@media(forced-colors:active){.hw-directory .nav-link.target-current,.hw-directory .nav-group-title[data-current=true]{outline:1px solid Highlight}}
@media print{.hw-directory,.hw-drawer-backdrop{display:none!important}body .layout{display:block}body .layout>main{inline-size:100%}}
'''

JS=r'''
(()=>{
 const sidebar=document.querySelector('.layout > .sidebar'),main=document.querySelector('.layout > main'),header=document.querySelector('body > .topbar'),old=header?.querySelector('.menu-btn');
 if(!sidebar||!main||!header){if(old)old.hidden=true;return;}
 const trigger=old?old.cloneNode(true):document.createElement('button');old?.remove();trigger.type='button';trigger.className='menu-btn home-btn';trigger.dataset.directoryTrigger='true';trigger.textContent='目录';trigger.setAttribute('aria-controls','handbook-directory');header.insertBefore(trigger,header.querySelector('.skill-download-header,#home-btn'));
 sidebar.id='handbook-directory';sidebar.classList.add('hw-directory');
 const hint=sidebar.querySelector('.side-hint')||document.createElement('div');hint.className='side-hint';hint.textContent='内容目录';
 const head=document.createElement('div');head.className='hw-directory-head';const close=document.createElement('button');close.type='button';close.className='hw-sidebar-toggle';close.textContent='收起';close.setAttribute('aria-label','收起目录');head.append(hint,close);sidebar.prepend(head);
 const nav=document.createElement('nav');nav.className='hw-directory-items';nav.setAttribute('aria-label','手册章节');[...sidebar.children].filter(x=>x.matches('.nav-group,.nav-flat,.nav-link,.hw-directory-section-label')).forEach(x=>nav.append(x));head.after(nav);
 nav.querySelectorAll(':scope > .nav-group').forEach(group=>{const summary=group.querySelector('summary'),title=summary.querySelector('.nav-group-title')||summary,label=title.textContent.trim(),name=document.createElement('span');name.className='hw-nav-label';name.textContent=label;title.replaceChildren(name);title.insertAdjacentHTML('beforeend','<svg class="hw-nav-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true"><path d="m7 10 5 5 5-5"/></svg>');});
 nav.querySelectorAll('.nav-link').forEach(a=>{const label=a.textContent.trim();a.querySelector('.nav-dot')?.remove();const match=label.match(/^([A-Z]\d{2}(?:-[A-Z])?)\s+(.+)$/);if(match){const code=document.createElement('span'),name=document.createElement('span');code.className='hw-nav-code';code.textContent=match[1];name.className='hw-nav-title';name.textContent=match[2];a.replaceChildren(code,name);}});
 let collapsed=false;try{collapsed=localStorage.getItem('handbook-directory-collapsed')==='true';}catch(e){}
 function currentIntoView(){const current=nav.querySelector('.target-current');if(!collapsed&&current){const r=current.getBoundingClientRect(),n=nav.getBoundingClientRect();if(r.top<n.top||r.bottom>n.bottom)nav.scrollTop+=r.top-n.top-nav.clientHeight/3;}}
 function sync(){document.documentElement.classList.toggle('hw-nav-collapsed',collapsed);trigger.setAttribute('aria-expanded',String(!collapsed));trigger.setAttribute('aria-label',collapsed?'打开目录':'收起目录');sidebar.inert=collapsed;if(collapsed)sidebar.setAttribute('aria-hidden','true');else sidebar.removeAttribute('aria-hidden');nav.querySelectorAll('.nav-group').forEach(g=>{g.querySelector('.nav-group-title').dataset.current=String(!!g.querySelector('.target-current'));});}
 function setCollapsed(value){if(!!value===collapsed)return;if(value&&sidebar.contains(document.activeElement))trigger.focus({preventScroll:true});collapsed=!!value;sync();try{localStorage.setItem('handbook-directory-collapsed',String(collapsed));}catch(e){}window.dispatchEvent(new Event('resize'));if(!collapsed)currentIntoView();}
 trigger.addEventListener('click',()=>setCollapsed(!collapsed));close.addEventListener('click',()=>setCollapsed(true));document.addEventListener('keydown',e=>{if(e.key==='Escape'&&sidebar.contains(document.activeElement)){e.preventDefault();setCollapsed(true);}});
 sidebar.addEventListener('transitionend',e=>{if(e.propertyName==='transform'){window.dispatchEvent(new Event('resize'));currentIntoView();}});addEventListener('hb:sectionchange',()=>{sync();currentIntoView();});new MutationObserver(sync).observe(nav,{subtree:true,attributes:true,attributeFilter:['class','open']});sync();requestAnimationFrame(()=>requestAnimationFrame(()=>document.documentElement.classList.add('hw-directory-ready')));
 // Remove suffix decorations from text actions; keep arrows that are the entire control (paging, galleries).
 function simplifyActions(root){const controls=[...(root.matches?.('a,button')?[root]:[]),...root.querySelectorAll('a,button')];for(const el of controls){if(el.matches('#pager-prev,#pager-next')||el.textContent.trim().length<2)continue;const walk=document.createTreeWalker(el,NodeFilter.SHOW_TEXT);let node;while(node=walk.nextNode()){const next=node.nodeValue.replace(/\s*[→↗↓]+\s*$/u,'');if(next!==node.nodeValue)node.nodeValue=next;}el.querySelectorAll('span[aria-hidden=true]').forEach(x=>{if(!x.textContent.trim()&&!x.querySelector('svg'))x.remove();});if(el.matches('.skill-download-header,[download]')&&el.textContent.trim())el.querySelectorAll('svg').forEach(x=>x.remove());}}
 simplifyActions(document.body);new MutationObserver(rows=>{for(const row of rows)for(const node of row.addedNodes)if(node.nodeType===1)simplifyActions(node);}).observe(document.body,{childList:true,subtree:true});
})();
'''
