"""短语保护是明确词库/内容标记，不假装通用语义理解。"""
import html,re
import font_catalog
BASE_PHRASES=('增长渠道','城市合伙人','中央空调','大金空调','新零售','资料中心','楼盘加私','私信跟进','配套附件','门店老板','可持续获客')
project_phrases=[]


def text(value,extra=None):
    value=str(value)
    terms=sorted({x for x in [*BASE_PHRASES,*project_phrases,*(extra or [])] if isinstance(x,str) and x.strip() and '\n' not in x},key=len,reverse=True)
    pattern='|'.join(re.escape(x) for x in terms)+r'|-?\d+(?:\.\d+)?\s?(?:%|℃|°C|kWh|mm|cm|㎡|万元|元|小时|分钟|天|人|项|节)'
    parts=[];start=0
    for m in re.finditer(pattern,value):
        parts.append(html.escape(value[start:m.start()],quote=True))
        parts.append('<span class="phrase-unit">'+html.escape(m.group(),quote=True)+'</span>');start=m.end()
    parts.append(html.escape(value[start:],quote=True))
    return ''.join(parts).replace('\n','<br>')

CSS=font_catalog.faces_css()+r'''

body,button,input,textarea,select{font-family:var(--sans)}
body{font-weight:var(--weight-body,330)}
.cover-actions{display:flex;flex-wrap:wrap;justify-content:center;align-items:stretch;gap:.875rem}
.cover-download{display:inline-flex;align-items:center;justify-content:center;gap:.625rem;border:1px solid var(--border);border-radius:.875rem;background:var(--surface);color:var(--brand);padding:.875rem 1.5rem;min-block-size:3.25rem;font-size:1rem;font-weight:var(--weight-medium,430);line-height:1.5;text-decoration:none}
.cover-download:hover{background:var(--accent-soft);border-color:var(--accent)}
.skill-download-card{padding:1.25rem;border:1px solid var(--border);border-radius:1rem;background:var(--accent-soft);margin-block:1.25rem}
.skill-download-card strong{font-weight:var(--weight-title,500);color:var(--brand)}
.skill-download-card p{margin-block:.5rem .875rem;font-size:.9375rem;color:var(--text)}
.skill-download-card a{display:inline-flex;align-items:center;gap:.5rem;min-block-size:2.75rem;padding:.625rem 1rem;background:var(--accent);color:#fff;border-radius:.625rem;text-decoration:none;font-weight:var(--weight-medium,430)}
.design-credit{font-size:.75rem;font-weight:var(--weight-body,330);line-height:1.8;color:var(--muted);margin-block:1.5rem .25rem}
.design-credit:has(>.credit-date[hidden]){display:none}
.design-credit [hidden]{display:none}
.cover .design-credit{color:var(--cover-muted,var(--muted))}
:root{--sidebar-width:16.5rem;--header-height:3.75rem;color-scheme:light;--cover-title-weight:500;--cover-description-weight:330}
.section h2,.section h3,.section h4{font-weight:550}
.cover h1{font-weight:var(--cover-title-weight)}
.cover p{font-weight:var(--cover-description-weight)}
.cover .cover-kicker{font-weight:400}
.cover .cover-start{font-weight:450}
.card-title,.pick-card .card-title,.pick-card.on .card-title{font-weight:520!important}
.sidebar .nav-group-title,.sidebar .nav-link.nav-bare,.sidebar .nav-link.target-current{font-weight:var(--weight-medium,430)}
.home-btn,.pager-btn,.tab-head,.cover-start,.mm-name,.mm-act-label{font-weight:var(--weight-title,500)}
.topbar-title{font-size:1.0625rem!important;font-weight:400!important;color:var(--brand)!important;line-height:1.3}
.topbar-title .project-name{font-size:1.0625rem;font-weight:var(--weight-title,500)}
.topbar-title .document-name{font-size:.875rem;font-weight:var(--weight-body,330);color:var(--muted)}
html[data-shell=dark] .topbar{background:linear-gradient(105deg,var(--nav-bg),var(--nav-bg2));border-color:var(--nav-line)}
/* Dark chrome owns its controls; reader content remains light. */
.topbar[data-surface=dark]{color-scheme:dark;color:var(--nav-text);--header-control-bg:rgba(255,255,255,.07);--header-control-hover:rgba(255,255,255,.12);--header-control-line:rgba(255,255,255,.28)}
.topbar[data-surface=dark] .search-box input,.topbar[data-surface=dark] .home-btn{background:var(--header-control-bg);border-color:var(--header-control-line);color:var(--nav-text);box-shadow:none;caret-color:var(--nav-text)}
.topbar[data-surface=dark] .search-box input::placeholder{color:var(--nav-text);opacity:1}
.topbar[data-surface=dark] .search-box svg{color:var(--nav-text)}
.topbar[data-surface=dark] .search-box input:hover,.topbar[data-surface=dark] .home-btn:hover{background:var(--header-control-hover);border-color:var(--nav-muted)}
.topbar[data-surface=dark] .search-box input:focus{background:var(--header-control-hover);border-color:var(--nav-active-text);box-shadow:none;outline:none}
.topbar[data-surface=dark] .search-box input:focus-visible,.topbar[data-surface=dark] .home-btn:focus-visible{outline:1.5px solid var(--nav-active-text);outline-offset:2px;box-shadow:none}
body.viewing{background:linear-gradient(90deg,var(--nav-bg) 0 var(--sidebar-width),var(--bg) var(--sidebar-width) 100%);min-block-size:100dvh}
@media(forced-colors:active){.topbar[data-surface=dark] :is(input,.home-btn):focus-visible{outline:2px solid Highlight}}
html[data-shell=dark] .topbar-title .project-name{color:var(--nav-text)}
html[data-shell=dark] .topbar-title .document-name{color:var(--nav-muted)}
/* Geometry is shared by both modes. Theme selectors below may only paint. */
.topbar{block-size:var(--header-height)}
.topbar .brand{flex:none}.topbar .brand-logo{inline-size:calc(var(--logo-header-height)*3.94);object-fit:contain}
.topbar .menu-btn{display:none}
.layout{max-width:none;grid-template-columns:var(--sidebar-width) minmax(0,1fr);gap:0;padding:0 0 6rem}
.layout>.sidebar{position:fixed;inset-inline-start:0;top:var(--header-height);bottom:0;inline-size:var(--sidebar-width);block-size:calc(100dvh - var(--header-height));max-block-size:calc(100dvh - var(--header-height));border-radius:0;padding:1.5rem 1.125rem;transform:none;z-index:40}
.layout>main{grid-column:2;inline-size:100%;max-inline-size:86rem;margin-inline:auto;padding:2rem clamp(1.5rem,3vw,3rem)}
.sidebar .nav-group summary{border:0;border-radius:0;background:transparent}
.sidebar .nav-link.nav-bare{border-radius:.5rem;margin-block-end:.375rem}
.pagerbar{inset-inline-start:var(--sidebar-width)}
.pager{max-width:none;padding-inline:clamp(1.5rem,3vw,3rem)}
.section{scroll-margin-block-start:calc(var(--header-height) + 1.5rem)}
html[data-shell=dark] .sidebar{color-scheme:dark;scrollbar-color:var(--nav-muted) transparent}
.data-table thead,.data-table thead th,.rt thead th{background:var(--table-head-bg)!important;color:var(--table-head-text)!important}
.data-table td{background:var(--surface)}
.rt thead th,.rt-cap,.rs-head{border-color:var(--border)}
.rt tbody tr:hover td,.tab-head{background:var(--accent-soft)}
.cmp-side.cmp-now{background:var(--compare-before-bg,#F7F9FC)}
.cmp-now .cmp-tag{background:#E8EDF3;color:var(--muted)}
.cmp-side.cmp-need{background:var(--accent-soft)}
.cmp-need .cmp-tag{background:color-mix(in oklab,var(--accent) 15%,var(--surface));color:var(--compare-after-label,var(--brand))}
.tt{background:linear-gradient(120deg,var(--brand),var(--brand2))}
.sidebar{background:var(--nav-bg);border-radius:0;scrollbar-width:thin;scrollbar-color:var(--nav-line) transparent;color-scheme:light;color:var(--nav-text)}
.sidebar .side-hint{font-weight:400;margin-block-end:.75rem}
.sidebar .nav-group{border:0;margin-block-end:.375rem;padding-block-end:0}
.sidebar .nav-flat{border:0;margin-block-end:.375rem}
.sidebar .nav-group-title,.sidebar .nav-link.nav-bare{font-weight:var(--weight-medium,430);font-size:.9375rem;line-height:1.5;letter-spacing:0;padding:.625rem .75rem;border:0}
.sidebar .nav-group-links{padding-block:.125rem .375rem}
.sidebar .nav-link{font-weight:var(--weight-body,330);line-height:1.5}
.sidebar .nav-link.target-current{font-weight:var(--weight-medium,430)}
.sidebar .side-hint,.sidebar .nav-link{color:var(--nav-muted)}
.sidebar .nav-group-title,.sidebar .nav-link.nav-bare{color:var(--nav-text)}
.sidebar .nav-group{border-color:var(--nav-line)}
.sidebar .nav-link.target-current,.sidebar .nav-link.nav-bare.target-current{background:var(--nav-active-bg);color:var(--nav-active-text)}
.sidebar .nav-link:hover,.sidebar .nav-group-title:hover{background:var(--nav-active-bg);color:var(--nav-text)}
.sidebar .nav-group-title::after{color:var(--nav-muted)}
.sidebar .nav-group-links .target-current .nav-dot{background:var(--nav-active-text)}
.sidebar .nav-group-links .nav-dot{background:var(--nav-muted)}

.phrase-unit{display:inline-block;max-inline-size:100%;white-space:normal;word-break:keep-all;overflow-wrap:anywhere;vertical-align:baseline}
.cmp-card,.cmp-side{min-inline-size:0}
.cmp-body{grid-template-columns:minmax(0,1fr) auto minmax(0,1fr)}
.cmp-side p,.cmp-tag{overflow-wrap:anywhere}
.body-text,.lede,.callout-body,.card-body,.quote{line-break:strict;text-wrap:pretty}
.section h2,.section h3,.cover h1{word-break:normal;text-wrap:balance}
.nav-link.nav-bare>.nav-dot{display:none}
.nav-link.nav-bare{padding-inline-start:.625rem}
.nav-link.nav-bare.target-current{background:var(--accent-soft);color:var(--accent)}
.nav-group-links .nav-dot{display:block;background:var(--muted);opacity:.35}
.nav-group-links .target-current .nav-dot{background:var(--accent);opacity:1}
'''

def decorate_document(source):
    """对旧图鉴的可见文案补短语标记，不修改 pre/code/script 或属性。"""
    from html.parser import HTMLParser
    class Decorator(HTMLParser):
        def __init__(self):super().__init__(convert_charrefs=False);self.stack=[];self.parts=[]
        def handle_starttag(self,tag,attrs):
            self.parts.append(self.get_starttag_text())
            if tag not in ('br','img','input','meta','link','hr','source','wbr','area','base','embed','param','track','col'):
                self.stack.append((tag,dict(attrs)))
        def handle_startendtag(self,tag,attrs):self.parts.append(self.get_starttag_text())
        def handle_endtag(self,tag):
            self.parts.append('</'+tag+'>')
            for i in range(len(self.stack)-1,-1,-1):
                if self.stack[i][0]==tag:self.stack=self.stack[:i];break
        def handle_data(self,data):
            blocked=any(t in ('script','style','pre','code','textarea','svg') for t,a in self.stack)
            active=any(t in ('p','blockquote','h1','h2','h3','h4','figcaption') or set(a.get('class','').split())&{'body-text','card-body','quote','qr-title','lede'} for t,a in self.stack)
            self.parts.append(text(data) if active and not blocked else data)
        def handle_entityref(self,n):self.parts.append('&'+n+';')
        def handle_charref(self,n):self.parts.append('&#'+n+';')
        def handle_comment(self,s):self.parts.append('<!--'+s+'-->')
        def handle_decl(self,s):self.parts.append('<!'+s+'>')
    parser=Decorator();parser.feed(source);return ''.join(parser.parts)
