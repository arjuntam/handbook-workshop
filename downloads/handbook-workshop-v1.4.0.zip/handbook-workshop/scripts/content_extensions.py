"""从实际手册抽取的受控组件；业务文案由内容提供，不执行来源 HTML。"""
from html import escape
from itertools import count

TYPES = {'solution', 'tracks', 'number_strip', 'watermark', 'decision', 'downloads', 'chapter_nav'}
_ids = count(1)


def attachment_index(attachments):
    result = {}
    for a in attachments or []:
        key = a.get('id') or a.get('path')
        if key:
            if key in result:
                raise ValueError('附件标识重复：' + str(key))
            result[key] = a
    return result


def validate(b, section_ids=None, attachments=None):
    t = b['t']
    if t == 'solution':
        if not b.get('quote') or not b.get('blocks'):
            raise ValueError('solution 需要 quote 与 blocks；只有引语时使用 quote.reveal')
    elif t == 'downloads':
        refs = b.get('attachment_ids', [])
        if not refs or len(refs) != len(set(refs)):
            raise ValueError('downloads 需要非空且不重复的 attachment_ids')
        if attachments is not None:
            index = attachment_index(attachments)
            for ref in refs:
                if ref not in index:
                    raise ValueError('就地附件引用不存在：' + str(ref))
    elif t == 'decision':
        if len(b.get('branches', [])) != 2:
            raise ValueError('decision 必须恰有两个分支')
        for branch in b['branches']:
            if not branch.get('title') or bool(branch.get('steps')) == bool(branch.get('cases')):
                raise ValueError('分支需要 title，且 steps / cases 只选一种')
        if len(b.get('conclusions', [])) > 2:
            raise ValueError('decision 最多两条结论')
    else:
        items = b.get('items', [])
        if not items:
            raise ValueError(t + ' 的 items 不能为空')
        if t == 'tracks' and len(items) != 2:
            raise ValueError('tracks 必须恰有两个互斥体系；纯对照使用 compare')
        if t == 'tracks' and not -1 <= int(b.get('default', -1)) < len(items):
            raise ValueError('tracks.default 超出选项范围')
        for item in items:
            if not item.get('title'):
                raise ValueError(t + ' 每项需要 title')
            if t == 'watermark' and not item.get('rows'):
                raise ValueError('watermark 每板块需要 rows')
            if t == 'chapter_nav' and not item.get('target'):
                raise ValueError('章节导航缺 target')
            target = item.get('target') if t == 'chapter_nav' else item.get('goto') if t == 'tracks' else None
            if target and section_ids is not None and target not in section_ids:
                raise ValueError('章节目标不存在：' + str(target))


def validate_tree(blocks, section_ids, attachments):
    for b in blocks:
        if b.get('t') in TYPES:
            validate(b, section_ids, attachments)
        if b.get('t') == 'solution':
            validate_tree(b.get('blocks', []), section_ids, attachments)
        if b.get('t') == 'tabs':
            for item in b.get('items', []):
                if item.get('block'):
                    validate_tree([item['block']], section_ids, attachments)


def render(b, render_children, attachment_rows, attachments):
    validate(b, attachments=attachments)
    t = b['t']
    def e(v): return escape(str(v), quote=True)
    def text(v): return e(v).replace('\n', '<br>')
    def heading(v): return '<h3 class="hw-title">' + text(v) + '</h3>' if v else ''
    def goto(target, label):
        return '<button type="button" class="xref-chip" data-goto="' + e(target) + '">' + text(label) + '<span class="xc-arrow" aria-hidden="true">→</span></button>'
    if t == 'solution':
        return ('<details class="quote-reveal hw-solution"><summary><span class="qr-title">' + text(b.get('title', '解决方案')) +
                '</span><span class="qr-btn" aria-hidden="true">展开查看</span></summary><blockquote class="quote">' + text(b['quote']) +
                '</blockquote><div class="hw-solution-body">' + render_children(b['blocks']) + '</div></details>')
    if t == 'tracks':
        uid = 'hw-track-' + str(next(_ids)); cards = []
        for i, item in enumerate(b['items']):
            rid = uid + '-' + str(i)
            checked = ' checked' if i == int(b.get('default', -1)) and not item.get('disabled') else ''
            disabled = ' disabled' if item.get('disabled') else ''
            points = ''.join('<span class="hw-track-point"><b>' + text(x['title']) + '</b><span>' + text(x.get('body', '')) + '</span></span>' for x in item.get('items', []))
            action = '<footer>' + goto(item['goto'], item.get('action_label', '查看' + item['title'])) + '</footer>' if item.get('goto') else ''
            # Selection label and navigation are siblings: no action button inside a label.
            cards.append('<article class="hw-track"><input class="hw-track-radio" type="radio" name="' + uid + '" id="' + rid + '" value="' + str(i) + '"' + checked + disabled + '><label class="hw-track-label" for="' + rid + '"><span class="hw-title">' + text(item['title']) + '</span><span class="hw-track-hint">' + text(item.get('hint', '选择此体系')) + '</span><span class="hw-track-points">' + points + '</span><span class="hw-track-foot">' + text(item.get('footer', '')) + '</span></label>' + action + '</article>')
        return '<fieldset class="hw-tracks"><legend>' + text(b.get('title', '选择一个体系')) + '</legend><div class="hw-tracks-grid">' + ''.join(cards) + '</div></fieldset>'
    if t == 'number_strip':
        cards = ''.join('<li class="hw-number-item' + (' is-highlight' if x.get('highlight') else '') + '"><span class="hw-number">' + e(x.get('num', str(i + 1).zfill(2))) + '</span><h4>' + text(x['title']) + '</h4><p>' + text(x.get('body', '')) + '</p></li>' for i, x in enumerate(b['items']))
        return '<div class="hw-number-strip">' + heading(b.get('title')) + '<ol>' + cards + '</ol></div>'
    if t == 'watermark':
        cards = []
        for i, x in enumerate(b['items']):
            n = e(x.get('num', str(i + 1).zfill(2)))
            rows = ''.join('<div><dt>' + text(r['title']) + '</dt><dd>' + text(r.get('body', '')) + '</dd></div>' for r in x['rows'])
            cards.append('<article class="hw-watermark"><span class="hw-watermark-mark" aria-hidden="true">' + n + '</span><header><span class="hw-badge">' + n + '</span><h4>' + text(x['title']) + '</h4>' + ('<p>' + text(x['sub']) + '</p>' if x.get('sub') else '') + '</header><dl>' + rows + '</dl></article>')
        return '<div class="hw-watermarks">' + ''.join(cards) + '</div>'
    if t == 'decision':
        branches = []
        for x in b['branches']:
            body = '<ol class="hw-branch-steps">' + ''.join('<li>' + text(v) + '</li>' for v in x['steps']) + '</ol>' if x.get('steps') else '<dl class="hw-branch-cases">' + ''.join('<div><dt>' + text(v['title']) + '</dt><dd>' + text(v.get('body', '')) + '</dd></div>' for v in x['cases']) + '</dl>'
            branches.append('<article class="hw-branch"><header><span class="hw-branch-tag">' + text(x.get('tag', '')) + '</span><h4>' + text(x['title']) + '</h4></header><p class="hw-desc">' + text(x.get('desc', '')) + '</p>' + body + '</article>')
        conclusions = ''.join('<article><h4>' + text(x['title']) + '</h4><p>' + text(x.get('body', '')) + '</p></article>' for x in b.get('conclusions', []))
        return '<div class="hw-decision">' + heading(b.get('title')) + '<div class="hw-branches">' + ''.join(branches) + '</div>' + ('<div class="hw-conclusions">' + conclusions + '</div>' if conclusions else '') + '</div>'
    if t == 'downloads':
        index = attachment_index(attachments)
        return '<div class="hw-downloads">' + heading(b.get('title', '本章配套附件')) + attachment_rows([index[ref] for ref in b['attachment_ids']]) + '</div>'
    if t == 'chapter_nav':
        return '<nav class="hw-chapter-nav" aria-label="' + e(b.get('title', '本章内容导航')) + '">' + heading(b.get('title', '本章内容导航')) + '<p class="hw-desc">' + text(b.get('desc', '')) + '</p><div>' + ''.join(goto(x['target'], x['title']) for x in b['items']) + '</div></nav>'
    raise ValueError('未知扩展组件：' + t)


CSS = r'''
.hw-title{display:block;font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);line-height:1.4;color:var(--brand);margin:0 0 .75rem;overflow-wrap:anywhere}
.hw-desc{font-size:var(--fs-note);color:var(--muted);line-height:1.7;margin:.5rem 0 1rem;overflow-wrap:anywhere}
.hw-solution-body{padding:0 1rem 1.125rem}
.hw-tracks{min-inline-size:0;border:0;padding:0;margin:1rem 0;container:hw-tracks/inline-size}
.hw-tracks>legend{font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);color:var(--brand);margin-block-end:1rem}
.hw-tracks-grid,.hw-branches{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,20rem),1fr));gap:1rem}
.hw-track{position:relative;display:flex;flex-direction:column;min-inline-size:0;border:1px solid var(--border);border-radius:var(--r-card);background:var(--accent-soft);padding:1.125rem;container:hw-track/inline-size}
.hw-track::before{content:'';position:absolute;inset-inline-start:0;inset-block:1rem;inline-size:4px;border-radius:0 4px 4px 0;background:transparent}
.hw-track:has(>.hw-track-radio:checked){background:var(--selected-bg);border-color:var(--selected-border);box-shadow:var(--selected-shadow)}
.hw-track:has(>.hw-track-radio:checked)::before{background:var(--selected-border)}
.hw-track:has(>.hw-track-radio:focus-visible){outline:3px solid var(--focus);outline-offset:4px}
.hw-track:has(>.hw-track-radio:disabled){opacity:.55}
.hw-track-radio{position:absolute;inline-size:1px;block-size:1px;margin:-1px;padding:0;border:0;clip-path:inset(50%);white-space:nowrap}
.hw-track-label{display:flex;flex-direction:column;flex:1;gap:.75rem;cursor:pointer;min-inline-size:0}
.hw-track:has(>.hw-track-radio:disabled) .hw-track-label{cursor:not-allowed}
.hw-track-label>.hw-title{text-align:center;margin:0}.hw-track-hint{font-size:var(--fs-note);text-align:center;color:var(--muted)}
.hw-track-points{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,10rem),1fr));gap:.75rem;flex:1;align-content:start}
.hw-track-point,.hw-track-foot{display:block;background:var(--surface);border:1px solid var(--border);border-radius:var(--r-ctl);padding:.75rem;overflow-wrap:anywhere}
.hw-track-point b{display:block;font-size:var(--fs-text);font-weight:var(--weight-title,500);line-height:1.5}.hw-track-point>span{display:block;font-size:var(--fs-note);color:var(--muted);line-height:1.7;margin-block-start:.375rem}
.hw-track-foot{margin-block-start:auto;font-size:var(--fs-text);text-align:center;line-height:1.6;color:var(--text)}
.hw-track>footer{margin-block-start:1rem;display:flex;justify-content:center}.hw-track .xref-chip{white-space:normal;max-inline-size:100%}
@container hw-track (inline-size >= 22rem){.hw-track-point:last-child:nth-child(odd){grid-column:1/-1}}
.hw-number-strip>ol{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,8rem),1fr));gap:.75rem;list-style:none;margin:0 0 1.125rem;padding:0}
.hw-number-item{min-inline-size:0;border:1px solid var(--border);border-block-start:2px solid var(--accent);border-radius:var(--r-ctl);padding:1rem .75rem;background:var(--surface);overflow-wrap:anywhere}
.hw-number{display:block;font-size:var(--fs-note);font-weight:var(--weight-title,500);color:var(--accent);margin-block-end:.75rem}
.hw-number-item h4,.hw-watermark h4,.hw-branch h4,.hw-conclusions h4{font-size:var(--fs-cardtitle);font-weight:var(--weight-title,500);line-height:1.5;margin:0;color:var(--brand);overflow-wrap:anywhere}
.hw-number-item p{font-size:var(--fs-note);line-height:1.7;color:var(--muted);margin:.5rem 0 0}
.hw-number-item.is-highlight{background:var(--brand);border-color:var(--brand)}
.hw-number-item.is-highlight :is(.hw-number,h4,p){color:var(--surface)}
.hw-watermark{position:relative;min-inline-size:0;border:1px solid var(--border);border-radius:var(--r-card);padding:1.125rem;margin-block-end:1rem;background:var(--surface);container:hw-watermark/inline-size}
.hw-watermark-mark{position:absolute;inset-inline-end:1rem;inset-block-start:.25rem;font-size:5.2rem;line-height:1;font-weight:600;color:var(--accent);opacity:.05;pointer-events:none;user-select:none}
.hw-watermark>header{position:relative;display:flex;flex-wrap:wrap;align-items:center;gap:.75rem;margin-block-end:1rem}
.hw-badge{display:inline-grid;place-items:center;min-inline-size:1.75rem;min-block-size:1.75rem;padding:.25rem;border-radius:.5rem;background:var(--brand);color:var(--surface);font-size:var(--fs-note);font-weight:var(--weight-title,500)}
.hw-watermark header p{margin:0;padding-inline-start:.75rem;border-inline-start:1px solid var(--border);font-size:var(--fs-note);color:var(--muted);overflow-wrap:anywhere}
.hw-watermark dl,.hw-branch-cases{position:relative;margin:0;display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,20rem),1fr));gap:.75rem 1.25rem}
.hw-watermark dl>div,.hw-branch-cases>div{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,2fr);gap:.75rem;align-items:baseline;border-block-end:1px dashed var(--border);padding-block:.5rem;min-inline-size:0}
.hw-watermark dt,.hw-branch-cases dt{font-size:var(--fs-text);font-weight:var(--weight-title,500);color:var(--text);overflow-wrap:anywhere}
.hw-watermark dd,.hw-branch-cases dd{font-size:var(--fs-text);line-height:1.7;color:var(--muted);margin:0;overflow-wrap:anywhere}
@container hw-watermark (inline-size < 22rem){.hw-watermark dl>div{grid-template-columns:1fr;gap:.25rem}}
.hw-decision{margin-block:1rem}.hw-branch{border:1px solid var(--border);border-block-start:3px solid var(--accent);border-radius:var(--r-card);padding:1.125rem;min-inline-size:0;background:var(--surface)}
.hw-branch:nth-child(2){border-block-start-color:var(--brand)}.hw-branch>header{display:flex;flex-wrap:wrap;align-items:center;gap:.75rem}
.hw-branch-tag{display:inline-block;background:var(--accent-soft);border-radius:999px;padding:.25rem .625rem;font-size:var(--fs-note);color:var(--brand)}
.hw-branch:nth-child(2) .hw-branch-tag{background:var(--brand);color:var(--surface)}
.hw-branch-steps{counter-reset:hw-step;list-style:none;display:grid;gap:.625rem;padding:0;margin:0}
.hw-branch-steps li{display:flex;align-items:baseline;gap:.75rem;border-radius:var(--r-ctl);padding:.75rem;background:var(--accent-soft);font-size:var(--fs-text);line-height:1.7;overflow-wrap:anywhere}
.hw-branch-steps li::before{counter-increment:hw-step;content:counter(hw-step);flex:none;display:inline-grid;place-items:center;min-inline-size:1.5rem;min-block-size:1.5rem;border-radius:.375rem;background:var(--brand);color:var(--surface);font-size:var(--fs-note)}
.hw-branch-cases{grid-template-columns:1fr}.hw-conclusions{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,20rem),1fr));gap:1rem;margin-block-start:1rem}
.hw-conclusions>article{border:1px solid var(--border);border-radius:var(--r-card);padding:1rem;background:var(--accent-soft);min-inline-size:0}
.hw-conclusions p{font-size:var(--fs-text);line-height:1.7;margin:.5rem 0 0;overflow-wrap:anywhere}
.hw-downloads,.hw-chapter-nav{border:1px solid var(--border);border-radius:var(--r-card);padding:1rem;margin-block:1rem;background:var(--surface);min-inline-size:0}
.hw-downloads .dl-row{font-size:var(--fs-text);min-inline-size:0;margin-block:.375rem}.hw-downloads .dl-name{min-inline-size:0;overflow-wrap:anywhere}.hw-downloads .dl-go{margin-inline-start:auto;flex:none;font-size:var(--fs-note)}
.hw-downloads .dl-row:hover{background:var(--accent-soft)}.hw-chapter-nav>div{display:flex;flex-wrap:wrap;gap:.625rem}
.hw-chapter-nav .xref-chip{margin:0;white-space:normal;overflow-wrap:anywhere;max-inline-size:100%}
'''
