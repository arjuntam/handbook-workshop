# 受控变体与资料配套组件

这组组件从实际手册的结构需求提炼。原业务项目的文案、效果数字、附件与章节 ID 不作为公共默认内容；原 X01–X07 只是交接编号，不覆盖现有 X01 受控自定义图形。

| 交接文件 | 公共编号 | 原生类型 t | 采纳方式 |
|---|---|---|---|
| X01-fold | T04-A 折叠解决方案区 | solution | T04 的复合变体，展开引语与已有内容块 |
| X02-track | L02-A 双赛道选择面板 | tracks | L02 的两体系变体，保留单选合同与独立跳章按钮 |
| X03-seven | L01-A 编号横条卡 | number_strip | L01 的紧凑编号变体，不固定七项或七列 |
| X04-watermark | L01-B 水印编号卡 | watermark | L01 的键值板块变体，小编号与装饰水印共存 |
| X05-flow | L20 分流决策面板 | decision | 两条静态条件路径，明确区分步骤与情形动作 |
| X06-inline-dl | A02 就地附件下载区 | downloads | 引用全局附件记录，复用抽屉的行组件 |
| X07-chapter-dir | L21 章节导航卡 | chapter_nav | 修复导出缺头后转原生配置，复用统一章节跳转 |
| 截图：可勾选清单 | L22 复选清单 | checklist | 多项独立勾选与取消，不与 L02 单选混用 |
| 截图：图标展开卡 | L23 图标折叠卡 | icon_folds | 原生独立折叠；展开高亮，图标使用固定 SVG 词库 |
| 截图：编号展开卡网格 | L24 编号折叠卡网格 | number_folds | 编号、标题、说明区与展开状态共用合同 |

在样式库「内容样式」第二级直接查看以上编号；不为变体再增加第三级菜单。完整可复制样例见 `assets/extension-examples.json`，样式库同时导出 `受控组件示例.json`。

## 字段与交互

- `solution`：`title`、`quote`、`blocks`。原生 details 默认收起；blocks 放已有展示卡、单选卡等。只有金句时用 `quote` 的 `reveal:true`。仅需展示的方案要点用 grid，不因为版式相似就加单选。
- `tracks`：`title`、`default`（默认 -1 初始不选）、恰好两个 `items`。每项包含 `title`、`hint`、要点 `items:[{title,body}]`、底部说明 `footer`，可选 `goto` 与 `action_label`，可设 `disabled`。选择用原生同名单选输入；两个组件的组名独立。选择不自动跳章，明确的独立按钮才导航，按钮不嵌在 label 中。选中不改变尺寸或字重。纯对照用 L04，不强加选择。
- `number_strip`：可选 `title` 与 `items:[{num,title,body,highlight}]`，num 未填按顺序生成。适合少量简短要点，自适应实际数量和容器宽度。突出项必须有来源，不能自动把最后一项解释为最重要；编号不自动补出业务先后。
- `watermark`：`items:[{num,title,sub,rows:[{title,body}]}]`。主编号与装饰大编号并存，大编号从辅助阅读中隐藏；副标紧跟标题，键列允许换行。标题与值使用统一字号，水印不承载唯一信息，不用裁切遮住正文溢出。
- `decision`：可选 `title`、恰好两个 `branches`、可选最多两项 `conclusions:[{title,body}]`。分支含 `tag/title/desc`，以及 `steps:[文字]` 或 `cases:[{title,body}]` 二选一。分支是静态内容，不是可选卡；条件与结论必须来自原稿，不自动推断业务逻辑。
- `downloads`：`title`、`attachment_ids:[标识]`。标识取全局 attachments 的 `id`，旧记录没有 id 时可用 path；每个标识需唯一。例：全局 `{id:"checklist",name:"清单.docx",path:"附件/清单.docx",kind:"local"}`，块内只写 `{t:"downloads",attachment_ids:["checklist"]}`。local 下载，link 打开，netdisk 网盘，pending 显示待补且无下载链接。构建前检查实际本地文件存在；不复制一套附件路径。归属由原稿明确标记或用户指定，不把某项目的红字标记规则推广为所有资料的解析规则。
- `chapter_nav`：`title`、`desc`、`items:[{title,target}]`。target 必须是当前手册实际章节 ID；沿用 xref-chip 委托，同步目录与 B03 底栏。在章节扉页或明确目录页使用，不在每个普通内容页重复堆导航。

构建与内容检查均识别这些原生类型，检查断开的章节目标和附件引用；solution 内块继续接受原有检查与来源核对。直接复用这些类型，不把它们降回任意 HTML 注入。旧业务项目的 HTML 不会自动重写或迁移，需按本次实际授权另存转换。

## 与既有块对齐

- L22：可选 `title`，`items:[{title,body?,checked?,disabled?}]`。checked/disabled 为布尔值。默认未勾选；允许多项同时勾选和取消，整行可点，Tab/空格可操作。状态只属于当前页面，切换章节不会清空；刷新不承诺保留，不显示已提交或跨设备保存。
- L23 / L24：可选组名 `title`，`items:[{title,body?,blocks?,open?,icon?/num?}]`。body 与 blocks 至少有一项；blocks 可嵌原生内容块。默认收起，`open:true` 可明确设初始展开。各卡独立，不互斥；柔底、主题边框、左竖线表示展开，不表示被选中。L23 的 icon 支持 person/badge/pen/image/building/calendar/info；不接受未经审查的任意 SVG 或 HTML。L24 的 num 未填按顺序生成，不把编号推断为流程关系。两列布局在内容容器不足时转一列，不缩小字号。
- L03 的 `layout:"bar"` 为横向整栏标签，等宽分配，活动项白底与底部主题色线；容器不足时标签栏局部横滚。未指定 layout 时保留原 pills 外观。完整编号图文标签样例见 `assets/interaction-examples.json` 的 tabs；同一个 num 字段生成标签和面板编号，tab/title 不再手写编号。img/cap 用于完整图片和说明；支持键盘切换、图片放大，原图不裁切。
- L12 的完整分组折叠样例见同文件的 scriptlib，使用 `flat:false, show_count:true`。show_count 按每组实际 `type:"say"` 可复制段落统计，标题和说明段不计入；原有未设置 show_count 的手工 count 保持兼容。分组独立展开，逐条复制有成功/失败反馈。放在 tabs 内时仍推荐 flat:true，避免连续两次展开。

以上十个新增组件在样式库中均有原生字段样例；L03/L12 完整样例位于既有编号内，不另设重复编号。新卡片内的嵌套块继续接受内容、图片、跳转与来源检查；输入框、复选框和折叠区的按键不抢占成章节翻页。

- L17-B 的原生类型仍为 `imgs`，`layout:"filmstrip"`；保留图片说明与来源映射，不再增加一个“胶片”实现。
- 自动序号与标题各写一次：tabs 是 L03，不是 L02；tabs 的 num 放编号，tab/title 不重复前缀编号。L02 是单选卡。
- L11 阶段导航条的短编号与阶段名分开；title 为步骤名、sub 为时长或补充、body 为动作。不要把整段阶段名同时塞进 num 与 title。

颜色由现有令牌继承。正文与卡片仍为浅底，因此交接文档中“深色主题露白”的说法不能套用为改成整页深色的理由；修改硬编码是为了统一主题与后续维护。效果数字不用固定红色强调，避免无风险语义时滥用警示色。桌面、1024px 电脑窗口、两档字号和放大状态验证后再交付；手机和平板仍执行既定拦截。
