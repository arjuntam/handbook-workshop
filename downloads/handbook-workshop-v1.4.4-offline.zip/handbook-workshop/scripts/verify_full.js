// 增强验证：逐节翻页触发懒加载后检查全部图片、翻页、复制按钮、附件、JS 错误。
// 用法：node verify_full.js <index.html路径>
const path = require('path');
const fs = require('fs');
const PW = process.env.PW_MODULE || '/Users/apple/.workbuddy/binaries/node/workspace/node_modules/playwright-core';
const EDGE = process.env.EDGE || '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge';

(async () => {
  const site = process.argv[2];
  if (!site) { console.error('用法: node verify_full.js <index.html路径>'); process.exit(1); }
  let chromium;
  try { ({ chromium } = require(PW)); }
  catch (e) { console.error('缺少 playwright-core:', e.message); process.exit(2); }
  const launch = { headless: true };
  if (EDGE && fs.existsSync(EDGE)) launch.executablePath = EDGE;
  const browser = await chromium.launch(launch);
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  const errs = [];
  page.on('pageerror', e => errs.push(String(e)));
  await page.goto('file://' + path.resolve(site) + '?t=' + Date.now(), { waitUntil: 'load' });
  await page.waitForTimeout(300);
  const start = await page.$('#cover-start');
  if (start) { await start.click(); await page.waitForTimeout(200); }

  // 逐节翻页，强制每张图进入视口
  const total = await page.evaluate(() => document.querySelectorAll('.section[id]').length);
  for (let i = 0; i < total; i++) {
    await page.evaluate((idx) => {
      const secs = [...document.querySelectorAll('.section[id]')];
      if (window.__showSection) window.__showSection(idx);
      else secs[idx].scrollIntoView();
    }, i);
    await page.waitForTimeout(150);
    await page.evaluate(async () => {
      const imgs = [...document.querySelectorAll('.section.active img, .section img')];
      imgs.forEach(im => { im.loading = 'eager'; });
      await Promise.all(imgs.map(im => im.complete ? Promise.resolve() :
        new Promise(r => { im.onload = r; im.onerror = r; setTimeout(r, 3000); })));
    });
  }
  const imgs = await page.evaluate(() => {
    const a = [...document.querySelectorAll('.section img')];
    return { total: a.length, broken: a.filter(i => i.naturalWidth === 0).map(i => i.getAttribute('src')) };
  });
  const ui = await page.evaluate(() => ({
    sections: document.querySelectorAll('.section[id]').length,
    copyBtns: document.querySelectorAll('.copy-button').length,
    faqs: document.querySelectorAll('details.faq').length,
    metros: document.querySelectorAll('.metro').length,
    dock: !!document.getElementById('dl-dock'),
    attachments: document.querySelectorAll('.dl-row').length,
    homeBtn: !!document.querySelector('.topbar .home-btn'),
  }));
  // 翻页按钮测试
  await page.evaluate(() => { if(window.__showSection) window.__showSection(0); });
  await page.waitForTimeout(100);
  const next = await page.$('#pager-next');
  if (next) { await next.click(); await page.waitForTimeout(150); }
  const paged = await page.evaluate(() => document.querySelector('.section.active h2')?.textContent?.trim() || '');

  console.log('UI:', JSON.stringify(ui));
  console.log('图片:', JSON.stringify(imgs));
  console.log('翻页后标题:', paged);
  console.log('JS 错误:', errs.length, errs.slice(0, 3));
  const ok = imgs.broken.length === 0 && errs.length === 0 && ui.sections > 0 && ui.copyBtns > 0 && !!paged;
  console.log('结论:', ok ? '通过' : '未通过');
  await browser.close();
  process.exit(ok ? 0 : 1);
})().catch(e => { console.error('FATAL', e); process.exit(1); });
