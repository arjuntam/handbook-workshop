// Verify the design contract, not only whether HTML can open.
const fs=require('fs'),path=require('path'),os=require('os');
const {pathToFileURL}=require('url');
const {chromium}=require(process.env.PW_MODULE||path.join(os.homedir(),'.workbuddy/binaries/node/workspace/node_modules/playwright-core'));
(async()=>{
 const root=path.resolve(process.argv[2]);const output=path.resolve(process.argv[3]||path.join(root,'验证'));
 fs.mkdirSync(output,{recursive:true});const rows=[];
 function check(name,ok,detail=''){rows.push({name,ok,detail});console.log(ok?'OK':'FAIL',name);if(!ok)console.error(detail);}
 const browser=await chromium.launch({headless:true,executablePath:process.env.EDGE||'/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge'});
 try{
 const page=await browser.newPage({viewport:{width:1440,height:900},reducedMotion:'no-preference'});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 const gallery=fs.existsSync(path.join(root,'design-gallery/index.html'))?path.join(root,'design-gallery'):path.join(root,'网页手册样式库');
 const site=path.join(gallery,'index.html');await page.goto(pathToFileURL(site).href);
 check('固定原色封面 logo',(await page.locator('.cover-logo').getAttribute('src'))==='assets/logo.png');
 check('流体无图封面',await page.locator('.cover-fluid-mode').count()===1);
 const before=await page.locator('.flow-one').evaluate(x=>getComputedStyle(x).transform);
 await page.waitForTimeout(650);
 check('流体背景确实移动',before!==await page.locator('.flow-one').evaluate(x=>getComputedStyle(x).transform));
 await page.locator('.cover-motion-toggle').click();
 check('暂停动态',await page.locator('.flow-one').evaluate(x=>getComputedStyle(x).animationPlayState)==='paused');
 await page.locator('.cover-motion-toggle').click();
 check('恢复动态',await page.locator('.flow-one').evaluate(x=>getComputedStyle(x).animationPlayState)==='running');
 async function go(id){const a=page.locator('a[href="#'+id+'"]');await a.evaluate(x=>{const d=x.closest('details');if(d)d.open=true;});await a.click();}
 await page.locator('#cover-start').click();await go('palette');
 const paletteNames=await page.locator('[data-palette]').evaluateAll(xs=>xs.map(x=>x.dataset.palette));
 for(const name of paletteNames){
  await page.locator(`[data-palette=${name}]`).click();
  check('配色切换 '+name,await page.locator('[data-palette][aria-pressed=true]').count()===1);
  const rgb=await page.locator('.pick-card.on').first().evaluate(x=>({bg:getComputedStyle(x).backgroundColor,shadow:getComputedStyle(x).boxShadow}));
  check('选中态联动 '+name,!rgb.bg.includes('255, 255, 255')&&rgb.shadow!=='none',rgb);
 }
 await page.locator('[data-type=presentation]').first().click();
 check('演示字号',await page.locator('.section.active h2').evaluate(x=>getComputedStyle(x).fontSize)==='32px');
 await page.locator('[data-type=standard]').first().click();
 // Inspect generated export without navigating a file:// page to a blob URL.
 await page.evaluate(()=>{
  window.testOriginalURL=URL.createObjectURL;window.testOriginalClick=HTMLAnchorElement.prototype.click;
  URL.createObjectURL=blob=>{window.testExportBlob=blob;return 'blob:test-export'};
  HTMLAnchorElement.prototype.click=function(){if(!this.download)window.testOriginalClick.call(this)};
 });
 await page.locator('#download-design').click();
 const exported=await page.evaluate(async()=>{const s=await window.testExportBlob.text();URL.createObjectURL=window.testOriginalURL;HTMLAnchorElement.prototype.click=window.testOriginalClick;return s;});
 const cfg=JSON.parse(exported);fs.writeFileSync(path.join(output,'下载样式配置.json'),exported);
 check('导出配置内容',cfg.palette===paletteNames[paletteNames.length-1]&&cfg.type_scale==='standard');
 await go('states');
 const cards=page.locator('.section.active .pick-card');
 await cards.nth(0).click();check('点击单选高亮',await cards.nth(0).locator('input').isChecked());
 await cards.nth(0).locator('input').focus();await page.keyboard.press('ArrowRight');
 check('方向键切换',await cards.nth(1).locator('input').isChecked());
 await cards.nth(2).click({force:true});check('禁用卡不可选',!(await cards.nth(2).locator('input').isChecked()));
 check('同组单选',await page.locator('.section.active .pick-control:checked').count()===1);
 check('选中有形状提示',await cards.nth(1).evaluate(x=>getComputedStyle(x).boxShadow)!=='none');
 await page.locator('[data-palette=air-blue]').evaluate(x=>x.click());
 await page.waitForTimeout(500);await page.screenshot({path:path.join(output,'卡片交互预览.png'),fullPage:true});
 await go('brand');
 check('白色 logo 透明素材',(await page.locator('.dark-plate img').evaluate(x=>x.naturalWidth))===1238);
 await page.screenshot({path:path.join(output,'双色logo规范.png'),fullPage:true});
 check('JS 无错误',errors.length===0,errors);
 const reduced=await browser.newPage({viewport:{width:1440,height:900},reducedMotion:'reduce'});
 await reduced.goto(pathToFileURL(site).href);
 check('减少动态时静止',await reduced.locator('.flow-one').evaluate(x=>x.getAnimations().length)===0);
 check('减少动态时隐藏暂停按钮',!(await reduced.locator('.cover-motion-toggle').isVisible()));
 await reduced.close();await page.close();
 }finally{await browser.close();}
 fs.writeFileSync(path.join(output,'设计交互检查.json'),JSON.stringify({checks:rows.length,failures:rows.filter(x=>!x.ok).length,rows},null,2));
 console.log(JSON.stringify({checks:rows.length,failures:rows.filter(x=>!x.ok).length}));
 process.exitCode=rows.some(x=>!x.ok)?1:0;
})().catch(e=>{console.error(e);process.exitCode=1});
