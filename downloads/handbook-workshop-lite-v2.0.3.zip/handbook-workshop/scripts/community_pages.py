"""Public RSS subscriptions and user-confirmed contribution email."""
import json
import re
import zipfile
from datetime import datetime, timezone
from email.utils import format_datetime
from html import escape
from pathlib import Path
from urllib.parse import urlencode, urlsplit, quote
from xml.etree import ElementTree as ET

ROOT=Path(__file__).resolve().parent.parent

def config():
    c=json.loads((ROOT/'assets/community-config.json').read_text())
    if not re.fullmatch(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',c['email']):raise ValueError('投稿邮箱格式无效')
    u=urlsplit(c['public_base_url'])
    if u.scheme!='https' or not u.netloc or u.username or u.password or u.query or u.fragment:raise ValueError('公开入口应为无账号、查询或片段的HTTPS地址')
    if c.get('update_mode')!='rss-subscription':raise ValueError('更新模式应为 rss-subscription')
    return c

def update_prompts(c):
    base=c['public_base_url'].rstrip('/')+'/'
    original='https://arjuntam.github.io/handbook-workshop/'
    return {kind:(ROOT/'assets'/name).read_text().replace(original,base) for kind,name in (
        ('subscribe','agent-rss-subscribe-prompt.txt'),('once','agent-update-prompt.txt'),('watch','agent-update-watch-prompt.txt'))}

def mailto(email,subject,body):
    if any(x in email+subject for x in '\r\n'):raise ValueError('邮件头不接受换行')
    return 'mailto:'+email+'?'+urlencode(dict(subject=subject,body=body.replace('\r\n','\n').replace('\n','\r\n')),quote_via=quote)

def outputs(out,version,notes):
    c=config();base=c['public_base_url'].rstrip('/')+'/';prompt=(ROOT/'assets/style-contribution-prompt.txt').read_text()
    (out/'样式投稿-AI提示词.txt').write_text(prompt)
    prompts=update_prompts(c)
    (out/'AI配置RSS订阅提示词.txt').write_text(prompts['subscribe'])
    (out/'AI检查更新提示词.txt').write_text(prompts['once'])
    (out/'AI定期检查提示词.txt').write_text(prompts['watch'])
    manifest=dict(name='待填写',category='待维护人审核',purpose='这个结构帮助读者理解什么',existing_style_relation='与现有样式的差异或改进',author='',source='原创演示/素材来源',checked=[],pending=[])
    with zipfile.ZipFile(out/'样式投稿模板.zip','w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('样式投稿模板/给AI的提示词.txt',prompt)
        z.writestr('样式投稿模板/style.json',json.dumps(manifest,ensure_ascii=False,indent=2))
        z.writestr('样式投稿模板/从这里开始.txt','把“给AI的提示词.txt”和你的现有页面一起交给AI。让AI完成整理和打包，你核对后把投稿ZIP作为附件发到 '+c['email']+'。模板不是已完成稿件；无需GitHub账号。')
    ET.register_namespace('atom','http://www.w3.org/2005/Atom')
    feed=ET.Element('rss',version='2.0');channel=ET.SubElement(feed,'channel')
    ET.SubElement(channel,'{http://www.w3.org/2005/Atom}link',href=base+'updates.xml',rel='self',type='application/rss+xml')
    for k,v in dict(title='网页手册样式库 · 更新',link=base+'#updates',description='样式与功能的版本更新、适用范围和升级方式。',language='zh-CN',ttl='240').items():ET.SubElement(channel,k).text=v
    if notes and notes[0].get('date'):
        ET.SubElement(channel,'lastBuildDate').text=format_datetime(datetime.fromisoformat(notes[0]['date']).replace(tzinfo=timezone.utc),usegmt=True)
    for n in notes:
        item=ET.SubElement(channel,'item');ET.SubElement(item,'title').text='V'+n['version']+' · '+n['title'];ET.SubElement(item,'link').text=base+'#release-notes';ET.SubElement(item,'guid',isPermaLink='false').text='handbook-workshop-release-'+n['version']
        ET.SubElement(item,'description').text='\n'.join(n['changes'])+'\n升级：'+n['upgrade']
        if n.get('date'):
            ET.SubElement(item,'pubDate').text=format_datetime(datetime.fromisoformat(n['date']).replace(tzinfo=timezone.utc),usegmt=True)
    ET.ElementTree(feed).write(out/'updates.xml',encoding='utf-8',xml_declaration=True)
    opml=ET.Element('opml',version='2.0');head=ET.SubElement(opml,'head');ET.SubElement(head,'title').text='网页手册工坊更新订阅'
    body=ET.SubElement(opml,'body');folder=ET.SubElement(body,'outline',text='工具更新',title='工具更新')
    ET.SubElement(folder,'outline',text='网页手册样式库 · 更新',title='网页手册样式库 · 更新',type='rss',xmlUrl=base+'updates.xml',htmlUrl=base+'#updates')
    ET.ElementTree(opml).write(out/'updates.opml',encoding='utf-8',xml_declaration=True)
    (out/'updates.json').write_text(json.dumps(dict(schema_version=1,current_version=version,update_mode='rss-subscription',notification_mode='reader-managed',rss_url=base+'updates.xml',opml_url=base+'updates.opml',release_manifest_url=base+'release.json',prompts=dict(subscribe=base+'AI配置RSS订阅提示词.txt',once=base+'AI检查更新提示词.txt',watch=base+'AI定期检查提示词.txt'),items=notes),ensure_ascii=False,indent=2))
    return c,prompt

def sections(sec,c,prompt,version):
    e=lambda s:escape(str(s),quote=True);email=c['email'];base=c['public_base_url'].rstrip('/')+'/'
    submit=mailto(email,'[网页手册样式投稿] 样式名称','你好，我想贡献一个样式。\n\n样式名称：\n解决的信息表达问题：\n希望使用的署名（可选）：\n\nAI整理的投稿包已作为附件添加。\n已验证与待验证内容见包内“检查记录”。\n（发送前请手动添加ZIP附件，网页不会自动附加文件。）')
    prompts=update_prompts(c)
    update_html=f"""<div class="hw-community-intro"><p class="hw-community-version">推荐方式 · RSS 更新订阅</p><h3>配置一次，后续自动接收更新</h3><p>把提示词交给 AI，让它帮你添加更新源并配置通知。以后发布新版，订阅工具自动获取更新，你不用每次找 AI 检查，维护人也无需逐人发邮件。</p></div>
<ol class="hw-contribution-steps"><li><b>让 AI 帮你配置订阅</b><span>优先使用你已有的 RSS 阅读器；没有时，AI 帮你选定可用工具。</span></li><li><b>核对订阅与通知状态</b><span>确认能读取更新记录，再检查通知权限与后台条件。</span></li><li><b>有新版本时自动接收</b><span>由订阅工具持续获取；启用通知后按该工具的设置提醒。需要升级时再下载安装。</span></li></ol>
<div class="preview-toolbar"><button type="button" id="copy-subscribe-prompt" class="atlas-link hw-update-primary" data-community-copy="subscribe-prompt">复制：让AI配置更新订阅</button><a class="atlas-link" href="AI配置RSS订阅提示词.txt" download data-community-download="community-subscribe-prompt">下载订阅提示词</a></div>
<p class="hw-community-note">RSS 提供更新源，自动获取和通知由阅读器或订阅服务负责；提醒时间取决于刷新频率、通知权限和后台运行条件，不保证即时推送。</p>
<details class="hw-contribution-prompt"><summary>查看订阅配置的完整提示词</summary><pre id="community-subscribe-prompt" tabindex="0">{e(prompts['subscribe'])}</pre></details>
<details class="hw-contribution-prompt hw-update-sources"><summary>已有 RSS 阅读器？直接添加更新源</summary><p class="hw-community-address" id="community-feed-address">{e(base+'updates.xml')}</p><div class="preview-toolbar"><button type="button" class="atlas-link" data-community-copy="feed">复制RSS地址</button><a class="atlas-link" href="updates.opml" download>下载订阅配置 OPML</a><a class="atlas-link" href="updates.xml" target="_blank" rel="noopener">查看更新源 ↗</a></div><p class="hw-community-note">添加或导入后，请在阅读器中核对订阅并开启需要的通知。仅下载文件不会建立订阅。</p></details>
<details class="hw-contribution-prompt hw-update-install"><summary>收到更新后：让AI下载安装新版</summary><p>需要升级时再运行这一段：识别本地版本，校验下载包并保留旧版。已有业务手册不会自动改写。</p><div class="preview-toolbar"><button type="button" id="copy-update-prompt" class="atlas-link" data-community-copy="update-prompt">复制：让AI下载安装新版</button><a class="atlas-link" href="AI检查更新提示词.txt" download data-community-download="community-update-prompt">下载升级提示词</a></div><pre id="community-update-prompt" tabindex="0">{e(prompts['once'])}</pre></details>
<details class="hw-contribution-prompt hw-update-fallback"><summary>备选：无法使用 RSS 时的定期检查</summary><p>仅在你选择这个备选方案、且 AI 平台支持后台定时任务时启用。默认每周一上午9点检查；它不是 RSS 订阅，也不会实时推送。</p><div class="preview-toolbar"><button type="button" id="copy-watch-prompt" class="atlas-link" data-community-copy="watch-prompt">复制：让AI定期检查</button><a class="atlas-link" href="AI定期检查提示词.txt" download data-community-download="community-watch-prompt">下载备选提示词</a></div><pre id="community-watch-prompt" tabindex="0">{e(prompts['watch'])}</pre></details>
<p class="preview-toolbar"><a class="atlas-link" href="#release-notes">查看完整更新记录 →</a><a class="atlas-link" href="#runtime-updates">已有项目怎么更新 →</a></p><p class="hw-community-note">复制提示词后，需要把它交给 AI 执行。网页不会直接订阅、申请通知权限或安装软件。</p><p class="hw-community-feedback" role="status"></p>"""
    prompt_html='<div class="hw-community-intro"><h3>把现有页面交给AI，剩下让它整理</h3><p>你只需指出想贡献哪一块。AI负责提取、演示、截图、自检和打包；你检查后发送，不需要GitHub账号。</p></div><ol class="hw-contribution-steps"><li><b>把提示词和页面交给AI</b><span>可以是本地项目、现成HTML或可访问页面。</span></li><li><b>AI交付一个投稿ZIP</b><span>包含可打开的演示、使用说明、截图和检查记录。</span></li><li><b>核对后邮件发送</b><span>维护人审核，通过后统一编号，随下一版收录。</span></li></ol><div class="preview-toolbar"><button type="button" id="copy-contribution-prompt" class="atlas-link" data-community-copy="prompt">复制给AI的投稿提示词</button><a class="atlas-link" href="样式投稿-AI提示词.txt" download>下载提示词</a><a class="atlas-link" href="样式投稿模板.zip" download>下载空白投稿模板</a></div><details class="hw-contribution-prompt"><summary>查看完整提示词</summary><pre id="community-agent-prompt" tabindex="0">'+e(prompt)+'</pre></details><div class="hw-community-delivery"><h3>AI整理完成后，发到这里</h3><p class="hw-community-address" id="community-contact-email">'+e(email)+'</p><a class="atlas-link" id="community-submit" href="'+e(submit)+'">打开投稿邮件 ↗</a> <button type="button" class="atlas-link" data-community-copy="email">复制邮箱</button><p class="hw-community-note">请手动添加AI生成的ZIP附件。点按钮不会上传文件，也不会自动发送邮件。</p></div><p class="hw-community-note">值得贡献的是能帮助传达信息的结构或交互。已有样式的换色、圆角调整也可以提改进建议，审核后合并到原样式。</p><p class="hw-community-feedback" role="status"></p>'
    return [sec('updates','更新订阅','__bare__',[dict(t='html',v=update_html)]),sec('contribute','贡献新样式','__bare__',[dict(t='html',v=prompt_html)])]

CSS=r'''
.hw-community-intro{padding:1.25rem 0;margin:0 0 1rem;border-block-end:1px solid var(--border);font-size:var(--fs-lede);line-height:1.8;color:var(--text)}.hw-community-intro h3{margin-top:0}.hw-community-version{font-size:var(--fs-note);color:var(--muted)}
.hw-community-options{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:1.5rem;margin:1.5rem 0}.hw-community-options article{padding:1.25rem;border:1px solid var(--border);border-radius:var(--r-card);background:var(--surface)}.hw-community-options h3{margin-top:0}.hw-community-options p,.hw-community-delivery p{line-height:1.8}
.hw-community-note{font-size:var(--fs-note);line-height:1.8;color:var(--muted)}.hw-community-address{overflow-wrap:anywhere;color:var(--brand);font-size:var(--fs-text)}
.hw-contribution-steps{list-style:decimal;padding-inline-start:1.5rem;line-height:1.8}.hw-contribution-steps li{margin:1rem 0;padding-inline-start:.375rem}.hw-contribution-steps b,.hw-contribution-steps span{display:block}.hw-contribution-steps span{font-size:var(--fs-note);color:var(--muted)}
.hw-contribution-prompt{margin:1.5rem 0;border-block:1px solid var(--border);padding:1rem 0}.hw-contribution-prompt summary{cursor:pointer;color:var(--brand);font-weight:var(--weight-title,600)}.hw-contribution-prompt pre{white-space:pre-wrap;overflow-wrap:anywhere;max-block-size:28rem;overflow:auto;background:var(--bg);color:var(--text);font:inherit;font-size:var(--fs-note);line-height:1.9;padding:1rem;border:1px solid var(--border);border-radius:.5rem}
.hw-community-delivery{margin-top:2rem;padding-top:1rem;border-block-start:1px solid var(--border)}.hw-community-feedback{font-size:var(--fs-note);line-height:1.6;color:var(--brand);min-block-size:1.6em}.hw-community-options a,.hw-community-delivery a{display:inline-flex;min-block-size:2.75rem;align-items:center}
#updates .hw-update-primary{background:var(--accent);border-color:var(--accent);color:#fff;font-weight:var(--weight-medium,550)}
@container(max-width:48rem){.hw-community-options{grid-template-columns:1fr}}
'''

def js(c,version):
    data=json.dumps(dict(version=version),ensure_ascii=False).replace('<','\\u003c')
    return r"""(()=>{
const cfg=__DATA__,command='--community-copy';
const targets={'subscribe-prompt':'community-subscribe-prompt',prompt:'community-agent-prompt','update-prompt':'community-update-prompt','watch-prompt':'community-watch-prompt',feed:'community-feed-address',email:'community-contact-email'};
document.querySelectorAll('[data-community-download]').forEach(a=>a.addEventListener('click',e=>{if(location.protocol!=='file:')return;const source=document.getElementById(a.dataset.communityDownload);if(!source)return;e.preventDefault();const url=URL.createObjectURL(new Blob([source.textContent],{type:'text/plain;charset=utf-8'})),link=document.createElement('a');link.href=url;link.download=a.getAttribute('href').split('/').at(-1);document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}));
const feedbackTimers=new WeakMap();let lastMessage='';
function report(button,ok){
 const section=button.closest('.section'),feedback=section?.querySelector('.hw-community-feedback');
 if(!feedback)return;clearTimeout(feedbackTimers.get(feedback));section.querySelectorAll('[data-community-copy][data-state]').forEach(x=>delete x.dataset.state);button.dataset.state=ok?'success':'error';
 let message=ok?(button.dataset.communityCopy==='subscribe-prompt'?'已复制。交给AI配置订阅，并核对通知是否启用。':button.dataset.communityCopy==='prompt'?'已复制。把提示词和你的项目一起交给AI。':button.dataset.communityCopy==='update-prompt'?'已复制。把提示词交给你的AI执行检查。':button.dataset.communityCopy==='watch-prompt'?'已复制。请让AI确认平台是否支持，并实际建立定时任务。':'已复制。'):'复制未成功，请展开内容手动选择，或下载提示词文件。';
 if(message===lastMessage)message+='\u00a0';lastMessage=message;feedback.textContent='';requestAnimationFrame(()=>feedback.textContent=message);
 feedbackTimers.set(feedback,setTimeout(()=>{delete button.dataset.state;feedback.textContent='';},3500));
}
function legacyCopy(text){const focused=document.activeElement,field=document.createElement('textarea');field.value=text;field.readOnly=true;field.style.cssText='position:fixed;inset-block-start:0;opacity:0';document.body.append(field);field.select();try{return document.execCommand('copy');}finally{field.remove();focused?.focus({preventScroll:true});}}
async function copy(button,target){if(!button||!target){if(button)report(button,false);return;}const text=target.matches('input,textarea')?target.value:target.textContent;if(!text){report(button,false);return;}try{if(navigator.clipboard?.writeText)await navigator.clipboard.writeText(text);else if(!legacyCopy(text))throw Error('copy unavailable');report(button,true);}catch(e){report(button,false);}}
document.querySelectorAll('[data-community-copy]').forEach(button=>{button.setAttribute('command',command);button.setAttribute('commandfor',targets[button.dataset.communityCopy]||'');});
if('CommandEvent' in window)document.addEventListener('command',e=>{if(e.command===command)copy(e.source,e.target);},true);
else document.addEventListener('click',e=>{if(e.defaultPrevented)return;const button=e.target.closest('[data-community-copy]');if(button)copy(button,document.getElementById(button.getAttribute('commandfor')));});
try{const key='handbook-library-last-visited-version',previous=localStorage.getItem(key);if(previous&&previous!==cfg.version){const a=document.querySelector('.hw-directory-items a[href="#updates"]');if(a){const tag=document.createElement('span');tag.className='hw-nav-count';tag.textContent='更新';a.append(tag);}}localStorage.setItem(key,cfg.version);}catch(e){}
})();""".replace('__DATA__',data)
