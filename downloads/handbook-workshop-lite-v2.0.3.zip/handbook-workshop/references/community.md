# RSS 更新订阅与样式投稿

这两个栏目只用于样式库，普通业务成品不注入它们。

## 主推：AI配置一次RSS订阅

页面主入口“更新订阅”保持原有 #updates 地址。使用者复制“让AI配置更新订阅”提示词，Agent复用现有阅读器或在必要选择后配置合适工具，添加正式更新源并核对通知。维护人发布新版时，构建同步更新RSS；不维护收件名单、不逐人发信。

- 订阅提示词：`assets/agent-rss-subscribe-prompt.txt`，生成站点下载 `AI配置RSS订阅提示词.txt`。
- 正式RSS：`updates.xml`，稳定guid按发布版本标识；有新版本时新增条目，旧版本guid保持不变。
- OPML：`updates.opml`，可导入“工具更新”分组；下载文件不等于已经订阅。
- 自动发现：HTML head 中提供 application/rss+xml alternate 链接。
- `assets/community-config.json` 更新模式为 `rss-subscription`；`updates.json` 提供 rss_url、opml_url、notification_mode=reader-managed 及提示词地址。

RSS是数据源，后台刷新与消息通知由阅读器或订阅服务负责，当前站点没有WebSub/rssCloud推送服务。不能承诺即时推送、所有阅读器免费通知或电脑关机后本地阅读器仍可运行。订阅成功与通知启用分别核验；不能测试未来新条目时明确待实测。不默认安装软件、注册账号、付费、建立AI定时任务或开启全局通知。

## 收到通知后的升级与备选

一次升级提示词 `assets/agent-update-prompt.txt` 和旧公开文件名 `AI检查更新提示词.txt` 保留，收进“收到更新后：让AI下载安装新版”。仍要求识别版本、检查SHA-256、另存与验证、不降级、不自动改写业务页。

仅在无法使用RSS且使用者选择备选时，使用 `assets/agent-update-watch-prompt.txt` 建立AI定期检查。平台必须实际返回创建成功才算生效，不把临时等待当作后台任务。网页本身不会替使用者配置阅读器、申请通知权限或安装软件。

## AI 投稿

投稿人复制“贡献新样式”的提示词，将现有页面/项目交给AI，指出哪一块值得复用。AI负责识别价值、比较已有样式、整理最小演示、替换公开演示内容、截图、检验和打包。本人核对后，把ZIP附在邮件里发送到 `tan.yujun@daikin-gz.com`。无需GitHub账号或内网。

提示词源文件：`assets/style-contribution-prompt.txt`。站点另提供“样式投稿-AI提示词.txt”和空白“样式投稿模板.zip”。模板不是已完成稿件。无法验证时必须列出未验证内容，不捏造截图或通过记录。

维护人审核后决定合并到原样式还是新增编号；未审核稿件不会自动进入样式库。本版不自动上传投稿附件或发送邮件。

## 目录参数

公共实现：`scripts/sidebar_navigation.py`。颜色沿用项目 `--nav-*` 令牌；`--hw-sidebar-expanded`、`--hw-sidebar-rail`、`--hw-sidebar-icon` 和 `--hw-sidebar-duration` 分别控制宽度、图标与箭头反馈时长。

宽屏开关位于目录标题右侧，侧栏不显示总节数或分组数量；窄窗口的目录入口位于顶栏右侧工具区，logo保持最左。
