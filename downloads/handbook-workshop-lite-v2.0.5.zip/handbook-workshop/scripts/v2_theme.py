"""Project-owned colors and expression; no reader theme switcher."""
import re

EXPRESSIONS = {'professional': '清爽专业', 'warm': '温暖叙事', 'showcase': '重点展示'}
COLOR_KEYS = {'accent', 'title', 'text', 'muted', 'bg', 'surface', 'secondary'}


def mix(a, b, f):
    return '#' + ''.join(f'{int(int(a[i:i+2],16)*(1-f)+int(b[i:i+2],16)*f+.5):02x}' for i in (1,3,5))


def luminance(c):
    vals = [int(c[i:i+2],16)/255 for i in (1,3,5)]
    vals = [v/12.92 if v <= .04045 else ((v+.055)/1.055)**2.4 for v in vals]
    return sum(a*b for a,b in zip(vals, (.2126,.7152,.0722)))


def contrast(a, b):
    x,y=sorted((luminance(a),luminance(b)))
    return (y+.05)/(x+.05)


def readable(c, bg, ratio=4.5):
    if contrast(c,bg)>=ratio:return c
    end='#000000' if contrast('#000000',bg)>=contrast('#ffffff',bg) else '#ffffff'
    for i in range(1,101):
        out=mix(c,end,i/100)
        if contrast(out,bg)>=ratio:return out
    return end


def validate(cfg):
    if cfg.get('expression','professional') not in EXPRESSIONS:raise ValueError('expression 无效')
    colors=cfg.get('custom_colors',{})
    if not isinstance(colors,dict) or any(k not in COLOR_KEYS or not isinstance(v,str) or not re.fullmatch('#[0-9a-fA-F]{6}',v) for k,v in colors.items()):raise ValueError('custom_colors 只接受已定义角色的六位十六进制颜色')
    if not isinstance(cfg.get('custom_name',''),str) or len(cfg.get('custom_name',''))>40:raise ValueError('自定义方案名最长40字')


def tokens(cfg, base):
    validate(cfg)
    c=cfg.get('custom_colors',{})
    expression=cfg.get('expression','professional')
    bg=c.get('bg', '#faf7f2' if expression=='warm' else base['--bg'])
    surface=c.get('surface',base['--surface'])
    accent=readable(c.get('accent',base['--accent']),surface)
    # Buttons carry white text throughout the established component contract.
    accent=readable(accent,'#ffffff')
    title=c.get('title',readable(base['--brand'],surface))
    text=c.get('text',readable(base['--text'],surface))
    muted=c.get('muted',readable(base['--muted'],surface))
    soft=mix(surface,accent,.08)
    ink=readable(accent,soft)
    secondary=readable(c.get('secondary','#a45226'),surface,3)
    nav=mix(accent,'#000000',.6) if cfg.get('shell_mode')=='dark' else bg
    dark=cfg.get('shell_mode')=='dark'
    t={'--brand':title,'--brand2':ink,'--accent':accent,'--accent-soft':soft,'--bg':bg,'--surface':surface,'--text':text,'--muted':muted,'--border':mix(surface,text,.16),
       '--selected-bg':soft,'--selected-border':accent,'--selected-text':title,'--selected-shadow':'0 0 0 2px '+accent,'--focus':ink,'--table-head-bg':soft,'--table-head-text':title,
       '--nav-bg':nav,'--nav-bg2':nav,'--nav-text':'#f5f7fa' if dark else title,'--nav-muted':mix(nav,'#ffffff',.8) if dark else muted,'--nav-active-bg':mix(nav,'#ffffff',.14) if dark else soft,'--nav-active-text':'#ffffff' if dark else ink,'--nav-line':mix(nav,'#ffffff',.35) if dark else mix(bg,title,.25),
       '--feature-bg':mix(surface,secondary,.08) if expression=='warm' else soft,'--feature-accent':secondary if expression=='warm' else ink,
       '--map-covered-fill':mix(surface,accent,.4),'--map-covered-stroke':accent,'--map-dot':accent,'--map-land-fill':mix(surface,text,.14),'--compare-after-label':ink,
       '--feature-size':'2.4rem' if expression=='showcase' else '2.05rem','--feature-radius':'1rem',
       '--chart-1':readable(accent,surface,3),'--chart-2':secondary,'--chart-3':readable('#28715a',surface,3),'--chart-4':readable('#70518c',surface,3),'--chart-5':readable('#76621e',surface,3),'--chart-6':readable('#4c6584',surface,3)}
    for key in ('--brand','--text','--muted'):
        if min(contrast(t[key],surface),contrast(t[key],bg))<4.5:raise ValueError('自定义'+key+'与背景对比不足，请使用推荐修正')
    for i,amount in enumerate((.24,.14,.09,.025),1):t['--flow-'+('one','two','three','paper')[i-1]]=mix(surface,accent,amount)
    return t


JS = r'''
window.HWTheme=(()=>{
 const mix=(a,b,f)=>'#'+[1,3,5].map(i=>Math.round(parseInt(a.slice(i,i+2),16)*(1-f)+parseInt(b.slice(i,i+2),16)*f).toString(16).padStart(2,'0')).join('');
 const lum=c=>[1,3,5].map(i=>parseInt(c.slice(i,i+2),16)/255).map(v=>v<=.04045?v/12.92:((v+.055)/1.055)**2.4).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);
 const contrast=(a,b)=>(Math.max(lum(a),lum(b))+.05)/(Math.min(lum(a),lum(b))+.05);
 function readable(c,bg,r=4.5){if(contrast(c,bg)>=r)return c;const end=contrast('#000000',bg)>=contrast('#ffffff',bg)?'#000000':'#ffffff';for(let i=1;i<=100;i++){const out=mix(c,end,i/100);if(contrast(out,bg)>=r)return out;}return end;}
 function tokens(cfg,base){
  const c=cfg.custom_colors||{},exp=cfg.expression||'professional',bg=c.bg||(exp==='warm'?'#faf7f2':base['--bg']),surface=c.surface||base['--surface'];
  const accent=readable(readable(c.accent||base['--accent'],surface),'#ffffff'),title=c.title||readable(base['--brand'],surface),text=c.text||readable(base['--text'],surface),muted=c.muted||readable(base['--muted'],surface),soft=mix(surface,accent,.08),secondary=readable(c.secondary||'#a45226',surface,3),dark=cfg.shell_mode==='dark',nav=dark?mix(accent,'#000000',.6):bg;
  const ink=readable(accent,soft);
  const t={'--brand':title,'--brand2':ink,'--accent':accent,'--accent-soft':soft,'--bg':bg,'--surface':surface,'--text':text,'--muted':muted,'--border':mix(surface,text,.16),'--selected-bg':soft,'--selected-border':accent,'--selected-text':title,'--selected-shadow':'0 0 0 2px '+accent,'--focus':ink,'--table-head-bg':soft,'--table-head-text':title,'--nav-bg':nav,'--nav-bg2':nav,'--nav-text':dark?'#f5f7fa':title,'--nav-muted':dark?mix(nav,'#ffffff',.8):muted,'--nav-active-bg':dark?mix(nav,'#ffffff',.14):soft,'--nav-active-text':dark?'#ffffff':ink,'--nav-line':dark?mix(nav,'#ffffff',.35):mix(bg,title,.25),'--feature-bg':exp==='warm'?mix(surface,secondary,.08):soft,'--feature-accent':exp==='warm'?secondary:ink,'--feature-size':exp==='showcase'?'2.4rem':'2.05rem','--feature-radius':'1rem','--map-covered-fill':mix(surface,accent,.4),'--map-covered-stroke':accent,'--map-dot':accent,'--map-land-fill':mix(surface,text,.14),'--compare-after-label':ink,'--chart-1':readable(accent,surface,3),'--chart-2':secondary,'--chart-3':readable('#28715a',surface,3),'--chart-4':readable('#70518c',surface,3),'--chart-5':readable('#76621e',surface,3),'--chart-6':readable('#4c6584',surface,3)};
  ['one','two','three','paper'].forEach((k,i)=>t['--flow-'+k]=mix(surface,accent,[.24,.14,.09,.025][i]));return t;
 }
 return {mix,contrast,readable,tokens};
})();
'''
