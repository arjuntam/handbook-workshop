"""Responsive shell and a single compact contextual navigation surface."""
CSS=r'''
html{scroll-padding-block-start:calc(var(--header-height,3.75rem) + 5rem);scrollbar-color:var(--muted) var(--bg);scrollbar-width:auto}
body{accent-color:var(--accent)}body>.topbar{min-inline-size:0}.topbar .search-box{min-inline-size:0}.section{container-type:inline-size}.section,.tab-panel,.metro-panel{overflow-wrap:anywhere}
.layout>main{padding:1.5rem clamp(1rem,2.2vw,2.5rem) 2rem}.section{padding:clamp(1.25rem,3.5cqi,2.5rem)}.layout{padding-bottom:6rem}
.data-table-scroll{scrollbar-width:auto}.hw-summary-table thead th,.hw-matrix thead th{text-align:center}.hw-summary-table thead th:first-child,.hw-matrix thead th:first-child{text-align:start}
.hw-local-bar{position:fixed;top:var(--header-height,3.75rem);z-index:35;display:flex;align-items:center;gap:.5rem;padding:.4rem .75rem;background:var(--surface);border:1px solid var(--border);border-radius:0 0 .75rem .75rem;box-shadow:0 5px 18px #00000012;max-block-size:5rem;min-inline-size:0}
.hw-local-bar[hidden]{display:none}.hw-local-bar>strong{flex:none;font-size:var(--fs-note);max-inline-size:10rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.hw-local-items{display:flex;gap:.375rem;overflow:auto;align-items:center;min-inline-size:0;padding:3px}.hw-local-bar button,.hw-local-bar select{font:inherit;font-size:var(--fs-note);color:var(--brand);background:var(--surface);border:1px solid var(--border);border-radius:.5rem;padding:.45rem .65rem;min-block-size:2.75rem;flex:none;white-space:nowrap}.hw-local-bar button[aria-pressed=true]{background:var(--accent-soft);border-color:var(--accent);font-weight:var(--weight-title,600)}.hw-local-bar select{min-inline-size:0;max-inline-size:100%}.hw-local-bar button:focus-visible,.hw-local-bar select:focus-visible{outline:3px solid var(--focus);outline-offset:2px}.hw-section-jump.hw-local-suppressed.is-primary{position:static;box-shadow:none}
.hw-drawer-backdrop{position:fixed;inset:0;background:#0b1b2b70;z-index:59;border:0}.hw-drawer-close{font:inherit;display:none;min-block-size:2.75rem;padding:.5rem .75rem;margin-bottom:.75rem;background:var(--nav-bg);color:var(--nav-text);border:1px solid var(--nav-line);border-radius:.5rem}.hw-drawer-backdrop[hidden]{display:none}
.metro-label b{white-space:normal}.metro-track{gap:.5rem}.metro-label small{overflow-wrap:anywhere}.metro-stop{min-inline-size:0}.hw-fold-grid{align-items:stretch}
@media(max-width:1439px){:root{--sidebar-width:13.25rem}.layout>.sidebar{padding:1rem .75rem}.layout>main{padding:1.25rem}.section{padding:1.5rem}.brand-text{max-inline-size:10rem}.topbar-title{max-inline-size:13rem}.topbar{gap:.75rem;padding-inline:1rem}}
@media(max-width:1099px){:root{--sidebar-width:0rem}.layout{display:block}.layout>main{inline-size:100%;padding:1rem}.topbar .menu-btn{display:grid;place-items:center;flex:none}.layout>.sidebar{display:none;inline-size:min(22rem,86dvw);z-index:60;top:0;block-size:100dvh;bottom:0;padding:1rem;overflow:auto}.layout>.sidebar.open{display:block;transform:none}.hw-drawer-close{display:block}.pagerbar{inset-inline-start:0}.topbar-title{display:none}.brand-text{display:none}.search-box input{inline-size:clamp(9rem,25vw,15rem)}.section{padding:1.25rem}.topbar{gap:.5rem}.hw-local-bar>strong{display:none}}
@media(max-width:680px){.topbar .brand-logo{max-inline-size:5.5rem}.search-box input{inline-size:9rem}.topbar .skill-download-header{display:none}.topbar{padding-inline:.5rem}.layout>main{padding:.625rem}.section{padding:1rem}.pager-label{display:none}.metro-track{display:flex;overflow:auto;scrollbar-width:auto}.metro-stop{flex:0 0 6rem}.metro-track::before,.metro-fill,.metro-train{display:none}}
@container(max-width:50rem){.grid-4,.grid-3,.grid-5,.grid-6{grid-template-columns:repeat(2,minmax(0,1fr))}.hw-stages-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@container(max-width:32rem){.grid-2,.grid-3,.grid-4,.grid-5,.grid-6,.hw-fold-grid,.cmp-body{grid-template-columns:minmax(0,1fr)}.cmp-arrow{transform:rotate(90deg)}}
@media(max-height:720px){:root{--header-height:3.25rem}body>.topbar{height:3.25rem;block-size:3.25rem}.section-head{margin-bottom:1.25rem;padding-bottom:.875rem}.pager{padding-block:.5rem}.pagerbar{min-block-size:0}.hw-local-bar{max-block-size:4rem}.metro-board{margin-bottom:1rem}}
@media(max-height:480px){.hw-local-bar{display:none!important}.hw-section-jump.is-primary{position:static}}
@media(forced-colors:active){.hw-local-bar{border:1px solid CanvasText}.hw-local-bar button[aria-pressed=true]{outline:2px solid Highlight}.hw-feature{border:1px solid CanvasText}}
@supports not (scrollbar-color:auto){html::-webkit-scrollbar{width:12px;height:12px}html::-webkit-scrollbar-thumb{background:var(--muted);border:3px solid var(--bg);border-radius:8px}html::-webkit-scrollbar-track{background:var(--bg)}}
/* Theme-neutral components inherit the author's actual surface and text. */
body .step,body .g-code,body .quote-reveal,body .xref-chip,body .card,body .pick-card,body .faq,body .sl-group,body .cmp-card,body .qr,body .quote,body .resource-card,body .gallery-item,body .cm-hint,body .preview-toolbar button,body .atlas-link{background:var(--surface);color:var(--text)}
body .step-body,body .lede,body .card-body,body .cmp-side p,body .stat-label,body .rt td{color:var(--text)}
body .faq-answer,body .faq-principle,body .cmp-side,body .cmp-now,body .cmp-need,body .gallery-item figcaption,body .chat-cap{background:var(--bg);color:var(--text)}
.section .cmp-card .cmp-side{background:var(--bg)}
body .quote,body .qr-title,body .sl-h,body .cmp-head h4{color:var(--brand)}
body .sec-kicker,body .step-n,body .cmp-num,body .hw-cover-num,body .resource-tag,body .metro-now,body .hw-feature-kicker,body .hw-fold-open,body .hw-data-name,body .hw-choice-on,body .hw-section-jump button{color:var(--brand2)}
body .metro-num{background:var(--surface);color:var(--muted)}body .metro-stop[aria-pressed=true] .metro-num{background:var(--accent);color:#fff}body .metro-label b{color:var(--text)}
body .cmp-tag,body .cmp-arrow,body .rt-time,body .rt-n,body .rt-note,body .rt-row.hi td{color:var(--muted)}body .cmp-tag{background:var(--bg)}body .rt-row.hi td{background:var(--accent-soft)}body .rt-row.hi .rt-name{color:var(--brand)}
body .card-num{background:var(--accent-soft);color:var(--brand2)}
body .preview-toolbar button[aria-pressed=true]{background:var(--accent-soft)}
.section .hw-data-choice[aria-pressed=true] .hw-choice-on,.section .hw-section-jump button.is-active,.section .hw-section-jump button[aria-current=location],.section .xref-chip,.section .xref-chip .xc-arrow{color:var(--brand2)}
.section .cmp-now .cmp-tag,.section .cmp-need .cmp-tag{color:var(--muted);background:var(--bg)}
/* Mimicked messaging UI has its own reading surface; images are untouched. */
.chat,.moments{--text:#263445;--muted:#52657a;--brand:#18354e;--brand2:#17588b}.chat .copy-text{color:#263445}body .chat .chat-cap{color:#52657a;background:#f7f9fc}.mm-time{color:#53657a}
body .logo-plates figure figcaption{color:#263445}body .logo-plates figure.dark-plate figcaption{color:#fff}
[data-expression=professional] .hw-feature.has-visual{grid-template-columns:1.25fr .75fr;gap:1.5rem}[data-expression=professional] .hw-feature{padding:1.5rem}[data-expression=professional] .hw-feature-body{font-size:var(--fs-text)}
[data-expression=warm] .hw-feature.has-visual{grid-template-columns:1fr 1.15fr;gap:2rem}[data-expression=warm] .hw-feature-copy{max-inline-size:42ch}[data-expression=warm] .hw-feature-body{line-height:1.9}[data-expression=warm] .hw-feature img{border-radius:1.5rem}
[data-expression=showcase] .hw-feature-metric strong{font-size:clamp(3rem,8cqi,5rem)}[data-expression=showcase] .hw-feature{border-block-start:4px solid var(--accent)}[data-expression=showcase] .hw-feature-kicker{font-weight:var(--weight-title,650)}
@container(max-width:42rem){[data-expression] .hw-feature.has-visual{grid-template-columns:1fr;gap:1.25rem}}
@media print{.hw-local-bar,.hw-drawer-backdrop,.hw-drawer-close{display:none!important}.layout>main{padding:0}.layout>.sidebar{display:none}}
'''

JS=r'''
(()=>{
 const header=document.querySelector('body > .topbar'),sidebar=document.querySelector('.layout > .sidebar'),main=document.querySelector('.layout > main'),menu=document.querySelector('.topbar .menu-btn');
 const small=matchMedia('(max-width:1099px)');let opener;
 const bar=document.createElement('nav');bar.className='hw-local-bar';bar.hidden=true;bar.setAttribute('aria-label','当前板块精简导航');const label=document.createElement('strong'),items=document.createElement('div');items.className='hw-local-items';bar.append(label,items);document.body.append(bar);
 const candidates=[];
 document.querySelectorAll('.metro').forEach(root=>candidates.push({root,head:root.querySelector('.metro-track'),type:'metro',name:'当前阶段',buttons:()=>[...root.querySelectorAll(':scope > .metro-track > .metro-stop')],title:b=>b.querySelector('.metro-label b')?.textContent||b.textContent,selected:b=>b.getAttribute('aria-pressed')==='true'}));
 document.querySelectorAll('.tabset').forEach(root=>{if(root.parentElement.closest('.tabset,.metro,.hw-detail-table'))return;candidates.push({root,head:root.querySelector('.tab-heads'),type:'tabs',name:'当前场景',buttons:()=>[...root.querySelectorAll(':scope > .tab-heads > .tab-head')],title:b=>b.textContent,selected:b=>b.getAttribute('aria-selected')==='true'||b.classList.contains('on')});});
 document.querySelectorAll('.hw-detail-table').forEach(root=>candidates.push({root,head:root.querySelector('.data-table-scroll'),type:'details',name:'当前对象',buttons:()=>[...root.querySelectorAll('.hw-data-choice')].filter(x=>x.closest('.hw-detail-table')===root),title:b=>b.querySelector('.hw-data-name').textContent,selected:b=>b.getAttribute('aria-pressed')==='true'}));
 document.querySelectorAll('.scriptlib').forEach(root=>{const groups=[...root.querySelectorAll('.sl-group')];if(groups.length>1)candidates.push({root,head:groups[0].querySelector('summary'),type:'groups',name:'话术分组',buttons:()=>groups.map(x=>x.querySelector('summary')),title:b=>b.textContent,selected:b=>{const edge=(header?.getBoundingClientRect().height||0)+bar.offsetHeight+24;const current=groups.filter(x=>x.getBoundingClientRect().top<=edge).at(-1)||groups[0];return b.parentElement===current;}});});
 document.querySelectorAll('.faq-list').forEach(root=>{const headings=[...root.querySelectorAll(':scope > .hw-faq-heading')];if(headings.length>1)candidates.push({root,head:headings[0],type:'groups',name:'问答分组',buttons:()=>headings,title:b=>b.textContent,selected:b=>{const edge=(header?.getBoundingClientRect().height||0)+bar.offsetHeight+24;return b===(headings.filter(x=>x.getBoundingClientRect().top<=edge).at(-1)||headings[0]);}});});
 let active=null,signature='',pending=false;
 function update(){
  pending=false;const previousHeight=bar.offsetHeight;const h=header?.getBoundingClientRect().height||0;if(h)document.documentElement.style.setProperty('--header-height',h+'px');
  const choices=candidates.filter(c=>{if(!c.head||!c.root.getClientRects().length)return false;const r=c.root.getBoundingClientRect(),n=c.head.getBoundingClientRect();return innerHeight>480&&n.bottom<h+8&&r.bottom>h+140&&r.height>innerHeight*.65;});
  choices.sort((a,b)=>b.root.getBoundingClientRect().top-a.root.getBoundingClientRect().top);const next=choices[0]||null;
  document.querySelectorAll('.hw-section-jump').forEach(n=>n.classList.toggle('hw-local-suppressed',!!next&&n.closest('.section')===next.root.closest('.section')));
  if(!next){bar.hidden=true;active=null;signature='';return;}
  const buttons=next.buttons(),sig=buttons.map(b=>next.title(b)+'|'+next.selected(b)).join('~');
  if(active!==next||signature!==sig){const focused=bar.contains(document.activeElement)?(document.activeElement.tagName==='SELECT'?'select':document.activeElement?.dataset?.localIndex):undefined;items.replaceChildren();label.textContent=next.name;
   if(next.type==='details'||next.type==='groups'){
    const select=document.createElement('select');select.setAttribute('aria-label',next.name);buttons.forEach((b,i)=>select.add(new Option(next.title(b),String(i),false,next.selected(b))));select.addEventListener('change',()=>{const b=buttons[Number(select.value)];if(next.type==='groups'){if(b.parentElement.tagName==='DETAILS')b.parentElement.open=true;const y=b.getBoundingClientRect().top+scrollY-h-bar.offsetHeight-20;window.scrollTo({top:y,behavior:'instant'});}else b.click();schedule();});items.append(select);
    if(next.type==='details'){const back=document.createElement('button');back.type='button';back.textContent='返回汇总 ↑';back.addEventListener('click',()=>{next.head.focus({preventScroll:true});window.scrollTo({top:scrollY+next.head.getBoundingClientRect().top-h-16,behavior:'instant'});});items.append(back);}
   }else buttons.forEach((b,i)=>{const proxy=document.createElement('button');proxy.type='button';proxy.dataset.localIndex=String(i);proxy.textContent=(next.type==='metro'?(i+1)+' · ':'')+next.title(b);proxy.setAttribute('aria-pressed',String(next.selected(b)));proxy.addEventListener('click',()=>{b.click();schedule();});items.append(proxy);});
   active=next;signature=sig;if(focused!==undefined)(focused==='select'?items.querySelector('select'):items.querySelector('[data-local-index="'+focused+'"]'))?.focus({preventScroll:true});
  }
  const r=main.getBoundingClientRect();bar.style.left=Math.max(8,r.left+16)+'px';bar.style.width=Math.max(160,Math.min(innerWidth-32,r.width-32))+'px';bar.hidden=false;if(Math.abs(previousHeight-bar.offsetHeight)>.5)schedule();
  next.root.closest('.section')?.style.setProperty('--hw-anchor-offset',(h+bar.offsetHeight+24)+'px');
 }
 function schedule(){if(!pending){pending=true;requestAnimationFrame(update);}}
 addEventListener('scroll',schedule,{passive:true});addEventListener('resize',schedule);addEventListener('hb:sectionchange',schedule);document.addEventListener('click',()=>queueMicrotask(schedule));document.addEventListener('toggle',schedule,true);
 if(header)new ResizeObserver(schedule).observe(header);document.fonts?.ready.then(schedule);schedule();
})();
'''
