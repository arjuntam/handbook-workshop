"""L28: deterministic, offline SVG charts with signed values and searchable tables."""
from html import escape
from itertools import count
import math
from datetime import date

_ids = count(1)
KINDS = {'column', 'bar', 'line', 'stacked', 'donut', 'pie'}


def number(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def fmt(v):
    if v is None:
        return '未提供'
    return format(v, ',.6g').replace('-', '−')


def validate(b):
    if b.get('kind', 'column') not in KINDS:
        raise ValueError('chart.kind 只接受 column/bar/line/stacked/donut/pie')
    if not b.get('title') or not b.get('unit') or not b.get('source'):
        raise ValueError('图表需要 title、unit 和 source；模拟数据须明确来源')
    cats, series = b.get('categories', []), b.get('series', [])
    if not isinstance(cats, list) or not isinstance(series, list) or len(cats) > 60 or len(series) > 6:
        raise ValueError('图表 categories/series 必须为列表，最多60类、6系列')
    if any(not isinstance(c, str) or not c for c in cats) or len(set(cats)) != len(cats):
        raise ValueError('图表类别名称不能为空或重复')
    names = []
    for s in series:
        if not isinstance(s, dict) or not s.get('name') or not isinstance(s.get('values'), list) or len(s['values']) != len(cats):
            raise ValueError('图表系列需要 name 与逐类对应的 values')
        names.append(s['name'])
        if any(v is not None and not number(v) for v in s['values']):
            raise ValueError('图表数值必须是有限数或 null，不能用文本冒充零')
    if len(set(names)) != len(names):
        raise ValueError('图表系列名称不能重复')
    if b.get('percent') and b.get('kind') != 'stacked':
        raise ValueError('percent 仅用于百分比堆叠')
    composition = b.get('kind') in ('donut', 'pie') or b.get('percent')
    if composition and any(v < 0 for s in series for v in s['values'] if v is not None):
        raise ValueError('组成占比图不支持负数；请使用条形图或正负堆叠，不取绝对值')
    if b.get('kind') in ('donut', 'pie') and (len(series) > 1 or len(cats) > 5):
        raise ValueError('环形/饼图只接受一个系列、最多5类；更多类别请使用条形图')
    if 'x_values' in b:
        if b.get('kind') != 'line': raise ValueError('x_values 仅用于折线')
        raw=b['x_values']
        if not isinstance(raw,list) or len(raw)!=len(cats): raise ValueError('x_values 必须逐类对应')
        try: coords=[date.fromisoformat(v).toordinal() if isinstance(v,str) else v for v in raw]
        except ValueError: raise ValueError('日期使用 YYYY-MM-DD')
        if any(not number(v) for v in coords) or any(y<=x for x,y in zip(coords,coords[1:])):raise ValueError('时间/数值坐标需要严格递增，不自动重排来源数据')
    return cats, series


def render(b):
    cats, series = validate(b)
    e = lambda x: escape(str(x), quote=True)
    uid = 'hw-chart-' + str(next(_ids))
    title, unit, kind = b['title'], b['unit'], b.get('kind', 'column')
    def color(i): return 'var(--chart-' + str(i % 6 + 1) + ')'
    def txt(x, y, value, anchor='start', cls=''):
        return f'<text x="{x:.2f}" y="{y:.2f}" text-anchor="{anchor}" class="{cls}">{e(value)}</text>'
    def point(shape, label):
        return '<g tabindex="0" role="img" aria-label="' + e(label) + '"><title>' + e(label) + '</title>' + shape + '</g>'
    head = '<tr><th scope="col">对象</th>' + ''.join('<th scope="col">' + e(s['name']) + '（' + e(unit) + '）</th>' for s in series) + '</tr>'
    rows = ''.join('<tr><th scope="row">' + e(c) + '</th>' + ''.join('<td>' + e(fmt(s['values'][i])) + '</td>' for s in series) + '</tr>' for i, c in enumerate(cats))
    body = []
    values = [v for s in series for v in s['values'] if v is not None]
    width, height = max(660, len(cats) * (85 if kind != 'bar' else 10)), 390
    if not cats or not series or not values:
        graphic = '<p class="hw-chart-empty" role="status">暂无可绘制数据；未提供不等于零。</p>'
    elif kind in ('donut', 'pie'):
        vals = series[0]['values']
        total = sum(v for v in vals if v is not None)
        if any(v is None for v in vals):
            graphic = '<p class="hw-chart-empty">组成数据存在缺项，不能计算完整总体的占比。请查看明细。</p>'
        elif total == 0:
            graphic = '<p class="hw-chart-empty">总量为零，无可计算占比。</p>'
        else:
            width, height = 660, 360
            cx, cy, r, angle = 175, 175, 118, -math.pi / 2
            for i, v in enumerate(vals):
                part = v / total
                label = f'{cats[i]}：{fmt(v)}{unit}，占比{part:.1%}'
                if part >= 1 - 1e-12:
                    shape = f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{color(i)}"/>'
                elif part > 0:
                    end = angle + part * 2 * math.pi
                    x1, y1 = cx + r * math.cos(angle), cy + r * math.sin(angle)
                    x2, y2 = cx + r * math.cos(end), cy + r * math.sin(end)
                    shape = f'<path d="M{cx} {cy} L{x1:.3f} {y1:.3f} A{r} {r} 0 {int(part > .5)} 1 {x2:.3f} {y2:.3f} Z" fill="{color(i)}" stroke="var(--surface)" stroke-width="2"/>'
                else:
                    shape = ''
                body.append(point(shape, label))
                body.append(txt(330, 75 + i * 45, label))
                angle += part * 2 * math.pi
            if kind == 'donut':
                body += [f'<circle cx="{cx}" cy="{cy}" r="72" fill="var(--surface)"/>', txt(cx, cy, fmt(total), 'middle', 'hw-chart-total'), txt(cx, cy + 28, '总计（' + unit + '）', 'middle')]
            graphic = None
    else:
        percent = bool(b.get('percent'))
        # Missing columns are never converted to zero in stacked totals.
        columns = [[s['values'][i] for s in series] for i in range(len(cats))]
        complete = [all(v is not None for v in col) for col in columns]
        positives = [sum(max(v, 0) for v in col if v is not None) for col in columns]
        negatives = [sum(min(v, 0) for v in col if v is not None) for col in columns]
        lo = min([0, *(negatives if kind == 'stacked' else values)])
        hi = 100 if percent else max([0, *(positives if kind == 'stacked' else values)])
        if hi == lo:
            hi = lo + 1
        span = hi - lo
        if not percent:
            if hi > 0: hi += span * .12
            if lo < 0: lo -= span * .12
        # Rounded, shared tick intervals preserve sign and avoid false precision.
        raw_step=(hi-lo)/5
        magnitude=10**math.floor(math.log10(raw_step))
        axis_step=next(x*magnitude for x in (1,2,2.5,5,10) if x*magnitude>=raw_step)
        lo=math.floor(lo/axis_step)*axis_step
        hi=math.ceil(hi/axis_step)*axis_step
        tick_count=int(round((hi-lo)/axis_step))+1
        left, right, top, bottom = 82, width - 75, 36, 305
        if kind == 'bar':
            height = max(270, len(cats) * (38 * len(series) + 30) + 100)
            right, bottom = width - 90, height - 50
            left = 170
            scale = lambda v: left + (v - lo) / (hi - lo) * (right - left)
            zero = scale(0)
            body.append(f'<line x1="{zero}" x2="{zero}" y1="{top}" y2="{bottom}" class="hw-chart-zero"/>')
            for tick in range(tick_count):
                v = lo + axis_step * tick
                x = scale(v)
                body.append(txt(x, bottom + 25, fmt(v), 'middle'))
            group = (bottom - top) / len(cats)
            for i, c in enumerate(cats):
                body.append(txt(left - 12, top + group * (i + .5), c, 'end'))
                for j, s in enumerate(series):
                    v = s['values'][i]
                    y = top + group * i + 8 + j * (group - 16) / len(series)
                    if v is None:
                        body.append(txt(zero + 5, y + 16, '未提供')); continue
                    x, w = min(zero, scale(v)), abs(scale(v) - zero)
                    label = f'{c} · {s["name"]}：{fmt(v)}{unit}'
                    shape = f'<rect x="{x:.2f}" y="{y:.2f}" width="{max(w, 1):.2f}" height="{max(8, (group-16)/len(series)-6):.2f}" fill="{color(j)}"/>'
                    body += [point(shape, label), txt(scale(v) + (6 if v >= 0 else -6), y + 16, fmt(v), 'start' if v >= 0 else 'end')]
        else:
            scale = lambda v: bottom - (v - lo) / (hi - lo) * (bottom - top)
            zero = scale(0)
            for tick in range(tick_count):
                v = lo + axis_step * tick
                y = scale(v)
                body += [f'<line x1="{left}" x2="{right}" y1="{y:.2f}" y2="{y:.2f}" class="hw-chart-grid"/>', txt(left - 10, y + 5, fmt(v) + ('%' if percent else ''), 'end')]
            body.append(f'<line x1="{left}" x2="{right}" y1="{zero:.2f}" y2="{zero:.2f}" class="hw-chart-zero"/>')
            step = (right - left) / len(cats)
            xs=[left+step*(i+.5) for i in range(len(cats))]
            if kind=='line' and b.get('x_values') and len(cats)>1:
                coords=[date.fromisoformat(v).toordinal() if isinstance(v,str) else v for v in b['x_values']]
                xs=[left+step/2+(v-coords[0])/(coords[-1]-coords[0])*(right-left-step) for v in coords]
            for i, c in enumerate(cats): body.append(txt(xs[i], bottom + 28, c, 'middle'))
            if kind == 'line':
                for j, s in enumerate(series):
                    segment = []
                    for i, v in enumerate(s['values']):
                        if v is None:
                            if segment: body.append(f'<polyline points="{" ".join(segment)}" fill="none" stroke="{color(j)}" stroke-width="3" stroke-dasharray="{("none","10 5","3 5","12 4 2 4","8 3","2 3")[j]}"/>')
                            segment = []; continue
                        x, y = xs[i], scale(v)
                        segment.append(f'{x:.2f},{y:.2f}')
                        body += [point(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="5" fill="{color(j)}"/>', f'{cats[i]} · {s["name"]}：{fmt(v)}{unit}'), txt(x, y - 12 - j * 14, fmt(v), 'middle')]
                    if segment: body.append(f'<polyline points="{" ".join(segment)}" fill="none" stroke="{color(j)}" stroke-width="3" stroke-dasharray="{("none","10 5","3 5","12 4 2 4","8 3","2 3")[j]}"/>')
            else:
                for i, c in enumerate(cats):
                    pos, neg = 0, 0
                    if kind == 'stacked' and (not complete[i] or percent and positives[i] == 0):
                        body.append(txt(left + step * (i + .5), top + 25, '缺项' if not complete[i] else '总量为零', 'middle')); continue
                    for j, s in enumerate(series):
                        raw = s['values'][i]
                        if raw is None: continue
                        v = raw / positives[i] * 100 if percent else raw
                        barw = min(48, step * .68 / (1 if kind == 'stacked' else len(series)))
                        x = left + step * (i + .5) - (barw / 2 if kind == 'stacked' else barw * len(series) / 2 - j * barw)
                        base = (pos if v >= 0 else neg) if kind == 'stacked' else 0
                        end = base + v
                        if kind == 'stacked':
                            if v >= 0: pos = end
                            else: neg = end
                        y, h = min(scale(base), scale(end)), abs(scale(end) - scale(base))
                        shape = f'<rect x="{x:.2f}" y="{y:.2f}" width="{barw-2:.2f}" height="{max(h, 1):.2f}" fill="{color(j)}"/>'
                        body.append(point(shape, f'{c} · {s["name"]}：{fmt(raw)}{unit}' + (f'，占比{v:.1f}%' if percent else '')))
                        if kind != 'stacked': body.append(txt(x + barw / 2, scale(v) + (-10 if v >= 0 else 20), fmt(raw), 'middle'))
                    if kind == 'stacked' and not percent:
                        body += [txt(left + step * (i + .5), scale(pos) - 10, '+' + fmt(pos), 'middle'), txt(left + step * (i + .5), scale(neg) + 20, fmt(neg), 'middle')]
            if kind == 'stacked' and not percent:
                rows += '<tr><th scope="row">各对象净值</th><td colspan="' + str(len(series)) + '">' + e('；'.join(cats[i] + '：' + (fmt(positives[i] + negatives[i]) if complete[i] else '缺项，净值待确认') for i in range(len(cats)))) + '</td></tr>'
        graphic = None
    if graphic is None:
        graphic = f'<div class="hw-chart-scroll" tabindex="0" role="region" aria-label="{e(title)}图形，可在图内滚动"><svg viewBox="0 0 {width} {height}" width="{width}" height="{height}" role="group" aria-label="{e(title)}，单位{e(unit)}">' + ''.join(body) + '</svg></div>'
    legend = ''.join(f'<span><i style="background:{color(i)}" aria-hidden="true"></i>{e(s["name"])}</span>' for i, s in enumerate(series)) if kind not in ('pie','donut') else ''
    return f'<figure class="hw-chart" id="{uid}"><figcaption><strong>{e(title)}</strong><span>{e(b.get("period", ""))} · 单位：{e(unit)}</span></figcaption>' + (f'<p class="hw-chart-summary">{e(b["summary"])}</p>' if b.get('summary') else '') + graphic + f'<div class="hw-chart-legend">{legend}</div><p class="hw-chart-focus" role="status"></p><p class="hw-chart-source">来源：{e(b["source"])}' + (f' · 口径：{e(b["note"])}' if b.get('note') else '') + f'</p><details class="hw-chart-data"><summary>查看数据明细</summary><div class="data-table-scroll" tabindex="0"><table class="data-table"><caption>{e(title)} · 原始数据</caption><thead>{head}</thead><tbody>{rows}</tbody></table></div></details></figure>'


CSS = r'''
.hw-chart{margin:1.5rem 0;padding:1.25rem;border:1px solid var(--border);border-radius:var(--r-card);background:var(--surface);min-inline-size:0}
.hw-chart figcaption{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.5rem;text-align:start}.hw-chart figcaption strong{font-size:var(--fs-cardtitle);color:var(--brand)}.hw-chart figcaption span,.hw-chart-source{font-size:var(--fs-note);color:var(--muted)}
.hw-chart-summary{font-size:var(--fs-lede);line-height:1.6;color:var(--brand)}.hw-chart-scroll{overflow:auto;max-inline-size:100%;max-block-size:30rem;scrollbar-width:auto}.hw-chart svg{display:block;max-inline-size:none;min-inline-size:100%;max-block-size:none;block-size:auto;background:var(--surface);font-family:var(--sans);font-size:15px;fill:var(--text)}
.hw-chart svg g:focus{outline:3px solid var(--focus);outline-offset:4px}.hw-chart-grid{stroke:var(--border);stroke-width:1}.hw-chart-zero{stroke:var(--muted);stroke-width:1.5}.hw-chart-total{font-size:28px;font-weight:650}.hw-chart-legend{display:flex;gap:.75rem 1.5rem;flex-wrap:wrap;font-size:var(--fs-note);margin:.75rem 0}.hw-chart-legend span{display:flex;gap:.5rem;align-items:center}.hw-chart-legend i{display:inline-block;width:.875rem;height:.875rem;border-radius:2px}.hw-chart-data summary{cursor:pointer;color:var(--accent);padding:.5rem 0}.hw-chart-focus{min-block-size:1.5em;font-size:var(--fs-note)}.hw-chart-empty{padding:2rem;background:var(--bg)}
@media print{.hw-chart-scroll{overflow:visible;max-block-size:none}.hw-chart svg{inline-size:100%;min-inline-size:0;max-inline-size:100%}.hw-chart-data{display:block}.hw-chart{break-inside:avoid}}
@media(forced-colors:active){.hw-chart svg g{forced-color-adjust:none}.hw-chart-zero{stroke:CanvasText}.hw-chart-grid{stroke:GrayText}}
'''

JS = r'''
(()=>{let opened=[];addEventListener('beforeprint',()=>{if(opened.length)return;opened=[...document.querySelectorAll('.hw-chart-data:not([open])')];opened.forEach(x=>x.open=true);});addEventListener('afterprint',()=>{opened.forEach(x=>x.open=false);opened=[];});})();
document.querySelectorAll('.hw-chart').forEach(chart=>{chart.addEventListener('focusin',e=>{const p=e.target.closest('svg [aria-label]');if(p)chart.querySelector('.hw-chart-focus').textContent=p.getAttribute('aria-label');});});
'''
