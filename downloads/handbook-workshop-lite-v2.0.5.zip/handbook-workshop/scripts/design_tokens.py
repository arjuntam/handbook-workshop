"""手册视觉配置。示意配色，不代表任何品牌官方规范。"""
import math
PALETTES = {
 'air-blue': dict(name='清透蓝', brand='#0B1B2B', accent='#0A6ED1', bg='#F7F9FC', soft='#EAF4FE', text='#1E2D3D', muted='#526579', border='#E8EDF3'),
 'ink': dict(name='墨黑灰', brand='#242830', accent='#48576B', bg='#F3F4F6', soft='#E9EDF2', text='#272F3B', muted='#596370', border='#D4D9E0'),
 'forest': dict(name='松绿', brand='#214B3F', accent='#28715A', bg='#F2F7F4', soft='#E5F1EA', text='#263F35', muted='#536A5E', border='#CDDCD2'),
 'sand': dict(name='暖米金', brand='#5E4630', accent='#875B24', bg='#F8F5F0', soft='#F4E9D8', text='#42382F', muted='#746352', border='#E0D5C7'),
 'slate': dict(name='雾蓝灰', brand='#34455B', accent='#4C6584', bg='#F2F5F8', soft='#E7EDF5', text='#2C3D51', muted='#5E6E80', border='#D0DAE5'),
 'burgundy': dict(name='酒红', brand='#612C3C', accent='#924358', bg='#FAF4F5', soft='#F6E7EC', text='#482E37', muted='#785B66', border='#E5CFD7'),
}
PALETTES.update({
 'teal':dict(name='湖水青',brand='#20494B',accent='#1B737A',bg='#F1F7F7',soft='#E2F2F1',text='#263D40',muted='#526B6E',border='#CBDFDF'),
 'violet':dict(name='雅紫',brand='#453659',accent='#70518C',bg='#F7F4FA',soft='#EDE5F4',text='#3B3444',muted='#6A5C76',border='#DDD2E7'),
 'clay':dict(name='陶土橙',brand='#603C2D',accent='#A04F2F',bg='#FAF5F1',soft='#F6E6DB',text='#46362E',muted='#776051',border='#E7D5CA'),
 'olive':dict(name='橄榄灰',brand='#42482D',accent='#626B32',bg='#F6F7F1',soft='#EAEEDC',text='#363E2B',muted='#626D53',border='#D9DFCB'),

})
TYPE_SCALES = {
 'standard': {'--fs-cover':'2.5rem','--fs-title':'1.75rem','--fs-h3':'1.3125rem','--fs-cardtitle':'1.1875rem','--fs-body':'1.0625rem'},
 'presentation': {'--fs-cover':'2.875rem','--fs-title':'2rem','--fs-h3':'1.5rem','--fs-cardtitle':'1.3125rem','--fs-body':'1.125rem'},
}
READING_SIZES = {'--fs-text':'1rem','--fs-lede':'1.125rem','--fs-note':'.8125rem','--fs-tag':'.6875rem'}
for _preset in TYPE_SCALES.values():
    _preset.update(READING_SIZES)
TYPE_SCALES['compact'] = {key:format(float(value[:-3])*.9,'.6g')+'rem' for key,value in TYPE_SCALES['standard'].items()}
TYPE_SCALE_LIMITS = dict(min=.8,max=1.5,step=.01)


def type_tokens(config):
    preset=config.get('type_scale','standard')
    if preset not in TYPE_SCALES:
        raise ValueError('type_scale 只能为 compact、standard 或 presentation')
    factor=config.get('type_scale_factor',1)
    if isinstance(factor,bool) or not isinstance(factor,(int,float)) or not math.isfinite(factor) or not .8<=factor<=1.5:
        raise ValueError('type_scale_factor 必须是 0.8–1.5 之间的有限数值')
    result={key:format(float(value[:-3])*factor,'.6g')+'rem' for key,value in TYPE_SCALES[preset].items()}
    result['--type-size-factor']=format(factor*(.9 if preset=='compact' else 1),'.6g')
    return result

LEGACY_PALETTES={'night-blue':'air-blue','night-graphite':'ink','night-forest':'forest','night-wine':'burgundy'}

def selection(config):
    raw=config.get('palette','air-blue')
    palette=LEGACY_PALETTES.get(raw,raw)
    shell='dark' if raw in LEGACY_PALETTES else config.get('shell_mode','light')
    if palette not in PALETTES:raise ValueError(f'未知 palette：{raw}；可选 {list(PALETTES)}')
    if shell not in ('light','dark'):raise ValueError('shell_mode 只能为 light 或 dark')
    return palette,shell

def blend(a,b,f):
    return '#'+''.join(f'{round(int(a[i:i+2],16)*(1-f)+int(b[i:i+2],16)*f):02x}' for i in (1,3,5))

def tokens(config):
    palette,shell=selection(config)
    p=dict(PALETTES[palette])
    if shell=='dark':
        nav=blend(p['accent'],'#000000',.58)
        p.update(nav=nav,nav2=blend(nav,p['accent'],.22),navtext='#F1F5F9',navmuted=blend(nav,'#FFFFFF',.74),navactive=blend(nav,'#FFFFFF',.12),navaccent=blend(p['accent'],'#FFFFFF',.76))
    sizes = type_tokens(config)
    for key in ('logo_header_height','logo_cover_height'):
        if key in config and (not isinstance(config[key],(int,float)) or not 12 <= config[key] <= 120):
            raise ValueError(f'{key} 必须是 12–120 之间的数值')
    v = {'--brand':p['brand'],'--brand2':p['accent'],'--accent':p['accent'],'--accent-soft':p['soft'],
         '--bg':p['bg'],'--surface':'#FFFFFF','--text':p['text'],'--muted':p['muted'],'--border':p['border'],
         '--selected-bg':p['soft'],'--selected-border':p['accent'],'--selected-text':p['brand'],
         '--selected-shadow':'0 0 0 2px '+p['accent'], '--focus':p['accent'],
         '--sans':'"MiSans",sans-serif',
         '--table-head-bg':p['soft'],'--table-head-text':p['brand'],
         '--compare-before-bg':'#F7F9FC',
         '--compare-after-label':blend(p['accent'],p['brand'],.35),
         '--map-land-fill':blend(p['soft'],'#DFE5EC',.4),
         '--map-covered-fill':blend('#FFFFFF',p['accent'],.4),
         '--map-covered-stroke':blend(p['accent'],'#FFFFFF',.28),
         '--map-dot':blend(p['accent'],p['brand'],.45),
         '--nav-bg':p.get('nav',p['bg']),'--nav-bg2':p.get('nav2',p.get('nav',p['bg'])),'--nav-text':p.get('navtext',p['brand']),'--nav-muted':p.get('navmuted',p['muted']),
         '--nav-active-bg':p.get('navactive',p['soft']),'--nav-active-text':p.get('navaccent',p['accent']),'--nav-line':p.get('navactive',p['border']),
         '--logo-header-height':str(config.get('logo_header_height',28))+'px',
         '--logo-cover-height':str(config.get('logo_cover_height',48))+'px',
         **sizes}
    def tint(h,f):
        return '#'+''.join(f'{round(int(h[i:i+2],16)*f+255*(1-f)):02x}' for i in (1,3,5))
    v.update({'--flow-one':tint(p['accent'],.24),'--flow-two':tint(p['accent'],.14),'--flow-three':tint(p['accent'],.09),'--flow-paper':tint(p['accent'],.025)})
    import v2_theme
    v.update(v2_theme.tokens(config,v))
    return v
