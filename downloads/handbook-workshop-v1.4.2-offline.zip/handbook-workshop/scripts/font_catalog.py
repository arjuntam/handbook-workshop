"""项目级字体选型与官方完整字库元数据；不做字形裁剪。"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT = 'misans'


def catalog(root=None):
    return json.loads((Path(root or ROOT)/'assets/font-catalog.json').read_text(encoding='utf-8'))


def spec(key=DEFAULT, root=None):
    fonts = catalog(root)
    if key not in fonts:
        raise ValueError('未知字体选项：' + str(key))
    return fonts[key]


def tokens(key=DEFAULT):
    face = spec(key)
    serif = key == 'source-han-serif'
    return {'--sans': '"' + face['family'] + '",' + ('serif' if serif else 'sans-serif'),
            '--weight-body': '330' if key == DEFAULT else '400',
            '--weight-title': '600' if serif else '500',
            '--weight-medium': '430' if key == DEFAULT else '500'}


def faces_css():
    return ''.join('@font-face{font-family:"'+f['family']+'";src:url("assets/fonts/'+f['file']+'") format("'+f['format']+'");font-weight:'+f['weight']+';font-style:normal;font-display:swap}' for f in catalog().values())


def preview_data():
    return {k:dict(name=f['name'],family=f['family'],tokens=tokens(k)) for k,f in catalog().items()}
