# 项目字体选项

同一系列在 `project-style.json` 选择一款正文字体，标题、正文和控件沿用统一字体层级。默认 `font_family:"misans"`；可选 `source-han-sans`（思源黑体）和 `source-han-serif`（思源宋体）。字体与色系、深浅外框、两档字号独立，不逐页混用。

在样式库「配色、字体与字号」切换后预览整本效果，再下载配置。预览须等所选字体实际加载成功才切换；失败会明确提示并保持原字体。配置导出的是实际生效的字体，不把加载失败的选项当成成功。

思源黑体与思源宋体来自 Adobe 官方仓库的 SC 完整语言版变量字体（WOFF2），不是自行抽取常用汉字的子集。字库版本、官方来源、原文件大小和 SHA-256 记录在 `assets/font-catalog.json`；不删字，不重命名字体内部名称，不以本机同名字体代替交付资源。授权文本与字体随产物保留。

共享包不包含三款大字库。首次构建只准备项目选中的一款：`python scripts/prepare_resources.py --font source-han-serif`。字体按资源清单下载、校验并缓存，出错停止，不静默换系统字体；也可加 `--font-file 官方原文件路径` 离线提供与清单一致的文件。字体文件通过 HTTPS 下载，不执行远端代码，不上传用户资料。

正式生成的手册只携带所选字体及授权文件，可独立离线查看和重新构建。完整离线技能包与离线样式库包含全部三款，方便断网选择。共享包仍按 5,242,880 字节上限验收；实际 WorkBuddy 云端能否联网与持续缓存仍需在其环境验证。

保留字体角色而非统一套用相同字重：MiSans 正文 330、标题 500；思源黑体正文 400、标题 500；思源宋体正文 400、标题 600。字号、间距、卡片结构与交互不因换字体重新设计；检查长标题、表格、问答、底栏和 200% 文字放大，不能靠缩小文字或裁切内容掩盖问题。

只调整字体沿用资料原更新日期。生成业务读者页面不添加样式库版本号或设计者。旧页面另存换样式时可用 `apply_design.py --font source-han-serif`；未指定时保留已有 data-font，旧页面无此项则沿用 MiSans。

官方来源与授权：

- 思源黑体：https://github.com/adobe-fonts/source-han-sans ，授权 https://github.com/adobe-fonts/source-han-sans/blob/master/LICENSE.txt
- 思源宋体：https://github.com/adobe-fonts/source-han-serif ，授权 https://github.com/adobe-fonts/source-han-serif/blob/master/LICENSE.txt
