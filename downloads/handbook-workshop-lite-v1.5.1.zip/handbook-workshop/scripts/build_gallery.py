#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从已跑通的手册项目里采集真实块样例，生成一本「样式库」手册。

用法：
  python3 build_gallery.py --out <目录>            # 使用包内素材生成统一样式库
  python3 build_gallery.py --src A --src B --out <目录>

产出：
  <out>/index.html    可翻阅的样式库（每个块一页：什么时候用 / 别用 / 真实样例 / 可复制代码）
  <out>/assets/       样例引用的图片
  <out>/samples.json  采样清单，便于核对来源

只读源项目，不改动其任何文件。
"""
import argparse
import html as H
import importlib.util
import json
import sys
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(SKILL / "scripts"))
from handbook_core import build_html, ensure_brand_assets, write_handbook  # noqa: E402

# 每个块：中文名、所属分组、什么时候用、别用来干什么、必填字段
META = {
    "lede": ("导语", "文本", "一节开头的一句话定调，全页只放一条。", "别当正文用，超过两行就不像导语了。", "v"),
    "text": ("正文", "文本", "需要完整说明、读者要逐句读的段落。", "别把要点塞进长段落，那种情况用 callout 或 grid。", "v"),
    "h3": ("小标题", "文本", "一页内确实要分两层时，给第二层加标题。", "一个 h3 就该一页，堆 3 个以上说明该拆页。", "v"),
    "quote": ("金句", "文本", "要让人记住的一句话，视觉上单独跳出来。", "别用来装普通结论，用多了整本都在喊。", "v"),
    "callout": ("强调卡", "文本", "一条必须看到的结论、目标、共同点。", "别拿它装列表内容，会变成大字报。", "v（tone 可选 blue/red/green/amber）"),
    "warn": ("避坑卡", "文本", "明确写「不要这样做」的地方。", "只有真踩过坑才用，泛泛的注意事项会稀释警示。", "v"),
    "divider": ("分隔线", "文本", "同页两个不相干段落之间做视觉切分。", "别靠它撑版面，块之间本来就有间距。", "无"),
    "grid": ("卡片网格", "卡片", "2–4 张并列、每张 1–3 行的短内容。", "超过 cols×2 张改用 cut() 横切；字段统一的 6 行以上改用 roster。", "items（cols 默认 2）"),
    "pick": ("单选卡", "卡片", "让读者在心里选一个：选套餐、选档位、选场景。", "别用打钩样式，那看起来像表单已完成。", "items（cols、default）"),
    "compare": ("左右对照", "卡片", "现状 vs 需要、错 vs 对、竞品 vs 我们。", "别用两张 grid 并排假装对照，左右对不齐。", "items[{title,left,right}]"),
    "tabs": ("标签切换", "卡片", "3–6 个并列场景，一次只想看一个。", "只放 1 个标签等于多一次点击；标签栏超过 6 个会挤。", "items[{tab, block}]"),
    "stats": ("数字卡", "数据", "几个关键数字要一眼看清，且数字是真的。", "别放估算值或百分比凑数，滚动动画会放大不严谨。", "items[{num,label}]"),
    "total": ("合计条", "数据", "把总量从明细里拎出来单独一层。", "别把合计塞进卡片网格当第 N 张。", "items[{v,label}]（note 可选）"),
    "roster": ("分工表格", "数据", "字段统一的 N 行清单：分工、排班、物料、责任矩阵。", "少于 4 行改用 grid，表格会显得空。", "items[{name,who,own,time}]"),
    "runsheet": ("流程时间轴", "流程", "一条带具体时间点的完整流程，一屏装完。", "没有时间点的纯步骤用 steps；节点少于 5 个也用 steps。", "items[{time,name}]（sep 分组）"),
    "steps": ("步骤", "流程", "3–5 步、每步要解释一句的动作。", "十几步的流程用 runsheet，steps 会拖两屏。", "items[{title,body}]"),
    "metro": ("地铁报站", "流程", "4–6 个阶段的推进节奏，每站有自己的要点。", "num 别塞「第一阶段」四个字，40px 圆圈会溢出；也别开 navigate。", "items[{num,title,body}]（compact 可选）"),
    "faq": ("折叠问答", "话术", "现场会被反复问的问题 + 可直接背的答复口径。", "别把长文档塞进答案，折叠层不是阅读区。", "items[{q,principle,answer}]"),
    "chat": ("对话气泡", "话术", "一对一聊天话术示例，要像真在微信里说。", "别在气泡里塞正文大图，只放文字 + 真实头像。", "bubbles[{role,text}]（role=sales/client）"),
    "scriptlib": ("话术库", "话术", "成组话术，按场景折叠。", "放进 tabs 里要设 flat，否则标签内再套折叠＝两次点击。", "data[{group,blocks}]"),
    "moments": ("朋友圈", "仿真", "发圈文案示例，要像真的朋友圈。", "一对一聊天别用它；头像和点赞名单必须是真实素材里的人和图。", "name、text（avatar/imgs/likes/comments 可选）"),
    "imgs": ("图片画廊", "图片", "2–4 张图并列，读者要看细节。", "别用固定高度裁剪关键图表，会看不全。", "items[{src,cap}]（cols）"),
    "img": ("单图", "图片", "单独一张有说明的图，占满一行。", "多张同类图别逐张 img，用 imgs 画廊。", "src（cap 可选）"),
    "note": ("附件提示", "图片", "提醒读者页脚有附件可下载。", "别用它装正文，它只是提示条。", "v"),
    "html": ("原生片段", "图片", "外部生成的图表（如内联 SVG 地图）要原样塞进页面。", "别拿它手写版式，样式会脱离设计系统。", "v（完整 HTML 片段）"),
}

# 分组顺序与说明
FAMILIES = [
    ("文本", "先把话说清楚", "文字块决定这页读起来累不累。原则上少而准：一页一条导语、一条结论，其余交给卡片。"),
    ("卡片", "并列内容怎么摆", "这是最容易选错的一组。判断只看一件事：内容长度。短 → 平铺，长 → 横切，成对 → 对照。"),
    ("数据", "数字怎么立住", "数字要有层级：明细在上，合计单独一层；字段统一就上表格，不要硬摆成卡片。"),
    ("流程", "先干什么后干什么", "有时间点用 runsheet，有阶段用 metro，只有先后顺序用 steps。"),
    ("话术", "让人能照着说", "话术类块都自带复制按钮。能复制才叫话术，读完再手抄就不算。"),
    ("仿真", "要像真的", "朋友圈和聊天记录是给一线看的样例，人名、头像、点赞名单必须来自真实素材。"),
    ("图片", "图怎么放", "图要以看清为前提：多图并排给画廊，单图占满一行，关键图表必须可点开放大。"),
]

# 相关块互跳，方便「想不明白」时横向找替代方案
RELATED = {
    "grid": ["tabs", "roster", "pick"], "tabs": ["grid", "scriptlib", "pick"],
    "pick": ["grid", "tabs"], "roster": ["grid", "total"], "total": ["roster", "stats"],
    "stats": ["total", "compare"], "runsheet": ["steps", "metro"], "steps": ["runsheet", "metro"],
    "metro": ["runsheet", "steps"], "imgs": ["img"], "img": ["imgs"],
    "chat": ["scriptlib", "faq"], "scriptlib": ["chat", "faq", "tabs"], "faq": ["chat", "scriptlib"],
    "compare": ["grid"], "callout": ["warn", "quote"], "quote": ["callout"], "warn": ["callout"],
    "lede": ["callout", "text"], "text": ["lede", "callout"], "moments": ["chat", "imgs"],
    "note": ["imgs"], "html": ["imgs"], "h3": ["text"], "divider": ["h3"],
}

# 想要「第二种形态」的块：靠这些字段区分
VARIANT_FLAGS = {"quote": ("reveal",), "metro": ("compact", "navigate"), "scriptlib": ("flat", "open")}

HTML_SAMPLE = ('<div style="border:1px solid var(--border);border-radius:10px;padding:14px 16px;'
               'background:linear-gradient(90deg,var(--accent-soft),#fff)">'
               '<b style="color:var(--brand)">外部片段注入示例</b>'
               '<div style="font-size:13px;color:var(--muted)">这段 HTML 由 gen_map.py 之类的外部脚本生成，'
               '构建时替换占位符 <!--COVERAGE_MAP--> 写入。</div></div>')

# 两个项目还没用到、但模型里已有的块：给手写样例，保证库不缺页
FALLBACK = {
    "h3": [{"t": "h3", "v": "一页里的第二层标题"}],
    "divider": [{"t": "divider"}],
    "img": [{"t": "img", "src": "__FIRST_IMAGE__", "cap": "单图占满一行，说明写在图下"}],
    "moments": [{
        "t": "moments", "name": "大金 · 暖通顾问", "time": "3 小时前",
        "text": "今天在新盘驻点，遇到一户 180 平户型，客户原本只想做一拖三。\n"
                "现场把客餐厅的送风路径画给客户看了一遍，方案改成全屋新风 + 中央空调。",
        "likes": "宁静致远、冰清玉洁",
        "comments": [{"name": "宁静致远", "text": "这种户型做全屋确实更稳"}],
    }],
}


# 代码区样式：折叠壳保留原生 summary 标记（可被「页内查找」命中），代码块深色、可聚焦滚动
GALLERY_CSS = """
.g-code{margin:8px 0 4px;border:1px solid var(--border);border-radius:10px;background:#fbfcfe;padding:0 12px}
.g-code>summary{cursor:pointer;padding:11px 0;font-size:13px;font-weight:700;color:var(--brand2)}
.g-code[open]>summary{padding-bottom:2px}
.g-code pre{margin:0 0 12px;padding:14px 52px 15px 16px;background:#0f2233;color:#d6e4f0;border-radius:10px;
  font-size:12.5px;line-height:1.7;overflow:auto;max-block-size:400px;
  font-family:ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre-wrap;word-break:break-word}
.g-code pre:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
@media (prefers-reduced-motion: no-preference){.g-code pre{scroll-behavior:smooth}}
"""


def load_sections(proj):
    cf = proj / "content.py"
    if not cf.exists():
        print(f"跳过（无 content.py）：{proj}")
        return []
    spec = importlib.util.spec_from_file_location("hb_g", cf)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return getattr(mod, "SECTIONS", [])


def iter_blocks(blocks):
    for b in blocks or []:
        if not isinstance(b, dict):
            continue
        yield b
        for it in b.get("items") or []:
            if isinstance(it, dict) and isinstance(it.get("block"), dict):
                yield it["block"]


def weight(b):
    """样例优选：优先能一屏看完、有信息量的那块。"""
    s = json.dumps(b, ensure_ascii=False)
    n = len(s)
    score = 0
    if 120 <= n <= 800:
        score += 100 - abs(600 - n) / 20
    if b.get("t") in ("imgs", "grid", "chat", "moments", "tabs", "compare", "runsheet", "roster", "metro"):
        score += 10 if any(k in b for k in ("items", "bubbles")) else 0
    return score


def harvest(projects):
    """返回 {类型: [样例块,...]}，每类最多 2 个（主样例 + 一个不同形态）。"""
    buckets, sources = {}, {}
    for proj in projects:
        for sec in load_sections(proj):
            for b in iter_blocks(sec.get("blocks")):
                t = b.get("t")
                if t not in META:
                    continue
                buckets.setdefault(t, []).append(b)
                sources.setdefault(t, proj.name)

    picked = {}
    for t, lst in buckets.items():
        if t == "html":
            picked[t] = [{"t": "html", "v": HTML_SAMPLE}]
            continue
        best = sorted(lst, key=weight)[-1]
        out = [best]
        flags = VARIANT_FLAGS.get(t)
        if flags:
            for b in lst:
                if b is best:
                    continue
                if any(bool(b.get(f)) != bool(best.get(f)) for f in flags):
                    out.append(b)
                    break
        picked[t] = out
    return picked, sources, buckets


def pyval(v):
    """按 content.py 的书写习惯输出：双引号、True/False/None。"""
    if isinstance(v, bool):
        return "True" if v else "False"
    if isinstance(v, (int, float)):
        return json.dumps(v)
    if v is None:
        return "None"
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    if isinstance(v, list):
        return "[" + ", ".join(pyval(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ", ".join(f'"{k}": {pyval(x)}' for k, x in v.items()) + "}"
    return json.dumps(v, ensure_ascii=False)


def fmt_dict(d, ind):
    """一行放得下就一行；放不下就每个键一行。"""
    flat = "{" + ", ".join(f'"{k}": {pyval(v)}' for k, v in d.items()) + "}"
    if len(flat) + ind * 4 <= 96:
        return flat
    pad = "    " * (ind + 1)
    body = ",\n".join(f'{pad}"{k}": {pyval(v)}' for k, v in d.items())
    return "{\n" + body + ",\n" + "    " * ind + "}"


def code_of(block):
    """把块打印成可直接粘进 content.py 的片段：列表项逐条换行。"""
    keys = [(k, v) for k, v in block.items() if k not in ("items", "bubbles", "data")]
    list_key = next((k for k in ("items", "bubbles", "data") if k in block), None)
    head = "{" + ", ".join(f'"{k}": {pyval(v)}' for k, v in keys)
    if not list_key:
        return H.escape(head + "}")
    lines = [head + f', "{list_key}": [']
    for it in block[list_key]:
        lines.append("    " + fmt_dict(it, 1) + ",")
        lines.append("")
    if lines[-1] == "":
        lines.pop()
    lines.append("]},")
    return H.escape("\n".join(lines))


def trim_sample(block, limit=8):
    """超长样例截取前若干项：样式库看的是形态，不是全量数据。返回 (块, 是否截取)。"""
    key = next((k for k in ("items", "bubbles", "data") if isinstance(block.get(k), list)), None)
    if key == "data":
        # 话术库按分组截取，每组最多留 3 条
        groups = []
        changed = len(block["data"]) > 2
        for g in block["data"][:2]:
            g2 = dict(g)
            if isinstance(g2.get("blocks"), list) and len(g2["blocks"]) > 3:
                g2["blocks"] = g2["blocks"][:3]
                changed = True
            groups.append(g2)
        if not changed:
            return block, False
        out = dict(block)
        out["data"] = groups
        return out, True
    if not key or len(block[key]) <= limit:
        return block, False
    out = dict(block)
    out[key] = block[key][:limit]
    if out.get("meta"):
        out["meta"] = "示例截取"      # 原 meta 常写「13 个节点」，与截取后的行数对不上
    return out, True


def build_sections(picked, sources, out_assets, proj_images):
    """组装样式库章节。图片按名复制到 out_assets，返回 (sections, xref, 缺失图片)。"""
    sections, missing = [], []
    copy_img = []

    # 兜底样例要用的第一张图
    first_img = None
    for proj, names in proj_images.items():
        for n in sorted(names):
            if n.lower().endswith((".jpg", ".jpeg", ".png", ".webp")):
                first_img = n
                break
        if first_img:
            break

    def pick_images(block):
        """把一个块里引用到的图片名收出来。"""
        names = []
        t = block.get("t")
        if block.get("src"):
            names.append(block["src"])
        if t in ("grid", "pick", "tabs", "imgs", "chat"):
            for it in block.get("items") or []:
                for k in ("img", "icon", "src"):
                    if it.get(k):
                        names.append(it[k])
        for m in block.get("bubbles") or []:
            for k in ("avatar", "img"):
                if m.get(k):
                    names.append(m[k])
        for x in block.get("imgs") or []:
            names.append(x)
        if block.get("avatar"):
            names.append(block["avatar"])
        for c in block.get("comments") or []:
            if isinstance(c, dict) and c.get("img"):
                names.append(c["img"])
        return names

    # 使用说明页
    guide = {
        "id": "how-to", "nav": "怎么用", "group": "使用说明",
        "kicker": "GUIDE · 先看这页", "title": "想不清怎么摆，就照着信息形状查",
        "subtitle": "每个块都有自己的形状。先认出形状，块就定了，不用凭感觉试。",
        "blocks": [
            {"t": "lede", "v": "这本库不是组件文档，是选型表：同一段内容换哪个块更合适，看完能直接决定。"},
            {"t": "roster", "title": "选块速查", "meta": "信息形状 → 用哪个", "head": ["#", "信息形状", "用什么", "不要用"],
             "items": [
                 {"name": "2 张以内、每张 1–2 行", "note": "", "who": "grid 平铺", "own": "tabs 横切（大片留白）"},
                 {"name": "3–5 张、每张 3 行以上", "note": "", "who": "cut() 横切", "own": "grid（纵着滚两屏）"},
                 {"name": "左右成对（现状/需要）", "note": "", "who": "compare", "own": "两张 grid 并排"},
                 {"name": "有先后、带时间点", "note": "", "who": "runsheet", "own": "steps / grid"},
                 {"name": "字段统一的 6 行以上", "note": "", "who": "roster", "own": "grid 卡片"},
                 {"name": "合计 / 总计", "note": "", "who": "total", "own": "塞进卡片网格"},
                 {"name": "多场景话术 3 段以上", "note": "", "who": "tabs + chat / scriptlib(flat)", "own": "每段一个章节"},
                 {"name": "5 个以内阶段 + 详情", "note": "", "who": "metro", "own": "真流程用 runsheet"},
             ]},
            {"t": "callout", "label": "判断口诀", "tone": "blue",
             "v": "内容长 → 横切省纵向；内容短 → 平铺更紧凑。有合计 → 合计比明细高一层。超过 6 行同构数据 → 表格，不要卡片。"},
            {"t": "note", "v": "每页底部都有「相关块」，可以直接跳到相近的替代方案；代码块右上角可一键复制，粘进 content.py 改字即用。样例全部来自已跑通的项目，字段和真实用法一致。"},
        ],
    }
    sections.append(guide)

    order = {"文本": 1, "卡片": 2, "数据": 3, "流程": 4, "话术": 5, "仿真": 6, "图片": 7}
    for fam, fam_title, fam_desc in FAMILIES:
        types = [t for t in META if META[t][1] == fam]
        if not types:
            continue
        for idx, t in enumerate(types):
            cn, _, use, avoid, fields = META[t]
            samples = picked.get(t) or []
            hand_made = False
            if not samples and t in FALLBACK:
                samples = json.loads(json.dumps(FALLBACK[t]).replace("__FIRST_IMAGE__", first_img or ""))
                hand_made = True
            blocks = []
            # 分组说明只在每组第一页出现
            if idx == 0:
                blocks.append({"t": "callout", "label": f"{fam} · {fam_title}", "tone": "blue", "v": fam_desc})
            blocks.append({"t": "compare", "cols": 1, "left_tag": "什么时候用", "right_tag": "别这样用",
                           "items": [{"title": f"{cn}的适用边界", "left": use, "right": avoid}]})
            for si, b in enumerate(samples):
                b, trimmed = trim_sample(b)
                if hand_made:
                    label = "手写样例（现有项目还没用到，下次落地后替换成真实截取）"
                else:
                    label = "真实样例" if si == 0 else "另一种形态"
                if trimmed:
                    label += "（原表更长，这里截取前 8 项看形态）"
                blocks.append({"t": "h3", "v": label})
                blocks.append(b)
                for name in pick_images(b):
                    if name not in copy_img:
                        copy_img.append(name)
                cid = f"code-{t}-{si}"
                # 复制按钮直接复用引擎的 .copy / .copy-button / role=status 气泡，
                # 不另写脚本：反馈、失败回退、图标切换都由引擎统一处理。
                code_html = (
                    '<details class="g-code">'
                    '<summary>查看并复制代码</summary>'
                    '<div style="position:relative">'
                    f'<span class="copy" style="position:absolute;right:8px;top:8px;z-index:2">'
                    f'<button type="button" class="copy-button" command="--copy" commandfor="{cid}" '
                    f'aria-label="复制这段 {t} 代码">'
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 8h10M9 12h10M9 16h10M5 8h.01M5 12h.01M5 16h.01" '
                    'stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round"/></svg>'
                    '</button><span class="tip" role="status"></span></span>'
                    f'<pre id="{cid}" tabindex="0" aria-label="{t} 块示例代码，可用方向键滚动">'
                    f'{code_of(b)}</pre></div></details>'
                )
                blocks.append({"t": "html", "v": code_html})
            sections.append({
                "id": f"blk-{t}",
                "nav": cn,
                "group": f"{order[fam]} · {fam}",
                "kicker": f'BLOCK · t = "{t}"',
                "title": f"{cn}",
                "subtitle": f"必填：{fields}",
                "blocks": blocks,
            })

    # 复制图片
    out_assets.mkdir(parents=True, exist_ok=True)
    for name in copy_img:
        src = None
        for proj, names in proj_images.items():
            if name in names:
                src = proj / "assets" / name
                break
        if src and src.exists():
            (out_assets / name).write_bytes(src.read_bytes())
        else:
            missing.append(name)
    # 清掉上次生成留下的图片，避免 assets 越攒越多
    for f in out_assets.iterdir():
        if f.is_file() and f.name not in copy_img:
            f.unlink()

    # 交叉引用
    xref = {}
    all_ids = {s["id"] for s in sections}
    for t, rel in RELATED.items():
        sid = f"blk-{t}"
        if sid not in all_ids:
            continue
        xref[sid] = [f"blk-{r}" for r in rel if f"blk-{r}" in all_ids]
    return sections, xref, missing


def main():
    ap = argparse.ArgumentParser(description="从真实项目采集块样例，生成样式库手册")
    ap.add_argument("--src", action="append", help="手册项目目录，可多次传入")
    ap.add_argument("--out", required=True, help="可写的新输出目录，不写入技能安装目录")
    args = ap.parse_args()

    out = Path(args.out).expanduser()
    if out.exists() and any(out.iterdir()):ap.error('输出目录非空，请使用新目录，避免覆盖原文件')
    if not args.src:
        from build_design_gallery import build
        print(build(out))
        return
    projects = [Path(p).expanduser() for p in args.src]
    if any(not p.is_dir() for p in projects):ap.error('指定的来源项目目录不存在')
    out.mkdir(parents=True, exist_ok=True)

    picked, sources, buckets = harvest(projects)
    proj_images = {}
    for p in projects:
        ad = p / "assets"
        proj_images[p] = {f.name for f in ad.iterdir() if f.is_file()} if ad.exists() else set()

    sections, xref, missing = build_sections(picked, sources, out / "assets", proj_images)

    hero = {
        "kicker": "样式库 · 跟着实战长出来",
        "title": "网页手册\n样式库",
        "desc": "想不清这段内容该怎么摆，先来这里找形状。\n每个块都有真实样例和可复制代码。",
        "meta": f"采集自 {len(projects)} 本已跑通的手册 · {len(picked)} 个块类型",
    }
    cfg = {
        "brand": "样式库", "brand_logo": "", "cover_image": "", "home_href": "",
        "mobile_block": True, "dock_note": "",
        "theme": {"--brand": "#0d3b66", "--brand2": "#1b5c96", "--accent": "#2b7fd4"},
    }
    # 追加复制按钮脚本（引擎 JS 不处理 .gcopy）
    ensure_brand_assets(out)
    page = build_html("网页手册样式库", "块类型 · 真实样例 · 可复制代码", hero, sections,
                      [], {}, search_placeholder="搜索块 / 场景 / 字段", xref=xref, config=cfg)
    # 代码区样式：折叠壳 + 深色代码块。复制按钮与提示气泡走引擎既有 .copy / .tip，
    # pre 可键盘聚焦（tabindex=0）以支持方向键横向滚动。
    page = page.replace("</head>", "<style>" + GALLERY_CSS + "</style></head>")
    write_handbook(out / "index.html", page)
    (out / "samples.json").write_text(json.dumps({
        "sources": [p.name for p in projects],
        "counts": {t: len(v) for t, v in buckets.items()},
        "sampled": {t: len(v) for t, v in picked.items()},
        "missing_images": missing,
    }, ensure_ascii=False, indent=2), encoding="utf-8")

    absent = [t for t in META if t not in picked and t not in FALLBACK]
    hand = [t for t in META if t not in picked and t in FALLBACK]
    real = len([t for t in META if t in picked])
    print(f"样式库已生成：{out / 'index.html'}")
    print(f"  块类型 {len(META)} 个：真实样例 {real}，手写兜底 {len(hand)}，缺样例 {len(absent)}")
    print(f"  章节 {len(sections)} 页")
    if hand:
        print(f"  手写兜底：{', '.join(hand)}")
    if absent:
        print(f"  缺样例：{', '.join(absent)}")
    if missing:
        print(f"  缺图 {len(missing)} 张：{', '.join(missing[:5])}")


if __name__ == "__main__":
    main()
