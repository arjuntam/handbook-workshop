// Verify viewport pinning and layout. Physical OS rubber-banding still needs device acceptance.
const fs=require('fs'),path=require('path'),{pathToFileURL}=require('url');
const {launchBrowser,loadPlaywright}=require('./browser_runtime');
const [site,out,baseline]=process.argv.slice(2);if(!out)throw Error('Usage: generated/index.html output [previous/index.html]');fs.mkdirSync(out,{recursive:true});
(async()=>{const browser=await launchBrowser(),results=[],errors=[];
const ck=(name,ok,detail)=>{results.push({name,ok,detail});if(!ok)throw Error(name+' '+JSON.stringify(detail))};
try{const p=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'reduce'});p.on('pageerror',e=>errors.push(String(e)));
if(baseline){await p.goto(pathToFileURL(path.resolve(baseline)).href+'#blk-section_jump',{waitUntil:'domcontentloaded'});ck('基线顶栏使用 sticky',await p.locator('body > .topbar').evaluate(x=>getComputedStyle(x).position==='sticky'))}
await p.goto(pathToFileURL(path.resolve(site)).href+'#blk-section_jump',{waitUntil:'domcontentloaded'});
async function visit(id){await p.evaluate(id=>location.hash=id,id);await p.locator('#'+id+'.active').waitFor();await p.waitForTimeout(70)}
const header=p.locator('body > .topbar');
for(const width of [1440,1024])for(const font of ['misans','source-han-sans','source-han-serif'])for(const factor of [1,1.5]){
 const mode=[width,font,factor].join('-');await p.setViewportSize({width,height:1000});await visit('palette');await p.locator('#palette [data-font="'+font+'"]').click();await p.locator('#palette [data-type="'+(factor===1?'standard':'presentation')+'"]').click();await p.locator('#type-size-slider').evaluate((x,f)=>{x.value=String(f*100);x.dispatchEvent(new Event('input',{bubbles:true}))},factor);await p.evaluate(()=>document.fonts.ready);await visit('blk-section_jump');
 const layout=await header.evaluate(h=>({position:getComputedStyle(h).position,rect:h.getBoundingClientRect().toJSON(),space:parseFloat(getComputedStyle(document.body).paddingTop),root:getComputedStyle(document.documentElement).overscrollBehaviorY,body:getComputedStyle(document.body).overscrollBehaviorY,section:document.querySelector('.section.active').getBoundingClientRect().top,overflow:document.documentElement.scrollWidth>innerWidth+2}));
 ck('窗口固定与根回弹策略 '+mode,layout.position==='fixed'&&layout.rect.top===0&&layout.root==='none'&&layout.body==='none',layout);
 ck('正文留空且不被遮挡 '+mode,Math.abs(layout.space-layout.rect.height)<1&&layout.section>=layout.rect.bottom&&!layout.overflow,layout);
 for(const y of [350,1000,0]){await p.evaluate(y=>scrollTo({top:y,behavior:'instant'}),y);await p.waitForTimeout(40);ck('滚动后顶栏不移位 '+mode+' '+y,await header.evaluate(h=>Math.abs(h.getBoundingClientRect().top)<1))}
 await p.mouse.move(width-50,300);await p.mouse.wheel(0,-1800);await p.waitForTimeout(100);ck('向上滚轮后保持窗口顶部 '+mode,await header.evaluate(h=>h.getBoundingClientRect().top===0));
 await p.locator('#blk-section_jump [data-scroll=check]').click();await p.waitForTimeout(80);ck('分区定位避让固定顶栏 '+mode,await p.locator('#blk-section_jump [data-hw-anchor=check]').evaluate(t=>t.getBoundingClientRect().top>=document.querySelector('#blk-section_jump .hw-section-jump').getBoundingClientRect().bottom+20));
 if(width===1440&&font==='misans'&&factor===1)await p.screenshot({path:path.join(out,'固定顶栏与分区.png')});
}
await visit('shared-header');const embedded=p.locator('#shared-header .header-demo-row .topbar');ck('嵌入式页头演示仍在文档流',await embedded.evaluateAll(xs=>xs.length===2&&xs.every(x=>getComputedStyle(x).position==='static')));
await p.emulateMedia({media:'print'});ck('打印时去掉顶栏空白',await p.evaluate(()=>getComputedStyle(document.body).paddingTop==='0px'));await p.emulateMedia({media:'screen'});
await p.locator('body > .topbar #home-btn').click();ck('回封面不留顶部空白',await p.evaluate(()=>!document.body.classList.contains('viewing')&&getComputedStyle(document.body).paddingTop==='0px'));
await p.goto(pathToFileURL(path.resolve(path.dirname(site),'header-sales.html')).href,{waitUntil:'domcontentloaded'});ck('独立页头演示无固定栏空白',await p.locator('body > .topbar').evaluate(h=>getComputedStyle(h).position==='static'&&h.getBoundingClientRect().top===0&&getComputedStyle(document.body).paddingTop==='0px'));
ck('无脚本异常',errors.length===0,errors);
}finally{await browser.close();fs.writeFileSync(path.join(out,'report.json'),JSON.stringify({checks:results.length,failures:results.filter(x=>!x.ok).length,results,errors,physical_device_rubberbanding:'not tested'},null,2))}console.log('Fixed header checks passed: '+results.length)})().catch(e=>{console.error(e);process.exitCode=1});
