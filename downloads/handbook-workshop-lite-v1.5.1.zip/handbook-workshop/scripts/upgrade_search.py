"""为已生成的同引擎旧页追加全文搜索；另存完整副本，保留原稿与内容。"""
import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import shutil
import tempfile
import full_text_search
from prepare_resources import copy_resources

LEGACY = re.compile(r'// 搜索：过滤目录项并定位首个命中\s*\(function\(\)\{.*?\}\)\(\);', re.S)
LEGACY_SHA256 = '6fcaf9ce997ba89df259a1f4aa18a40398b37228ea718afd2c546ffea96e0135'
VOID = {'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr'}


class SearchBox(HTMLParser):
    def __init__(self, html):
        super().__init__(convert_charrefs=False)
        self.html, self.stack, self.matches = html, [], []
        self.lines = [0]
        self.lines += [m.end() for m in re.finditer('\n', html)]

    def source_offset(self):
        line, col = self.getpos()
        return self.lines[line - 1] + col

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        classes = attrs.get('class', '').split()
        in_header = any('topbar' in a.get('class', '').split() for _, a, _ in self.stack)
        in_demo = any('inert' in a or t == 'section' for t, a, _ in self.stack)
        mark = self.source_offset() if 'search-box' in classes and in_header and not in_demo else None
        if tag not in VOID:
            self.stack.append((tag, attrs, mark))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                for _, _, mark in self.stack[i:]:
                    if mark is not None:
                        self.matches.append((mark, self.html.index('>', self.source_offset()) + 1))
                del self.stack[i:]
                break

    def handle_startendtag(self, tag, attrs):
        pass


def patch(html):
    if 'id="handbook-common-script"' in html:
        raise ValueError("该页已有统一运行文件与全文搜索，请用 update_handbook.py 更新")
    if '// 全文搜索：按章节聚合' in html or 'id="handbook-full-text-search"' in html:
        raise ValueError('该页面已有全文搜索，无需重复追加。')
    if 'window.__showSection=show' not in html or 'class="section"' not in html:
        raise ValueError('未识别为网页手册工坊的章节手册，未修改。')
    old = list(LEGACY.finditer(html))
    if len(old) != 1 or hashlib.sha256(re.sub(r'\s+', '', old[0].group()).encode()).hexdigest() != LEGACY_SHA256:
        raise ValueError('旧搜索代码不是已识别版本，需单独核对，未修改。')
    parser = SearchBox(html)
    parser.feed(html)
    if len(parser.matches) != 1 or html.count('</head>') != 1 or html.count('</body>') != 1:
        raise ValueError('页头或文档结构不符合升级条件，未修改。')
    # Edits use the original offsets, from right to left. No document reserialization.
    a, b = parser.matches[0]
    edits = [(a, b, full_text_search.markup()), (old[0].start(), old[0].end(), '// 目录筛选已由全文搜索升级替换。')]
    for a, b, replacement in sorted(edits, reverse=True):
        html = html[:a] + replacement + html[b:]
    html = html.replace('</head>', '<style id="handbook-full-text-search-style">' + full_text_search.CSS + '</style></head>', 1)
    html = html.replace('</body>', '<script id="handbook-full-text-search">' + full_text_search.JS + '</script></body>', 1)
    return html


def upgrade(src, out):
    src, out = Path(src).resolve(), Path(out).resolve()
    if out.exists():
        raise FileExistsError('目标目录已存在；请指定新的升级副本目录。')
    if src.parent == out or src.parent in out.parents or out in src.parents:
        raise ValueError('升级副本须放在源项目之外。')
    original = src.read_bytes().decode('utf-8')
    updated = patch(original)  # Complete compatibility checks before copying or writing.
    out.parent.mkdir(parents=True, exist_ok=True)
    report = dict(feature='full-text-search',version='1.4.13',source_file=src.name,
                  original_untouched=True,source_runtime_updated=False,
                  changes=['替换旧目录筛选', '更新页头搜索控件', '追加全文搜索样式与脚本'],
                  preserved=['章节正文与顺序', '原有样式', '资料日期', '附件与图片相对路径', '原有其他交互'],
                  before_sha256=hashlib.sha256(original.encode()).hexdigest(),after_sha256=hashlib.sha256(updated.encode()).hexdigest())
    with tempfile.TemporaryDirectory(prefix='.handbook-search-upgrade-', dir=out.parent) as tmp:
        staging = Path(tmp) / 'copy'
        copy_resources(src.parent, staging, ignore=shutil.ignore_patterns('.DS_Store', '__pycache__', '.git'))
        (staging / src.name).write_bytes(updated.encode('utf-8'))
        (staging / '全文搜索升级报告.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        staging.rename(out)
    return out / src.name


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--src', required=True, help='旧手册 HTML')
    parser.add_argument('--out', required=True, help='新的升级副本目录')
    args = parser.parse_args()
    print(upgrade(args.src, args.out))
