"""Meaningful migration protection, preservation, repeated update and source rebuild tests."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import zipfile
from unittest.mock import patch
import handbook_core as h
import managed_runtime as m
import update_handbook as u

SCRIPT=Path(__file__).resolve().parent
PUBLISHED=Path(os.environ.get('HANDBOOK_HISTORY_DIR',str(SCRIPT.parent/'test-fixtures/history')))

def run_build(folder):
    result=subprocess.run([sys.executable,str(folder/'build.py')],capture_output=True,text=True)
    if result.returncode:raise AssertionError(result.stdout+'\n'+result.stderr)

class ManagedRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def new(self,name='input'):
        folder=self.root/name;folder.mkdir()
        sections=[dict(id='first',title='第一节',nav='第一节',blocks=[dict(t='text',v='正文不改 123。'),dict(t='faq',items=[dict(q='问题',answer='可复制回答')])]),dict(id='second',title='第二节',nav='第二节',blocks=[dict(t='text',v='第二节正文')])]
        html=h.build_html('项目','资料',dict(title='项目',desc='说明'),sections,config=dict(updated_at='2020-02-03',home_href=''))
        m.write_handbook(folder/'index.html',html)
        (folder/'assets/evidence.txt').write_text('附件原件')
        (folder/'assets/handbook-custom.css').write_text('.card { border-radius: 23px; }')
        return folder
    def old(self,version):
        folder=self.root/('old-'+version);folder.mkdir()
        if not (PUBLISHED/('handbook-workshop-full-v'+version+'.zip')).exists():self.skipTest('旧包验收需用 HANDBOOK_HISTORY_DIR 指定历史包目录')
        with zipfile.ZipFile(PUBLISHED/('handbook-workshop-full-v'+version+'.zip')) as z:
            html=z.read('handbook-workshop/design-gallery/index.html').decode().replace('../assets/fonts/','assets/fonts/')
        (folder/'index.html').write_text(html);(folder/'assets').mkdir();(folder/'assets/original.txt').write_text('资料原件')
        return folder
    def source_project(self):
        import ast
        p=self.root/'source-project';p.mkdir();(p/'runtime').mkdir()
        archive=PUBLISHED/'handbook-workshop-full-v1.4.14.zip'
        if not archive.exists():self.skipTest('源工程验收需指定历史包目录')
        with zipfile.ZipFile(archive) as z:
            for name in z.namelist():
                rel=name.removeprefix('handbook-workshop/')
                if rel.startswith('scripts/') and rel.endswith('.py'):
                    (p/'runtime'/Path(rel).name).write_bytes(z.read(name))
                if rel.startswith('assets/brand/') or rel in ('assets/base-style.json','assets/font-catalog.json') or rel.startswith('assets/fonts/MiSans'):
                    target=p/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
            for node in ast.parse(z.read('handbook-workshop/scripts/draft_handbook.py').decode()).body:
                if isinstance(node,ast.Assign) and getattr(node.targets[0],'id','')=='BUILD':(p/'build.py').write_text(ast.literal_eval(node.value))
        (p/'project-style.json').write_bytes((p/'assets/base-style.json').read_bytes())
        doc=dict(schema_version='2.0',source_sha256='f'*64,pages=[dict(page=1,items=[dict(id='text-1',kind='text',text='原始资料 123。')])])
        plan=dict(schema_version='1.0',source_sha256=doc['source_sha256'],config=dict(title='源工程验收',updated_at='2020-02-03',home_href=''),hero=dict(title='源工程验收'),sections=[dict(id='first',title='第一节',nav='第一节',blocks=[dict(t='text',v='原始资料 123。',source_refs=['text-1'])])])
        from draft_handbook import CONTENT_LOADER
        (p/'content.py').write_text(CONTENT_LOADER)
        (p/'source.json').write_text(json.dumps(doc,ensure_ascii=False));(p/'content.json').write_text(json.dumps(plan,ensure_ascii=False))
        run_build(p)
        return p
    def test_old_source_rebuild_remains_managed_and_keeps_date(self):
        p=self.source_project();before=(p/'content.json').read_bytes();out=self.root/'source-updated';report=u.update(p,out)
        self.assertEqual(report['source_projects'],['.']);self.assertEqual(before,(out/'content.json').read_bytes())
        run_build(out)
        self.assertIn('src="assets/handbook-runtime-',(out/'index.html').read_text());self.assertIn('2020-02-03',(out/'index.html').read_text())
        m.verify(out,m.read_manifest(out));u.update(out,self.root/'source-second-update')
    def test_modified_source_stops_and_html_only_is_explicit(self):
        p=self.source_project();(p/'runtime/handbook_core.py').write_text((p/'runtime/handbook_core.py').read_text()+'\n# project modification\n')
        with self.assertRaisesRegex(ValueError,'定制修改'):u.update(p,self.root/'bad-source')
        self.assertFalse((self.root/'bad-source').exists());report=u.update(p,self.root/'html-only',html_only=True);self.assertEqual(report['mode'],'html-only')
    def test_palette_update_reuses_existing_full_font_offline(self):
        p=self.source_project();style=self.root/'palette-only.json';style.write_text('{"palette":"forest"}')
        with patch('prepare_resources.font_source',side_effect=AssertionError('已有完整字体时不应下载')):
            u.update(p,self.root/'offline-palette',style=style)
    def test_visual_change_survives_source_rebuild(self):
        p=self.source_project();style=self.root/'source-style.json';style.write_text(json.dumps(dict(palette='forest',type_scale='compact',theme={'--radius':'19px'})))
        out=self.root/'source-styled';u.update(p,out,style=style);run_build(out)
        data=m.read_manifest(out);css=(out/data['pages']['index.html']['theme_file']).read_text();self.assertIn('#28715A',css);self.assertIn('--radius:19px',css)
    def test_native_separates_assets_and_uses_local_urls(self):
        p=self.new();s=(p/'index.html').read_text();data=m.read_manifest(p);m.verify(p,data)
        self.assertNotIn('window.__showSection=show',s);self.assertIn('src="assets/handbook-runtime-',s)
        self.assertNotIn('assets/assets/fonts',(p/'assets/handbook-runtime.css').read_text())
        self.assertIn('../assets/fonts/',(p/'assets/handbook-runtime.css').read_text())
        self.assertNotIn('fetch(',s);self.assertEqual(data['content_schema'],1)
    def test_update_preserves_body_date_assets_and_project_overrides(self):
        p=self.new();before=(p/'index.html').read_bytes();out=self.root/'result';u.update(p,out)
        self.assertEqual(before,(p/'index.html').read_bytes());self.assertEqual(m.content_fingerprint(before.decode()),m.content_fingerprint((out/'index.html').read_text()))
        for name in ('assets/evidence.txt','assets/handbook-custom.css'):self.assertEqual((p/name).read_bytes(),(out/name).read_bytes())
    def test_future_runtime_updates_without_regenerating_content(self):
        p=self.new();before=m.content_fingerprint((p/'index.html').read_text());base=m.payload
        def future(*args,**kwargs):
            files=base(*args,**kwargs);files['assets/handbook-runtime.js']+='\nwindow.futureRuntimeProof=1;';return files
        with patch.object(m,'VERSION','1.5.1-test'),patch.object(m,'payload',future):u.update(p,self.root/'future')
        out=self.root/'future';self.assertIn('futureRuntimeProof',(out/'assets/handbook-runtime.js').read_text());self.assertEqual(before,m.content_fingerprint((out/'index.html').read_text()))
        self.assertEqual(m.read_manifest(out)['runtime_version'],'1.5.1-test')
    def test_old_cached_html_keeps_its_immutable_runtime_after_update(self):
        p=self.new();old=(p/'index.html').read_text();tag=next(t for t in m.Tags(old).tags if t['attrs'].get('id')==m.COMMON_SCRIPT);ref=tag['attrs']['src'];data=(p/ref).read_bytes();base=m.payload
        def future(*args,**kwargs):
            files=base(*args,**kwargs);files['assets/handbook-runtime.js']+='\nwindow.proofOfNewVersion=1;';return files
        with patch.object(m,'VERSION','1.5.1-test'),patch.object(m,'payload',future):u.update(p,self.root/'pinned-future')
        out=self.root/'pinned-future';self.assertEqual(data,(out/ref).read_bytes());self.assertNotIn(ref,(out/'index.html').read_text())
    def test_repeated_update_has_one_runtime_reference(self):
        p=self.new();u.update(p,self.root/'one');u.update(self.root/'one',self.root/'two')
        self.assertEqual((self.root/'two/index.html').read_text().count('id="handbook-common-script"'),1)
    def test_multi_page_shared_runtime_is_updated_together(self):
        p=self.new();m.write_handbook(p/'other.html',h.build_html('另一页','',dict(title='另一页'),[dict(id='x',title='内容',nav='内容',blocks=[dict(t='text',v='另外正文')])]))
        (p/'unrelated.html').write_text('<h1>独立网页</h1>');report=u.update(p,self.root/'multi')
        self.assertEqual(len(report['pages']),2);self.assertIn('unrelated.html',report['ignored_pages'])
        with self.assertRaisesRegex(ValueError,'多页共用'):u.update(p/'index.html',self.root/'single')
    def test_batch_nested_manuals(self):
        root=self.root/'collection';root.mkdir();a=self.new('a');b=self.new('b');c=self.new('c');shutil.move(str(a),root/'a');shutil.move(str(b),root/'b');shutil.move(str(c),root/'c')
        report=u.update(root,self.root/'collection-new');self.assertEqual(len(report['pages']),3)
    def test_theme_update_preserves_material_date(self):
        p=self.new();style=self.root/'style.json';style.write_text(json.dumps(dict(palette='forest',shell_mode='dark',type_scale='compact',theme={'--radius':'18px'},updated_at='2099-01-01')))
        u.update(p,self.root/'theme',style=style);out=self.root/'theme';data=m.read_manifest(out);css=(out/data['pages']['index.html']['theme_file']).read_text();html=(out/'index.html').read_text()
        self.assertIn('#28715A',css);self.assertIn('--radius:18px',css);self.assertIn('2020-02-03',html);self.assertNotIn('2099',html);self.assertIn('data-shell="dark"',html)
    def test_public_runtime_tamper_stops_before_copy(self):
        p=self.new();(p/'assets/handbook-runtime.js').write_text('custom code')
        with self.assertRaisesRegex(ValueError,'被修改'):u.update(p,self.root/'bad')
        self.assertFalse((self.root/'bad').exists())
    def test_theme_tamper_stops(self):
        p=self.new();data=m.read_manifest(p);(p/data['pages']['index.html']['theme_file']).write_text(':root{}')
        with self.assertRaisesRegex(ValueError,'主题文件'):u.update(p,self.root/'bad')
    def test_older_tool_will_not_downgrade_a_newer_project(self):
        p=self.new();data=m.read_manifest(p);data['runtime_version']='1.6.0';(p/m.MANIFEST).write_text(json.dumps(data))
        with self.assertRaisesRegex(ValueError,'版本高于'):u.update(p,self.root/'downgrade')
        self.assertFalse((self.root/'downgrade').exists())
    def test_unknown_api_stops(self):
        p=self.new();data=m.read_manifest(p);data['api']=99;(p/m.MANIFEST).write_text(json.dumps(data))
        with self.assertRaisesRegex(ValueError,'不兼容'):u.update(p,self.root/'bad')
    def test_unsafe_manifest_path_stops(self):
        p=self.new();data=m.read_manifest(p);data['files']['../outside']='x';(p/m.MANIFEST).write_text(json.dumps(data))
        with self.assertRaises(ValueError):u.update(p,self.root/'bad')
    def test_changed_reference_and_duplicate_inline_handlers_stop(self):
        for kind in ('ref','duplicate'):
            p=self.new(kind);s=(p/'index.html').read_text()
            s=s.replace('src="assets/handbook-runtime-','src="https://example.invalid/x') if kind=='ref' else s.replace('</body>','<script>window.__showSection=show</script></body>')
            (p/'index.html').write_text(s)
            with self.assertRaises(ValueError):u.update(p,self.root/(kind+'-bad'))
    def test_symbolic_link_stops(self):
        p=self.new();(p/'assets/link').symlink_to('/tmp')
        with self.assertRaisesRegex(ValueError,'符号链接'):u.update(p,self.root/'bad')
    def test_in_place_and_existing_outputs_stop(self):
        p=self.new()
        for out in (p,p/'nested',self.root):
            with self.assertRaises((ValueError,FileExistsError)):u.update(p,out)
    def test_old_appended_design_is_migrated_and_not_duplicated(self):
        from apply_design import apply
        p=self.old('1.4.14');styled=self.root/'styled';apply(p/'index.html',styled,palette='forest')
        out=self.root/'styled-updated';u.update(styled,out)
        self.assertNotIn('handbook-design-v11',(out/'index.html').read_text());data=m.read_manifest(out)
        self.assertIn('#28715A',(out/data['pages']['index.html']['theme_file']).read_text())
    def test_unknown_legacy_code_stops(self):
        p=self.old('1.4.14');s=(p/'index.html').read_text().replace('window.__showSection=show','window.__showSection=show;window.myCustomCode=1');(p/'index.html').write_text(s)
        with self.assertRaises(ValueError):u.update(p,self.root/'bad')
    def test_legacy_versions_migrate_with_main_content_preserved(self):
        for version in ('1.4.6','1.4.11','1.4.14'):
            p=self.old(version);before=m.content_fingerprint((p/'index.html').read_text());out=self.root/('new-'+version);u.update(p,out)
            self.assertEqual(before,m.content_fingerprint((out/'index.html').read_text()));self.assertIn('class="search-results"',(out/'index.html').read_text());m.verify(out,m.read_manifest(out))
    def test_inspect_is_read_only(self):
        p=self.new();before={x.relative_to(p):m.sha(x.read_bytes()) for x in p.rglob('*') if x.is_file()};report=u.update(p,inspect=True)
        self.assertTrue(report['compatible']);self.assertEqual(before,{x.relative_to(p):m.sha(x.read_bytes()) for x in p.rglob('*') if x.is_file()})
    def test_explicit_custom_css_replacement(self):
        p=self.new();custom=self.root/'custom.css';custom.write_text('.section { padding: 32px; }');u.update(p,self.root/'custom-new',custom_css=custom)
        self.assertEqual(custom.read_text(),(self.root/'custom-new/assets/handbook-custom.css').read_text())
    def test_malformed_theme_is_rejected_without_output(self):
        p=self.new();style=self.root/'bad-style.json';style.write_text(json.dumps({'theme':{'--text':'red;}body{display:none'}}))
        with self.assertRaises(ValueError):u.update(p,self.root/'bad',style=style)
        self.assertFalse((self.root/'bad').exists())

if __name__=='__main__':unittest.main()
