"""本地公共功能与视觉文件：固定版本、逐页主题、项目覆盖、可核对清单。"""
import hashlib
from html.parser import HTMLParser
from html import escape
import json
from pathlib import Path
import re
from urllib.parse import urlsplit

VERSION = '1.5.1'
API = 1
MANIFEST = 'handbook-runtime.json'
COMMON_STYLE = 'handbook-common-style'
COMMON_SCRIPT = 'handbook-common-script'
THEME_STYLE = 'handbook-theme-style'
STYLE_KEYS = ('palette','shell_mode','font_family','type_scale','type_scale_factor','logo_header_height','logo_cover_height','style_preset','theme')
RUNTIME_FILES = ('handbook_core.py','share_card.py','design_tokens.py','cover_design.py','desktop_gate.py','gallery_layouts.py','portal_layout.py','typography_rules.py','china_map.py','content_extensions.py','data_views.py','full_text_search.py','navigation_media.py','section_navigation.py','font_catalog.py','prepare_resources.py','lint_content.py','audit_sources.py','managed_runtime.py')


def version_tuple(value):
    match=re.fullmatch(r"(\d+)\.(\d+)\.(\d+)(?:-[A-Za-z0-9.-]+)?",str(value))
    if not match:raise ValueError("版本号格式无效")
    return tuple(map(int,match.groups()))


def sha(value):
    return hashlib.sha256(value.encode() if isinstance(value,str) else value).hexdigest()


class Tags(HTMLParser):
    """Capture raw offsets; never reserialize business HTML."""
    def __init__(self, html):
        super().__init__(convert_charrefs=False)
        self.html=html;self.rows=[0]+[m.end() for m in re.finditer('\n',html)];self.open=[];self.tags=[]
        self.feed(html)
    def pos(self):
        line,col=self.getpos();return self.rows[line-1]+col
    def handle_starttag(self,tag,attrs):
        a=self.pos();b=a+len(self.get_starttag_text());attrs=dict(attrs)
        if tag in ('style','script'):
            self.open.append((tag,attrs,a,b))
        elif tag in ('link','meta'):
            self.tags.append(dict(tag=tag,attrs=attrs,a=a,b=b,body='',inner_a=b,inner_b=b))
    def handle_endtag(self,tag):
        if self.open and self.open[-1][0]==tag:
            name,attrs,a,inner_a=self.open.pop();inner_b=self.pos();b=self.html.index('>',inner_b)+1
            self.tags.append(dict(tag=name,attrs=attrs,a=a,b=b,body=self.html[inner_a:inner_b],inner_a=inner_a,inner_b=inner_b))


def edit(html,changes):
    changes=sorted(changes,reverse=True)
    last=len(html)
    for a,b,value in changes:
        if b>last:raise ValueError('更新位置重叠，未修改')
        html=html[:a]+value+html[b:];last=a
    return html


def rebase_css(css):
    def replace(m):
        value=m[2]
        if not value or value.startswith(('#','/')) or urlsplit(value).scheme:return m[0]
        return 'url('+m[1]+('../'+value)+m[1]+')'
    return re.sub(r'url\(\s*([\'\"]?)([^)\'\"]+)\1\s*\)',replace,css)


def payload(preset='apple',font_prefix='assets/fonts/'):
    import handbook_core as h
    css=h.CSS+('' if preset=='classic' else h.APPLE_BASE_CSS)+h.cover_design.SKIN_CSS+h.cover_design.CSS
    js=h.desktop_gate.JS+h.JS+h.cover_design.JS+h.gallery_layouts.JS+h.china_map.JS+h.data_views.JS+h.navigation_media.JS
    js='/* Handbook runtime '+VERSION+'; API '+str(API)+' */\n(()=>{if(window.HandbookRuntime)return;window.HandbookRuntime=Object.freeze('+json.dumps(dict(version=VERSION,api=API))+');\n'+js+'\n})();\n'
    return {'assets/handbook-runtime.css':rebase_css(css.replace('assets/fonts/',font_prefix)),'assets/handbook-runtime.js':js}


def safe_path(root,relative):
    p=Path(relative)
    if p.is_absolute() or '..' in p.parts or not p.parts:raise ValueError('运行文件路径不符合约定')
    target=root/p
    if not target.resolve().is_relative_to(root.resolve()):raise ValueError('运行文件路径越出项目目录')
    return target


def asset_ref(relative,digest):
    path=Path(relative)
    return path.with_name(path.stem+'-'+digest[:16]+path.suffix).as_posix()


def write_asset(folder,relative,value):
    target=safe_path(folder,relative);target.parent.mkdir(parents=True,exist_ok=True)
    frozen=safe_path(folder,asset_ref(relative,sha(value)))
    if frozen.exists() and frozen.read_text()!=value:raise ValueError('固定版本资源同名但内容不同，未覆盖')
    frozen.write_text(value);target.write_text(value)


def read_manifest(folder):
    p=folder/MANIFEST
    if not p.exists():return None
    if p.is_symlink():raise ValueError('清单不能是符号链接')
    data=json.loads(p.read_text())
    if data.get('schema')!=1 or data.get('api')!=API or data.get('content_schema')!=1:
        raise ValueError('运行接口或内容结构版本不兼容，须单独迁移')
    if not re.fullmatch(r'(?:\.\./)*assets/fonts/',data.get('font_prefix','assets/fonts/')):raise ValueError('字体资源前缀不符合约定')
    return data


def verify(folder,data):
    for rel,digest in data['files'].items():
        p=safe_path(folder,rel)
        if p.is_symlink() or not p.is_file() or sha(p.read_bytes())!=digest:
            raise ValueError('公共运行文件被修改或缺失：'+rel+'；先把项目调整移到 handbook-custom.css')
        frozen=safe_path(folder,asset_ref(rel,digest))
        if not frozen.is_file() or sha(frozen.read_bytes())!=digest:raise ValueError('固定版本运行文件缺失或被修改：'+rel)
    for name,record in data['pages'].items():
        safe_path(folder,name)
        for key in ('theme_file','style_file'):
            safe_path(folder,record[key])
        for key in ('theme_file','style_file'):
            p=folder/record[key]
            if not p.is_file() or sha(p.read_bytes())!=record[key+'_sha256']:
                raise ValueError('主题文件被手动修改：'+record[key]+'；请通过样式配置更新或使用 handbook-custom.css')
        for rel,digest in ((record['theme_file'],record['theme_file_sha256']),('assets/handbook-custom.css',record['custom_sha256'])):
            frozen=safe_path(folder,asset_ref(rel,digest))
            if not frozen.is_file() or sha(frozen.read_bytes())!=digest:raise ValueError('固定版本主题或覆盖文件缺失：'+rel)


def style_config(cfg):
    from design_tokens import tokens
    import font_catalog
    base={**tokens(cfg),**font_catalog.tokens(cfg.get('font_family','misans'))}
    data={k:cfg[k] for k in STYLE_KEYS if k in cfg and k!='theme'}
    data['theme']={k:v for k,v in cfg.get('theme',{}).items() if base.get(k)!=v}
    return data


def validate_style(data):
    from design_tokens import tokens
    import font_catalog
    values={k:data[k] for k in STYLE_KEYS if k in data}
    if values.get('style_preset','apple') not in ('apple','classic'):raise ValueError('未知视觉基线')
    theme=values.get('theme',{})
    if not isinstance(theme,dict):raise ValueError('theme 必须为对象')
    for key,value in theme.items():
        if not re.fullmatch(r'--[a-zA-Z0-9_-]+',key) or not isinstance(value,str) or re.search(r'[{};<>]|url\s*\(|@|expression\s*\(',value,re.I):
            raise ValueError('无效的主题变量：'+str(key))
    tokens(values);font_catalog.tokens(values.get('font_family','misans'))
    return values


def theme_css(cfg):
    from design_tokens import tokens
    import font_catalog
    cfg=validate_style(cfg)
    return ':root{'+''.join(k+':'+str(v)+';' for k,v in {**tokens(cfg),**font_catalog.tokens(cfg.get('font_family','misans')),**cfg.get('theme',{})}.items())+'}'


def content_fingerprint(html):
    main=re.search(r'<main\b[^>]*>.*?</main>',html,re.S)
    dates=re.findall(r'<(?:span|div)\b[^>]*class="(?:credit-date|design-credit)"[^>]*>.*?</(?:span|div)>',html,re.S)
    return sha((main[0] if main else '')+'\n'+''.join(dates))


def managed_refs(html,filename,theme_file,files):
    styles=Tags(html).tags
    expected={COMMON_STYLE:('link','assets/handbook-runtime.css'),THEME_STYLE:('link',theme_file),COMMON_SCRIPT:('script','assets/handbook-runtime.js')}
    changes=[]
    for id,(tag,rel) in expected.items():
        found=[t for t in styles if t['attrs'].get('id')==id]
        if len(found)!=1:raise ValueError('缺少或重复的运行引用：'+id)
        url=escape(asset_ref(rel,sha(files[rel])),quote=True)
        markup='<link id="'+id+'" rel="stylesheet" href="'+url+'">' if tag=='link' else '<script id="'+id+'" src="'+url+'"></script>'
        changes.append((found[0]['a'],found[0]['b'],markup))
    return edit(html,changes)


def write_handbook(path,html,font_prefix=None):
    """New builders emit marked inline HTML; this writes a portable managed page."""
    path=Path(path);folder=path.parent;folder.mkdir(parents=True,exist_ok=True)
    tags=Tags(html).tags
    def one(id):
        matches=[t for t in tags if t['attrs'].get('id')==id]
        if len(matches)!=1:raise ValueError('生成器缺少运行标识：'+id)
        return matches[0]
    config=json.loads(one('handbook-style-config')['body'])
    theme=one(THEME_STYLE)['body']
    key=sha(path.name)[:12];theme_file='assets/handbook-theme-'+key+'.css';style_file='assets/handbook-style-'+key+'.json'
    manifest=read_manifest(folder)
    font_prefix=font_prefix or (manifest or {}).get('font_prefix','assets/fonts/')
    files=payload(config.get('style_preset','apple'),font_prefix);files[theme_file]=rebase_css(theme)
    if manifest:
        verify(folder,manifest)
        if version_tuple(manifest['runtime_version'])>version_tuple(VERSION):raise ValueError("页面版本高于构建器，请先更新源工程")
    manifest=manifest or dict(schema=1,api=API,content_schema=1,pages={},files={})
    if manifest['pages'] and manifest.get('style_preset',config.get('style_preset','apple'))!=config.get('style_preset','apple'):
        raise ValueError('同目录须使用相同视觉基线')
    html=managed_refs(html,path.name,theme_file,files)
    config_tag=one('handbook-style-config')
    # The config is stored separately; no fetch is needed for file:// readers.
    html=re.sub(r'<script id="handbook-style-config" type="application/json">.*?</script>','',html,count=1,flags=re.S)
    if 'id="handbook-custom-style"' not in html:
        html=html.replace('</head>','<link id="handbook-custom-style" rel="stylesheet" href="assets/handbook-custom.css"></head>',1)
    for rel,value in files.items():
        write_asset(folder,rel,value)
    custom=folder/'assets/handbook-custom.css'
    if not custom.exists():custom.write_text('/* 项目单独调整的样式写在这里；统一更新保留此文件。 */\n')
    write_asset(folder,'assets/handbook-custom.css',custom.read_text())
    html=custom_ref(html,custom.read_text())
    style_text=json.dumps(config,ensure_ascii=False,indent=2)+'\n';(folder/style_file).write_text(style_text)
    manifest.update(runtime_version=VERSION,style_preset=config.get('style_preset','apple'),font_prefix=font_prefix)
    manifest['files']={rel:sha(value) for rel,value in files.items() if rel!=theme_file}
    manifest['pages'][path.name]=dict(theme_file=theme_file,theme_file_sha256=sha(files[theme_file]),style_file=style_file,style_file_sha256=sha(style_text),custom_sha256=sha(custom.read_text()),content_sha256=content_fingerprint(html))
    (folder/MANIFEST).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    path.write_text(html,encoding='utf-8')
    return path


def relocate_fonts(folder,font_prefix):
    """Full embeds its gallery next to the shared font directory."""
    folder=Path(folder);data=read_manifest(folder);verify(folder,data)
    files=payload(data.get('style_preset','apple'),font_prefix)
    for rel,value in files.items():write_asset(folder,rel,value)
    for name,record in data['pages'].items():
        theme=(folder/record['theme_file']).read_text();assets={**files,record['theme_file']:theme}
        html=managed_refs((folder/name).read_text(),name,record['theme_file'],assets)
        (folder/name).write_text(html)
        record['content_sha256']=content_fingerprint(html)
    data['files']={rel:sha(value) for rel,value in files.items()};data['font_prefix']=font_prefix
    (folder/MANIFEST).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')


def custom_ref(html,css):
    matches=[t for t in Tags(html).tags if t['attrs'].get('id')=='handbook-custom-style']
    if len(matches)!=1:raise ValueError('项目覆盖样式引用重复或缺失')
    t=matches[0]
    return edit(html,[(t['a'],t['b'],'<link id="handbook-custom-style" rel="stylesheet" href="'+asset_ref('assets/handbook-custom.css',sha(css))+'">')])
