# 项目字体选项

同一系列在 `project-style.json` 选择一款正文字体，标题、正文和控件沿用统一字体层级。默认 `font_family:"misans"`；可选 `source-han-sans`（思源黑体）和 `source-han-serif`（思源宋体）。字体与色系、深浅外框、三档字号及自定义微调独立，不逐页混用。字号微调用 `type_scale_factor` 保存，不通过改变字体字重冒充放大。

在样式库「配色、字体与字号」切换后预览整本效果，再下载配置。预览须等所选字体实际加载成功才切换；失败会明确提示并保持原字体。配置导出的是实际生效的字体，不把加载失败的选项当成成功。

思源黑体与思源宋体来自 Adobe 官方仓库的 SC 完整语言版变量字体（WOFF2），不是自行抽取常用汉字的子集。字库版本、官方来源、原文件大小和 SHA-256 记录在 `assets/font-catalog.json`；不删字，不重命名字体内部名称，不以本机同名字体代替交付资源。授权文本与字体随产物保留。

Lite 包不包含三款大字库。首次构建只准备项目选中的一款：`python scripts/prepare_resources.py --font source-han-serif`。字体按资源清单下载、校验并缓存，出错停止，不静默换系统字体；也可加 `--font-file 官方原文件路径` 离线提供与清单一致的文件。字体文件通过 HTTPS 下载，不执行远端代码，不上传用户资料。

正式生成的手册只携带所选字体及授权文件，可独立离线查看和重新构建。Full 包与离线样式库包含全部三款，方便断网选择。Lite 包仍按 5,242,880 字节上限验收；实际 WorkBuddy 云端能否联网与持续缓存仍需在其环境验证。

按字体和栏目角色校准字重，不统一加粗。MiSans 沿用原基准；两款思源字体使用完整变量字体的真实字重，角色表由 `scripts/font_catalog.py` 统一提供，预览、生成和旧页样式应用共用。

| 文字角色 | 思源黑体 | 思源宋体 |
|---|---:|---:|
| 章节、封面标题 | 650 | 700 |
| 段内标题 | 600 | 650 |
| 卡片、问答、折叠分组标题 | 600 | 650 |
| 目录分类 | 600 | 600 |
| 按钮、当前目录项、导语与引语 | 550 | 600 |
| 表头、语义强调 | 600 | 650 |
| 正文、表格内容、普通目录项 | 450 | 450 |
| 辅助说明 | 400 | 450 |
| 数字指标 | 700 | 700 |

选中与展开状态不临时改变卡片标题字重，避免版面跳动。字号、间距、卡片结构与交互不因换字体重新设计；检查长标题、表格、问答、底栏和 200% 文字放大，不能靠缩小文字或裁切内容掩盖问题。

只调整字体沿用资料原更新日期。生成业务读者页面不添加样式库版本号或设计者。已有项目优先用 `update_handbook.py --style 样式配置.json` 另存副本，配置中选择 `font_family:"source-han-serif"`。未请求字体变化时沿用项目选型。`apply_design.py --font` 仅保留给旧内联页的限定验证，不能用于统一运行页。

官方来源与授权：

- 思源黑体：https://github.com/adobe-fonts/source-han-sans ，授权 https://github.com/adobe-fonts/source-han-sans/blob/master/LICENSE.txt
- 思源宋体：https://github.com/adobe-fonts/source-han-serif ，授权 https://github.com/adobe-fonts/source-han-serif/blob/master/LICENSE.txt
