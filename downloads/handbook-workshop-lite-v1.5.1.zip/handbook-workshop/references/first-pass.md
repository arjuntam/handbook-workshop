> v1.3.0 当前规范以 gallery-and-portal.md 为准：统一两级目录，十个色系各有深浅模式，固定 MiSans 与品牌标识，更新日期默认显示且可关闭；手机和平板均拦截。

# 首版生成与来源核对

## 运行条件与实际范围

Python 3.10+、`python-pptx`。样式库重建另需 Pillow；本地 HTML 浏览不需这些依赖。浏览器检查需要 Node.js、playwright-core 和可用浏览器，可通过 `PW_MODULE` / `EDGE` 指定。

本次新链路支持单份 PPTX 的 v2 提取清单。Word 提取工具保留，但未接入此自动骨架。多个来源文件需 Agent 分别提取并规划，目前不要把多个文件的局部 ID 直接混为同一来源。

## 最短可运行路径

以下路径均由实际项目位置替换，脚本位于技能包 scripts/。

```sh
python3 scripts/extract_pptx.py --src 原稿.pptx --out 提取-v1
python3 scripts/draft_handbook.py --source 提取-v1/原稿.json --out 手册-v1 --name 门店工作手册
python3 手册-v1/build.py
node scripts/verify_layout.js 手册-v1/index.html 手册-v1/版式检查
```

自动骨架保留按原页组织的原文，长文拆段、图片独立、表格按八行分段。这是能构建的保守工作底稿，不是已经完成的语义手册。复杂对象和备注集中进入 `reviews`，不会被声称已经转换。

语义重组时，复制 `content.json` 为 `plan-v2.json`，按页面组合修改 sections，保留 `source_refs` 与原稿指纹，然后生成新目录：

```sh
python3 scripts/draft_handbook.py --source 提取-v1/原稿.json --plan plan-v2.json --out 手册-v2
python3 手册-v2/build.py
```

已有生成项目内直接编辑 `content.json` 后可重跑 `build.py`。引擎文件已复制到 `runtime/`，移动交付目录仍可构建，不依赖原电脑技能位置。V1.5.0 构建器通过 `write_handbook` 输出独立功能与样式文件；旧项目升级用统一更新工具并同步源工程，不能只手换一个核心文件。保留前版后再开始大修改；不手改 index.html。

## 文件职责

- `project-style.json`：手册随附的视觉快照；构建时优先使用父目录同名共用配置。
- `source.json`：提取清单快照、对象 ID、源文件指纹及提取局限。
- `content.json`：内容、来源引用及待处理项的编辑入口；系列视觉统一读取 `project-style.json`。
- `content.py`：兼容旧内容检查器的加载器，不手工填另一份内容。
- `build.py`：先检查，再构建；硬错误阻止覆盖上一份 HTML。
- `来源映射.tsv`：对象、原页与章节对应关系，每次构建后更新。
- `检查报告.json`：当前来源检查结果。
- `版式检查/`：浏览器测量报告与截图，由独立命令生成。

## JSON 结构

`schema_version / route / source_sha256 / config / hero / sections / attachments / xref / reviews / exclusions / transformations`。

章节字段沿用 content-model.md。每个 block 可加 `source_refs:["p002-s3"]`；章节上同名字段只指向章节标题等自身字段，不把整章所有文字都当作标题对象的证据。ID 来自实际提取结果，不能凭示例编号编造。

新增通用表格：

```json
{
  "t": "table",
  "caption": "原始数据表",
  "head": ["对象", "数量", "单位"],
  "rows": [["示例", "12", "项"]],
  "source_refs": ["p003-s4"]
}
```

`head` 可省略；不能未经确认就把首行当表头。保守生成器把所有行保留为 rows，不丢列、不把多列表硬套五列 roster；合并单元格平铺后仍需核对语义。

`pick.items` 新增 `disabled:true`，块上 `default:-1` 表示初始未选。卡片默认只显示文字；有图或独立动作时使用 grid + 明确按钮，避免在整卡选择控件里嵌套操作。

## 排除、待处理、改写

- `exclusions:[{"ref":"实际对象ID","reason":"对照原页后确认为重复装饰，不进入读者正文"}]`：明确记录排除依据；不得用笼统“无用”掩盖缺失。
- `reviews:[{"ref":"实际对象ID","reason":"图表关系需对照原页","status":"pending"}]`：仍需处理。初稿可以构建，但报告必须保留未解决状态。处理完后从 reviews 移除。
- `transformations:[{"ref":"实际对象ID","reason":"从原表重组为分工卡，保留所有字段，需核对"}]`：解释改写或结构重组。这里只改变硬错误为复核提醒，不是自动证明内容正确。

## 检查的边界

来源检查能发现：对象没有去向、指纹冲突、虚构 ID、映射却漏原文、图片引用/素材缺失、表格单元格丢失。相同对象分成多个块可合并核对；不以引用数量或“覆盖率 100%”冒充转换质量。

它不能证明：母版元素已提取、图片中文字已识别、图表/箭头关系已理解、改写等价、读者逻辑合适。PPT 母版/背景/动画/超链接/嵌入文件等提取边界会始终出现在报告中；需整页比对。演讲者备注不自动进入对外正文。

`audit_sources.py 项目 --strict` 会对所有待复核提醒返回非零；默认模式只把硬错误作为失败。报告状态保守为 `review-required`，不是“正式成稿”。

浏览器检查遍历所有章节及标签面板，在桌面、1024px 电脑窗口、390px 手机拦截和模拟 200% 根字号下测横溢、破图、裁字、翻页按钮并截图。模拟文字放大不是真实 OS 设置，也不是 Windows/iPad/微信实机结果。复杂交互、原稿核对、视觉与业务验收需单独记录。
